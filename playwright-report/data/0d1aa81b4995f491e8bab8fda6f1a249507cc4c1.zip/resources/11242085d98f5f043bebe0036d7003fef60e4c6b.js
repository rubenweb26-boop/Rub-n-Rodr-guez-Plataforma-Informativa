import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/node_modules/vinext/dist/server/app-browser-entry.js?v=b41becdd");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "__vite_rsc_build__": false};const Fragment = __vite__cjsImport47_react["Fragment"]; const createElement = __vite__cjsImport47_react["createElement"]; const startTransition = __vite__cjsImport47_react["startTransition"]; const use = __vite__cjsImport47_react["use"]; const useEffect = __vite__cjsImport47_react["useEffect"]; const useLayoutEffect = __vite__cjsImport47_react["useLayoutEffect"]; const useMemo = __vite__cjsImport47_react["useMemo"]; const useRef = __vite__cjsImport47_react["useRef"]; const useState = __vite__cjsImport47_react["useState"];const createRoot = __vite__cjsImport48_reactDom_client["createRoot"]; const hydrateRoot = __vite__cjsImport48_reactDom_client["hydrateRoot"];const flushSync = __vite__cjsImport50_reactDom["flushSync"];import { addBasePathToPathname, stripBasePath } from "/node_modules/vinext/dist/utils/base-path.js?v=b41becdd";
import { VINEXT_MOUNTED_LAYOUTS_HEADER, VINEXT_PARAMS_HEADER, VINEXT_RENDERED_PATH_AND_SEARCH_HEADER, VINEXT_RSC_REDIRECT_HEADER, VINEXT_RSC_REDIRECT_TYPE_HEADER } from "/node_modules/vinext/dist/server/headers.js?v=b41becdd";
import { splitPathnameForRouteMatch } from "/node_modules/vinext/dist/routing/utils.js?v=b41becdd";
import { AppRouterContext } from "/node_modules/vinext/dist/shims/internal/app-router-context.js?v=b41becdd";
import { matchRoutePattern } from "/node_modules/vinext/dist/routing/route-pattern.js?v=b41becdd";
import { installWindowNext, setWindowNextInternalSourcePage } from "/node_modules/vinext/dist/client/window-next.js?v=b41becdd";
import { retryScrollTo, scrollToHashTargetOnNextFrame } from "/node_modules/vinext/dist/shims/hash-scroll.js?v=b41becdd";
import { VINEXT_RSC_COMPATIBILITY_ID_HEADER, VINEXT_RSC_CONTENT_TYPE, createRscRequestHeaders, createRscRequestUrl, formatRscRequestPath, isRscCompatibilityIdCompatible } from "/node_modules/vinext/dist/server/app-rsc-cache-busting.js?v=b41becdd";
import { clearAppNavigationFailureTarget, installAppNavigationFailureListeners } from "/node_modules/vinext/dist/client/app-nav-failure-handler.js?v=b41becdd";
import { notifyAppRouterTransitionStart } from "/node_modules/vinext/dist/client/instrumentation-client-state.js?v=b41becdd";
import "/node_modules/vinext/dist/client/instrumentation-client.js?v=b41becdd";
import { createNavigationRuntimeRouteManifestLoader, getNavigationRuntime, loadNavigationRuntimeRouteManifest, registerNavigationRuntimeBootstrap, registerNavigationRuntimeFunctions } from "/node_modules/vinext/dist/client/navigation-runtime.js?v=b41becdd";
import { AppElementsWire } from "/node_modules/vinext/dist/server/app-elements-wire.js?v=b41becdd";
import { getMountedSlotIdsHeader, resolveVisitedResponseInterceptionContext } from "/node_modules/vinext/dist/server/app-elements.js?v=b41becdd";
import { createBfcacheSegmentIdentityMap, createInitialBfcacheIdMap } from "/node_modules/vinext/dist/server/app-bfcache-identity.js?v=b41becdd";
import { createDiscardedServerActionRefreshScheduler, createServerActionInitiationSnapshot, resolveServerActionOperationLane } from "/node_modules/vinext/dist/server/app-browser-action-result.js?v=b41becdd";
import { resolveManifestNavigationInterceptionContext, resolveMiddlewareRewriteNavigationInterceptionContext } from "/node_modules/vinext/dist/server/app-browser-interception-context.js?v=b41becdd";
import { isExternalHistoryState, readHistoryStateActiveRoutePaths, readHistoryStatePreviousNextUrl, resolveActiveRoutePaths } from "/node_modules/vinext/dist/server/app-history-state.js?v=b41becdd";
import { AppBrowserMpaNavigationScheduler } from "/node_modules/vinext/dist/server/app-browser-mpa-navigation.js?v=b41becdd";
import { stripRscCompletionMetadataResponse } from "/node_modules/vinext/dist/server/rsc-completion-metadata.js?v=b41becdd";
import { blockDangerousStreamedRscRedirect } from "/node_modules/vinext/dist/server/app-browser-rsc-redirect.js?v=b41becdd";
import { navigationPlanner } from "/node_modules/vinext/dist/server/navigation-planner.js?v=b41becdd";
import { decodeRedirectError, isRedirectError } from "/node_modules/vinext/dist/shims/navigation-errors.js?v=b41becdd";
import { beginAppRouterScrollIntent, consumeAppRouterScrollIntent } from "/node_modules/vinext/dist/shims/app-router-scroll-state.js?v=b41becdd";
import { getBfcacheIdMapContext, getNavigationContext, setNavigationContext } from "/node_modules/vinext/dist/shims/navigation-context-state.js?v=b41becdd";
import { DYNAMIC_NAVIGATION_CACHE_TTL, PREFETCH_CACHE_TTL, __basePath, appRouterInstance, commitClientNavigationState, consumePrefetchResponse, consumePrefetchResponseForNavigation, createCachedRscResponseSnapshot, createClientNavigationRenderSnapshot, createSnapshotPathAndSearch, deletePrefetchResponseSnapshot, disableNavigationResponsePrefetchCacheReuse, getClientNavigationRenderContext, getMountedSlotsHeader, getPrefetchCache, hasPrefetchCacheEntryForNavigation, invalidateDynamicPrefetchCache, invalidatePrefetchCache, invalidateVisitedResponsePrefetches, parseRenderedPathAndSearchHeader, preloadHybridClientRouteOwner, pushHistoryStateWithoutNotify, replaceClientParamsWithoutNotify, replaceHistoryStateWithoutNotify, resolveLoadedHybridClientRewriteHref, resolvePrefetchCacheEntryMountedSlotsHeader, restoreRscResponse, saveScrollPosition, seedPrefetchResponseSnapshot, setClientParams, setMountedSlotsHeader, setPendingPathname, trackAppRouterNavigationInFlight, useRouter } from "/node_modules/vinext/dist/shims/navigation.js?v=b41becdd";
import { AppRouterScrollCommitProvider } from "/node_modules/vinext/dist/shims/app-router-scroll.js?v=b41becdd";
import { chunksToReadableStream, createProgressiveRscStream, getVinextBrowserGlobal } from "/node_modules/vinext/dist/server/app-browser-stream.js?v=b41becdd";
import { createMountedLayoutsHeader, holdsSkippedLayouts } from "/node_modules/vinext/dist/server/app-mounted-layouts.js?v=b41becdd";
import { BfcacheIdentityMapContext, bindAppElementsRenderedSearch, setAppElementsRenderedSearch } from "/node_modules/vinext/dist/shims/slot.js?v=b41becdd";
import { COMMITTED_CACHE_APP_NAVIGATION_PAYLOAD_ORIGIN, FRESH_APP_NAVIGATION_PAYLOAD_ORIGIN, VISITED_CACHE_APP_NAVIGATION_PAYLOAD_ORIGIN, isCacheRestorableAppPayloadMetadata, isCompleteAppPayloadMetadata, resolveInterceptionContextFromPreviousNextUrl } from "/node_modules/vinext/dist/server/app-browser-state.js?v=b41becdd";
import { clearHardNavigationLoopGuard, createAppBrowserNavigationController, createBasePathStrippedPathAndSearch, navigateDocumentDirectly } from "/node_modules/vinext/dist/server/app-browser-navigation-controller.js?v=b41becdd";
import { createAppRouteTree } from "/node_modules/vinext/dist/server/app-route-tree.js?v=b41becdd";
import { shouldRecoverSamePathSearchCommitOnResponseCompletion } from "/node_modules/vinext/dist/server/app-browser-navigation-response.js?v=b41becdd";
import { createSupplementalRefreshCoordinator, mergeRefreshedParallelSlot, requireCompleteSupplementalRefresh, resolvePersistedSourcePageRefreshes, resolveServerActionSupplementalRefresh, resolveSupplementalRefreshes } from "/node_modules/vinext/dist/server/app-browser-supplemental-refresh.js?v=b41becdd";
import { createAppBrowserNavigationAbortCoordinator } from "/node_modules/vinext/dist/server/app-browser-navigation-abort.js?v=b41becdd";
import { consumeInitialFormState, createVinextHydrateRootOptions, hydrateRootInTransition, resolveFetchedHydrationLocation } from "/node_modules/vinext/dist/server/app-browser-hydration.js?v=b41becdd";
import { AppBrowserHistoryController } from "/node_modules/vinext/dist/server/app-browser-history-controller.js?v=b41becdd";
import { createVisitedResponseCacheEntry, deleteAllVisitedResponseCacheEntries, deleteVisitedResponseCacheEntry, findVisitedResponseCacheEntry, findVisitedResponseForFullPrefetch, hasNavigationResponseHistoryLifetime, isVisitedResponseCacheEntryFresh, revokeHistoryRestoreNavigationReuse } from "/node_modules/vinext/dist/server/app-visited-response-cache.js?v=b41becdd";
import { createPopstateRestoreHandler, restoreSynchronousPopstateScrollPosition, shouldCommitPopstateUrlWithoutNavigation } from "/node_modules/vinext/dist/server/app-browser-popstate.js?v=b41becdd";
import DefaultGlobalError from "/node_modules/vinext/dist/shims/default-global-error.js?v=b41becdd";
import { DevRecoveryBoundary, GlobalErrorBoundary, RedirectBoundary } from "/node_modules/vinext/dist/shims/error-boundary.js?v=b41becdd";
import { createDevOnCaughtError, createOnUncaughtError, createProdOnCaughtError, createProdOnRecoverableError } from "/node_modules/vinext/dist/server/app-browser-error.js?v=b41becdd";
import { createHydrationCachePublication } from "/node_modules/vinext/dist/server/app-hydration-cache-publication.js?v=b41becdd";
import { peekSettledPrefetchResponseForNavigation, prepareConsumedPrefetchResponseForPublication, preserveCommittedPrefetchExpiry, resolvePrefetchNavigationResponseUrl } from "/node_modules/vinext/dist/server/app-browser-prefetch-response.js?v=b41becdd";
import { canCommitOptimisticRouteTemplate, createOptimisticRouteTemplate, createOptimisticRouteTemplateStore, getOptimisticPrefetchSourceKey, getOptimisticRouteTemplateKey, keepOptimisticStreamingMetadata, resolveOptimisticNavigationParamsForHref, resolveOptimisticNavigationPayload } from "/node_modules/vinext/dist/server/app-optimistic-routing.js?v=b41becdd";
import { removeStylesheetLinksCoveredByInlineCss } from "/node_modules/vinext/dist/server/app-inline-css-client.js?v=b41becdd";
import __vite__cjsImport47_react from "/node_modules/.vite/deps/react.js?v=b41becdd";
import __vite__cjsImport48_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=b41becdd";
import { createFromFetch, createFromReadableStream, setServerCallback } from "/node_modules/@vitejs/plugin-rsc/dist/browser.js?v=b41becdd";
import __vite__cjsImport50_reactDom from "/node_modules/.vite/deps/react-dom.js?v=b41becdd";
import { hasServerActions, loadServerActionClient } from "/@id/__x00__virtual:vinext-app-capabilities";
//#region src/server/app-browser-entry.ts
const HAS_CLIENT_REWRITES = process.env.__VINEXT_HAS_CLIENT_REWRITES !== "false";
function toActionType(kind) {
	return kind === "traverse" ? "traverse" : "navigate";
}
function toOperationLane(kind) {
	switch (kind) {
		case "navigate": return "navigation";
		case "refresh": return "refresh";
		case "traverse": return "traverse";
		default: throw new Error("[vinext] Unknown navigation kind: " + String(kind));
	}
}
const MAX_VISITED_RESPONSE_CACHE_SIZE = 50;
const IS_STATIC_EXPORT = "development" === "production" && process.env.__NEXT_CONFIG_OUTPUT === "export";
let clientDeploymentVersion = null;
let clientRscCompatibilityId = IS_STATIC_EXPORT ? null : "vinext:missing";
/**
* Decoding a payload loads the chunks its client references name, so a
* payload this page can't navigate to is only decoded by the navigation that
* hard-navigates. Otherwise a prefetch after a deploy would load the new
* deployment's code and stylesheets into this page.
*/
function isRscResponseCompatible(compatibilityIdHeader) {
	return isRscCompatibilityIdCompatible(compatibilityIdHeader, clientRscCompatibilityId);
}
function setClientRscCompatibilityId(compatibilityId) {
	if (IS_STATIC_EXPORT || !compatibilityId) return;
	clientRscCompatibilityId = compatibilityId;
}
const optimisticRouteTemplates = createOptimisticRouteTemplateStore();
function claimInitialAppRouterBootstrap() {
	if (window.__VINEXT_RSC_ROOT__ || window.__VINEXT_RSC_BOOTSTRAP_STATE__) return false;
	window.__VINEXT_RSC_BOOTSTRAP_STATE__ = "starting";
	return true;
}
function markInitialAppRouterBootstrapHydrated() {
	window.__VINEXT_RSC_BOOTSTRAP_STATE__ = "hydrated";
}
registerNavigationRuntimeFunctions({ loadRouteManifest: createNavigationRuntimeRouteManifestLoader(() => import("/@id/__x00__virtual:vinext-app-route-manifest")) });
function getBrowserRouteManifest() {
	return getNavigationRuntime()?.bootstrap.routeManifest ?? null;
}
function resolveStaticExportRouteParams(href) {
	const routeManifest = getBrowserRouteManifest();
	if (routeManifest === null) return {};
	return resolveOptimisticNavigationParamsForHref({
		basePath: __basePath,
		href,
		routeManifest
	}) ?? {};
}
function isStaticExportPayloadDeploymentCompatible(elements) {
	if (!IS_STATIC_EXPORT) return true;
	const deploymentVersion = AppElementsWire.readMetadata(elements).artifactCompatibility.deploymentVersion;
	return clientDeploymentVersion !== null && deploymentVersion === clientDeploymentVersion;
}
const historyController = new AppBrowserHistoryController({
	initialHistoryState: window.history.state,
	maxHistoryStateSnapshots: 50,
	readHistoryState: () => window.history.state,
	readCurrentHref: () => window.location.href,
	pushHistoryState: (state, href, land) => pushHistoryStateWithoutNotify(state, "", href, land),
	replaceHistoryState: (state, href, land) => replaceHistoryStateWithoutNotify(state, "", href, land),
	readVisibleNavigationMetadata: () => {
		if (!hasBrowserRouterState()) return null;
		const routerState = getBrowserRouterState();
		return {
			activeRoutePaths: resolveActiveRoutePaths(routerState.slotBindings),
			bfcacheIds: routerState.bfcacheIds,
			previousNextUrl: routerState.previousNextUrl
		};
	}
});
const browserNavigationController = createAppBrowserNavigationController({
	basePath: __basePath,
	getRouteManifest: getBrowserRouteManifest,
	loadRouteManifest: loadNavigationRuntimeRouteManifest,
	navigateDocument: (href, mode) => {
		if (mpaNavigationTree) {
			mpaNavigationTree.enter(href, mode === "replace" ? "replace" : "push");
			return;
		}
		navigateDocumentDirectly(href, mode);
	},
	syncHistoryStatePreviousNextUrl: (previousNextUrl, bfcacheIds) => historyController.syncCurrentHistoryStatePreviousNextUrl(previousNextUrl, bfcacheIds)
});
const discardedServerActionRefreshScheduler = hasServerActions ? createDiscardedServerActionRefreshScheduler({ runRefresh() {
	clearClientNavigationCaches();
	getNavigationRuntime()?.functions.navigate?.(window.location.href, 0, "refresh", void 0, void 0, true);
} }) : {
	markNavigationSettled() {},
	markNavigationStart() {},
	schedule() {}
};
const serverActionSupplementalRefreshCoordinator = createSupplementalRefreshCoordinator();
const NavigationCommitSignal = browserNavigationController.NavigationCommitSignal;
const NavigationHistoryCommit = browserNavigationController.NavigationHistoryCommit;
const ACTION_HTTP_FALLBACK_ROBOTS_META_ATTR = "data-vinext-action-http-fallback";
function syncServerActionHttpFallbackHead(status) {
	document.head.querySelectorAll(`meta[${ACTION_HTTP_FALLBACK_ROBOTS_META_ATTR}="robots"]`).forEach((node) => node.remove());
	if (status !== 404) return;
	const robots = document.createElement("meta");
	robots.name = "robots";
	robots.content = "noindex";
	robots.setAttribute(ACTION_HTTP_FALLBACK_ROBOTS_META_ATTR, "robots");
	document.head.appendChild(robots);
}
const BfcacheIdMapContext = getBfcacheIdMapContext();
function parseEncodedJsonHeader(value) {
	if (!value) return null;
	try {
		return JSON.parse(decodeURIComponent(value));
	} catch {
		return null;
	}
}
function isRouterStatePromise(value) {
	return value instanceof Promise;
}
let latestClientParams = {};
const visitedResponseCache = /* @__PURE__ */ new Map();
let clientNavigationCacheGeneration = 0;
let browserRouterStateHasEverCommitted = false;
let initialPrefetchRouterState = null;
const mpaNavigationScheduler = new AppBrowserMpaNavigationScheduler();
const unresolvedMpaNavigation = new Promise(() => {});
let mpaNavigationTree = null;
let mpaNavigationRestore = null;
function waitForMpaNavigationRestore() {
	if (!mpaNavigationRestore) {
		let resolve = () => {};
		mpaNavigationRestore = {
			promise: new Promise((resolvePromise) => {
				resolve = resolvePromise;
			}),
			resolve
		};
	}
	return mpaNavigationRestore.promise;
}
const RSC_HMR_SETTLE_DELAY_MS = 150;
const DEFAULT_GLOBAL_ERROR_COMPONENT = DefaultGlobalError;
let latestRscHmrUpdateId = 0;
let synchronousPopstateScrollRestoreNavigationId = null;
function waitForRscHmrSettle(delayMs = RSC_HMR_SETTLE_DELAY_MS) {
	return new Promise((resolve) => {
		window.setTimeout(resolve, delayMs);
	});
}
function restoreHistoryStateSnapshot(historyState, navId, onApprovedBeforeCommit, restoreCopiedExternalHistoryEntry = false) {
	let restored = false;
	flushSync(() => {
		restored = historyController.restoreHistorySnapshot({
			historyState,
			preferExternalSnapshot: restoreCopiedExternalHistoryEntry,
			stageClientParams,
			approveVisibleRestore: ({ state, beforeCommit }) => browserNavigationController.restoreHistorySnapshotVisibleState({
				restoreCopiedExternalHistoryEntry,
				beforeCommit: () => {
					onApprovedBeforeCommit?.();
					beforeCommit();
				},
				navId,
				state,
				targetHref: window.location.href
			})
		});
	});
	if (!restored) return false;
	clientNavigationCacheGeneration += 1;
	revokeHistoryRestoreNavigationReuse(visitedResponseCache);
	disableNavigationResponsePrefetchCacheReuse();
	commitClientNavigationState(navId, { releaseSnapshot: false });
	return true;
}
function getBrowserRouterState() {
	return browserNavigationController.getBrowserRouterState();
}
function hasBrowserRouterState() {
	return browserNavigationController.hasBrowserRouterState();
}
function waitForBrowserRouterStateReady() {
	return browserNavigationController.waitForBrowserRouterStateReady();
}
function beginPendingBrowserRouterState() {
	return browserNavigationController.beginPendingBrowserRouterState();
}
function applyClientParams(params) {
	latestClientParams = params;
	setClientParams(params);
}
function stageClientParams(params) {
	latestClientParams = params;
	replaceClientParamsWithoutNotify(params);
}
function clearVisitedResponseCache() {
	visitedResponseCache.clear();
	invalidateVisitedResponsePrefetches();
}
function clearPrefetchState(options) {
	invalidatePrefetchCache(options);
	optimisticRouteTemplates.clear();
}
function clearClientNavigationCaches(options) {
	clientNavigationCacheGeneration += 1;
	clearVisitedResponseCache();
	clearPrefetchState(options);
	historyController.invalidateRestorableClientState();
}
function clearDynamicClientNavigationCaches() {
	clientNavigationCacheGeneration += 1;
	clearVisitedResponseCache();
	invalidateDynamicPrefetchCache();
	optimisticRouteTemplates.clear();
	historyController.invalidateRestorableClientState();
}
function getMatchedUrlPathname(matchedUrl) {
	return new URL(matchedUrl, "https://vinext.local").pathname;
}
function resolvePersistedRefreshInterceptions(state, routeManifest, refreshUrl, requestInterceptionContext) {
	if (routeManifest === null) return [];
	const refreshPathname = stripBasePath(refreshUrl.pathname, __basePath);
	const refreshPathParts = splitPathnameForRouteMatch(refreshPathname);
	const resolved = [];
	for (const binding of state.slotBindings) {
		if (binding.state !== "active" || !binding.activeRouteId) continue;
		if (!binding.interceptionId || !binding.interceptionSourceMatchedUrl) continue;
		const activeRoute = AppElementsWire.parseElementKey(binding.activeRouteId);
		if (activeRoute?.kind !== "route") continue;
		const match = routeManifest.segmentGraph.interceptions.get(binding.interceptionId);
		if (!match) continue;
		const retainedInterception = state.interception?.slotId === binding.slotId && matchRoutePattern(splitPathnameForRouteMatch(getMatchedUrlPathname(state.interception.targetMatchedUrl)), match.targetPatternParts) !== null ? state.interception : null;
		const targetPathname = retainedInterception?.targetMatchedUrl ?? activeRoute.path;
		const targetParts = splitPathnameForRouteMatch(getMatchedUrlPathname(targetPathname));
		if (requestInterceptionContext !== null && state.interception?.slotId === binding.slotId && matchRoutePattern(refreshPathParts, match.targetPatternParts) !== null && matchRoutePattern(targetParts, match.targetPatternParts) !== null) continue;
		const targetUrl = new URL(targetPathname, refreshUrl);
		targetUrl.pathname = addBasePathToPathname(targetUrl.pathname, __basePath);
		targetUrl.search = refreshUrl.search;
		resolved.push({
			interception: match,
			interceptionContext: retainedInterception?.sourceMatchedUrl ?? binding.interceptionSourceMatchedUrl,
			targetPathname: `${targetUrl.pathname}${targetUrl.search}`
		});
	}
	return resolved;
}
async function fetchPersistedInterceptedSlotRefresh(options) {
	const headers = createRscRequestHeaders({
		interceptionContext: options.interceptionContext,
		interceptionId: options.interceptionId,
		mountedSlotsHeader: options.mountedSlotsHeader
	});
	return decodeSupplementalRefresh(await fetch(await createRscRequestUrl(options.targetPathname, headers), {
		credentials: "include",
		headers,
		signal: options.signal
	}), options.targetPathname);
}
async function fetchPersistedSourcePageRefresh(options) {
	const headers = createRscRequestHeaders({ mountedSlotsHeader: options.mountedSlotsHeader });
	return decodeSupplementalRefresh(await fetch(await createRscRequestUrl(options.targetPathname, headers), {
		credentials: "include",
		headers,
		signal: options.signal
	}), options.targetPathname);
}
/**
* Decode a kept branch a refresh fetched from its own URL. Its client pages
* read the query the server rendered it with, not the navigation's.
*/
async function decodeSupplementalRefresh(response, targetPathname) {
	if (!isRscResponseCompatible(response.headers.get("X-Vinext-RSC-Compatibility-Id"))) {
		response.body?.cancel().catch(() => {});
		throw new Error("[vinext] Refreshed another deployment's payload");
	}
	const elements = await decodeAppElementsPromise(createFromFetch(Promise.resolve(response)));
	const renderedPathAndSearch = parseRenderedPathAndSearchHeader(response.headers.get(VINEXT_RENDERED_PATH_AND_SEARCH_HEADER));
	setAppElementsRenderedSearch(elements, new URL(renderedPathAndSearch ?? targetPathname, window.location.origin).search);
	return elements;
}
function isSettledPrefetchCacheEntry(entry) {
	return entry.outcome === "cache-seeded" && entry.pending === void 0 && entry.snapshot !== void 0;
}
function parsePrefetchCacheKey(cacheKey) {
	const separatorIndex = cacheKey.indexOf("\0");
	if (separatorIndex === -1) return {
		interceptionContext: null,
		rscUrl: cacheKey
	};
	return {
		interceptionContext: cacheKey.slice(separatorIndex + 1),
		rscUrl: cacheKey.slice(0, separatorIndex)
	};
}
async function learnOptimisticRouteTemplateFromPrefetch(options) {
	const source = parsePrefetchCacheKey(options.cacheKey);
	if (source.interceptionContext !== options.interceptionContext) return null;
	if (resolvePrefetchCacheEntryMountedSlotsHeader(options.entry) !== options.mountedSlotsHeader) return null;
	if (options.interceptionContext !== null) return null;
	if (!isRscResponseCompatible(options.entry.snapshot.compatibilityIdHeader)) return null;
	const elements = await decodeAppElementsPromise(createFromFetch(Promise.resolve(restoreRscResponse(options.entry.snapshot))));
	const template = createOptimisticRouteTemplate({
		allowLoadingShell: options.entry.optimisticRouteShell === true,
		basePath: __basePath,
		elements,
		href: options.entry.snapshot.url || source.rscUrl,
		interceptionContext: options.interceptionContext,
		mountedSlotsHeader: options.mountedSlotsHeader,
		routeManifest: options.routeManifest
	});
	if (template === null) return null;
	return {
		key: getOptimisticRouteTemplateKey({
			interceptionContext: options.interceptionContext,
			mountedSlotsHeader: options.mountedSlotsHeader,
			routeId: template.routeId
		}),
		template
	};
}
async function learnOptimisticRouteTemplatesFromPrefetchCache(options) {
	const { routeManifest } = options;
	if (routeManifest === null) return;
	const learning = optimisticRouteTemplates.pendingLearning();
	for (const [cacheKey, entry] of getPrefetchCache()) {
		const sourceKey = getOptimisticPrefetchSourceKey({
			cacheKey,
			interceptionContext: options.interceptionContext,
			mountedSlotsHeader: options.mountedSlotsHeader
		});
		if (optimisticRouteTemplates.hasSource(sourceKey)) continue;
		if (!isSettledPrefetchCacheEntry(entry)) continue;
		if (entry.prefetchKind === "route-tree") continue;
		learning.push(optimisticRouteTemplates.learn(sourceKey, () => learnOptimisticRouteTemplateFromPrefetch({
			cacheKey,
			entry,
			interceptionContext: options.interceptionContext,
			mountedSlotsHeader: options.mountedSlotsHeader,
			routeManifest
		})));
	}
	if (learning.length === 0) return;
	await Promise.allSettled(learning);
}
function createActionInitiationSnapshot() {
	const routerState = getBrowserRouterState();
	return createServerActionInitiationSnapshot({
		href: window.location.href,
		navigationId: browserNavigationController.getActiveNavigationId(),
		routerState
	});
}
function createNavigationCommitEffect(options) {
	const { activeRoutePaths, bfcacheIds, href, historyUpdateMode, navId, params, previousNextUrl, targetHistoryIndex } = options;
	let wroteHistory = false;
	return {
		writeHistory({ keepCurrentUrl }) {
			if (!browserNavigationController.isCurrentNavigation(navId)) return;
			historyController.commitNavigationHistory({
				activeRoutePaths,
				bfcacheIds,
				href,
				historyUpdateMode: keepCurrentUrl ? void 0 : historyUpdateMode,
				previousNextUrl,
				stageClientParams: () => stageClientParams(params),
				targetHistoryIndex
			});
			wroteHistory = true;
		},
		publish({ releaseSnapshot }) {
			if (!wroteHistory) {
				commitClientNavigationState(void 0, { releaseSnapshot });
				return;
			}
			clearAppNavigationFailureTarget(href);
			commitClientNavigationState(navId, { releaseSnapshot });
		}
	};
}
async function renderNavigationPayload(options) {
	syncServerActionHttpFallbackHead(null);
	return browserNavigationController.renderNavigationPayload({
		actionType: options.actionType ?? "navigate",
		createNavigationCommitEffect,
		historyUpdateMode: options.historyUpdateMode,
		navigationCommitKind: options.navigationCommitKind,
		navigationInitiationState: options.navigationInitiationState,
		navigationResponseCompletion: options.navigationResponseCompletion,
		navigationSnapshot: options.navigationSnapshot,
		navId: options.navId,
		nextElements: options.payload,
		onCommittedState: options.onCommittedState,
		operationLane: options.operationLane ?? "navigation",
		params: options.params,
		payloadOrigin: options.payloadOrigin,
		pendingRouterState: options.pendingRouterState,
		previousNextUrl: options.previousNextUrl,
		restoredBfcacheIds: options.restoredBfcacheIds ?? null,
		reuseCurrentBfcacheIds: options.reuseCurrentBfcacheIds ?? true,
		scrollIntent: options.scrollIntent ?? null,
		targetHistoryIndex: options.traversalIntent?.targetHistoryIndex,
		targetHref: options.targetHref,
		visibleCommitMode: options.visibleCommitMode ?? "transition"
	});
}
async function commitSameUrlNavigatePayload(nextElements, actionInitiation, returnValue, revalidation = "none", renderedPathAndSearch = null) {
	let shouldRetrySupplementalRefresh = false;
	let supplementalHandle = null;
	let routeManifestLoaded = true;
	if (revalidation !== "none") {
		const routeManifestLoad = loadNavigationRuntimeRouteManifest();
		if (routeManifestLoad !== null) routeManifestLoaded = await routeManifestLoad;
		if (!routeManifestLoaded && browserNavigationController.isCurrentNavigation(actionInitiation.navigationId)) {
			browserNavigationController.performHardNavigation(actionInitiation.href);
			return;
		}
	}
	if (revalidation !== "none" && routeManifestLoaded) {
		const refreshUrl = new URL(actionInitiation.href);
		const requestInterceptionContext = resolveInterceptionContextFromPreviousNextUrl(actionInitiation.routerState.previousNextUrl, __basePath);
		const persistedInterceptions = resolvePersistedRefreshInterceptions(actionInitiation.routerState, getBrowserRouteManifest(), refreshUrl, requestInterceptionContext);
		const sourcePageRefreshes = resolvePersistedSourcePageRefreshes({
			basePath: __basePath,
			refreshUrl,
			state: actionInitiation.routerState
		}).filter((sourcePathname) => !persistedInterceptions.some((interception) => interception.targetPathname === sourcePathname));
		if (persistedInterceptions.length > 0 || sourcePageRefreshes.length > 0) {
			supplementalHandle = serverActionSupplementalRefreshCoordinator.begin({
				activeNavigationId: browserNavigationController.getActiveNavigationId(),
				startedNavigationId: actionInitiation.navigationId
			});
			const mountedSlotsHeader = getMountedSlotIdsHeader(actionInitiation.routerState.elements);
			const supplemental = persistedInterceptions.map((interception) => (signal) => fetchPersistedInterceptedSlotRefresh({
				interceptionContext: interception.interceptionContext,
				interceptionId: interception.interception.id,
				mountedSlotsHeader,
				signal,
				targetPathname: interception.targetPathname
			}));
			for (const sourcePageRefresh of sourcePageRefreshes) supplemental.push((signal) => fetchPersistedSourcePageRefresh({
				mountedSlotsHeader,
				signal,
				targetPathname: sourcePageRefresh
			}));
			nextElements = resolveSupplementalRefreshes({
				merge: mergeRefreshedParallelSlot,
				primary: nextElements,
				signal: supplementalHandle.signal,
				supplemental
			}).then((result) => {
				const resolution = resolveServerActionSupplementalRefresh(result, actionInitiation.routerState.elements);
				shouldRetrySupplementalRefresh ||= resolution.retry;
				return resolution.value;
			});
		}
	}
	const navigationSnapshot = renderedPathAndSearch === null ? withRenderedSearchOf(createClientNavigationRenderSnapshot(actionInitiation.href, actionInitiation.routerState.navigationSnapshot.params), actionInitiation.routerState.navigationSnapshot) : createClientNavigationRenderSnapshot(actionInitiation.href, actionInitiation.routerState.navigationSnapshot.params, renderedPathAndSearch);
	try {
		const result = await browserNavigationController.commitSameUrlNavigatePayload(nextElements, navigationSnapshot, returnValue, actionInitiation.routerState, {
			onDiscardedRevalidation() {
				discardedServerActionRefreshScheduler.schedule();
			},
			revalidation,
			startedNavigationId: actionInitiation.navigationId,
			targetHref: actionInitiation.href
		});
		if (shouldRetrySupplementalRefresh) discardedServerActionRefreshScheduler.schedule();
		return result;
	} finally {
		supplementalHandle?.finish();
	}
}
function evictVisitedResponseCacheIfNeeded() {
	while (visitedResponseCache.size >= MAX_VISITED_RESPONSE_CACHE_SIZE) {
		const oldest = visitedResponseCache.keys().next().value;
		if (oldest === void 0) return;
		visitedResponseCache.delete(oldest);
	}
}
function readVisitedResponseCacheCandidate(rscUrl, interceptionContext, mountedSlotsHeader, navigationKind) {
	const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	const match = findVisitedResponseCacheEntry(visitedResponseCache, rscUrl, interceptionContext);
	if (!match || match.entry.navigationReuseRevoked) return {
		cacheKey,
		entry: null,
		facts: {
			candidate: "missing",
			navigationKind
		}
	};
	return {
		cacheKey: match.cacheKey,
		entry: match.entry,
		facts: {
			candidate: "present",
			fresh: isVisitedResponseCacheEntryFresh(match.entry, {
				navigationKind,
				now: Date.now()
			}),
			mountedSlotsMatch: match.entry.elements !== void 0 || match.entry.mountedSlotsHeader === mountedSlotsHeader,
			navigationKind
		}
	};
}
function applyVisitedResponseCacheCandidateDecision(candidate, decision) {
	if (candidate.entry === null) return null;
	if (decision.kind === "reuse") {
		visitedResponseCache.delete(candidate.cacheKey);
		visitedResponseCache.set(candidate.cacheKey, candidate.entry);
		return candidate.entry;
	}
	visitedResponseCache.delete(candidate.cacheKey);
	return null;
}
function deleteVisitedResponse(rscUrl, interceptionContext) {
	deleteVisitedResponseCacheEntry(visitedResponseCache, rscUrl, interceptionContext);
}
function storeVisitedResponseSnapshot(rscUrl, interceptionContext, snapshot, params, prefetchFallbackTtlMs = DYNAMIC_NAVIGATION_CACHE_TTL, requestMountedSlotsHeader = snapshot.mountedSlotsHeader ?? null, elements, seedPrefetchCache = true, prefetchSnapshot = snapshot, reuseAfterHistoryRestore = false, fromHydration = false) {
	const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	deleteAllVisitedResponseCacheEntries(visitedResponseCache, rscUrl, interceptionContext);
	evictVisitedResponseCacheIfNeeded();
	const entry = createVisitedResponseCacheEntry({
		fallbackTtlMs: prefetchFallbackTtlMs,
		elements,
		fromHydration,
		now: Date.now(),
		mountedSlotsHeader: requestMountedSlotsHeader,
		params,
		response: snapshot,
		reuseAfterHistoryRestore
	});
	visitedResponseCache.set(cacheKey, entry);
	if (seedPrefetchCache) seedPrefetchResponseSnapshot(rscUrl, prefetchSnapshot, interceptionContext, requestMountedSlotsHeader, prefetchFallbackTtlMs, reuseAfterHistoryRestore);
	return () => {
		if (visitedResponseCache.get(cacheKey) === entry) visitedResponseCache.delete(cacheKey);
		if (seedPrefetchCache) deletePrefetchResponseSnapshot(rscUrl, prefetchSnapshot, interceptionContext);
	};
}
function clientNavigationSnapshotHref(snapshot) {
	return `${window.location.origin}${createSnapshotPathAndSearch(snapshot)}`;
}
function getCurrentMatchedRoutePathname() {
	const routeKey = AppElementsWire.parseElementKey(getBrowserRouterState().routeId);
	return routeKey?.kind === "route" ? routeKey.path : null;
}
function getRequestState(navigationKind, targetPathname, previousNextUrlOverride, traverseHistoryState) {
	if (previousNextUrlOverride !== void 0) return {
		interceptionContext: resolveInterceptionContextFromPreviousNextUrl(previousNextUrlOverride, __basePath),
		previousNextUrl: previousNextUrlOverride
	};
	switch (navigationKind) {
		case "navigate": {
			const currentPreviousNextUrl = getBrowserRouterState().previousNextUrl;
			if (currentPreviousNextUrl !== null) return {
				interceptionContext: resolveInterceptionContextFromPreviousNextUrl(currentPreviousNextUrl, __basePath),
				previousNextUrl: currentPreviousNextUrl
			};
			const manifestInterceptionContext = resolveManifestNavigationInterceptionContext({
				basePath: __basePath,
				currentPathname: window.location.pathname,
				routeManifest: getBrowserRouteManifest(),
				targetPathname
			});
			if (manifestInterceptionContext !== null) return {
				interceptionContext: manifestInterceptionContext,
				previousNextUrl: window.location.pathname + window.location.search
			};
			const middlewareRewriteInterceptionContext = resolveMiddlewareRewriteNavigationInterceptionContext({
				basePath: __basePath,
				currentMatchedPathname: getCurrentMatchedRoutePathname(),
				currentPathname: window.location.pathname,
				routeManifest: getBrowserRouteManifest(),
				targetPathname
			});
			if (middlewareRewriteInterceptionContext !== null) return {
				interceptionContext: middlewareRewriteInterceptionContext,
				previousNextUrl: window.location.pathname + window.location.search
			};
			return {
				interceptionContext: null,
				previousNextUrl: null
			};
		}
		case "traverse": {
			const previousNextUrl = readHistoryStatePreviousNextUrl(traverseHistoryState ?? window.history.state);
			return {
				interceptionContext: resolveInterceptionContextFromPreviousNextUrl(previousNextUrl, __basePath),
				previousNextUrl
			};
		}
		case "refresh": {
			const currentPreviousNextUrl = getBrowserRouterState().previousNextUrl;
			return {
				interceptionContext: resolveInterceptionContextFromPreviousNextUrl(currentPreviousNextUrl, __basePath),
				previousNextUrl: currentPreviousNextUrl
			};
		}
		default: throw new Error("[vinext] Unknown navigation kind: " + String(navigationKind));
	}
}
function handleDevRecoveryBoundaryCatch(resetKey) {
	browserNavigationController.drainPrePaintEffects(resetKey);
}
function isMpaNavigationState(value) {
	return value !== null && typeof value === "object" && "kind" in value && value.kind === "mpa-navigation";
}
function performMpaNavigation(href, historyUpdateMode) {
	mpaNavigationScheduler.navigate(window, href, historyUpdateMode);
}
function AppRouterRedirectBridge({ children }) {
	const router = useRouter();
	useEffect(() => {
		const handleUnhandledRedirect = (event) => {
			const error = "reason" in event ? event.reason : event.error;
			if (!isRedirectError(error)) return;
			if ("handled" in error && error.handled === true) {
				event.preventDefault();
				return;
			}
			const result = decodeRedirectError(error.digest);
			if (!result) return;
			event.preventDefault();
			startTransition(() => {
				if (result.type === "push") router.push(result.url);
				else router.replace(result.url);
			});
		};
		window.addEventListener("error", handleUnhandledRedirect);
		window.addEventListener("unhandledrejection", handleUnhandledRedirect);
		return () => {
			window.removeEventListener("error", handleUnhandledRedirect);
			window.removeEventListener("unhandledrejection", handleUnhandledRedirect);
		};
	}, [router]);
	return children ?? null;
}
function decodeAppElementsPromise(payload) {
	return Promise.resolve(payload).then((elements) => AppElementsWire.decode(elements));
}
function BrowserRoot({ hydrationCachePublication, initialElements, initialNavigationSnapshot }) {
	const resolvedElements = use(initialElements);
	const initialMetadata = AppElementsWire.readMetadata(resolvedElements);
	const [treeStateValue, setTreeStateValue] = useState(() => ({
		activeOperation: null,
		bfcacheIds: createInitialBfcacheIdMap(resolvedElements),
		elements: resolvedElements,
		interception: initialMetadata.interception,
		interceptionContext: initialMetadata.interceptionContext,
		layoutIds: initialMetadata.layoutIds,
		navigationSnapshot: initialNavigationSnapshot,
		previousNextUrl: null,
		renderId: 0,
		rootLayoutTreePath: initialMetadata.rootLayoutTreePath,
		routeId: initialMetadata.routeId,
		slotBindings: initialMetadata.slotBindings,
		visibleCommitVersion: 0
	}));
	if (isMpaNavigationState(treeStateValue)) {
		performMpaNavigation(treeStateValue.href, treeStateValue.historyUpdateMode);
		throw unresolvedMpaNavigation;
	}
	const treeState = isRouterStatePromise(treeStateValue) ? use(treeStateValue) : treeStateValue;
	const stateRef = useRef(treeState);
	stateRef.current = treeState;
	const committedStateRef = useRef(treeState);
	useLayoutEffect(() => {
		committedStateRef.current = treeState;
	}, [treeState]);
	useLayoutEffect(() => {
		const setAppRouterStateValue = (value) => {
			setTreeStateValue(value);
		};
		const detach = browserNavigationController.attachBrowserRouterState(setAppRouterStateValue, stateRef);
		const setMpaNavigationState = (href, historyUpdateMode) => {
			startTransition(() => {
				setTreeStateValue({
					href,
					historyUpdateMode,
					kind: "mpa-navigation"
				});
			});
		};
		const currentMpaNavigationTree = {
			enter: setMpaNavigationState,
			restore() {
				setTreeStateValue((current) => isMpaNavigationState(current) ? committedStateRef.current : current);
			}
		};
		mpaNavigationTree = currentMpaNavigationTree;
		registerNavigationRuntimeFunctions({ navigateExternal: (href, historyUpdateMode) => {
			setMpaNavigationState(href, historyUpdateMode);
			return waitForMpaNavigationRestore();
		} });
		browserRouterStateHasEverCommitted = true;
		hydrationCachePublication.commit();
		return () => {
			hydrationCachePublication.invalidate();
			if (mpaNavigationTree === currentMpaNavigationTree) mpaNavigationTree = null;
			registerNavigationRuntimeFunctions({ navigateExternal: void 0 });
			detach();
			setMountedSlotsHeader(null);
		};
	}, [hydrationCachePublication, setTreeStateValue]);
	useEffect(() => {
		hydrationCachePublication.complete();
		const hydratedAt = performance.now();
		window.__VINEXT_HYDRATED_AT = hydratedAt;
		window.__NEXT_HYDRATED = true;
		window.__NEXT_HYDRATED_AT = hydratedAt;
		window.__NEXT_HYDRATED_CB?.();
	}, [hydrationCachePublication]);
	useLayoutEffect(() => {
		historyController.rememberHistoryStateSnapshot(treeState);
	}, [treeState]);
	useEffect(() => {
		setWindowNextInternalSourcePage(AppElementsWire.readMetadata(treeState.elements).sourcePage);
	}, [treeState.elements]);
	useLayoutEffect(() => {
		const previousMountedSlotsHeader = getMountedSlotsHeader();
		const nextMountedSlotsHeader = getMountedSlotIdsHeader(stateRef.current.elements);
		setMountedSlotsHeader(nextMountedSlotsHeader);
		removeStylesheetLinksCoveredByInlineCss();
		if (previousMountedSlotsHeader === nextMountedSlotsHeader) return;
		const pingTimer = window.setTimeout(() => {
			getNavigationRuntime()?.functions.pingVisibleLinks?.();
		}, 0);
		return () => {
			window.clearTimeout(pingTimer);
		};
	}, [treeState.elements]);
	useLayoutEffect(() => {
		if (treeState.renderId !== 0) return;
		historyController.writeHydratedHistoryMetadata({
			activeRoutePaths: resolveActiveRoutePaths(treeState.slotBindings),
			bfcacheIds: treeState.bfcacheIds,
			previousNextUrl: treeState.previousNextUrl
		});
	}, [
		treeState.bfcacheIds,
		treeState.previousNextUrl,
		treeState.renderId,
		treeState.slotBindings
	]);
	const routeTree = createElement(RedirectBoundary, null, createElement(NavigationCommitSignal, { renderId: treeState.renderId }, createAppRouteTree({
		elements: treeState.elements,
		historyCommit: createElement(NavigationHistoryCommit, { renderId: treeState.renderId }),
		routeId: treeState.routeId
	})));
	const bfcacheSegmentIdentities = useMemo(() => createBfcacheSegmentIdentityMap({ elements: treeState.elements }), [treeState.elements]);
	const identityMapTree = createElement(BfcacheIdentityMapContext.Provider, { value: bfcacheSegmentIdentities }, routeTree);
	const bfcacheTree = BfcacheIdMapContext ? createElement(BfcacheIdMapContext.Provider, { value: treeState.bfcacheIds }, identityMapTree) : identityMapTree;
	const redirectedTree = createElement(AppRouterRedirectBridge, null, bfcacheTree);
	const innerTree = AppRouterContext ? createElement(AppRouterContext.Provider, { value: appRouterInstance }, redirectedTree) : redirectedTree;
	const committedTree = import.meta.env.DEV ? createElement(DevRecoveryBoundary, {
		isImplicitRootErrorBoundary: true,
		resetKey: treeState.renderId,
		onCatch: handleDevRecoveryBoundaryCatch
	}, innerTree) : innerTree;
	const scrollScopedTree = createElement(AppRouterScrollCommitProvider, { commitId: treeState.renderId }, committedTree);
	const rootErrorTree = createElement(GlobalErrorBoundary, {
		fallback: DEFAULT_GLOBAL_ERROR_COMPONENT,
		children: scrollScopedTree
	});
	const ClientNavigationRenderContext = getClientNavigationRenderContext();
	if (!ClientNavigationRenderContext) return rootErrorTree;
	return createElement(ClientNavigationRenderContext.Provider, { value: treeState.navigationSnapshot }, rootErrorTree);
}
function restoreHydrationNavigationContext(pathname, searchParams, params) {
	setNavigationContext({
		pathname,
		searchParams: new URLSearchParams(searchParams),
		params
	});
}
function restoreEmbeddedHydrationNavigationContext(pathname, searchParams, params, searchParamsFromBrowser) {
	restoreHydrationNavigationContext(pathname, searchParamsFromBrowser ? window.location.search : searchParams, params);
}
/**
* The path and query SSR rendered, from the navigation payload the document
* embeds: the effective query, which a rewrite may have changed, or the
* browser URL's when a stored document leaves the query out.
*/
function getHydrationRenderedPathAndSearch() {
	const context = getNavigationContext();
	if (!context) return null;
	const search = context.searchParams.toString();
	return search ? `${context.pathname}?${search}` : context.pathname;
}
/**
* A render that turns dynamic after the head sends its client pages' query
* later in the document (see `app-ssr-entry.ts`), possibly after bootstrap, so
* the hydration snapshot reads it when a client page first renders.
*/
function withLateRenderedSearch(snapshot, rsc) {
	if (!rsc) return snapshot;
	const headRenderedSearch = snapshot.renderedSearch;
	return Object.defineProperty(snapshot, "renderedSearch", {
		configurable: true,
		enumerable: true,
		get: () => rsc.renderedSearch ?? headRenderedSearch
	});
}
/** Carry the rendered query over to a snapshot of the same URL. */
function withRenderedSearchOf(snapshot, source) {
	return source.renderedSearch === void 0 ? snapshot : {
		...snapshot,
		renderedSearch: source.renderedSearch
	};
}
function restorePopstateScrollPosition(state, options) {
	const shouldContinue = options?.shouldContinue ?? (() => true);
	if (!shouldContinue()) return;
	if (!(state && typeof state === "object" && "__vinext_scrollY" in state)) {
		if (window.location.hash) scrollToHashTargetOnNextFrame(window.location.hash);
		return;
	}
	const y = Number(state.__vinext_scrollY);
	const x = "__vinext_scrollX" in state ? Number(state.__vinext_scrollX) : 0;
	retryScrollTo(x, y, {
		minFrames: 1,
		shouldContinue
	});
}
function isSameAppRoutePopstateTarget(href) {
	if (!hasBrowserRouterState()) return false;
	const target = new URL(href, window.location.origin);
	const routerState = getBrowserRouterState();
	return createBasePathStrippedPathAndSearch(target, __basePath) === createSnapshotPathAndSearch(routerState.navigationSnapshot);
}
let isPageUnloading = false;
const RSC_RELOAD_KEY = "__vinext_rsc_initial_reload__";
function readReloadFlag() {
	try {
		return sessionStorage.getItem(RSC_RELOAD_KEY);
	} catch {
		return null;
	}
}
function writeReloadFlag(path) {
	try {
		sessionStorage.setItem(RSC_RELOAD_KEY, path);
	} catch {}
}
function clearReloadFlag() {
	try {
		sessionStorage.removeItem(RSC_RELOAD_KEY);
	} catch {}
}
function recoverFromBadInitialRscResponse(reason) {
	const currentPath = window.location.pathname + window.location.search;
	if (readReloadFlag() === currentPath) {
		clearReloadFlag();
		console.error(`[vinext] Initial RSC fetch ${reason} after reload; aborting hydration. Server-rendered HTML remains visible; client components will not hydrate.`);
		return null;
	}
	writeReloadFlag(currentPath);
	if (readReloadFlag() !== currentPath) {
		console.error(`[vinext] Initial RSC fetch ${reason}; sessionStorage unavailable so the reload-loop guard cannot persist — aborting hydration. Server-rendered HTML remains visible; client components will not hydrate.`);
		return null;
	}
	console.warn(`[vinext] Initial RSC fetch ${reason}; reloading once to let the server render the HTML error page`);
	window.location.reload();
	return null;
}
async function readInitialRscStream() {
	const vinext = getVinextBrowserGlobal();
	const runtimeRsc = getNavigationRuntime()?.bootstrap.rsc;
	if (runtimeRsc || vinext.__VINEXT_RSC_CHUNKS__ || vinext.__VINEXT_RSC_DONE__) {
		clearReloadFlag();
		clearHardNavigationLoopGuard();
		if (runtimeRsc) {
			applyRuntimeRscBootstrap(runtimeRsc);
			if (runtimeRsc.done) {
				registerNavigationRuntimeBootstrap({ rsc: void 0 });
				return chunksToReadableStream(runtimeRsc.rsc);
			}
			return createProgressiveRscStream();
		}
		if (vinext.__VINEXT_RSC_PARAMS__) applyClientParams(vinext.__VINEXT_RSC_PARAMS__);
		return createProgressiveRscStream();
	}
	const rscHeaders = createRscRequestHeaders();
	const rscResponse = await fetch(await createRscRequestUrl(window.location.pathname + window.location.search, rscHeaders), {
		credentials: "include",
		headers: rscHeaders
	});
	if (!rscResponse.ok) return recoverFromBadInitialRscResponse(`returned ${rscResponse.status}`);
	const contentType = rscResponse.headers.get("content-type") ?? "";
	if (!contentType.startsWith("text/x-component")) return recoverFromBadInitialRscResponse(`returned non-RSC content-type "${contentType || "(missing)"}"`);
	if (!rscResponse.body) return recoverFromBadInitialRscResponse("returned empty body");
	clearReloadFlag();
	clearHardNavigationLoopGuard();
	setClientRscCompatibilityId(rscResponse.headers.get(VINEXT_RSC_COMPATIBILITY_ID_HEADER));
	const parsedParams = parseEncodedJsonHeader(rscResponse.headers.get(VINEXT_PARAMS_HEADER));
	const params = parsedParams ?? {};
	if (parsedParams) try {
		applyClientParams(parsedParams);
	} catch {}
	const rendered = resolveFetchedHydrationLocation(parseRenderedPathAndSearchHeader(rscResponse.headers.get(VINEXT_RENDERED_PATH_AND_SEARCH_HEADER)), window.location);
	restoreHydrationNavigationContext(rendered.pathname, rendered.search, params);
	return rscResponse.body;
}
function applyRuntimeRscBootstrap(rsc) {
	setClientRscCompatibilityId(rsc.compatibilityId);
	const params = rsc.params ?? {};
	if (rsc.params) applyClientParams(rsc.params);
	if (rsc.nav) restoreEmbeddedHydrationNavigationContext(rsc.nav.pathname, rsc.nav.searchParams, params, rsc.searchParamsFromBrowser === true);
}
function registerServerActionCallback() {
	setServerCallback((id, args) => {
		const releaseCacheInvalidationGuard = historyController.beginCacheInvalidationGuard();
		const actionInitiation = createActionInitiationSnapshot();
		return loadServerActionClient().then(({ invokeClientServerAction }) => invokeClientServerAction(id, args, actionInitiation, {
			basePath: __basePath,
			clearClientNavigationCaches,
			clearDynamicClientNavigationCaches,
			clientRscCompatibilityId,
			commitSameUrlNavigatePayload,
			navigationPlanner,
			performHardNavigation: (url, historyMode) => browserNavigationController.performHardNavigation(url, historyMode),
			renderRedirectPayload(elements, target, actionInitiation, revalidation) {
				if (browserNavigationController.isCurrentNavigation(actionInitiation.navigationId)) getNavigationRuntime()?.functions.notifyLinkNavigationStart?.();
				const hashIdx = target.href.indexOf("#");
				const hash = hashIdx !== -1 ? target.href.slice(hashIdx) : "";
				const actionScrollIntent = beginAppRouterScrollIntent(hash || null);
				if (target.type === "push") saveScrollPosition();
				renderNavigationPayload({
					actionType: target.type === "push" ? "navigate" : "replace",
					historyUpdateMode: target.type === "push" ? "push" : "replace",
					navigationInitiationState: actionInitiation.routerState,
					navigationSnapshot: createClientNavigationRenderSnapshot(target.href, actionInitiation.routerState.navigationSnapshot.params, target.renderedPathAndSearch),
					navId: actionInitiation.navigationId,
					operationLane: resolveServerActionOperationLane(revalidation),
					params: {},
					payload: Promise.resolve(elements),
					payloadOrigin: FRESH_APP_NAVIGATION_PAYLOAD_ORIGIN,
					pendingRouterState: null,
					previousNextUrl: null,
					scrollIntent: actionScrollIntent,
					targetHref: target.href
				}).catch(() => {
					browserNavigationController.performHardNavigation(target.href);
				});
			},
			syncCurrentHistoryState: (previousNextUrl, bfcacheIds) => historyController.syncCurrentHistoryStatePreviousNextUrl(previousNextUrl, bfcacheIds),
			syncServerActionHttpFallbackHead
		})).finally(releaseCacheInvalidationGuard);
	});
}
function ReplayInitialDevServerErrors({ report }) {
	useEffect(report, [report]);
	return null;
}
async function main() {
	if (!claimInitialAppRouterBootstrap()) return;
	loadNavigationRuntimeRouteManifest();
	if (hasServerActions) registerServerActionCallback();
	installAppNavigationFailureListeners();
	if (HAS_CLIENT_REWRITES) await preloadHybridClientRouteOwner();
	let devErrorOverlay = null;
	if (import.meta.env.DEV) {
		devErrorOverlay = await import("/node_modules/vinext/dist/client/dev-error-overlay.js?v=b41becdd");
		devErrorOverlay.installDevErrorOverlay();
		devErrorOverlay.installViteHmrErrorHandler(import.meta.hot);
		if (document.documentElement.id !== "__next_error__") devErrorOverlay.reportInitialDevServerErrors();
	}
	const initialRscBootstrap = getNavigationRuntime()?.bootstrap.rsc;
	const rscStream = await readInitialRscStream();
	if (rscStream === null) return;
	bootstrapHydration(rscStream, devErrorOverlay, initialRscBootstrap);
}
function bootstrapHydration(rscStream, devErrorOverlay, initialRscBootstrap) {
	const hydrationCachePublication = createHydrationCachePublication();
	const cacheGeneration = clientNavigationCacheGeneration;
	const [reactBranch, cacheBranch] = rscStream.tee();
	const initialNavigationSnapshot = withLateRenderedSearch(createClientNavigationRenderSnapshot(window.location.href, latestClientParams, getHydrationRenderedPathAndSearch()), initialRscBootstrap);
	const initialPathAndSearch = createSnapshotPathAndSearch(initialNavigationSnapshot);
	const root = decodeAppElementsPromise(createFromReadableStream(reactBranch)).then((elements) => {
		if (IS_STATIC_EXPORT) clientDeploymentVersion = AppElementsWire.readMetadata(elements).artifactCompatibility.deploymentVersion;
		bindAppElementsRenderedSearch(elements, initialNavigationSnapshot);
		initialPrefetchRouterState = {
			pathAndSearch: initialPathAndSearch,
			routeId: AppElementsWire.readMetadata(elements).routeId
		};
		return elements;
	});
	const initialParams = initialNavigationSnapshot.params;
	const initialCacheBuffer = new Response(cacheBranch).arrayBuffer();
	Promise.all([root, initialCacheBuffer]).then(async ([elements, buffer]) => {
		if (cacheGeneration !== clientNavigationCacheGeneration) return;
		const metadata = AppElementsWire.readMetadata(elements);
		if (!isCompleteAppPayloadMetadata(metadata)) return;
		const mountedSlotsHeader = getMountedSlotIdsHeader(elements);
		const headers = createRscRequestHeaders({ mountedSlotsHeader });
		const rscUrl = await createRscRequestUrl(initialPathAndSearch, headers);
		if (cacheGeneration !== clientNavigationCacheGeneration) return;
		const snapshot = {
			compatibilityIdHeader: clientRscCompatibilityId,
			buffer,
			contentType: VINEXT_RSC_CONTENT_TYPE,
			...initialRscBootstrap?.dynamicStaleTimeSeconds !== void 0 ? { dynamicStaleTimeSeconds: initialRscBootstrap.dynamicStaleTimeSeconds } : {},
			...initialRscBootstrap?.staleTimeSeconds === void 0 ? {} : { serverStaleTime: {
				kind: "resolved",
				seconds: initialRscBootstrap.staleTimeSeconds
			} },
			mountedSlotsHeader,
			paramsHeader: encodeURIComponent(JSON.stringify(initialParams)),
			renderedPathAndSearch: null,
			url: rscUrl
		};
		const fallbackTtlMs = initialRscBootstrap?.initialCacheKind === "static" ? PREFETCH_CACHE_TTL : DYNAMIC_NAVIGATION_CACHE_TTL;
		hydrationCachePublication.publish(() => {
			if (cacheGeneration !== clientNavigationCacheGeneration) return () => {};
			return storeVisitedResponseSnapshot(rscUrl, metadata.interceptionContext, snapshot, initialParams, fallbackTtlMs, mountedSlotsHeader, elements, false, snapshot, initialRscBootstrap?.initialCacheKind === "static" || metadata.interceptionContext !== null, true);
		});
	}).catch(() => {});
	historyController.writeBootstrapHistoryMetadata();
	const reportUncaughtError = createOnUncaughtError({ coerceToError: import.meta.env.DEV });
	const onUncaughtError = (...args) => {
		hydrationCachePublication.fail();
		reportUncaughtError(...args);
	};
	const onRecoverableError = createProdOnRecoverableError(() => {
		hydrationCachePublication.fail();
	});
	const invalidateOnCaughtError = (handler) => ((...args) => {
		hydrationCachePublication.fail();
		handler(...args);
	});
	const formState = consumeInitialFormState(getVinextBrowserGlobal());
	const hydrateRootOptions = import.meta.env.DEV && devErrorOverlay ? createVinextHydrateRootOptions({
		formState,
		onCaughtError: invalidateOnCaughtError(createDevOnCaughtError(devErrorOverlay.devOnCaughtError, onUncaughtError)),
		onUncaughtError
	}) : createVinextHydrateRootOptions({
		formState,
		onCaughtError: invalidateOnCaughtError(createProdOnCaughtError(onUncaughtError)),
		onRecoverableError,
		onUncaughtError
	});
	const children = createElement(BrowserRoot, {
		hydrationCachePublication,
		initialElements: root,
		initialNavigationSnapshot
	});
	const errorShellStyles = document.querySelectorAll("style[data-vinext-error-shell-style]");
	if (document.documentElement.id === "__next_error__") {
		const { formState: _inertFormState, ...createRootOptions } = hydrateRootOptions;
		for (const style of errorShellStyles) style.remove();
		startTransition(() => {
			const clientRoot = createRoot(document, createRootOptions);
			clientRoot.render(import.meta.env.DEV && devErrorOverlay ? createElement(Fragment, null, children, createElement(ReplayInitialDevServerErrors, { report: devErrorOverlay.reportInitialDevServerErrors })) : children);
			window.__VINEXT_RSC_ROOT__ = clientRoot;
		});
	} else window.__VINEXT_RSC_ROOT__ = hydrateRootInTransition({
		children,
		container: document,
		hydrateRoot,
		options: hydrateRootOptions,
		startTransition
	});
	markInitialAppRouterBootstrapHydrated();
	const navigationAbortCoordinator = createAppBrowserNavigationAbortCoordinator();
	registerNavigationRuntimeFunctions({
		clearNavigationCaches: clearClientNavigationCaches,
		commitHashNavigation: (href, historyUpdateMode, scroll) => historyController.commitHashOnlyNavigation(href, historyUpdateMode, scroll),
		getPrefetchRouterState: () => {
			if (!browserNavigationController.hasBrowserRouterState()) return initialPrefetchRouterState;
			const state = browserNavigationController.getBrowserRouterState();
			return {
				pathAndSearch: createSnapshotPathAndSearch(state.navigationSnapshot),
				routeId: state.routeId
			};
		},
		navigate: async function navigateRsc(href, redirectDepth = 0, navigationKind = "navigate", historyUpdateMode, previousNextUrlOverride, programmaticTransition = false, traversalIntent, scrollIntent, visibleCommitMode = "transition", initialBypassNavigationCache) {
			serverActionSupplementalRefreshCoordinator.abortAll();
			const navigationAbortHandle = navigationAbortCoordinator.begin();
			let pendingRouterState = null;
			const navId = browserNavigationController.beginNavigation();
			const navigationCacheGeneration = clientNavigationCacheGeneration;
			discardedServerActionRefreshScheduler.markNavigationStart();
			let currentHref = href;
			let currentHistoryMode = historyUpdateMode;
			let currentPrevNextUrl = previousNextUrlOverride;
			let redirectCount = redirectDepth;
			let detachedNavigationCommits = false;
			let optimisticShellElements = null;
			const keepOptimisticShellMetadata = (payload) => {
				const shellElements = optimisticShellElements;
				if (shellElements === null) return payload;
				return payload instanceof Promise ? payload.then((elements) => keepOptimisticStreamingMetadata(elements, shellElements, String(navId))) : keepOptimisticStreamingMetadata(payload, shellElements, String(navId));
			};
			const activeTraversalIntent = navigationKind === "traverse" ? traversalIntent ?? historyController.resolveTraversalIntent(window.history.state) : null;
			let startedHardNavigation = false;
			const performHardNavigationForScrollIntent = (targetHref, mode) => {
				consumeAppRouterScrollIntent(scrollIntent ?? null);
				const didNavigate = browserNavigationController.performHardNavigation(targetHref, mode ?? (currentHistoryMode === "push" ? "assign" : "replace"));
				if (didNavigate) {
					startedHardNavigation = true;
					browserNavigationController.abandonPendingBrowserRouterState(pendingRouterState);
				} else clearAppNavigationFailureTarget(targetHref);
				return didNavigate;
			};
			let restoredBfcacheIds = navigationKind === "traverse" ? historyController.readCurrentBfcacheVersionHistoryIds(activeTraversalIntent?.historyState ?? window.history.state) : null;
			const reuseCurrentBfcacheIds = navigationKind !== "traverse" || !historyController.isCacheInvalidationGuarded() && historyController.isCurrentBfcacheVersion(activeTraversalIntent?.historyState ?? window.history.state);
			const releaseNavigationInFlight = trackAppRouterNavigationInFlight();
			try {
				const shouldUsePendingRouterState = programmaticTransition;
				if (hasBrowserRouterState()) {
					if (shouldUsePendingRouterState) pendingRouterState = beginPendingBrowserRouterState();
				} else {
					await waitForBrowserRouterStateReady();
					if (!browserNavigationController.isCurrentNavigation(navId)) return;
					if (shouldUsePendingRouterState) pendingRouterState = beginPendingBrowserRouterState();
				}
				const routeManifestLoad = loadNavigationRuntimeRouteManifest();
				if (routeManifestLoad !== null) {
					const routeManifestLoaded = await routeManifestLoad;
					if (!browserNavigationController.isCurrentNavigation(navId)) return;
					if (!routeManifestLoaded) {
						performHardNavigationForScrollIntent(currentHref);
						return;
					}
				}
				const navigationInitiationState = getBrowserRouterState();
				const mountedSlotsHeader = getMountedSlotIdsHeader(navigationInitiationState.elements);
				let mountedLayoutsHeader = navigationKind === "navigate" ? createMountedLayoutsHeader(navigationInitiationState.elements, navigationInitiationState.layoutIds) : null;
				while (true) {
					const url = new URL(currentHref, window.location.origin);
					const requestState = getRequestState(navigationKind, url.pathname, currentPrevNextUrl, activeTraversalIntent?.historyState);
					const requestInterceptionContext = requestState.interceptionContext;
					const requestPreviousNextUrl = requestState.previousNextUrl;
					const shouldSupplementVisibleBranches = navigationKind === "refresh" || navigationKind === "traverse" && !reuseCurrentBfcacheIds;
					const persistedRefreshInterceptions = navigationKind === "refresh" ? resolvePersistedRefreshInterceptions(navigationInitiationState, getBrowserRouteManifest(), url, requestInterceptionContext) : [];
					const persistedSourcePageRefreshes = shouldSupplementVisibleBranches ? resolvePersistedSourcePageRefreshes({
						activeRoutePaths: navigationKind === "traverse" ? readHistoryStateActiveRoutePaths(activeTraversalIntent?.historyState) ?? [] : void 0,
						basePath: __basePath,
						refreshUrl: url,
						state: navigationKind === "traverse" ? {
							previousNextUrl: requestPreviousNextUrl,
							slotBindings: []
						} : navigationInitiationState
					}).filter((sourcePathAndSearch) => {
						if (persistedRefreshInterceptions.some((interception) => interception.targetPathname === sourcePathAndSearch)) return false;
						return true;
					}) : [];
					const hasSupplementalRefresh = persistedRefreshInterceptions.length > 0 || persistedSourcePageRefreshes.length > 0;
					if (navigationKind === "refresh") historyController.syncCurrentHistoryStatePreviousNextUrl(requestPreviousNextUrl, getBrowserRouterState().bfcacheIds, resolveActiveRoutePaths(getBrowserRouterState().slotBindings));
					setPendingPathname(url.pathname, navId);
					const usesInitialNavigationCachePolicy = navigationKind === "navigate" && currentHref === href && redirectCount === redirectDepth && initialBypassNavigationCache !== void 0;
					const earlyIntentDecision = navigationKind === "navigate" && !usesInitialNavigationCachePolicy ? navigationPlanner.classifyEarlyNavigationIntent({
						basePath: __basePath,
						currentUrlSpace: "appRelativeSnapshot",
						currentHref: clientNavigationSnapshotHref(navigationInitiationState.navigationSnapshot),
						mode: "push",
						scroll: false,
						targetHref: url.href
					}) : null;
					const shouldBypassNavigationCache = usesInitialNavigationCachePolicy ? initialBypassNavigationCache : earlyIntentDecision?.kind === "flightNavigation" && earlyIntentDecision.bypassNavigationCache;
					const requestHeaders = createRscRequestHeaders({
						fetchPriority: "auto",
						interceptionContext: requestInterceptionContext,
						mountedSlotsHeader,
						routerState: {
							pathAndSearch: createSnapshotPathAndSearch(navigationInitiationState.navigationSnapshot),
							routeId: navigationInitiationState.routeId
						}
					});
					const rewrittenNavigationHref = navigationKind === "navigate" && HAS_CLIENT_REWRITES ? resolveLoadedHybridClientRewriteHref(currentHref, __basePath) : null;
					const targetPathAndSearch = formatRscRequestPath(url);
					const additionalPrefetchPathAndSearch = rewrittenNavigationHref && rewrittenNavigationHref !== currentHref ? [rewrittenNavigationHref] : [];
					const settledPrefetchedResponse = peekSettledPrefetchResponseForNavigation({
						additionalRscUrls: additionalPrefetchPathAndSearch,
						bypassNavigationCache: shouldBypassNavigationCache,
						interceptionContext: requestInterceptionContext,
						mountedSlotsHeader,
						navigationKind,
						targetPathAndSearch
					});
					const rscUrl = settledPrefetchedResponse ? resolvePrefetchNavigationResponseUrl({
						additionalRscUrls: additionalPrefetchPathAndSearch,
						origin: window.location.origin,
						responseUrl: settledPrefetchedResponse.url,
						visibleRscUrl: targetPathAndSearch
					}) : await createRscRequestUrl(targetPathAndSearch, requestHeaders);
					const additionalPrefetchRscUrls = settledPrefetchedResponse ? additionalPrefetchPathAndSearch : await Promise.all(additionalPrefetchPathAndSearch.map((href) => createRscRequestUrl(href, requestHeaders)));
					const visitedResponseCandidate = shouldBypassNavigationCache ? {
						cacheKey: AppElementsWire.encodeCacheKey(rscUrl, requestInterceptionContext),
						entry: null,
						facts: {
							candidate: "missing",
							navigationKind
						}
					} : readVisitedResponseCacheCandidate(rscUrl, requestInterceptionContext, mountedSlotsHeader, navigationKind);
					const cachedRoute = applyVisitedResponseCacheCandidateDecision(visitedResponseCandidate, navigationPlanner.classifyVisitedResponseCacheCandidate(visitedResponseCandidate.facts));
					const visitedResponse = cachedRoute === null ? { status: "unavailable" } : { status: "available" };
					const prefetchProbeDecision = navigationPlanner.classifyNavigationPrefetchProbe({
						bypassNavigationCache: shouldBypassNavigationCache,
						navigationKind,
						visitedResponse
					});
					let routeManifest = navigationKind === "navigate" ? getBrowserRouteManifest() : null;
					const hasPrefetchCandidate = settledPrefetchedResponse !== null || prefetchProbeDecision.kind === "probe" && hasPrefetchCacheEntryForNavigation(rscUrl, requestInterceptionContext, mountedSlotsHeader, {
						additionalRscUrls: additionalPrefetchRscUrls,
						notifyInvalidation: false
					});
					const reuseDecision = navigationPlanner.classifyNavigationReuse({
						bypassNavigationCache: shouldBypassNavigationCache,
						navigationKind,
						optimisticRouteShell: routeManifest === null ? {
							reason: "routeManifestMissing",
							status: "unavailable"
						} : { status: "available" },
						prefetch: hasPrefetchCandidate ? { status: "available" } : { status: "unavailable" },
						targetHref: currentHref,
						visitedResponse
					});
					if (reuseDecision.kind === "reuseVisitedResponse" && cachedRoute) {
						const cachedFetchDecision = navigationPlanner.classifyRscFetchResult({
							clientCompatibilityId: clientRscCompatibilityId,
							compatibilityIdHeader: cachedRoute.response.compatibilityIdHeader ?? null,
							currentHref,
							effectiveHistoryUpdateMode: currentHistoryMode ?? "replace",
							hasBody: true,
							isRscContentType: true,
							origin: window.location.origin,
							redirectDepth: redirectCount,
							requestPreviousNextUrl,
							responseOk: true,
							responseUrl: IS_STATIC_EXPORT ? currentHref : cachedRoute.response.url,
							source: "cached",
							streamedRedirectTarget: null
						});
						if (cachedFetchDecision.kind === "hardNavigate") {
							if (cachedFetchDecision.reason === "redirectDepthExhausted") console.error("[vinext] Too many RSC redirects — aborting navigation to prevent infinite loop.");
							performHardNavigationForScrollIntent(cachedFetchDecision.url);
							return;
						}
						if (cachedFetchDecision.kind === "followRedirect") {
							if (navigationKind === "traverse") restoredBfcacheIds = null;
							currentHref = cachedFetchDecision.redirect.href;
							currentHistoryMode = cachedFetchDecision.redirect.historyUpdateMode;
							currentPrevNextUrl = cachedFetchDecision.redirect.previousNextUrl;
							redirectCount = cachedFetchDecision.redirect.redirectDepth;
							continue;
						}
						if (!browserNavigationController.isCurrentNavigation(navId)) return;
						const cachedParams = cachedRoute.params;
						const cachedNavigationSnapshot = createClientNavigationRenderSnapshot(currentHref, cachedParams, cachedRoute.response.renderedPathAndSearch);
						const cachedPayload = cachedRoute.elements ? Promise.resolve(cachedRoute.elements) : decodeAppElementsPromise(createFromFetch(Promise.resolve(restoreRscResponse(cachedRoute.response))));
						if (!browserNavigationController.isCurrentNavigation(navId)) return;
						const cachedRenderOutcome = await renderNavigationPayload({
							actionType: toActionType(navigationKind),
							historyUpdateMode: currentHistoryMode,
							navigationCommitKind: detachedNavigationCommits ? "authoritative" : void 0,
							navigationInitiationState,
							navigationSnapshot: cachedNavigationSnapshot,
							navId,
							operationLane: toOperationLane(navigationKind),
							params: cachedParams,
							payload: keepOptimisticShellMetadata(cachedPayload),
							payloadOrigin: cachedRoute.elements ? COMMITTED_CACHE_APP_NAVIGATION_PAYLOAD_ORIGIN : VISITED_CACHE_APP_NAVIGATION_PAYLOAD_ORIGIN,
							pendingRouterState: detachedNavigationCommits ? null : pendingRouterState,
							previousNextUrl: requestPreviousNextUrl,
							restoredBfcacheIds,
							reuseCurrentBfcacheIds,
							scrollIntent,
							targetHref: currentHref,
							traversalIntent: activeTraversalIntent,
							visibleCommitMode
						});
						if (cachedRenderOutcome === "hard-navigate") {
							startedHardNavigation = true;
							browserNavigationController.abandonPendingBrowserRouterState(pendingRouterState);
						}
						if (cachedRenderOutcome === "no-commit") {
							if (!browserNavigationController.isCurrentNavigation(navId)) return;
							deleteVisitedResponse(rscUrl, requestInterceptionContext);
							continue;
						}
						return;
					}
					let navResponse;
					let navResponseExpiresAt;
					let navResponseUrl = null;
					let consumedPrefetchSnapshot;
					let prefetchedElements;
					let fallbackReuseDecision = reuseDecision;
					if (reuseDecision.kind === "consumePrefetch") {
						const prefetchedResponse = settledPrefetchedResponse ? consumePrefetchResponse(targetPathAndSearch, requestInterceptionContext, mountedSlotsHeader, { additionalRscUrls: additionalPrefetchPathAndSearch }) : await consumePrefetchResponseForNavigation(rscUrl, requestInterceptionContext, mountedSlotsHeader, {
							additionalRscUrls: additionalPrefetchRscUrls,
							shouldConsume: () => browserNavigationController.isCurrentNavigation(navId)
						});
						if (!browserNavigationController.isCurrentNavigation(navId)) return;
						if (prefetchedResponse) {
							navResponse = restoreRscResponse(prefetchedResponse, false);
							navResponseUrl = resolvePrefetchNavigationResponseUrl({
								additionalRscUrls: additionalPrefetchRscUrls,
								origin: window.location.origin,
								responseUrl: prefetchedResponse.url,
								visibleRscUrl: rscUrl
							});
							const publication = prepareConsumedPrefetchResponseForPublication(prefetchedResponse, navResponseUrl);
							consumedPrefetchSnapshot = publication.snapshot;
							prefetchedElements = publication.preparedElements;
							navResponseExpiresAt = publication.expiresAt;
						}
						if (!navResponse) {
							routeManifest = navigationKind === "navigate" ? getBrowserRouteManifest() : null;
							fallbackReuseDecision = navigationPlanner.classifyNavigationReuse({
								bypassNavigationCache: shouldBypassNavigationCache,
								navigationKind,
								optimisticRouteShell: routeManifest === null ? {
									reason: "routeManifestMissing",
									status: "unavailable"
								} : { status: "available" },
								prefetch: { status: "unavailable" },
								targetHref: currentHref,
								visitedResponse: { status: "unavailable" }
							});
						}
					}
					if (!navResponse && fallbackReuseDecision.kind === "attemptOptimisticRouteShell") {
						await learnOptimisticRouteTemplatesFromPrefetchCache({
							interceptionContext: requestInterceptionContext,
							mountedSlotsHeader,
							routeManifest
						});
						if (!browserNavigationController.isCurrentNavigation(navId)) return;
						if (routeManifest !== null) {
							const optimisticPayload = resolveOptimisticNavigationPayload({
								basePath: __basePath,
								href: currentHref,
								interceptionContext: requestInterceptionContext,
								mountedSlotsHeader,
								routeManifest,
								templates: optimisticRouteTemplates.templates
							});
							if (optimisticPayload !== null && canCommitOptimisticRouteTemplate({
								currentElements: navigationInitiationState.elements,
								currentLayoutIds: navigationInitiationState.layoutIds,
								currentParams: navigationInitiationState.navigationSnapshot.params,
								routeManifest,
								targetRouteParams: optimisticPayload.routeParams,
								targetUrlParts: optimisticPayload.urlParts,
								template: optimisticPayload.template
							})) {
								detachedNavigationCommits = true;
								optimisticShellElements = optimisticPayload.elements;
								const optimisticNavigationSnapshot = createClientNavigationRenderSnapshot(currentHref, optimisticPayload.params);
								renderNavigationPayload({
									actionType: toActionType(navigationKind),
									historyUpdateMode: currentHistoryMode,
									navigationCommitKind: "detached",
									navigationInitiationState,
									navigationSnapshot: optimisticNavigationSnapshot,
									navId,
									operationLane: toOperationLane(navigationKind),
									params: optimisticPayload.params,
									payload: Promise.resolve(optimisticPayload.elements),
									payloadOrigin: FRESH_APP_NAVIGATION_PAYLOAD_ORIGIN,
									pendingRouterState: null,
									previousNextUrl: requestPreviousNextUrl,
									restoredBfcacheIds,
									reuseCurrentBfcacheIds,
									scrollIntent,
									targetHref: currentHref,
									traversalIntent: activeTraversalIntent,
									visibleCommitMode
								}).catch((error) => {
									if (browserNavigationController.isCurrentNavigation(navId)) console.error("[vinext] Optimistic RSC navigation error:", error);
								});
							}
						}
					}
					let sentMountedLayouts = false;
					if (!navResponse) {
						let liveRequestHeaders = requestHeaders;
						if (mountedLayoutsHeader !== null && requestInterceptionContext === null) {
							liveRequestHeaders = new Headers(requestHeaders);
							liveRequestHeaders.set(VINEXT_MOUNTED_LAYOUTS_HEADER, mountedLayoutsHeader);
							sentMountedLayouts = true;
						}
						navResponse = await fetch(rscUrl, {
							headers: liveRequestHeaders,
							credentials: "include",
							priority: "auto",
							signal: navigationAbortHandle.signal
						});
					}
					if (!browserNavigationController.isCurrentNavigation(navId)) return;
					const navContentType = navResponse.headers.get("content-type") ?? "";
					const isNavigationRscContentType = navContentType.startsWith("text/x-component") || IS_STATIC_EXPORT && navContentType.startsWith("text/plain");
					const navigationResponseUrl = IS_STATIC_EXPORT ? currentHref : navResponseUrl ?? navResponse.url;
					const streamedRedirectTarget = navResponse.headers.get(VINEXT_RSC_REDIRECT_HEADER);
					const streamedRedirectTypeHeader = navResponse.headers.get(VINEXT_RSC_REDIRECT_TYPE_HEADER);
					const streamedRedirectType = streamedRedirectTypeHeader === "push" || streamedRedirectTypeHeader === "replace" ? streamedRedirectTypeHeader : null;
					if (blockDangerousStreamedRscRedirect(navResponse, streamedRedirectTarget)) return;
					const liveFetchDecision = navigationPlanner.classifyRscFetchResult({
						clientCompatibilityId: clientRscCompatibilityId,
						compatibilityIdHeader: navResponse.headers.get(VINEXT_RSC_COMPATIBILITY_ID_HEADER),
						currentHref,
						effectiveHistoryUpdateMode: currentHistoryMode ?? "replace",
						hasBody: navResponse.body !== null,
						isRscContentType: isNavigationRscContentType,
						origin: window.location.origin,
						redirectDepth: redirectCount,
						requestPreviousNextUrl,
						responseOk: navResponse.ok,
						responseUrl: navigationResponseUrl,
						source: "live",
						streamedRedirectTarget,
						streamedRedirectType
					});
					if (liveFetchDecision.kind === "hardNavigate") {
						if (liveFetchDecision.discardBody) navResponse.body?.cancel().catch(() => {});
						if (liveFetchDecision.reason === "redirectDepthExhausted") console.error("[vinext] Too many RSC redirects — aborting navigation to prevent infinite loop.");
						if (liveFetchDecision.reason === "streamedRedirectLoop") console.error("[vinext] RSC streamed redirect resolved to the current URL — aborting navigation to prevent infinite loop.");
						performHardNavigationForScrollIntent(liveFetchDecision.url, liveFetchDecision.hardNavigationMode);
						return;
					}
					if (liveFetchDecision.kind === "followRedirect") {
						if (liveFetchDecision.discardBody) navResponse.body?.cancel().catch(() => {});
						if (navigationKind === "traverse") restoredBfcacheIds = null;
						currentHref = liveFetchDecision.redirect.href;
						currentHistoryMode = liveFetchDecision.redirect.historyUpdateMode;
						currentPrevNextUrl = liveFetchDecision.redirect.previousNextUrl;
						redirectCount = liveFetchDecision.redirect.redirectDepth;
						continue;
					}
					if (!hasSupplementalRefresh) navigationAbortHandle.release();
					const navParams = parseEncodedJsonHeader(navResponse.headers.get("X-Vinext-Params")) ?? (IS_STATIC_EXPORT ? resolveStaticExportRouteParams(currentHref) : {});
					const navigationSnapshot = createClientNavigationRenderSnapshot(currentHref, navParams, parseRenderedPathAndSearchHeader(navResponse.headers.get(VINEXT_RENDERED_PATH_AND_SEARCH_HEADER)));
					const navBody = navResponse.body;
					if (!navBody) return;
					const [reactBranch, cacheBranch] = navBody.tee();
					const reactResponse = stripRscCompletionMetadataResponse(new Response(reactBranch, {
						status: navResponse.status,
						headers: navResponse.headers
					}));
					const cacheBufferPromise = new Response(cacheBranch).arrayBuffer();
					cacheBufferPromise.catch(() => {});
					if (!browserNavigationController.isCurrentNavigation(navId)) return;
					if (prefetchedElements) reactResponse.body?.cancel().catch(() => {});
					let rscPayload = prefetchedElements ? prefetchedElements : decodeAppElementsPromise(createFromFetch(Promise.resolve(reactResponse)));
					if (hasSupplementalRefresh) {
						const supplemental = persistedRefreshInterceptions.map((interception) => (signal) => fetchPersistedInterceptedSlotRefresh({
							interceptionContext: interception.interceptionContext,
							interceptionId: interception.interception.id,
							mountedSlotsHeader,
							signal,
							targetPathname: interception.targetPathname
						}));
						for (const persistedSourcePageRefresh of persistedSourcePageRefreshes) supplemental.push((signal) => fetchPersistedSourcePageRefresh({
							mountedSlotsHeader,
							signal,
							targetPathname: persistedSourcePageRefresh
						}));
						rscPayload = resolveSupplementalRefreshes({
							merge: mergeRefreshedParallelSlot,
							primary: Promise.resolve(rscPayload),
							signal: navigationAbortHandle.signal,
							supplemental
						}).finally(() => {
							navigationAbortHandle.release();
						}).then(requireCompleteSupplementalRefresh);
					}
					if (sentMountedLayouts) {
						const elements = await rscPayload;
						if (!browserNavigationController.isCurrentNavigation(navId)) return;
						if (!holdsSkippedLayouts(navigationInitiationState, elements) || !holdsSkippedLayouts(getBrowserRouterState(), elements)) {
							mountedLayoutsHeader = null;
							continue;
						}
						rscPayload = Promise.resolve(elements);
					}
					if (IS_STATIC_EXPORT) {
						const staticExportElements = await rscPayload;
						if (!browserNavigationController.isCurrentNavigation(navId)) return;
						if (!isStaticExportPayloadDeploymentCompatible(staticExportElements)) {
							performHardNavigationForScrollIntent(currentHref);
							return;
						}
						rscPayload = Promise.resolve(staticExportElements);
					}
					if (!browserNavigationController.isCurrentNavigation(navId)) return;
					let committedState = null;
					const renderOutcome = await renderNavigationPayload({
						actionType: toActionType(navigationKind),
						historyUpdateMode: currentHistoryMode,
						navigationCommitKind: detachedNavigationCommits ? "authoritative" : void 0,
						navigationInitiationState,
						navigationSnapshot,
						navigationResponseCompletion: shouldRecoverSamePathSearchCommitOnResponseCompletion({
							basePath: __basePath,
							currentSnapshot: navigationInitiationState.navigationSnapshot,
							navigationKind,
							programmaticTransition,
							targetUrl: url
						}) ? cacheBufferPromise : void 0,
						navId,
						onCommittedState: (state) => {
							committedState = state;
							navigationAbortHandle.release();
						},
						operationLane: toOperationLane(navigationKind),
						params: navParams,
						payload: keepOptimisticShellMetadata(rscPayload),
						payloadOrigin: FRESH_APP_NAVIGATION_PAYLOAD_ORIGIN,
						pendingRouterState: detachedNavigationCommits ? null : pendingRouterState,
						previousNextUrl: requestPreviousNextUrl,
						restoredBfcacheIds,
						reuseCurrentBfcacheIds,
						scrollIntent,
						targetHref: currentHref,
						traversalIntent: activeTraversalIntent,
						visibleCommitMode
					});
					if (renderOutcome === "hard-navigate") {
						startedHardNavigation = true;
						browserNavigationController.abandonPendingBrowserRouterState(pendingRouterState);
					}
					if (renderOutcome !== "committed") return;
					if (hasSupplementalRefresh) {
						clearVisitedResponseCache();
						return;
					}
					committedState ??= getBrowserRouterState();
					try {
						const renderedElements = await rscPayload;
						if (navigationCacheGeneration !== clientNavigationCacheGeneration) return;
						const metadata = AppElementsWire.readMetadata(renderedElements);
						if (navigationCacheGeneration !== clientNavigationCacheGeneration) return;
						const responseSnapshot = consumedPrefetchSnapshot ?? createCachedRscResponseSnapshot(navResponse, await cacheBufferPromise, navigationResponseUrl);
						const cacheRestorable = !(responseSnapshot.completedDynamicStaleTimeSeconds !== void 0) && isCacheRestorableAppPayloadMetadata(metadata);
						const { completedDynamicStaleTimeSeconds: _staticCompletedDynamicStaleTime, dynamicStaleTimeSeconds: _staticDynamicStaleTime, ...staticResponseSnapshot } = responseSnapshot;
						const snapshot = {
							...cacheRestorable ? staticResponseSnapshot : {
								...responseSnapshot,
								...responseSnapshot.dynamicStaleTimeSeconds === void 0 && metadata.dynamicStaleTimeSeconds !== void 0 ? { dynamicStaleTimeSeconds: metadata.dynamicStaleTimeSeconds } : {}
							},
							mountedSlotsHeader: getMountedSlotIdsHeader(renderedElements)
						};
						const prefetchSnapshot = preserveCommittedPrefetchExpiry(snapshot, navResponseExpiresAt);
						const interceptionContext = resolveVisitedResponseInterceptionContext(requestInterceptionContext, metadata.interceptionContext);
						if (cacheRestorable) {
							if (navigationCacheGeneration !== clientNavigationCacheGeneration) return;
							storeVisitedResponseSnapshot(rscUrl, interceptionContext, snapshot, navParams, PREFETCH_CACHE_TTL, mountedSlotsHeader, void 0, true, prefetchSnapshot, true);
						} else {
							const state = committedState;
							const committedElements = {
								...state.elements,
								[AppElementsWire.keys.layoutIds]: state.layoutIds,
								[AppElementsWire.keys.skippedLayoutIds]: [],
								[AppElementsWire.keys.slotBindings]: state.slotBindings
							};
							if (navigationCacheGeneration !== clientNavigationCacheGeneration) return;
							storeVisitedResponseSnapshot(rscUrl, interceptionContext, snapshot, navParams, DYNAMIC_NAVIGATION_CACHE_TTL, mountedSlotsHeader, committedElements, isCompleteAppPayloadMetadata(metadata), prefetchSnapshot, interceptionContext !== null || hasNavigationResponseHistoryLifetime(snapshot));
						}
					} catch {}
					return;
				}
			} catch (error) {
				if (!browserNavigationController.isCurrentNavigation(navId)) return;
				if (!isPageUnloading) console.error("[vinext] RSC navigation error:", error);
				performHardNavigationForScrollIntent(navigationPlanner.classifyRscNavigationError({ currentHref }).url);
			} finally {
				navigationAbortHandle.release();
				browserNavigationController.finalizeNavigation(navId, pendingRouterState);
				discardedServerActionRefreshScheduler.markNavigationSettled();
				releaseNavigationInFlight();
				if (startedHardNavigation) await waitForMpaNavigationRestore();
			}
		},
		readVisitedResponseForFullPrefetch: (rscUrls, interceptionContext, mountedSlotsHeader) => findVisitedResponseForFullPrefetch(visitedResponseCache, rscUrls, interceptionContext, mountedSlotsHeader),
		preparePrefetchResponse: (response) => {
			if (!isRscResponseCompatible(response.headers.get("X-Vinext-RSC-Compatibility-Id"))) return Promise.reject(/* @__PURE__ */ new Error("[vinext] Prefetched another deployment's payload"));
			return decodeAppElementsPromise(createFromFetch(Promise.resolve(response)));
		},
		claimCurrentHistoryTreeSnapshot: (historyUpdateMode, previousHistoryState) => historyController.claimCurrentHistoryTreeSnapshot(historyUpdateMode, previousHistoryState),
		commitAppOwnedHistoryStateWrite: (historyUpdateMode, previousHistoryState) => historyController.commitAppOwnedHistoryStateWrite(historyUpdateMode, previousHistoryState),
		discardPendingNavigation: () => {
			if (browserNavigationController.discardPendingNavigation(historyController.readCurrentTreeSnapshot())) navigationAbortCoordinator.abortActive();
		},
		flushCommittingNavigationUrl: () => browserNavigationController.flushCommittingNavigationUrl()
	});
	const handlePopstate = createPopstateRestoreHandler({
		getActiveNavigationId: browserNavigationController.getActiveNavigationId.bind(browserNavigationController),
		getPendingNavigation: () => window.__VINEXT_RSC_PENDING__,
		getNavigate: () => getNavigationRuntime()?.functions.navigate,
		isCurrentNavigation: browserNavigationController.isCurrentNavigation.bind(browserNavigationController),
		notifyAppRouterTransitionStart: (href) => {
			notifyAppRouterTransitionStart(href, "traverse");
		},
		restorePopstateScrollPosition,
		setPendingNavigation: (pendingNavigation) => {
			window.__VINEXT_RSC_PENDING__ = pendingNavigation;
		},
		shouldSkipScrollRestore: (navId) => synchronousPopstateScrollRestoreNavigationId === navId
	});
	window.addEventListener("popstate", (event) => {
		const href = window.location.href;
		const isExternalHistoryEntry = isExternalHistoryState(event.state);
		if (shouldCommitPopstateUrlWithoutNavigation({
			historyState: event.state,
			isCurrentExternalHistoryTree: historyController.isCurrentExternalHistoryTree(event.state),
			isSameAppRouteTarget: isSameAppRoutePopstateTarget(href)
		})) {
			notifyAppRouterTransitionStart(href, "traverse");
			historyController.commitTraversalIndexFromHistoryState(event.state);
			commitClientNavigationState();
			restorePopstateScrollPosition(event.state);
			return;
		}
		const snapshotNavigationId = browserNavigationController.beginNavigation();
		if (restoreHistoryStateSnapshot(event.state, snapshotNavigationId, () => {
			navigationAbortCoordinator.abortActive();
			notifyAppRouterTransitionStart(href, "traverse");
		}, isExternalHistoryEntry)) {
			window.__VINEXT_RSC_PENDING__ = null;
			restoreSynchronousPopstateScrollPosition({
				getActiveNavigationId: () => browserNavigationController.getActiveNavigationId(),
				isCurrentNavigation: (navId) => browserNavigationController.isCurrentNavigation(navId),
				markScrollRestoreConsumed: (navId) => {
					synchronousPopstateScrollRestoreNavigationId = navId;
				},
				restorePopstateScrollPosition
			}, event.state);
			browserNavigationController.finalizeNavigation(snapshotNavigationId, null);
			return;
		}
		browserNavigationController.finalizeNavigation(snapshotNavigationId, null);
		handlePopstate(event);
	});
	if (import.meta.env.DEV && import.meta.hot) {
		const applyRscHmrUpdate = async (updateId) => {
			if (updateId !== latestRscHmrUpdateId) return;
			if (document.documentElement.id === "__next_error__") {
				window.location.reload();
				return;
			}
			if (browserRouterStateHasEverCommitted && !browserNavigationController.hasBrowserRouterState()) {
				window.location.reload();
				return;
			}
			await waitForBrowserRouterStateReady();
			if (updateId !== latestRscHmrUpdateId) return;
			if (!browserNavigationController.hasBrowserRouterState()) return;
			clearClientNavigationCaches();
			devErrorOverlay?.dismissOverlay();
			const hmrHeaders = createRscRequestHeaders({ mountedSlotsHeader: getMountedSlotIdsHeader(browserNavigationController.getBrowserRouterState().elements) });
			const hmrHref = window.location.href;
			const hmrParams = latestClientParams;
			const sameQuerySnapshot = withRenderedSearchOf(createClientNavigationRenderSnapshot(hmrHref, hmrParams), browserNavigationController.getBrowserRouterState().navigationSnapshot);
			const hmrResponse = fetch(await createRscRequestUrl(window.location.pathname + window.location.search, hmrHeaders), { headers: hmrHeaders });
			await browserNavigationController.hmrReplaceTree(decodeAppElementsPromise(createFromFetch(hmrResponse.then(stripRscCompletionMetadataResponse))), hmrResponse.then((response) => {
				const renderedPathAndSearch = parseRenderedPathAndSearchHeader(response.headers.get(VINEXT_RENDERED_PATH_AND_SEARCH_HEADER));
				return renderedPathAndSearch === null ? sameQuerySnapshot : createClientNavigationRenderSnapshot(hmrHref, hmrParams, renderedPathAndSearch);
			}));
		};
		const handleRscUpdate = async (updateId) => {
			try {
				await waitForRscHmrSettle();
				await applyRscHmrUpdate(updateId);
			} catch (error) {
				console.error("[vinext] RSC HMR error:", error);
			}
		};
		import.meta.hot.on("rsc:update", () => {
			const updateId = ++latestRscHmrUpdateId;
			handleRscUpdate(updateId);
		});
	}
}
if (typeof document !== "undefined") {
	installWindowNext({
		appDir: true,
		router: appRouterInstance
	});
	window.addEventListener("pagehide", () => {
		isPageUnloading = true;
	});
	window.addEventListener("pageshow", (event) => {
		isPageUnloading = false;
		if (event.persisted) {
			mpaNavigationScheduler.reset();
			mpaNavigationTree?.restore();
			mpaNavigationRestore?.resolve();
			mpaNavigationRestore = null;
		}
	});
	main();
}
//#endregion
export {};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyx1QkFBdUIscUJBQXFCO0FBQ3JELFNBQVMsK0JBQStCLHNCQUFzQix3Q0FBd0MsNEJBQTRCLHVDQUF1QztBQUN6SyxTQUFTLGtDQUFrQztBQUMzQyxTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLG1CQUFtQix1Q0FBdUM7QUFDbkUsU0FBUyxlQUFlLHFDQUFxQztBQUM3RCxTQUFTLG9DQUFvQyx5QkFBeUIseUJBQXlCLHFCQUFxQixzQkFBc0Isc0NBQXNDO0FBQ2hMLFNBQVMsaUNBQWlDLDRDQUE0QztBQUN0RixTQUFTLHNDQUFzQztBQUMvQyxPQUFPO0FBQ1AsU0FBUyw0Q0FBNEMsc0JBQXNCLG9DQUFvQyxvQ0FBb0MsMENBQTBDO0FBQzdMLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMseUJBQXlCLGlEQUFpRDtBQUNuRixTQUFTLGlDQUFpQyxpQ0FBaUM7QUFDM0UsU0FBUyw2Q0FBNkMsc0NBQXNDLHdDQUF3QztBQUNwSSxTQUFTLDhDQUE4Qyw2REFBNkQ7QUFDcEgsU0FBUyx3QkFBd0Isa0NBQWtDLGlDQUFpQywrQkFBK0I7QUFDbkksU0FBUyx3Q0FBd0M7QUFDakQsU0FBUywwQ0FBMEM7QUFDbkQsU0FBUyx5Q0FBeUM7QUFDbEQsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxxQkFBcUIsdUJBQXVCO0FBQ3JELFNBQVMsNEJBQTRCLG9DQUFvQztBQUN6RSxTQUFTLHdCQUF3QixzQkFBc0IsNEJBQTRCO0FBQ25GLFNBQVMsOEJBQThCLG9CQUFvQixZQUFZLG1CQUFtQiw2QkFBNkIseUJBQXlCLHNDQUFzQyxpQ0FBaUMsc0NBQXNDLDZCQUE2QixnQ0FBZ0MsNkNBQTZDLGtDQUFrQyx1QkFBdUIsa0JBQWtCLG9DQUFvQyxnQ0FBZ0MseUJBQXlCLHFDQUFxQyxrQ0FBa0MsK0JBQStCLCtCQUErQixrQ0FBa0Msa0NBQWtDLHNDQUFzQyw2Q0FBNkMsb0JBQW9CLG9CQUFvQiw4QkFBOEIsaUJBQWlCLHVCQUF1QixvQkFBb0Isa0NBQWtDLGlCQUFpQjtBQUNoK0IsU0FBUyxxQ0FBcUM7QUFDOUMsU0FBUyx3QkFBd0IsNEJBQTRCLDhCQUE4QjtBQUMzRixTQUFTLDRCQUE0QiwyQkFBMkI7QUFDaEUsU0FBUywyQkFBMkIsK0JBQStCLG9DQUFvQztBQUN2RyxTQUFTLCtDQUErQyxxQ0FBcUMsNkNBQTZDLHFDQUFxQyw4QkFBOEIscURBQXFEO0FBQ2xRLFNBQVMsOEJBQThCLHNDQUFzQyxxQ0FBcUMsZ0NBQWdDO0FBQ2xKLFNBQVMsMEJBQTBCO0FBQ25DLFNBQVMsNkRBQTZEO0FBQ3RFLFNBQVMsc0NBQXNDLDRCQUE0QixvQ0FBb0MscUNBQXFDLHdDQUF3QyxvQ0FBb0M7QUFDaE8sU0FBUyxrREFBa0Q7QUFDM0QsU0FBUyx5QkFBeUIsZ0NBQWdDLHlCQUF5Qix1Q0FBdUM7QUFDbEksU0FBUyxtQ0FBbUM7QUFDNUMsU0FBUyxpQ0FBaUMsc0NBQXNDLGlDQUFpQywrQkFBK0Isb0NBQW9DLHNDQUFzQyxrQ0FBa0MsMkNBQTJDO0FBQ3ZTLFNBQVMsOEJBQThCLDBDQUEwQyxnREFBZ0Q7QUFDakksT0FBTyx3QkFBd0I7QUFDL0IsU0FBUyxxQkFBcUIscUJBQXFCLHdCQUF3QjtBQUMzRSxTQUFTLHdCQUF3Qix1QkFBdUIseUJBQXlCLG9DQUFvQztBQUNySCxTQUFTLHVDQUF1QztBQUNoRCxTQUFTLDBDQUEwQywrQ0FBK0MsaUNBQWlDLDRDQUE0QztBQUMvSyxTQUFTLGtDQUFrQywrQkFBK0Isb0NBQW9DLGdDQUFnQywrQkFBK0IsaUNBQWlDLDBDQUEwQywwQ0FBMEM7QUFDbFMsU0FBUywrQ0FBK0M7QUFDeEQsU0FBUyxVQUFVLGVBQWUsaUJBQWlCLEtBQUssV0FBVyxpQkFBaUIsU0FBUyxRQUFRLGdCQUFnQjtBQUNySCxTQUFTLFlBQVksbUJBQW1CO0FBQ3hDLFNBQVMsaUJBQWlCLDBCQUEwQix5QkFBeUI7QUFDN0UsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxrQkFBa0IsOEJBQThCOztBQUV6RCxNQUFNLHNCQUFzQixRQUFRLElBQUksaUNBQWlDO0FBQ3pFLFNBQVMsYUFBYSxNQUFNO0NBQzNCLE9BQU8sU0FBUyxhQUFhLGFBQWE7QUFDM0M7QUFDQSxTQUFTLGdCQUFnQixNQUFNO0NBQzlCLFFBQVEsTUFBUjtFQUNDLEtBQUssWUFBWSxPQUFPO0VBQ3hCLEtBQUssV0FBVyxPQUFPO0VBQ3ZCLEtBQUssWUFBWSxPQUFPO0VBQ3hCLFNBQVMsTUFBTSxJQUFJLE1BQU0sdUNBQXVDLE9BQU8sSUFBSSxDQUFDO0NBQzdFO0FBQ0Q7QUFDQSxNQUFNLGtDQUFrQztBQUN4QyxNQUFNLHFDQUE0QyxnQkFBZ0IsUUFBUSxJQUFJLHlCQUF5QjtBQUN2RyxJQUFJLDBCQUEwQjtBQUM5QixJQUFJLDJCQUEyQixtQkFBbUIsT0FBTzs7Ozs7OztBQU96RCxTQUFTLHdCQUF3Qix1QkFBdUI7Q0FDdkQsT0FBTywrQkFBK0IsdUJBQXVCLHdCQUF3QjtBQUN0RjtBQUNBLFNBQVMsNEJBQTRCLGlCQUFpQjtDQUNyRCxJQUFJLG9CQUFvQixDQUFDLGlCQUFpQjtDQUMxQywyQkFBMkI7QUFDNUI7QUFDQSxNQUFNLDJCQUEyQixtQ0FBbUM7QUFDcEUsU0FBUyxpQ0FBaUM7Q0FDekMsSUFBSSxPQUFPLHVCQUF1QixPQUFPLGdDQUFnQyxPQUFPO0NBQ2hGLE9BQU8saUNBQWlDO0NBQ3hDLE9BQU87QUFDUjtBQUNBLFNBQVMsd0NBQXdDO0NBQ2hELE9BQU8saUNBQWlDO0FBQ3pDO0FBQ0EsbUNBQW1DLEVBQUUsbUJBQW1CLGlEQUFpRCxPQUFPLG9DQUFvQyxFQUFFLENBQUM7QUFDdkosU0FBUywwQkFBMEI7Q0FDbEMsT0FBTyxxQkFBcUIsQ0FBQyxFQUFFLFVBQVUsaUJBQWlCO0FBQzNEO0FBQ0EsU0FBUywrQkFBK0IsTUFBTTtDQUM3QyxNQUFNLGdCQUFnQix3QkFBd0I7Q0FDOUMsSUFBSSxrQkFBa0IsTUFBTSxPQUFPLENBQUM7Q0FDcEMsT0FBTyx5Q0FBeUM7RUFDL0MsVUFBVTtFQUNWO0VBQ0E7Q0FDRCxDQUFDLEtBQUssQ0FBQztBQUNSO0FBQ0EsU0FBUywwQ0FBMEMsVUFBVTtDQUM1RCxJQUFJLENBQUMsa0JBQWtCLE9BQU87Q0FDOUIsTUFBTSxvQkFBb0IsZ0JBQWdCLGFBQWEsUUFBUSxDQUFDLENBQUMsc0JBQXNCO0NBQ3ZGLE9BQU8sNEJBQTRCLFFBQVEsc0JBQXNCO0FBQ2xFO0FBQ0EsTUFBTSxvQkFBb0IsSUFBSSw0QkFBNEI7Q0FDekQscUJBQXFCLE9BQU8sUUFBUTtDQUNwQywwQkFBMEI7Q0FDMUIsd0JBQXdCLE9BQU8sUUFBUTtDQUN2Qyx1QkFBdUIsT0FBTyxTQUFTO0NBQ3ZDLG1CQUFtQixPQUFPLE1BQU0sU0FBUyw4QkFBOEIsT0FBTyxJQUFJLE1BQU0sSUFBSTtDQUM1RixzQkFBc0IsT0FBTyxNQUFNLFNBQVMsaUNBQWlDLE9BQU8sSUFBSSxNQUFNLElBQUk7Q0FDbEcscUNBQXFDO0VBQ3BDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxPQUFPO0VBQ3JDLE1BQU0sY0FBYyxzQkFBc0I7RUFDMUMsT0FBTztHQUNOLGtCQUFrQix3QkFBd0IsWUFBWSxZQUFZO0dBQ2xFLFlBQVksWUFBWTtHQUN4QixpQkFBaUIsWUFBWTtFQUM5QjtDQUNEO0FBQ0QsQ0FBQztBQUNELE1BQU0sOEJBQThCLHFDQUFxQztDQUN4RSxVQUFVO0NBQ1Ysa0JBQWtCO0NBQ2xCLG1CQUFtQjtDQUNuQixtQkFBbUIsTUFBTSxTQUFTO0VBQ2pDLElBQUksbUJBQW1CO0dBQ3RCLGtCQUFrQixNQUFNLE1BQU0sU0FBUyxZQUFZLFlBQVksTUFBTTtHQUNyRTtFQUNEO0VBQ0EseUJBQXlCLE1BQU0sSUFBSTtDQUNwQztDQUNBLGtDQUFrQyxpQkFBaUIsZUFBZSxrQkFBa0IsdUNBQXVDLGlCQUFpQixVQUFVO0FBQ3ZKLENBQUM7QUFDRCxNQUFNLHdDQUF3QyxtQkFBbUIsNENBQTRDLEVBQUUsYUFBYTtDQUMzSCw0QkFBNEI7Q0FDNUIscUJBQXFCLENBQUMsRUFBRSxVQUFVLFdBQVcsT0FBTyxTQUFTLE1BQU0sR0FBRyxXQUFXLEtBQUssR0FBRyxLQUFLLEdBQUcsSUFBSTtBQUN0RyxFQUFFLENBQUMsSUFBSTtDQUNOLHdCQUF3QixDQUFDO0NBQ3pCLHNCQUFzQixDQUFDO0NBQ3ZCLFdBQVcsQ0FBQztBQUNiO0FBQ0EsTUFBTSw2Q0FBNkMscUNBQXFDO0FBQ3hGLE1BQU0seUJBQXlCLDRCQUE0QjtBQUMzRCxNQUFNLDBCQUEwQiw0QkFBNEI7QUFDNUQsTUFBTSx3Q0FBd0M7QUFDOUMsU0FBUyxpQ0FBaUMsUUFBUTtDQUNqRCxTQUFTLEtBQUssaUJBQWlCLFFBQVEsc0NBQXNDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsU0FBUyxLQUFLLE9BQU8sQ0FBQztDQUN6SCxJQUFJLFdBQVcsS0FBSztDQUNwQixNQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07Q0FDNUMsT0FBTyxPQUFPO0NBQ2QsT0FBTyxVQUFVO0NBQ2pCLE9BQU8sYUFBYSx1Q0FBdUMsUUFBUTtDQUNuRSxTQUFTLEtBQUssWUFBWSxNQUFNO0FBQ2pDO0FBQ0EsTUFBTSxzQkFBc0IsdUJBQXVCO0FBQ25ELFNBQVMsdUJBQXVCLE9BQU87Q0FDdEMsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixJQUFJO0VBQ0gsT0FBTyxLQUFLLE1BQU0sbUJBQW1CLEtBQUssQ0FBQztDQUM1QyxRQUFRO0VBQ1AsT0FBTztDQUNSO0FBQ0Q7QUFDQSxTQUFTLHFCQUFxQixPQUFPO0NBQ3BDLE9BQU8saUJBQWlCO0FBQ3pCO0FBQ0EsSUFBSSxxQkFBcUIsQ0FBQztBQUMxQixNQUFNLHVDQUF1QyxJQUFJLElBQUk7QUFDckQsSUFBSSxrQ0FBa0M7QUFDdEMsSUFBSSxxQ0FBcUM7QUFDekMsSUFBSSw2QkFBNkI7QUFDakMsTUFBTSx5QkFBeUIsSUFBSSxpQ0FBaUM7QUFDcEUsTUFBTSwwQkFBMEIsSUFBSSxjQUFjLENBQUMsQ0FBQztBQUNwRCxJQUFJLG9CQUFvQjtBQUN4QixJQUFJLHVCQUF1QjtBQUMzQixTQUFTLDhCQUE4QjtDQUN0QyxJQUFJLENBQUMsc0JBQXNCO0VBQzFCLElBQUksZ0JBQWdCLENBQUM7RUFDckIsdUJBQXVCO0dBQ3RCLFNBQVMsSUFBSSxTQUFTLG1CQUFtQjtJQUN4QyxVQUFVO0dBQ1gsQ0FBQztHQUNEO0VBQ0Q7Q0FDRDtDQUNBLE9BQU8scUJBQXFCO0FBQzdCO0FBQ0EsTUFBTSwwQkFBMEI7QUFDaEMsTUFBTSxpQ0FBaUM7QUFDdkMsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSwrQ0FBK0M7QUFDbkQsU0FBUyxvQkFBb0IsVUFBVSx5QkFBeUI7Q0FDL0QsT0FBTyxJQUFJLFNBQVMsWUFBWTtFQUMvQixPQUFPLFdBQVcsU0FBUyxPQUFPO0NBQ25DLENBQUM7QUFDRjtBQUNBLFNBQVMsNEJBQTRCLGNBQWMsT0FBTyx3QkFBd0Isb0NBQW9DLE9BQU87Q0FDNUgsSUFBSSxXQUFXO0NBQ2YsZ0JBQWdCO0VBQ2YsV0FBVyxrQkFBa0IsdUJBQXVCO0dBQ25EO0dBQ0Esd0JBQXdCO0dBQ3hCO0dBQ0Esd0JBQXdCLEVBQUUsT0FBTyxtQkFBbUIsNEJBQTRCLG1DQUFtQztJQUNsSDtJQUNBLG9CQUFvQjtLQUNuQix5QkFBeUI7S0FDekIsYUFBYTtJQUNkO0lBQ0E7SUFDQTtJQUNBLFlBQVksT0FBTyxTQUFTO0dBQzdCLENBQUM7RUFDRixDQUFDO0NBQ0YsQ0FBQztDQUNELElBQUksQ0FBQyxVQUFVLE9BQU87Q0FDdEIsbUNBQW1DO0NBQ25DLG9DQUFvQyxvQkFBb0I7Q0FDeEQsNENBQTRDO0NBQzVDLDRCQUE0QixPQUFPLEVBQUUsaUJBQWlCLE1BQU0sQ0FBQztDQUM3RCxPQUFPO0FBQ1I7QUFDQSxTQUFTLHdCQUF3QjtDQUNoQyxPQUFPLDRCQUE0QixzQkFBc0I7QUFDMUQ7QUFDQSxTQUFTLHdCQUF3QjtDQUNoQyxPQUFPLDRCQUE0QixzQkFBc0I7QUFDMUQ7QUFDQSxTQUFTLGlDQUFpQztDQUN6QyxPQUFPLDRCQUE0QiwrQkFBK0I7QUFDbkU7QUFDQSxTQUFTLGlDQUFpQztDQUN6QyxPQUFPLDRCQUE0QiwrQkFBK0I7QUFDbkU7QUFDQSxTQUFTLGtCQUFrQixRQUFRO0NBQ2xDLHFCQUFxQjtDQUNyQixnQkFBZ0IsTUFBTTtBQUN2QjtBQUNBLFNBQVMsa0JBQWtCLFFBQVE7Q0FDbEMscUJBQXFCO0NBQ3JCLGlDQUFpQyxNQUFNO0FBQ3hDO0FBQ0EsU0FBUyw0QkFBNEI7Q0FDcEMscUJBQXFCLE1BQU07Q0FDM0Isb0NBQW9DO0FBQ3JDO0FBQ0EsU0FBUyxtQkFBbUIsU0FBUztDQUNwQyx3QkFBd0IsT0FBTztDQUMvQix5QkFBeUIsTUFBTTtBQUNoQztBQUNBLFNBQVMsNEJBQTRCLFNBQVM7Q0FDN0MsbUNBQW1DO0NBQ25DLDBCQUEwQjtDQUMxQixtQkFBbUIsT0FBTztDQUMxQixrQkFBa0IsZ0NBQWdDO0FBQ25EO0FBQ0EsU0FBUyxxQ0FBcUM7Q0FDN0MsbUNBQW1DO0NBQ25DLDBCQUEwQjtDQUMxQiwrQkFBK0I7Q0FDL0IseUJBQXlCLE1BQU07Q0FDL0Isa0JBQWtCLGdDQUFnQztBQUNuRDtBQUNBLFNBQVMsc0JBQXNCLFlBQVk7Q0FDMUMsT0FBTyxJQUFJLElBQUksWUFBWSxzQkFBc0IsQ0FBQyxDQUFDO0FBQ3BEO0FBQ0EsU0FBUyxxQ0FBcUMsT0FBTyxlQUFlLFlBQVksNEJBQTRCO0NBQzNHLElBQUksa0JBQWtCLE1BQU0sT0FBTyxDQUFDO0NBQ3BDLE1BQU0sa0JBQWtCLGNBQWMsV0FBVyxVQUFVLFVBQVU7Q0FDckUsTUFBTSxtQkFBbUIsMkJBQTJCLGVBQWU7Q0FDbkUsTUFBTSxXQUFXLENBQUM7Q0FDbEIsS0FBSyxNQUFNLFdBQVcsTUFBTSxjQUFjO0VBQ3pDLElBQUksUUFBUSxVQUFVLFlBQVksQ0FBQyxRQUFRLGVBQWU7RUFDMUQsSUFBSSxDQUFDLFFBQVEsa0JBQWtCLENBQUMsUUFBUSw4QkFBOEI7RUFDdEUsTUFBTSxjQUFjLGdCQUFnQixnQkFBZ0IsUUFBUSxhQUFhO0VBQ3pFLElBQUksYUFBYSxTQUFTLFNBQVM7RUFDbkMsTUFBTSxRQUFRLGNBQWMsYUFBYSxjQUFjLElBQUksUUFBUSxjQUFjO0VBQ2pGLElBQUksQ0FBQyxPQUFPO0VBQ1osTUFBTSx1QkFBdUIsTUFBTSxjQUFjLFdBQVcsUUFBUSxVQUFVLGtCQUFrQiwyQkFBMkIsc0JBQXNCLE1BQU0sYUFBYSxnQkFBZ0IsQ0FBQyxHQUFHLE1BQU0sa0JBQWtCLE1BQU0sT0FBTyxNQUFNLGVBQWU7RUFDbFAsTUFBTSxpQkFBaUIsc0JBQXNCLG9CQUFvQixZQUFZO0VBQzdFLE1BQU0sY0FBYywyQkFBMkIsc0JBQXNCLGNBQWMsQ0FBQztFQUNwRixJQUFJLCtCQUErQixRQUFRLE1BQU0sY0FBYyxXQUFXLFFBQVEsVUFBVSxrQkFBa0Isa0JBQWtCLE1BQU0sa0JBQWtCLE1BQU0sUUFBUSxrQkFBa0IsYUFBYSxNQUFNLGtCQUFrQixNQUFNLE1BQU07RUFDek8sTUFBTSxZQUFZLElBQUksSUFBSSxnQkFBZ0IsVUFBVTtFQUNwRCxVQUFVLFdBQVcsc0JBQXNCLFVBQVUsVUFBVSxVQUFVO0VBQ3pFLFVBQVUsU0FBUyxXQUFXO0VBQzlCLFNBQVMsS0FBSztHQUNiLGNBQWM7R0FDZCxxQkFBcUIsc0JBQXNCLG9CQUFvQixRQUFRO0dBQ3ZFLGdCQUFnQixHQUFHLFVBQVUsV0FBVyxVQUFVO0VBQ25ELENBQUM7Q0FDRjtDQUNBLE9BQU87QUFDUjtBQUNBLGVBQWUscUNBQXFDLFNBQVM7Q0FDNUQsTUFBTSxVQUFVLHdCQUF3QjtFQUN2QyxxQkFBcUIsUUFBUTtFQUM3QixnQkFBZ0IsUUFBUTtFQUN4QixvQkFBb0IsUUFBUTtDQUM3QixDQUFDO0NBQ0QsT0FBTywwQkFBMEIsTUFBTSxNQUFNLE1BQU0sb0JBQW9CLFFBQVEsZ0JBQWdCLE9BQU8sR0FBRztFQUN4RyxhQUFhO0VBQ2I7RUFDQSxRQUFRLFFBQVE7Q0FDakIsQ0FBQyxHQUFHLFFBQVEsY0FBYztBQUMzQjtBQUNBLGVBQWUsZ0NBQWdDLFNBQVM7Q0FDdkQsTUFBTSxVQUFVLHdCQUF3QixFQUFFLG9CQUFvQixRQUFRLG1CQUFtQixDQUFDO0NBQzFGLE9BQU8sMEJBQTBCLE1BQU0sTUFBTSxNQUFNLG9CQUFvQixRQUFRLGdCQUFnQixPQUFPLEdBQUc7RUFDeEcsYUFBYTtFQUNiO0VBQ0EsUUFBUSxRQUFRO0NBQ2pCLENBQUMsR0FBRyxRQUFRLGNBQWM7QUFDM0I7Ozs7O0FBS0EsZUFBZSwwQkFBMEIsVUFBVSxnQkFBZ0I7Q0FDbEUsSUFBSSxDQUFDLHdCQUF3QixTQUFTLFFBQVEsSUFBSSwrQkFBK0IsQ0FBQyxHQUFHO0VBQ3BGLFNBQVMsTUFBTSxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUN0QyxNQUFNLElBQUksTUFBTSxpREFBaUQ7Q0FDbEU7Q0FDQSxNQUFNLFdBQVcsTUFBTSx5QkFBeUIsZ0JBQWdCLFFBQVEsUUFBUSxRQUFRLENBQUMsQ0FBQztDQUMxRixNQUFNLHdCQUF3QixpQ0FBaUMsU0FBUyxRQUFRLElBQUksc0NBQXNDLENBQUM7Q0FDM0gsNkJBQTZCLFVBQVUsSUFBSSxJQUFJLHlCQUF5QixnQkFBZ0IsT0FBTyxTQUFTLE1BQU0sQ0FBQyxDQUFDLE1BQU07Q0FDdEgsT0FBTztBQUNSO0FBQ0EsU0FBUyw0QkFBNEIsT0FBTztDQUMzQyxPQUFPLE1BQU0sWUFBWSxrQkFBa0IsTUFBTSxZQUFZLEtBQUssS0FBSyxNQUFNLGFBQWEsS0FBSztBQUNoRztBQUNBLFNBQVMsc0JBQXNCLFVBQVU7Q0FDeEMsTUFBTSxpQkFBaUIsU0FBUyxRQUFRLElBQUk7Q0FDNUMsSUFBSSxtQkFBbUIsQ0FBQyxHQUFHLE9BQU87RUFDakMscUJBQXFCO0VBQ3JCLFFBQVE7Q0FDVDtDQUNBLE9BQU87RUFDTixxQkFBcUIsU0FBUyxNQUFNLGlCQUFpQixDQUFDO0VBQ3RELFFBQVEsU0FBUyxNQUFNLEdBQUcsY0FBYztDQUN6QztBQUNEO0FBQ0EsZUFBZSx5Q0FBeUMsU0FBUztDQUNoRSxNQUFNLFNBQVMsc0JBQXNCLFFBQVEsUUFBUTtDQUNyRCxJQUFJLE9BQU8sd0JBQXdCLFFBQVEscUJBQXFCLE9BQU87Q0FDdkUsSUFBSSw0Q0FBNEMsUUFBUSxLQUFLLE1BQU0sUUFBUSxvQkFBb0IsT0FBTztDQUN0RyxJQUFJLFFBQVEsd0JBQXdCLE1BQU0sT0FBTztDQUNqRCxJQUFJLENBQUMsd0JBQXdCLFFBQVEsTUFBTSxTQUFTLHFCQUFxQixHQUFHLE9BQU87Q0FDbkYsTUFBTSxXQUFXLE1BQU0seUJBQXlCLGdCQUFnQixRQUFRLFFBQVEsbUJBQW1CLFFBQVEsTUFBTSxRQUFRLENBQUMsQ0FBQyxDQUFDO0NBQzVILE1BQU0sV0FBVyw4QkFBOEI7RUFDOUMsbUJBQW1CLFFBQVEsTUFBTSx5QkFBeUI7RUFDMUQsVUFBVTtFQUNWO0VBQ0EsTUFBTSxRQUFRLE1BQU0sU0FBUyxPQUFPLE9BQU87RUFDM0MscUJBQXFCLFFBQVE7RUFDN0Isb0JBQW9CLFFBQVE7RUFDNUIsZUFBZSxRQUFRO0NBQ3hCLENBQUM7Q0FDRCxJQUFJLGFBQWEsTUFBTSxPQUFPO0NBQzlCLE9BQU87RUFDTixLQUFLLDhCQUE4QjtHQUNsQyxxQkFBcUIsUUFBUTtHQUM3QixvQkFBb0IsUUFBUTtHQUM1QixTQUFTLFNBQVM7RUFDbkIsQ0FBQztFQUNEO0NBQ0Q7QUFDRDtBQUNBLGVBQWUsK0NBQStDLFNBQVM7Q0FDdEUsTUFBTSxFQUFFLGtCQUFrQjtDQUMxQixJQUFJLGtCQUFrQixNQUFNO0NBQzVCLE1BQU0sV0FBVyx5QkFBeUIsZ0JBQWdCO0NBQzFELEtBQUssTUFBTSxDQUFDLFVBQVUsVUFBVSxpQkFBaUIsR0FBRztFQUNuRCxNQUFNLFlBQVksK0JBQStCO0dBQ2hEO0dBQ0EscUJBQXFCLFFBQVE7R0FDN0Isb0JBQW9CLFFBQVE7RUFDN0IsQ0FBQztFQUNELElBQUkseUJBQXlCLFVBQVUsU0FBUyxHQUFHO0VBQ25ELElBQUksQ0FBQyw0QkFBNEIsS0FBSyxHQUFHO0VBQ3pDLElBQUksTUFBTSxpQkFBaUIsY0FBYztFQUN6QyxTQUFTLEtBQUsseUJBQXlCLE1BQU0saUJBQWlCLHlDQUF5QztHQUN0RztHQUNBO0dBQ0EscUJBQXFCLFFBQVE7R0FDN0Isb0JBQW9CLFFBQVE7R0FDNUI7RUFDRCxDQUFDLENBQUMsQ0FBQztDQUNKO0NBQ0EsSUFBSSxTQUFTLFdBQVcsR0FBRztDQUMzQixNQUFNLFFBQVEsV0FBVyxRQUFRO0FBQ2xDO0FBQ0EsU0FBUyxpQ0FBaUM7Q0FDekMsTUFBTSxjQUFjLHNCQUFzQjtDQUMxQyxPQUFPLHFDQUFxQztFQUMzQyxNQUFNLE9BQU8sU0FBUztFQUN0QixjQUFjLDRCQUE0QixzQkFBc0I7RUFDaEU7Q0FDRCxDQUFDO0FBQ0Y7QUFDQSxTQUFTLDZCQUE2QixTQUFTO0NBQzlDLE1BQU0sRUFBRSxrQkFBa0IsWUFBWSxNQUFNLG1CQUFtQixPQUFPLFFBQVEsaUJBQWlCLHVCQUF1QjtDQUN0SCxJQUFJLGVBQWU7Q0FDbkIsT0FBTztFQUNOLGFBQWEsRUFBRSxrQkFBa0I7R0FDaEMsSUFBSSxDQUFDLDRCQUE0QixvQkFBb0IsS0FBSyxHQUFHO0dBQzdELGtCQUFrQix3QkFBd0I7SUFDekM7SUFDQTtJQUNBO0lBQ0EsbUJBQW1CLGlCQUFpQixLQUFLLElBQUk7SUFDN0M7SUFDQSx5QkFBeUIsa0JBQWtCLE1BQU07SUFDakQ7R0FDRCxDQUFDO0dBQ0QsZUFBZTtFQUNoQjtFQUNBLFFBQVEsRUFBRSxtQkFBbUI7R0FDNUIsSUFBSSxDQUFDLGNBQWM7SUFDbEIsNEJBQTRCLEtBQUssR0FBRyxFQUFFLGdCQUFnQixDQUFDO0lBQ3ZEO0dBQ0Q7R0FDQSxnQ0FBZ0MsSUFBSTtHQUNwQyw0QkFBNEIsT0FBTyxFQUFFLGdCQUFnQixDQUFDO0VBQ3ZEO0NBQ0Q7QUFDRDtBQUNBLGVBQWUsd0JBQXdCLFNBQVM7Q0FDL0MsaUNBQWlDLElBQUk7Q0FDckMsT0FBTyw0QkFBNEIsd0JBQXdCO0VBQzFELFlBQVksUUFBUSxjQUFjO0VBQ2xDO0VBQ0EsbUJBQW1CLFFBQVE7RUFDM0Isc0JBQXNCLFFBQVE7RUFDOUIsMkJBQTJCLFFBQVE7RUFDbkMsOEJBQThCLFFBQVE7RUFDdEMsb0JBQW9CLFFBQVE7RUFDNUIsT0FBTyxRQUFRO0VBQ2YsY0FBYyxRQUFRO0VBQ3RCLGtCQUFrQixRQUFRO0VBQzFCLGVBQWUsUUFBUSxpQkFBaUI7RUFDeEMsUUFBUSxRQUFRO0VBQ2hCLGVBQWUsUUFBUTtFQUN2QixvQkFBb0IsUUFBUTtFQUM1QixpQkFBaUIsUUFBUTtFQUN6QixvQkFBb0IsUUFBUSxzQkFBc0I7RUFDbEQsd0JBQXdCLFFBQVEsMEJBQTBCO0VBQzFELGNBQWMsUUFBUSxnQkFBZ0I7RUFDdEMsb0JBQW9CLFFBQVEsaUJBQWlCO0VBQzdDLFlBQVksUUFBUTtFQUNwQixtQkFBbUIsUUFBUSxxQkFBcUI7Q0FDakQsQ0FBQztBQUNGO0FBQ0EsZUFBZSw2QkFBNkIsY0FBYyxrQkFBa0IsYUFBYSxlQUFlLFFBQVEsd0JBQXdCLE1BQU07Q0FDN0ksSUFBSSxpQ0FBaUM7Q0FDckMsSUFBSSxxQkFBcUI7Q0FDekIsSUFBSSxzQkFBc0I7Q0FDMUIsSUFBSSxpQkFBaUIsUUFBUTtFQUM1QixNQUFNLG9CQUFvQixtQ0FBbUM7RUFDN0QsSUFBSSxzQkFBc0IsTUFBTSxzQkFBc0IsTUFBTTtFQUM1RCxJQUFJLENBQUMsdUJBQXVCLDRCQUE0QixvQkFBb0IsaUJBQWlCLFlBQVksR0FBRztHQUMzRyw0QkFBNEIsc0JBQXNCLGlCQUFpQixJQUFJO0dBQ3ZFO0VBQ0Q7Q0FDRDtDQUNBLElBQUksaUJBQWlCLFVBQVUscUJBQXFCO0VBQ25ELE1BQU0sYUFBYSxJQUFJLElBQUksaUJBQWlCLElBQUk7RUFDaEQsTUFBTSw2QkFBNkIsOENBQThDLGlCQUFpQixZQUFZLGlCQUFpQixVQUFVO0VBQ3pJLE1BQU0seUJBQXlCLHFDQUFxQyxpQkFBaUIsYUFBYSx3QkFBd0IsR0FBRyxZQUFZLDBCQUEwQjtFQUNuSyxNQUFNLHNCQUFzQixvQ0FBb0M7R0FDL0QsVUFBVTtHQUNWO0dBQ0EsT0FBTyxpQkFBaUI7RUFDekIsQ0FBQyxDQUFDLENBQUMsUUFBUSxtQkFBbUIsQ0FBQyx1QkFBdUIsTUFBTSxpQkFBaUIsYUFBYSxtQkFBbUIsY0FBYyxDQUFDO0VBQzVILElBQUksdUJBQXVCLFNBQVMsS0FBSyxvQkFBb0IsU0FBUyxHQUFHO0dBQ3hFLHFCQUFxQiwyQ0FBMkMsTUFBTTtJQUNyRSxvQkFBb0IsNEJBQTRCLHNCQUFzQjtJQUN0RSxxQkFBcUIsaUJBQWlCO0dBQ3ZDLENBQUM7R0FDRCxNQUFNLHFCQUFxQix3QkFBd0IsaUJBQWlCLFlBQVksUUFBUTtHQUN4RixNQUFNLGVBQWUsdUJBQXVCLEtBQUssa0JBQWtCLFdBQVcscUNBQXFDO0lBQ2xILHFCQUFxQixhQUFhO0lBQ2xDLGdCQUFnQixhQUFhLGFBQWE7SUFDMUM7SUFDQTtJQUNBLGdCQUFnQixhQUFhO0dBQzlCLENBQUMsQ0FBQztHQUNGLEtBQUssTUFBTSxxQkFBcUIscUJBQXFCLGFBQWEsTUFBTSxXQUFXLGdDQUFnQztJQUNsSDtJQUNBO0lBQ0EsZ0JBQWdCO0dBQ2pCLENBQUMsQ0FBQztHQUNGLGVBQWUsNkJBQTZCO0lBQzNDLE9BQU87SUFDUCxTQUFTO0lBQ1QsUUFBUSxtQkFBbUI7SUFDM0I7R0FDRCxDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVc7SUFDbkIsTUFBTSxhQUFhLHVDQUF1QyxRQUFRLGlCQUFpQixZQUFZLFFBQVE7SUFDdkcsbUNBQW1DLFdBQVc7SUFDOUMsT0FBTyxXQUFXO0dBQ25CLENBQUM7RUFDRjtDQUNEO0NBQ0EsTUFBTSxxQkFBcUIsMEJBQTBCLE9BQU8scUJBQXFCLHFDQUFxQyxpQkFBaUIsTUFBTSxpQkFBaUIsWUFBWSxtQkFBbUIsTUFBTSxHQUFHLGlCQUFpQixZQUFZLGtCQUFrQixJQUFJLHFDQUFxQyxpQkFBaUIsTUFBTSxpQkFBaUIsWUFBWSxtQkFBbUIsUUFBUSxxQkFBcUI7Q0FDbFksSUFBSTtFQUNILE1BQU0sU0FBUyxNQUFNLDRCQUE0Qiw2QkFBNkIsY0FBYyxvQkFBb0IsYUFBYSxpQkFBaUIsYUFBYTtHQUMxSiwwQkFBMEI7SUFDekIsc0NBQXNDLFNBQVM7R0FDaEQ7R0FDQTtHQUNBLHFCQUFxQixpQkFBaUI7R0FDdEMsWUFBWSxpQkFBaUI7RUFDOUIsQ0FBQztFQUNELElBQUksZ0NBQWdDLHNDQUFzQyxTQUFTO0VBQ25GLE9BQU87Q0FDUixVQUFVO0VBQ1Qsb0JBQW9CLE9BQU87Q0FDNUI7QUFDRDtBQUNBLFNBQVMsb0NBQW9DO0NBQzVDLE9BQU8scUJBQXFCLFFBQVEsaUNBQWlDO0VBQ3BFLE1BQU0sU0FBUyxxQkFBcUIsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDbEQsSUFBSSxXQUFXLEtBQUssR0FBRztFQUN2QixxQkFBcUIsT0FBTyxNQUFNO0NBQ25DO0FBQ0Q7QUFDQSxTQUFTLGtDQUFrQyxRQUFRLHFCQUFxQixvQkFBb0IsZ0JBQWdCO0NBQzNHLE1BQU0sV0FBVyxnQkFBZ0IsZUFBZSxRQUFRLG1CQUFtQjtDQUMzRSxNQUFNLFFBQVEsOEJBQThCLHNCQUFzQixRQUFRLG1CQUFtQjtDQUM3RixJQUFJLENBQUMsU0FBUyxNQUFNLE1BQU0sd0JBQXdCLE9BQU87RUFDeEQ7RUFDQSxPQUFPO0VBQ1AsT0FBTztHQUNOLFdBQVc7R0FDWDtFQUNEO0NBQ0Q7Q0FDQSxPQUFPO0VBQ04sVUFBVSxNQUFNO0VBQ2hCLE9BQU8sTUFBTTtFQUNiLE9BQU87R0FDTixXQUFXO0dBQ1gsT0FBTyxpQ0FBaUMsTUFBTSxPQUFPO0lBQ3BEO0lBQ0EsS0FBSyxLQUFLLElBQUk7R0FDZixDQUFDO0dBQ0QsbUJBQW1CLE1BQU0sTUFBTSxhQUFhLEtBQUssS0FBSyxNQUFNLE1BQU0sdUJBQXVCO0dBQ3pGO0VBQ0Q7Q0FDRDtBQUNEO0FBQ0EsU0FBUywyQ0FBMkMsV0FBVyxVQUFVO0NBQ3hFLElBQUksVUFBVSxVQUFVLE1BQU0sT0FBTztDQUNyQyxJQUFJLFNBQVMsU0FBUyxTQUFTO0VBQzlCLHFCQUFxQixPQUFPLFVBQVUsUUFBUTtFQUM5QyxxQkFBcUIsSUFBSSxVQUFVLFVBQVUsVUFBVSxLQUFLO0VBQzVELE9BQU8sVUFBVTtDQUNsQjtDQUNBLHFCQUFxQixPQUFPLFVBQVUsUUFBUTtDQUM5QyxPQUFPO0FBQ1I7QUFDQSxTQUFTLHNCQUFzQixRQUFRLHFCQUFxQjtDQUMzRCxnQ0FBZ0Msc0JBQXNCLFFBQVEsbUJBQW1CO0FBQ2xGO0FBQ0EsU0FBUyw2QkFBNkIsUUFBUSxxQkFBcUIsVUFBVSxRQUFRLHdCQUF3Qiw4QkFBOEIsNEJBQTRCLFNBQVMsc0JBQXNCLE1BQU0sVUFBVSxvQkFBb0IsTUFBTSxtQkFBbUIsVUFBVSwyQkFBMkIsT0FBTyxnQkFBZ0IsT0FBTztDQUNyVSxNQUFNLFdBQVcsZ0JBQWdCLGVBQWUsUUFBUSxtQkFBbUI7Q0FDM0UscUNBQXFDLHNCQUFzQixRQUFRLG1CQUFtQjtDQUN0RixrQ0FBa0M7Q0FDbEMsTUFBTSxRQUFRLGdDQUFnQztFQUM3QyxlQUFlO0VBQ2Y7RUFDQTtFQUNBLEtBQUssS0FBSyxJQUFJO0VBQ2Qsb0JBQW9CO0VBQ3BCO0VBQ0EsVUFBVTtFQUNWO0NBQ0QsQ0FBQztDQUNELHFCQUFxQixJQUFJLFVBQVUsS0FBSztDQUN4QyxJQUFJLG1CQUFtQiw2QkFBNkIsUUFBUSxrQkFBa0IscUJBQXFCLDJCQUEyQix1QkFBdUIsd0JBQXdCO0NBQzdLLGFBQWE7RUFDWixJQUFJLHFCQUFxQixJQUFJLFFBQVEsTUFBTSxPQUFPLHFCQUFxQixPQUFPLFFBQVE7RUFDdEYsSUFBSSxtQkFBbUIsK0JBQStCLFFBQVEsa0JBQWtCLG1CQUFtQjtDQUNwRztBQUNEO0FBQ0EsU0FBUyw2QkFBNkIsVUFBVTtDQUMvQyxPQUFPLEdBQUcsT0FBTyxTQUFTLFNBQVMsNEJBQTRCLFFBQVE7QUFDeEU7QUFDQSxTQUFTLGlDQUFpQztDQUN6QyxNQUFNLFdBQVcsZ0JBQWdCLGdCQUFnQixzQkFBc0IsQ0FBQyxDQUFDLE9BQU87Q0FDaEYsT0FBTyxVQUFVLFNBQVMsVUFBVSxTQUFTLE9BQU87QUFDckQ7QUFDQSxTQUFTLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLHlCQUF5QixzQkFBc0I7Q0FDdkcsSUFBSSw0QkFBNEIsS0FBSyxHQUFHLE9BQU87RUFDOUMscUJBQXFCLDhDQUE4Qyx5QkFBeUIsVUFBVTtFQUN0RyxpQkFBaUI7Q0FDbEI7Q0FDQSxRQUFRLGdCQUFSO0VBQ0MsS0FBSyxZQUFZO0dBQ2hCLE1BQU0seUJBQXlCLHNCQUFzQixDQUFDLENBQUM7R0FDdkQsSUFBSSwyQkFBMkIsTUFBTSxPQUFPO0lBQzNDLHFCQUFxQiw4Q0FBOEMsd0JBQXdCLFVBQVU7SUFDckcsaUJBQWlCO0dBQ2xCO0dBQ0EsTUFBTSw4QkFBOEIsNkNBQTZDO0lBQ2hGLFVBQVU7SUFDVixpQkFBaUIsT0FBTyxTQUFTO0lBQ2pDLGVBQWUsd0JBQXdCO0lBQ3ZDO0dBQ0QsQ0FBQztHQUNELElBQUksZ0NBQWdDLE1BQU0sT0FBTztJQUNoRCxxQkFBcUI7SUFDckIsaUJBQWlCLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUztHQUM3RDtHQUNBLE1BQU0sdUNBQXVDLHNEQUFzRDtJQUNsRyxVQUFVO0lBQ1Ysd0JBQXdCLCtCQUErQjtJQUN2RCxpQkFBaUIsT0FBTyxTQUFTO0lBQ2pDLGVBQWUsd0JBQXdCO0lBQ3ZDO0dBQ0QsQ0FBQztHQUNELElBQUkseUNBQXlDLE1BQU0sT0FBTztJQUN6RCxxQkFBcUI7SUFDckIsaUJBQWlCLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUztHQUM3RDtHQUNBLE9BQU87SUFDTixxQkFBcUI7SUFDckIsaUJBQWlCO0dBQ2xCO0VBQ0Q7RUFDQSxLQUFLLFlBQVk7R0FDaEIsTUFBTSxrQkFBa0IsZ0NBQWdDLHdCQUF3QixPQUFPLFFBQVEsS0FBSztHQUNwRyxPQUFPO0lBQ04scUJBQXFCLDhDQUE4QyxpQkFBaUIsVUFBVTtJQUM5RjtHQUNEO0VBQ0Q7RUFDQSxLQUFLLFdBQVc7R0FDZixNQUFNLHlCQUF5QixzQkFBc0IsQ0FBQyxDQUFDO0dBQ3ZELE9BQU87SUFDTixxQkFBcUIsOENBQThDLHdCQUF3QixVQUFVO0lBQ3JHLGlCQUFpQjtHQUNsQjtFQUNEO0VBQ0EsU0FBUyxNQUFNLElBQUksTUFBTSx1Q0FBdUMsT0FBTyxjQUFjLENBQUM7Q0FDdkY7QUFDRDtBQUNBLFNBQVMsK0JBQStCLFVBQVU7Q0FDakQsNEJBQTRCLHFCQUFxQixRQUFRO0FBQzFEO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTztDQUNwQyxPQUFPLFVBQVUsUUFBUSxPQUFPLFVBQVUsWUFBWSxVQUFVLFNBQVMsTUFBTSxTQUFTO0FBQ3pGO0FBQ0EsU0FBUyxxQkFBcUIsTUFBTSxtQkFBbUI7Q0FDdEQsdUJBQXVCLFNBQVMsUUFBUSxNQUFNLGlCQUFpQjtBQUNoRTtBQUNBLFNBQVMsd0JBQXdCLEVBQUUsWUFBWTtDQUM5QyxNQUFNLFNBQVMsVUFBVTtDQUN6QixnQkFBZ0I7RUFDZixNQUFNLDJCQUEyQixVQUFVO0dBQzFDLE1BQU0sUUFBUSxZQUFZLFFBQVEsTUFBTSxTQUFTLE1BQU07R0FDdkQsSUFBSSxDQUFDLGdCQUFnQixLQUFLLEdBQUc7R0FDN0IsSUFBSSxhQUFhLFNBQVMsTUFBTSxZQUFZLE1BQU07SUFDakQsTUFBTSxlQUFlO0lBQ3JCO0dBQ0Q7R0FDQSxNQUFNLFNBQVMsb0JBQW9CLE1BQU0sTUFBTTtHQUMvQyxJQUFJLENBQUMsUUFBUTtHQUNiLE1BQU0sZUFBZTtHQUNyQixzQkFBc0I7SUFDckIsSUFBSSxPQUFPLFNBQVMsUUFBUSxPQUFPLEtBQUssT0FBTyxHQUFHO1NBQzdDLE9BQU8sUUFBUSxPQUFPLEdBQUc7R0FDL0IsQ0FBQztFQUNGO0VBQ0EsT0FBTyxpQkFBaUIsU0FBUyx1QkFBdUI7RUFDeEQsT0FBTyxpQkFBaUIsc0JBQXNCLHVCQUF1QjtFQUNyRSxhQUFhO0dBQ1osT0FBTyxvQkFBb0IsU0FBUyx1QkFBdUI7R0FDM0QsT0FBTyxvQkFBb0Isc0JBQXNCLHVCQUF1QjtFQUN6RTtDQUNELEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDWCxPQUFPLFlBQVk7QUFDcEI7QUFDQSxTQUFTLHlCQUF5QixTQUFTO0NBQzFDLE9BQU8sUUFBUSxRQUFRLE9BQU8sQ0FBQyxDQUFDLE1BQU0sYUFBYSxnQkFBZ0IsT0FBTyxRQUFRLENBQUM7QUFDcEY7QUFDQSxTQUFTLFlBQVksRUFBRSwyQkFBMkIsaUJBQWlCLDZCQUE2QjtDQUMvRixNQUFNLG1CQUFtQixJQUFJLGVBQWU7Q0FDNUMsTUFBTSxrQkFBa0IsZ0JBQWdCLGFBQWEsZ0JBQWdCO0NBQ3JFLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLGdCQUFnQjtFQUMzRCxpQkFBaUI7RUFDakIsWUFBWSwwQkFBMEIsZ0JBQWdCO0VBQ3RELFVBQVU7RUFDVixjQUFjLGdCQUFnQjtFQUM5QixxQkFBcUIsZ0JBQWdCO0VBQ3JDLFdBQVcsZ0JBQWdCO0VBQzNCLG9CQUFvQjtFQUNwQixpQkFBaUI7RUFDakIsVUFBVTtFQUNWLG9CQUFvQixnQkFBZ0I7RUFDcEMsU0FBUyxnQkFBZ0I7RUFDekIsY0FBYyxnQkFBZ0I7RUFDOUIsc0JBQXNCO0NBQ3ZCLEVBQUU7Q0FDRixJQUFJLHFCQUFxQixjQUFjLEdBQUc7RUFDekMscUJBQXFCLGVBQWUsTUFBTSxlQUFlLGlCQUFpQjtFQUMxRSxNQUFNO0NBQ1A7Q0FDQSxNQUFNLFlBQVkscUJBQXFCLGNBQWMsSUFBSSxJQUFJLGNBQWMsSUFBSTtDQUMvRSxNQUFNLFdBQVcsT0FBTyxTQUFTO0NBQ2pDLFNBQVMsVUFBVTtDQUNuQixNQUFNLG9CQUFvQixPQUFPLFNBQVM7Q0FDMUMsc0JBQXNCO0VBQ3JCLGtCQUFrQixVQUFVO0NBQzdCLEdBQUcsQ0FBQyxTQUFTLENBQUM7Q0FDZCxzQkFBc0I7RUFDckIsTUFBTSwwQkFBMEIsVUFBVTtHQUN6QyxrQkFBa0IsS0FBSztFQUN4QjtFQUNBLE1BQU0sU0FBUyw0QkFBNEIseUJBQXlCLHdCQUF3QixRQUFRO0VBQ3BHLE1BQU0seUJBQXlCLE1BQU0sc0JBQXNCO0dBQzFELHNCQUFzQjtJQUNyQixrQkFBa0I7S0FDakI7S0FDQTtLQUNBLE1BQU07SUFDUCxDQUFDO0dBQ0YsQ0FBQztFQUNGO0VBQ0EsTUFBTSwyQkFBMkI7R0FDaEMsT0FBTztHQUNQLFVBQVU7SUFDVCxtQkFBbUIsWUFBWSxxQkFBcUIsT0FBTyxJQUFJLGtCQUFrQixVQUFVLE9BQU87R0FDbkc7RUFDRDtFQUNBLG9CQUFvQjtFQUNwQixtQ0FBbUMsRUFBRSxtQkFBbUIsTUFBTSxzQkFBc0I7R0FDbkYsc0JBQXNCLE1BQU0saUJBQWlCO0dBQzdDLE9BQU8sNEJBQTRCO0VBQ3BDLEVBQUUsQ0FBQztFQUNILHFDQUFxQztFQUNyQywwQkFBMEIsT0FBTztFQUNqQyxhQUFhO0dBQ1osMEJBQTBCLFdBQVc7R0FDckMsSUFBSSxzQkFBc0IsMEJBQTBCLG9CQUFvQjtHQUN4RSxtQ0FBbUMsRUFBRSxrQkFBa0IsS0FBSyxFQUFFLENBQUM7R0FDL0QsT0FBTztHQUNQLHNCQUFzQixJQUFJO0VBQzNCO0NBQ0QsR0FBRyxDQUFDLDJCQUEyQixpQkFBaUIsQ0FBQztDQUNqRCxnQkFBZ0I7RUFDZiwwQkFBMEIsU0FBUztFQUNuQyxNQUFNLGFBQWEsWUFBWSxJQUFJO0VBQ25DLE9BQU8sdUJBQXVCO0VBQzlCLE9BQU8sa0JBQWtCO0VBQ3pCLE9BQU8scUJBQXFCO0VBQzVCLE9BQU8scUJBQXFCO0NBQzdCLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQztDQUM5QixzQkFBc0I7RUFDckIsa0JBQWtCLDZCQUE2QixTQUFTO0NBQ3pELEdBQUcsQ0FBQyxTQUFTLENBQUM7Q0FDZCxnQkFBZ0I7RUFDZixnQ0FBZ0MsZ0JBQWdCLGFBQWEsVUFBVSxRQUFRLENBQUMsQ0FBQyxVQUFVO0NBQzVGLEdBQUcsQ0FBQyxVQUFVLFFBQVEsQ0FBQztDQUN2QixzQkFBc0I7RUFDckIsTUFBTSw2QkFBNkIsc0JBQXNCO0VBQ3pELE1BQU0seUJBQXlCLHdCQUF3QixTQUFTLFFBQVEsUUFBUTtFQUNoRixzQkFBc0Isc0JBQXNCO0VBQzVDLHdDQUF3QztFQUN4QyxJQUFJLCtCQUErQix3QkFBd0I7RUFDM0QsTUFBTSxZQUFZLE9BQU8saUJBQWlCO0dBQ3pDLHFCQUFxQixDQUFDLEVBQUUsVUFBVSxtQkFBbUI7RUFDdEQsR0FBRyxDQUFDO0VBQ0osYUFBYTtHQUNaLE9BQU8sYUFBYSxTQUFTO0VBQzlCO0NBQ0QsR0FBRyxDQUFDLFVBQVUsUUFBUSxDQUFDO0NBQ3ZCLHNCQUFzQjtFQUNyQixJQUFJLFVBQVUsYUFBYSxHQUFHO0VBQzlCLGtCQUFrQiw2QkFBNkI7R0FDOUMsa0JBQWtCLHdCQUF3QixVQUFVLFlBQVk7R0FDaEUsWUFBWSxVQUFVO0dBQ3RCLGlCQUFpQixVQUFVO0VBQzVCLENBQUM7Q0FDRixHQUFHO0VBQ0YsVUFBVTtFQUNWLFVBQVU7RUFDVixVQUFVO0VBQ1YsVUFBVTtDQUNYLENBQUM7Q0FDRCxNQUFNLFlBQVksY0FBYyxrQkFBa0IsTUFBTSxjQUFjLHdCQUF3QixFQUFFLFVBQVUsVUFBVSxTQUFTLEdBQUcsbUJBQW1CO0VBQ2xKLFVBQVUsVUFBVTtFQUNwQixlQUFlLGNBQWMseUJBQXlCLEVBQUUsVUFBVSxVQUFVLFNBQVMsQ0FBQztFQUN0RixTQUFTLFVBQVU7Q0FDcEIsQ0FBQyxDQUFDLENBQUM7Q0FDSCxNQUFNLDJCQUEyQixjQUFjLGdDQUFnQyxFQUFFLFVBQVUsVUFBVSxTQUFTLENBQUMsR0FBRyxDQUFDLFVBQVUsUUFBUSxDQUFDO0NBQ3RJLE1BQU0sa0JBQWtCLGNBQWMsMEJBQTBCLFVBQVUsRUFBRSxPQUFPLHlCQUF5QixHQUFHLFNBQVM7Q0FDeEgsTUFBTSxjQUFjLHNCQUFzQixjQUFjLG9CQUFvQixVQUFVLEVBQUUsT0FBTyxVQUFVLFdBQVcsR0FBRyxlQUFlLElBQUk7Q0FDMUksTUFBTSxpQkFBaUIsY0FBYyx5QkFBeUIsTUFBTSxXQUFXO0NBQy9FLE1BQU0sWUFBWSxtQkFBbUIsY0FBYyxpQkFBaUIsVUFBVSxFQUFFLE9BQU8sa0JBQWtCLEdBQUcsY0FBYyxJQUFJO0NBQzlILE1BQU0sZ0JBQWdCLFlBQVksSUFBSSxNQUFNLGNBQWMscUJBQXFCO0VBQzlFLDZCQUE2QjtFQUM3QixVQUFVLFVBQVU7RUFDcEIsU0FBUztDQUNWLEdBQUcsU0FBUyxJQUFJO0NBQ2hCLE1BQU0sbUJBQW1CLGNBQWMsK0JBQStCLEVBQUUsVUFBVSxVQUFVLFNBQVMsR0FBRyxhQUFhO0NBQ3JILE1BQU0sZ0JBQWdCLGNBQWMscUJBQXFCO0VBQ3hELFVBQVU7RUFDVixVQUFVO0NBQ1gsQ0FBQztDQUNELE1BQU0sZ0NBQWdDLGlDQUFpQztDQUN2RSxJQUFJLENBQUMsK0JBQStCLE9BQU87Q0FDM0MsT0FBTyxjQUFjLDhCQUE4QixVQUFVLEVBQUUsT0FBTyxVQUFVLG1CQUFtQixHQUFHLGFBQWE7QUFDcEg7QUFDQSxTQUFTLGtDQUFrQyxVQUFVLGNBQWMsUUFBUTtDQUMxRSxxQkFBcUI7RUFDcEI7RUFDQSxjQUFjLElBQUksZ0JBQWdCLFlBQVk7RUFDOUM7Q0FDRCxDQUFDO0FBQ0Y7QUFDQSxTQUFTLDBDQUEwQyxVQUFVLGNBQWMsUUFBUSx5QkFBeUI7Q0FDM0csa0NBQWtDLFVBQVUsMEJBQTBCLE9BQU8sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUNwSDs7Ozs7O0FBTUEsU0FBUyxvQ0FBb0M7Q0FDNUMsTUFBTSxVQUFVLHFCQUFxQjtDQUNyQyxJQUFJLENBQUMsU0FBUyxPQUFPO0NBQ3JCLE1BQU0sU0FBUyxRQUFRLGFBQWEsU0FBUztDQUM3QyxPQUFPLFNBQVMsR0FBRyxRQUFRLFNBQVMsR0FBRyxXQUFXLFFBQVE7QUFDM0Q7Ozs7OztBQU1BLFNBQVMsdUJBQXVCLFVBQVUsS0FBSztDQUM5QyxJQUFJLENBQUMsS0FBSyxPQUFPO0NBQ2pCLE1BQU0scUJBQXFCLFNBQVM7Q0FDcEMsT0FBTyxPQUFPLGVBQWUsVUFBVSxrQkFBa0I7RUFDeEQsY0FBYztFQUNkLFlBQVk7RUFDWixXQUFXLElBQUksa0JBQWtCO0NBQ2xDLENBQUM7QUFDRjs7QUFFQSxTQUFTLHFCQUFxQixVQUFVLFFBQVE7Q0FDL0MsT0FBTyxPQUFPLG1CQUFtQixLQUFLLElBQUksV0FBVztFQUNwRCxHQUFHO0VBQ0gsZ0JBQWdCLE9BQU87Q0FDeEI7QUFDRDtBQUNBLFNBQVMsOEJBQThCLE9BQU8sU0FBUztDQUN0RCxNQUFNLGlCQUFpQixTQUFTLHlCQUF5QjtDQUN6RCxJQUFJLENBQUMsZUFBZSxHQUFHO0NBQ3ZCLElBQUksRUFBRSxTQUFTLE9BQU8sVUFBVSxZQUFZLHNCQUFzQixRQUFRO0VBQ3pFLElBQUksT0FBTyxTQUFTLE1BQU0sOEJBQThCLE9BQU8sU0FBUyxJQUFJO0VBQzVFO0NBQ0Q7Q0FDQSxNQUFNLElBQUksT0FBTyxNQUFNLGdCQUFnQjtDQUN2QyxNQUFNLElBQUksc0JBQXNCLFFBQVEsT0FBTyxNQUFNLGdCQUFnQixJQUFJO0NBQ3pFLGNBQWMsR0FBRyxHQUFHO0VBQ25CLFdBQVc7RUFDWDtDQUNELENBQUM7QUFDRjtBQUNBLFNBQVMsNkJBQTZCLE1BQU07Q0FDM0MsSUFBSSxDQUFDLHNCQUFzQixHQUFHLE9BQU87Q0FDckMsTUFBTSxTQUFTLElBQUksSUFBSSxNQUFNLE9BQU8sU0FBUyxNQUFNO0NBQ25ELE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsT0FBTyxvQ0FBb0MsUUFBUSxVQUFVLE1BQU0sNEJBQTRCLFlBQVksa0JBQWtCO0FBQzlIO0FBQ0EsSUFBSSxrQkFBa0I7QUFDdEIsTUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxpQkFBaUI7Q0FDekIsSUFBSTtFQUNILE9BQU8sZUFBZSxRQUFRLGNBQWM7Q0FDN0MsUUFBUTtFQUNQLE9BQU87Q0FDUjtBQUNEO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTTtDQUM5QixJQUFJO0VBQ0gsZUFBZSxRQUFRLGdCQUFnQixJQUFJO0NBQzVDLFFBQVEsQ0FBQztBQUNWO0FBQ0EsU0FBUyxrQkFBa0I7Q0FDMUIsSUFBSTtFQUNILGVBQWUsV0FBVyxjQUFjO0NBQ3pDLFFBQVEsQ0FBQztBQUNWO0FBQ0EsU0FBUyxpQ0FBaUMsUUFBUTtDQUNqRCxNQUFNLGNBQWMsT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTO0NBQy9ELElBQUksZUFBZSxNQUFNLGFBQWE7RUFDckMsZ0JBQWdCO0VBQ2hCLFFBQVEsTUFBTSw4QkFBOEIsT0FBTyw2R0FBNkc7RUFDaEssT0FBTztDQUNSO0NBQ0EsZ0JBQWdCLFdBQVc7Q0FDM0IsSUFBSSxlQUFlLE1BQU0sYUFBYTtFQUNyQyxRQUFRLE1BQU0sOEJBQThCLE9BQU8scUtBQXFLO0VBQ3hOLE9BQU87Q0FDUjtDQUNBLFFBQVEsS0FBSyw4QkFBOEIsT0FBTyw4REFBOEQ7Q0FDaEgsT0FBTyxTQUFTLE9BQU87Q0FDdkIsT0FBTztBQUNSO0FBQ0EsZUFBZSx1QkFBdUI7Q0FDckMsTUFBTSxTQUFTLHVCQUF1QjtDQUN0QyxNQUFNLGFBQWEscUJBQXFCLENBQUMsRUFBRSxVQUFVO0NBQ3JELElBQUksY0FBYyxPQUFPLHlCQUF5QixPQUFPLHFCQUFxQjtFQUM3RSxnQkFBZ0I7RUFDaEIsNkJBQTZCO0VBQzdCLElBQUksWUFBWTtHQUNmLHlCQUF5QixVQUFVO0dBQ25DLElBQUksV0FBVyxNQUFNO0lBQ3BCLG1DQUFtQyxFQUFFLEtBQUssS0FBSyxFQUFFLENBQUM7SUFDbEQsT0FBTyx1QkFBdUIsV0FBVyxHQUFHO0dBQzdDO0dBQ0EsT0FBTywyQkFBMkI7RUFDbkM7RUFDQSxJQUFJLE9BQU8sdUJBQXVCLGtCQUFrQixPQUFPLHFCQUFxQjtFQUNoRixPQUFPLDJCQUEyQjtDQUNuQztDQUNBLE1BQU0sYUFBYSx3QkFBd0I7Q0FDM0MsTUFBTSxjQUFjLE1BQU0sTUFBTSxNQUFNLG9CQUFvQixPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVMsUUFBUSxVQUFVLEdBQUc7RUFDekgsYUFBYTtFQUNiLFNBQVM7Q0FDVixDQUFDO0NBQ0QsSUFBSSxDQUFDLFlBQVksSUFBSSxPQUFPLGlDQUFpQyxZQUFZLFlBQVksUUFBUTtDQUM3RixNQUFNLGNBQWMsWUFBWSxRQUFRLElBQUksY0FBYyxLQUFLO0NBQy9ELElBQUksQ0FBQyxZQUFZLFdBQVcsa0JBQWtCLEdBQUcsT0FBTyxpQ0FBaUMsa0NBQWtDLGVBQWUsWUFBWSxFQUFFO0NBQ3hKLElBQUksQ0FBQyxZQUFZLE1BQU0sT0FBTyxpQ0FBaUMscUJBQXFCO0NBQ3BGLGdCQUFnQjtDQUNoQiw2QkFBNkI7Q0FDN0IsNEJBQTRCLFlBQVksUUFBUSxJQUFJLGtDQUFrQyxDQUFDO0NBQ3ZGLE1BQU0sZUFBZSx1QkFBdUIsWUFBWSxRQUFRLElBQUksb0JBQW9CLENBQUM7Q0FDekYsTUFBTSxTQUFTLGdCQUFnQixDQUFDO0NBQ2hDLElBQUksY0FBYyxJQUFJO0VBQ3JCLGtCQUFrQixZQUFZO0NBQy9CLFFBQVEsQ0FBQztDQUNULE1BQU0sV0FBVyxnQ0FBZ0MsaUNBQWlDLFlBQVksUUFBUSxJQUFJLHNDQUFzQyxDQUFDLEdBQUcsT0FBTyxRQUFRO0NBQ25LLGtDQUFrQyxTQUFTLFVBQVUsU0FBUyxRQUFRLE1BQU07Q0FDNUUsT0FBTyxZQUFZO0FBQ3BCO0FBQ0EsU0FBUyx5QkFBeUIsS0FBSztDQUN0Qyw0QkFBNEIsSUFBSSxlQUFlO0NBQy9DLE1BQU0sU0FBUyxJQUFJLFVBQVUsQ0FBQztDQUM5QixJQUFJLElBQUksUUFBUSxrQkFBa0IsSUFBSSxNQUFNO0NBQzVDLElBQUksSUFBSSxLQUFLLDBDQUEwQyxJQUFJLElBQUksVUFBVSxJQUFJLElBQUksY0FBYyxRQUFRLElBQUksNEJBQTRCLElBQUk7QUFDNUk7QUFDQSxTQUFTLCtCQUErQjtDQUN2QyxtQkFBbUIsSUFBSSxTQUFTO0VBQy9CLE1BQU0sZ0NBQWdDLGtCQUFrQiw0QkFBNEI7RUFDcEYsTUFBTSxtQkFBbUIsK0JBQStCO0VBQ3hELE9BQU8sdUJBQXVCLENBQUMsQ0FBQyxNQUFNLEVBQUUsK0JBQStCLHlCQUF5QixJQUFJLE1BQU0sa0JBQWtCO0dBQzNILFVBQVU7R0FDVjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0Esd0JBQXdCLEtBQUssZ0JBQWdCLDRCQUE0QixzQkFBc0IsS0FBSyxXQUFXO0dBQy9HLHNCQUFzQixVQUFVLFFBQVEsa0JBQWtCLGNBQWM7SUFDdkUsSUFBSSw0QkFBNEIsb0JBQW9CLGlCQUFpQixZQUFZLEdBQUcscUJBQXFCLENBQUMsRUFBRSxVQUFVLDRCQUE0QjtJQUNsSixNQUFNLFVBQVUsT0FBTyxLQUFLLFFBQVEsR0FBRztJQUN2QyxNQUFNLE9BQU8sWUFBWSxDQUFDLElBQUksT0FBTyxLQUFLLE1BQU0sT0FBTyxJQUFJO0lBQzNELE1BQU0scUJBQXFCLDJCQUEyQixRQUFRLElBQUk7SUFDbEUsSUFBSSxPQUFPLFNBQVMsUUFBUSxtQkFBbUI7SUFDL0Msd0JBQXdCO0tBQ3ZCLFlBQVksT0FBTyxTQUFTLFNBQVMsYUFBYTtLQUNsRCxtQkFBbUIsT0FBTyxTQUFTLFNBQVMsU0FBUztLQUNyRCwyQkFBMkIsaUJBQWlCO0tBQzVDLG9CQUFvQixxQ0FBcUMsT0FBTyxNQUFNLGlCQUFpQixZQUFZLG1CQUFtQixRQUFRLE9BQU8scUJBQXFCO0tBQzFKLE9BQU8saUJBQWlCO0tBQ3hCLGVBQWUsaUNBQWlDLFlBQVk7S0FDNUQsUUFBUSxDQUFDO0tBQ1QsU0FBUyxRQUFRLFFBQVEsUUFBUTtLQUNqQyxlQUFlO0tBQ2Ysb0JBQW9CO0tBQ3BCLGlCQUFpQjtLQUNqQixjQUFjO0tBQ2QsWUFBWSxPQUFPO0lBQ3BCLENBQUMsQ0FBQyxDQUFDLFlBQVk7S0FDZCw0QkFBNEIsc0JBQXNCLE9BQU8sSUFBSTtJQUM5RCxDQUFDO0dBQ0Y7R0FDQSwwQkFBMEIsaUJBQWlCLGVBQWUsa0JBQWtCLHVDQUF1QyxpQkFBaUIsVUFBVTtHQUM5STtFQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSw2QkFBNkI7Q0FDMUMsQ0FBQztBQUNGO0FBQ0EsU0FBUyw2QkFBNkIsRUFBRSxVQUFVO0NBQ2pELFVBQVUsUUFBUSxDQUFDLE1BQU0sQ0FBQztDQUMxQixPQUFPO0FBQ1I7QUFDQSxlQUFlLE9BQU87Q0FDckIsSUFBSSxDQUFDLCtCQUErQixHQUFHO0NBQ3ZDLG1DQUFtQztDQUNuQyxJQUFJLGtCQUFrQiw2QkFBNkI7Q0FDbkQscUNBQXFDO0NBQ3JDLElBQUkscUJBQXFCLE1BQU0sOEJBQThCO0NBQzdELElBQUksa0JBQWtCO0NBQ3RCLElBQUksWUFBWSxJQUFJLEtBQUs7RUFDeEIsa0JBQWtCLE1BQU0sT0FBTztFQUMvQixnQkFBZ0IsdUJBQXVCO0VBQ3ZDLGdCQUFnQiwyQkFBMkIsWUFBWSxHQUFHO0VBQzFELElBQUksU0FBUyxnQkFBZ0IsT0FBTyxrQkFBa0IsZ0JBQWdCLDZCQUE2QjtDQUNwRztDQUNBLE1BQU0sc0JBQXNCLHFCQUFxQixDQUFDLEVBQUUsVUFBVTtDQUM5RCxNQUFNLFlBQVksTUFBTSxxQkFBcUI7Q0FDN0MsSUFBSSxjQUFjLE1BQU07Q0FDeEIsbUJBQW1CLFdBQVcsaUJBQWlCLG1CQUFtQjtBQUNuRTtBQUNBLFNBQVMsbUJBQW1CLFdBQVcsaUJBQWlCLHFCQUFxQjtDQUM1RSxNQUFNLDRCQUE0QixnQ0FBZ0M7Q0FDbEUsTUFBTSxrQkFBa0I7Q0FDeEIsTUFBTSxDQUFDLGFBQWEsZUFBZSxVQUFVLElBQUk7Q0FDakQsTUFBTSw0QkFBNEIsdUJBQXVCLHFDQUFxQyxPQUFPLFNBQVMsTUFBTSxvQkFBb0Isa0NBQWtDLENBQUMsR0FBRyxtQkFBbUI7Q0FDak0sTUFBTSx1QkFBdUIsNEJBQTRCLHlCQUF5QjtDQUNsRixNQUFNLE9BQU8seUJBQXlCLHlCQUF5QixXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sYUFBYTtFQUMvRixJQUFJLGtCQUFrQiwwQkFBMEIsZ0JBQWdCLGFBQWEsUUFBUSxDQUFDLENBQUMsc0JBQXNCO0VBQzdHLDhCQUE4QixVQUFVLHlCQUF5QjtFQUNqRSw2QkFBNkI7R0FDNUIsZUFBZTtHQUNmLFNBQVMsZ0JBQWdCLGFBQWEsUUFBUSxDQUFDLENBQUM7RUFDakQ7RUFDQSxPQUFPO0NBQ1IsQ0FBQztDQUNELE1BQU0sZ0JBQWdCLDBCQUEwQjtDQUNoRCxNQUFNLHFCQUFxQixJQUFJLFNBQVMsV0FBVyxDQUFDLENBQUMsWUFBWTtDQUNqRSxRQUFRLElBQUksQ0FBQyxNQUFNLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxVQUFVLFlBQVk7RUFDMUUsSUFBSSxvQkFBb0IsaUNBQWlDO0VBQ3pELE1BQU0sV0FBVyxnQkFBZ0IsYUFBYSxRQUFRO0VBQ3RELElBQUksQ0FBQyw2QkFBNkIsUUFBUSxHQUFHO0VBQzdDLE1BQU0scUJBQXFCLHdCQUF3QixRQUFRO0VBQzNELE1BQU0sVUFBVSx3QkFBd0IsRUFBRSxtQkFBbUIsQ0FBQztFQUM5RCxNQUFNLFNBQVMsTUFBTSxvQkFBb0Isc0JBQXNCLE9BQU87RUFDdEUsSUFBSSxvQkFBb0IsaUNBQWlDO0VBQ3pELE1BQU0sV0FBVztHQUNoQix1QkFBdUI7R0FDdkI7R0FDQSxhQUFhO0dBQ2IsR0FBRyxxQkFBcUIsNEJBQTRCLEtBQUssSUFBSSxFQUFFLHlCQUF5QixvQkFBb0Isd0JBQXdCLElBQUksQ0FBQztHQUN6SSxHQUFHLHFCQUFxQixxQkFBcUIsS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFLGlCQUFpQjtJQUM3RSxNQUFNO0lBQ04sU0FBUyxvQkFBb0I7R0FDOUIsRUFBRTtHQUNGO0dBQ0EsY0FBYyxtQkFBbUIsS0FBSyxVQUFVLGFBQWEsQ0FBQztHQUM5RCx1QkFBdUI7R0FDdkIsS0FBSztFQUNOO0VBQ0EsTUFBTSxnQkFBZ0IscUJBQXFCLHFCQUFxQixXQUFXLHFCQUFxQjtFQUNoRywwQkFBMEIsY0FBYztHQUN2QyxJQUFJLG9CQUFvQixpQ0FBaUMsYUFBYSxDQUFDO0dBQ3ZFLE9BQU8sNkJBQTZCLFFBQVEsU0FBUyxxQkFBcUIsVUFBVSxlQUFlLGVBQWUsb0JBQW9CLFVBQVUsT0FBTyxVQUFVLHFCQUFxQixxQkFBcUIsWUFBWSxTQUFTLHdCQUF3QixNQUFNLElBQUk7RUFDblEsQ0FBQztDQUNGLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0NBQ2pCLGtCQUFrQiw4QkFBOEI7Q0FDaEQsTUFBTSxzQkFBc0Isc0JBQXNCLEVBQUUsZUFBZSxZQUFZLElBQUksSUFBSSxDQUFDO0NBQ3hGLE1BQU0sbUJBQW1CLEdBQUcsU0FBUztFQUNwQywwQkFBMEIsS0FBSztFQUMvQixvQkFBb0IsR0FBRyxJQUFJO0NBQzVCO0NBQ0EsTUFBTSxxQkFBcUIsbUNBQW1DO0VBQzdELDBCQUEwQixLQUFLO0NBQ2hDLENBQUM7Q0FDRCxNQUFNLDJCQUEyQixjQUFjLEdBQUcsU0FBUztFQUMxRCwwQkFBMEIsS0FBSztFQUMvQixRQUFRLEdBQUcsSUFBSTtDQUNoQjtDQUNBLE1BQU0sWUFBWSx3QkFBd0IsdUJBQXVCLENBQUM7Q0FDbEUsTUFBTSxxQkFBcUIsWUFBWSxJQUFJLE9BQU8sa0JBQWtCLCtCQUErQjtFQUNsRztFQUNBLGVBQWUsd0JBQXdCLHVCQUF1QixnQkFBZ0Isa0JBQWtCLGVBQWUsQ0FBQztFQUNoSDtDQUNELENBQUMsSUFBSSwrQkFBK0I7RUFDbkM7RUFDQSxlQUFlLHdCQUF3Qix3QkFBd0IsZUFBZSxDQUFDO0VBQy9FO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsTUFBTSxXQUFXLGNBQWMsYUFBYTtFQUMzQztFQUNBLGlCQUFpQjtFQUNqQjtDQUNELENBQUM7Q0FDRCxNQUFNLG1CQUFtQixTQUFTLGlCQUFpQixzQ0FBc0M7Q0FDekYsSUFBSSxTQUFTLGdCQUFnQixPQUFPLGtCQUFrQjtFQUNyRCxNQUFNLEVBQUUsV0FBVyxpQkFBaUIsR0FBRyxzQkFBc0I7RUFDN0QsS0FBSyxNQUFNLFNBQVMsa0JBQWtCLE1BQU0sT0FBTztFQUNuRCxzQkFBc0I7R0FDckIsTUFBTSxhQUFhLFdBQVcsVUFBVSxpQkFBaUI7R0FDekQsV0FBVyxPQUFPLFlBQVksSUFBSSxPQUFPLGtCQUFrQixjQUFjLFVBQVUsTUFBTSxVQUFVLGNBQWMsOEJBQThCLEVBQUUsUUFBUSxnQkFBZ0IsNkJBQTZCLENBQUMsQ0FBQyxJQUFJLFFBQVE7R0FDcE4sT0FBTyxzQkFBc0I7RUFDOUIsQ0FBQztDQUNGLE9BQU8sT0FBTyxzQkFBc0Isd0JBQXdCO0VBQzNEO0VBQ0EsV0FBVztFQUNYO0VBQ0EsU0FBUztFQUNUO0NBQ0QsQ0FBQztDQUNELHNDQUFzQztDQUN0QyxNQUFNLDZCQUE2QiwyQ0FBMkM7Q0FDOUUsbUNBQW1DO0VBQ2xDLHVCQUF1QjtFQUN2Qix1QkFBdUIsTUFBTSxtQkFBbUIsV0FBVyxrQkFBa0IseUJBQXlCLE1BQU0sbUJBQW1CLE1BQU07RUFDckksOEJBQThCO0dBQzdCLElBQUksQ0FBQyw0QkFBNEIsc0JBQXNCLEdBQUcsT0FBTztHQUNqRSxNQUFNLFFBQVEsNEJBQTRCLHNCQUFzQjtHQUNoRSxPQUFPO0lBQ04sZUFBZSw0QkFBNEIsTUFBTSxrQkFBa0I7SUFDbkUsU0FBUyxNQUFNO0dBQ2hCO0VBQ0Q7RUFDQSxVQUFVLGVBQWUsWUFBWSxNQUFNLGdCQUFnQixHQUFHLGlCQUFpQixZQUFZLG1CQUFtQix5QkFBeUIseUJBQXlCLE9BQU8saUJBQWlCLGNBQWMsb0JBQW9CLGNBQWMsOEJBQThCO0dBQ3JRLDJDQUEyQyxTQUFTO0dBQ3BELE1BQU0sd0JBQXdCLDJCQUEyQixNQUFNO0dBQy9ELElBQUkscUJBQXFCO0dBQ3pCLE1BQU0sUUFBUSw0QkFBNEIsZ0JBQWdCO0dBQzFELE1BQU0sNEJBQTRCO0dBQ2xDLHNDQUFzQyxvQkFBb0I7R0FDMUQsSUFBSSxjQUFjO0dBQ2xCLElBQUkscUJBQXFCO0dBQ3pCLElBQUkscUJBQXFCO0dBQ3pCLElBQUksZ0JBQWdCO0dBQ3BCLElBQUksNEJBQTRCO0dBQ2hDLElBQUksMEJBQTBCO0dBQzlCLE1BQU0sK0JBQStCLFlBQVk7SUFDaEQsTUFBTSxnQkFBZ0I7SUFDdEIsSUFBSSxrQkFBa0IsTUFBTSxPQUFPO0lBQ25DLE9BQU8sbUJBQW1CLFVBQVUsUUFBUSxNQUFNLGFBQWEsZ0NBQWdDLFVBQVUsZUFBZSxPQUFPLEtBQUssQ0FBQyxDQUFDLElBQUksZ0NBQWdDLFNBQVMsZUFBZSxPQUFPLEtBQUssQ0FBQztHQUNoTjtHQUNBLE1BQU0sd0JBQXdCLG1CQUFtQixhQUFhLG1CQUFtQixrQkFBa0IsdUJBQXVCLE9BQU8sUUFBUSxLQUFLLElBQUk7R0FDbEosSUFBSSx3QkFBd0I7R0FDNUIsTUFBTSx3Q0FBd0MsWUFBWSxTQUFTO0lBQ2xFLDZCQUE2QixnQkFBZ0IsSUFBSTtJQUNqRCxNQUFNLGNBQWMsNEJBQTRCLHNCQUFzQixZQUFZLFNBQVMsdUJBQXVCLFNBQVMsV0FBVyxVQUFVO0lBQ2hKLElBQUksYUFBYTtLQUNoQix3QkFBd0I7S0FDeEIsNEJBQTRCLGlDQUFpQyxrQkFBa0I7SUFDaEYsT0FBTyxnQ0FBZ0MsVUFBVTtJQUNqRCxPQUFPO0dBQ1I7R0FDQSxJQUFJLHFCQUFxQixtQkFBbUIsYUFBYSxrQkFBa0Isb0NBQW9DLHVCQUF1QixnQkFBZ0IsT0FBTyxRQUFRLEtBQUssSUFBSTtHQUM5SyxNQUFNLHlCQUF5QixtQkFBbUIsY0FBYyxDQUFDLGtCQUFrQiwyQkFBMkIsS0FBSyxrQkFBa0Isd0JBQXdCLHVCQUF1QixnQkFBZ0IsT0FBTyxRQUFRLEtBQUs7R0FDeE4sTUFBTSw0QkFBNEIsaUNBQWlDO0dBQ25FLElBQUk7SUFDSCxNQUFNLDhCQUE4QjtJQUNwQyxJQUFJLHNCQUFzQixHQUFHO0tBQzVCLElBQUksNkJBQTZCLHFCQUFxQiwrQkFBK0I7SUFDdEYsT0FBTztLQUNOLE1BQU0sK0JBQStCO0tBQ3JDLElBQUksQ0FBQyw0QkFBNEIsb0JBQW9CLEtBQUssR0FBRztLQUM3RCxJQUFJLDZCQUE2QixxQkFBcUIsK0JBQStCO0lBQ3RGO0lBQ0EsTUFBTSxvQkFBb0IsbUNBQW1DO0lBQzdELElBQUksc0JBQXNCLE1BQU07S0FDL0IsTUFBTSxzQkFBc0IsTUFBTTtLQUNsQyxJQUFJLENBQUMsNEJBQTRCLG9CQUFvQixLQUFLLEdBQUc7S0FDN0QsSUFBSSxDQUFDLHFCQUFxQjtNQUN6QixxQ0FBcUMsV0FBVztNQUNoRDtLQUNEO0lBQ0Q7SUFDQSxNQUFNLDRCQUE0QixzQkFBc0I7SUFDeEQsTUFBTSxxQkFBcUIsd0JBQXdCLDBCQUEwQixRQUFRO0lBQ3JGLElBQUksdUJBQXVCLG1CQUFtQixhQUFhLDJCQUEyQiwwQkFBMEIsVUFBVSwwQkFBMEIsU0FBUyxJQUFJO0lBQ2pLLE9BQU8sTUFBTTtLQUNaLE1BQU0sTUFBTSxJQUFJLElBQUksYUFBYSxPQUFPLFNBQVMsTUFBTTtLQUN2RCxNQUFNLGVBQWUsZ0JBQWdCLGdCQUFnQixJQUFJLFVBQVUsb0JBQW9CLHVCQUF1QixZQUFZO0tBQzFILE1BQU0sNkJBQTZCLGFBQWE7S0FDaEQsTUFBTSx5QkFBeUIsYUFBYTtLQUM1QyxNQUFNLGtDQUFrQyxtQkFBbUIsYUFBYSxtQkFBbUIsY0FBYyxDQUFDO0tBQzFHLE1BQU0sZ0NBQWdDLG1CQUFtQixZQUFZLHFDQUFxQywyQkFBMkIsd0JBQXdCLEdBQUcsS0FBSywwQkFBMEIsSUFBSSxDQUFDO0tBQ3BNLE1BQU0sK0JBQStCLGtDQUFrQyxvQ0FBb0M7TUFDMUcsa0JBQWtCLG1CQUFtQixhQUFhLGlDQUFpQyx1QkFBdUIsWUFBWSxLQUFLLENBQUMsSUFBSSxLQUFLO01BQ3JJLFVBQVU7TUFDVixZQUFZO01BQ1osT0FBTyxtQkFBbUIsYUFBYTtPQUN0QyxpQkFBaUI7T0FDakIsY0FBYyxDQUFDO01BQ2hCLElBQUk7S0FDTCxDQUFDLENBQUMsQ0FBQyxRQUFRLHdCQUF3QjtNQUNsQyxJQUFJLDhCQUE4QixNQUFNLGlCQUFpQixhQUFhLG1CQUFtQixtQkFBbUIsR0FBRyxPQUFPO01BQ3RILE9BQU87S0FDUixDQUFDLElBQUksQ0FBQztLQUNOLE1BQU0seUJBQXlCLDhCQUE4QixTQUFTLEtBQUssNkJBQTZCLFNBQVM7S0FDakgsSUFBSSxtQkFBbUIsV0FBVyxrQkFBa0IsdUNBQXVDLHdCQUF3QixzQkFBc0IsQ0FBQyxDQUFDLFlBQVksd0JBQXdCLHNCQUFzQixDQUFDLENBQUMsWUFBWSxDQUFDO0tBQ3BOLG1CQUFtQixJQUFJLFVBQVUsS0FBSztLQUN0QyxNQUFNLG1DQUFtQyxtQkFBbUIsY0FBYyxnQkFBZ0IsUUFBUSxrQkFBa0IsaUJBQWlCLGlDQUFpQyxLQUFLO0tBQzNLLE1BQU0sc0JBQXNCLG1CQUFtQixjQUFjLENBQUMsbUNBQW1DLGtCQUFrQiw4QkFBOEI7TUFDaEosVUFBVTtNQUNWLGlCQUFpQjtNQUNqQixhQUFhLDZCQUE2QiwwQkFBMEIsa0JBQWtCO01BQ3RGLE1BQU07TUFDTixRQUFRO01BQ1IsWUFBWSxJQUFJO0tBQ2pCLENBQUMsSUFBSTtLQUNMLE1BQU0sOEJBQThCLG1DQUFtQywrQkFBK0IscUJBQXFCLFNBQVMsc0JBQXNCLG9CQUFvQjtLQUM5SyxNQUFNLGlCQUFpQix3QkFBd0I7TUFDOUMsZUFBZTtNQUNmLHFCQUFxQjtNQUNyQjtNQUNBLGFBQWE7T0FDWixlQUFlLDRCQUE0QiwwQkFBMEIsa0JBQWtCO09BQ3ZGLFNBQVMsMEJBQTBCO01BQ3BDO0tBQ0QsQ0FBQztLQUNELE1BQU0sMEJBQTBCLG1CQUFtQixjQUFjLHNCQUFzQixxQ0FBcUMsYUFBYSxVQUFVLElBQUk7S0FDdkosTUFBTSxzQkFBc0IscUJBQXFCLEdBQUc7S0FDcEQsTUFBTSxrQ0FBa0MsMkJBQTJCLDRCQUE0QixjQUFjLENBQUMsdUJBQXVCLElBQUksQ0FBQztLQUMxSSxNQUFNLDRCQUE0Qix5Q0FBeUM7TUFDMUUsbUJBQW1CO01BQ25CLHVCQUF1QjtNQUN2QixxQkFBcUI7TUFDckI7TUFDQTtNQUNBO0tBQ0QsQ0FBQztLQUNELE1BQU0sU0FBUyw0QkFBNEIscUNBQXFDO01BQy9FLG1CQUFtQjtNQUNuQixRQUFRLE9BQU8sU0FBUztNQUN4QixhQUFhLDBCQUEwQjtNQUN2QyxlQUFlO0tBQ2hCLENBQUMsSUFBSSxNQUFNLG9CQUFvQixxQkFBcUIsY0FBYztLQUNsRSxNQUFNLDRCQUE0Qiw0QkFBNEIsa0NBQWtDLE1BQU0sUUFBUSxJQUFJLGdDQUFnQyxLQUFLLFNBQVMsb0JBQW9CLE1BQU0sY0FBYyxDQUFDLENBQUM7S0FDMU0sTUFBTSwyQkFBMkIsOEJBQThCO01BQzlELFVBQVUsZ0JBQWdCLGVBQWUsUUFBUSwwQkFBMEI7TUFDM0UsT0FBTztNQUNQLE9BQU87T0FDTixXQUFXO09BQ1g7TUFDRDtLQUNELElBQUksa0NBQWtDLFFBQVEsNEJBQTRCLG9CQUFvQixjQUFjO0tBQzVHLE1BQU0sY0FBYywyQ0FBMkMsMEJBQTBCLGtCQUFrQixzQ0FBc0MseUJBQXlCLEtBQUssQ0FBQztLQUNoTCxNQUFNLGtCQUFrQixnQkFBZ0IsT0FBTyxFQUFFLFFBQVEsY0FBYyxJQUFJLEVBQUUsUUFBUSxZQUFZO0tBQ2pHLE1BQU0sd0JBQXdCLGtCQUFrQixnQ0FBZ0M7TUFDL0UsdUJBQXVCO01BQ3ZCO01BQ0E7S0FDRCxDQUFDO0tBQ0QsSUFBSSxnQkFBZ0IsbUJBQW1CLGFBQWEsd0JBQXdCLElBQUk7S0FDaEYsTUFBTSx1QkFBdUIsOEJBQThCLFFBQVEsc0JBQXNCLFNBQVMsV0FBVyxtQ0FBbUMsUUFBUSw0QkFBNEIsb0JBQW9CO01BQ3ZNLG1CQUFtQjtNQUNuQixvQkFBb0I7S0FDckIsQ0FBQztLQUNELE1BQU0sZ0JBQWdCLGtCQUFrQix3QkFBd0I7TUFDL0QsdUJBQXVCO01BQ3ZCO01BQ0Esc0JBQXNCLGtCQUFrQixPQUFPO09BQzlDLFFBQVE7T0FDUixRQUFRO01BQ1QsSUFBSSxFQUFFLFFBQVEsWUFBWTtNQUMxQixVQUFVLHVCQUF1QixFQUFFLFFBQVEsWUFBWSxJQUFJLEVBQUUsUUFBUSxjQUFjO01BQ25GLFlBQVk7TUFDWjtLQUNELENBQUM7S0FDRCxJQUFJLGNBQWMsU0FBUywwQkFBMEIsYUFBYTtNQUNqRSxNQUFNLHNCQUFzQixrQkFBa0IsdUJBQXVCO09BQ3BFLHVCQUF1QjtPQUN2Qix1QkFBdUIsWUFBWSxTQUFTLHlCQUF5QjtPQUNyRTtPQUNBLDRCQUE0QixzQkFBc0I7T0FDbEQsU0FBUztPQUNULGtCQUFrQjtPQUNsQixRQUFRLE9BQU8sU0FBUztPQUN4QixlQUFlO09BQ2Y7T0FDQSxZQUFZO09BQ1osYUFBYSxtQkFBbUIsY0FBYyxZQUFZLFNBQVM7T0FDbkUsUUFBUTtPQUNSLHdCQUF3QjtNQUN6QixDQUFDO01BQ0QsSUFBSSxvQkFBb0IsU0FBUyxnQkFBZ0I7T0FDaEQsSUFBSSxvQkFBb0IsV0FBVywwQkFBMEIsUUFBUSxNQUFNLGlGQUFpRjtPQUM1SixxQ0FBcUMsb0JBQW9CLEdBQUc7T0FDNUQ7TUFDRDtNQUNBLElBQUksb0JBQW9CLFNBQVMsa0JBQWtCO09BQ2xELElBQUksbUJBQW1CLFlBQVkscUJBQXFCO09BQ3hELGNBQWMsb0JBQW9CLFNBQVM7T0FDM0MscUJBQXFCLG9CQUFvQixTQUFTO09BQ2xELHFCQUFxQixvQkFBb0IsU0FBUztPQUNsRCxnQkFBZ0Isb0JBQW9CLFNBQVM7T0FDN0M7TUFDRDtNQUNBLElBQUksQ0FBQyw0QkFBNEIsb0JBQW9CLEtBQUssR0FBRztNQUM3RCxNQUFNLGVBQWUsWUFBWTtNQUNqQyxNQUFNLDJCQUEyQixxQ0FBcUMsYUFBYSxjQUFjLFlBQVksU0FBUyxxQkFBcUI7TUFDM0ksTUFBTSxnQkFBZ0IsWUFBWSxXQUFXLFFBQVEsUUFBUSxZQUFZLFFBQVEsSUFBSSx5QkFBeUIsZ0JBQWdCLFFBQVEsUUFBUSxtQkFBbUIsWUFBWSxRQUFRLENBQUMsQ0FBQyxDQUFDO01BQ3hMLElBQUksQ0FBQyw0QkFBNEIsb0JBQW9CLEtBQUssR0FBRztNQUM3RCxNQUFNLHNCQUFzQixNQUFNLHdCQUF3QjtPQUN6RCxZQUFZLGFBQWEsY0FBYztPQUN2QyxtQkFBbUI7T0FDbkIsc0JBQXNCLDRCQUE0QixrQkFBa0IsS0FBSztPQUN6RTtPQUNBLG9CQUFvQjtPQUNwQjtPQUNBLGVBQWUsZ0JBQWdCLGNBQWM7T0FDN0MsUUFBUTtPQUNSLFNBQVMsNEJBQTRCLGFBQWE7T0FDbEQsZUFBZSxZQUFZLFdBQVcsZ0RBQWdEO09BQ3RGLG9CQUFvQiw0QkFBNEIsT0FBTztPQUN2RCxpQkFBaUI7T0FDakI7T0FDQTtPQUNBO09BQ0EsWUFBWTtPQUNaLGlCQUFpQjtPQUNqQjtNQUNELENBQUM7TUFDRCxJQUFJLHdCQUF3QixpQkFBaUI7T0FDNUMsd0JBQXdCO09BQ3hCLDRCQUE0QixpQ0FBaUMsa0JBQWtCO01BQ2hGO01BQ0EsSUFBSSx3QkFBd0IsYUFBYTtPQUN4QyxJQUFJLENBQUMsNEJBQTRCLG9CQUFvQixLQUFLLEdBQUc7T0FDN0Qsc0JBQXNCLFFBQVEsMEJBQTBCO09BQ3hEO01BQ0Q7TUFDQTtLQUNEO0tBQ0EsSUFBSTtLQUNKLElBQUk7S0FDSixJQUFJLGlCQUFpQjtLQUNyQixJQUFJO0tBQ0osSUFBSTtLQUNKLElBQUksd0JBQXdCO0tBQzVCLElBQUksY0FBYyxTQUFTLG1CQUFtQjtNQUM3QyxNQUFNLHFCQUFxQiw0QkFBNEIsd0JBQXdCLHFCQUFxQiw0QkFBNEIsb0JBQW9CLEVBQUUsbUJBQW1CLGdDQUFnQyxDQUFDLElBQUksTUFBTSxxQ0FBcUMsUUFBUSw0QkFBNEIsb0JBQW9CO09BQ2hULG1CQUFtQjtPQUNuQixxQkFBcUIsNEJBQTRCLG9CQUFvQixLQUFLO01BQzNFLENBQUM7TUFDRCxJQUFJLENBQUMsNEJBQTRCLG9CQUFvQixLQUFLLEdBQUc7TUFDN0QsSUFBSSxvQkFBb0I7T0FDdkIsY0FBYyxtQkFBbUIsb0JBQW9CLEtBQUs7T0FDMUQsaUJBQWlCLHFDQUFxQztRQUNyRCxtQkFBbUI7UUFDbkIsUUFBUSxPQUFPLFNBQVM7UUFDeEIsYUFBYSxtQkFBbUI7UUFDaEMsZUFBZTtPQUNoQixDQUFDO09BQ0QsTUFBTSxjQUFjLDhDQUE4QyxvQkFBb0IsY0FBYztPQUNwRywyQkFBMkIsWUFBWTtPQUN2QyxxQkFBcUIsWUFBWTtPQUNqQyx1QkFBdUIsWUFBWTtNQUNwQztNQUNBLElBQUksQ0FBQyxhQUFhO09BQ2pCLGdCQUFnQixtQkFBbUIsYUFBYSx3QkFBd0IsSUFBSTtPQUM1RSx3QkFBd0Isa0JBQWtCLHdCQUF3QjtRQUNqRSx1QkFBdUI7UUFDdkI7UUFDQSxzQkFBc0Isa0JBQWtCLE9BQU87U0FDOUMsUUFBUTtTQUNSLFFBQVE7UUFDVCxJQUFJLEVBQUUsUUFBUSxZQUFZO1FBQzFCLFVBQVUsRUFBRSxRQUFRLGNBQWM7UUFDbEMsWUFBWTtRQUNaLGlCQUFpQixFQUFFLFFBQVEsY0FBYztPQUMxQyxDQUFDO01BQ0Y7S0FDRDtLQUNBLElBQUksQ0FBQyxlQUFlLHNCQUFzQixTQUFTLCtCQUErQjtNQUNqRixNQUFNLCtDQUErQztPQUNwRCxxQkFBcUI7T0FDckI7T0FDQTtNQUNELENBQUM7TUFDRCxJQUFJLENBQUMsNEJBQTRCLG9CQUFvQixLQUFLLEdBQUc7TUFDN0QsSUFBSSxrQkFBa0IsTUFBTTtPQUMzQixNQUFNLG9CQUFvQixtQ0FBbUM7UUFDNUQsVUFBVTtRQUNWLE1BQU07UUFDTixxQkFBcUI7UUFDckI7UUFDQTtRQUNBLFdBQVcseUJBQXlCO09BQ3JDLENBQUM7T0FDRCxJQUFJLHNCQUFzQixRQUFRLGlDQUFpQztRQUNsRSxpQkFBaUIsMEJBQTBCO1FBQzNDLGtCQUFrQiwwQkFBMEI7UUFDNUMsZUFBZSwwQkFBMEIsbUJBQW1CO1FBQzVEO1FBQ0EsbUJBQW1CLGtCQUFrQjtRQUNyQyxnQkFBZ0Isa0JBQWtCO1FBQ2xDLFVBQVUsa0JBQWtCO09BQzdCLENBQUMsR0FBRztRQUNILDRCQUE0QjtRQUM1QiwwQkFBMEIsa0JBQWtCO1FBQzVDLE1BQU0sK0JBQStCLHFDQUFxQyxhQUFhLGtCQUFrQixNQUFNO1FBQy9HLHdCQUF3QjtTQUN2QixZQUFZLGFBQWEsY0FBYztTQUN2QyxtQkFBbUI7U0FDbkIsc0JBQXNCO1NBQ3RCO1NBQ0Esb0JBQW9CO1NBQ3BCO1NBQ0EsZUFBZSxnQkFBZ0IsY0FBYztTQUM3QyxRQUFRLGtCQUFrQjtTQUMxQixTQUFTLFFBQVEsUUFBUSxrQkFBa0IsUUFBUTtTQUNuRCxlQUFlO1NBQ2Ysb0JBQW9CO1NBQ3BCLGlCQUFpQjtTQUNqQjtTQUNBO1NBQ0E7U0FDQSxZQUFZO1NBQ1osaUJBQWlCO1NBQ2pCO1FBQ0QsQ0FBQyxDQUFDLENBQUMsT0FBTyxVQUFVO1NBQ25CLElBQUksNEJBQTRCLG9CQUFvQixLQUFLLEdBQUcsUUFBUSxNQUFNLDZDQUE2QyxLQUFLO1FBQzdILENBQUM7T0FDRjtNQUNEO0tBQ0Q7S0FDQSxJQUFJLHFCQUFxQjtLQUN6QixJQUFJLENBQUMsYUFBYTtNQUNqQixJQUFJLHFCQUFxQjtNQUN6QixJQUFJLHlCQUF5QixRQUFRLCtCQUErQixNQUFNO09BQ3pFLHFCQUFxQixJQUFJLFFBQVEsY0FBYztPQUMvQyxtQkFBbUIsSUFBSSwrQkFBK0Isb0JBQW9CO09BQzFFLHFCQUFxQjtNQUN0QjtNQUNBLGNBQWMsTUFBTSxNQUFNLFFBQVE7T0FDakMsU0FBUztPQUNULGFBQWE7T0FDYixVQUFVO09BQ1YsUUFBUSxzQkFBc0I7TUFDL0IsQ0FBQztLQUNGO0tBQ0EsSUFBSSxDQUFDLDRCQUE0QixvQkFBb0IsS0FBSyxHQUFHO0tBQzdELE1BQU0saUJBQWlCLFlBQVksUUFBUSxJQUFJLGNBQWMsS0FBSztLQUNsRSxNQUFNLDZCQUE2QixlQUFlLFdBQVcsa0JBQWtCLEtBQUssb0JBQW9CLGVBQWUsV0FBVyxZQUFZO0tBQzlJLE1BQU0sd0JBQXdCLG1CQUFtQixjQUFjLGtCQUFrQixZQUFZO0tBQzdGLE1BQU0seUJBQXlCLFlBQVksUUFBUSxJQUFJLDBCQUEwQjtLQUNqRixNQUFNLDZCQUE2QixZQUFZLFFBQVEsSUFBSSwrQkFBK0I7S0FDMUYsTUFBTSx1QkFBdUIsK0JBQStCLFVBQVUsK0JBQStCLFlBQVksNkJBQTZCO0tBQzlJLElBQUksa0NBQWtDLGFBQWEsc0JBQXNCLEdBQUc7S0FDNUUsTUFBTSxvQkFBb0Isa0JBQWtCLHVCQUF1QjtNQUNsRSx1QkFBdUI7TUFDdkIsdUJBQXVCLFlBQVksUUFBUSxJQUFJLGtDQUFrQztNQUNqRjtNQUNBLDRCQUE0QixzQkFBc0I7TUFDbEQsU0FBUyxZQUFZLFNBQVM7TUFDOUIsa0JBQWtCO01BQ2xCLFFBQVEsT0FBTyxTQUFTO01BQ3hCLGVBQWU7TUFDZjtNQUNBLFlBQVksWUFBWTtNQUN4QixhQUFhO01BQ2IsUUFBUTtNQUNSO01BQ0E7S0FDRCxDQUFDO0tBQ0QsSUFBSSxrQkFBa0IsU0FBUyxnQkFBZ0I7TUFDOUMsSUFBSSxrQkFBa0IsYUFBYSxZQUFZLE1BQU0sT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7TUFDNUUsSUFBSSxrQkFBa0IsV0FBVywwQkFBMEIsUUFBUSxNQUFNLGlGQUFpRjtNQUMxSixJQUFJLGtCQUFrQixXQUFXLHdCQUF3QixRQUFRLE1BQU0sNEdBQTRHO01BQ25MLHFDQUFxQyxrQkFBa0IsS0FBSyxrQkFBa0Isa0JBQWtCO01BQ2hHO0tBQ0Q7S0FDQSxJQUFJLGtCQUFrQixTQUFTLGtCQUFrQjtNQUNoRCxJQUFJLGtCQUFrQixhQUFhLFlBQVksTUFBTSxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztNQUM1RSxJQUFJLG1CQUFtQixZQUFZLHFCQUFxQjtNQUN4RCxjQUFjLGtCQUFrQixTQUFTO01BQ3pDLHFCQUFxQixrQkFBa0IsU0FBUztNQUNoRCxxQkFBcUIsa0JBQWtCLFNBQVM7TUFDaEQsZ0JBQWdCLGtCQUFrQixTQUFTO01BQzNDO0tBQ0Q7S0FDQSxJQUFJLENBQUMsd0JBQXdCLHNCQUFzQixRQUFRO0tBQzNELE1BQU0sWUFBWSx1QkFBdUIsWUFBWSxRQUFRLElBQUksaUJBQWlCLENBQUMsTUFBTSxtQkFBbUIsK0JBQStCLFdBQVcsSUFBSSxDQUFDO0tBQzNKLE1BQU0scUJBQXFCLHFDQUFxQyxhQUFhLFdBQVcsaUNBQWlDLFlBQVksUUFBUSxJQUFJLHNDQUFzQyxDQUFDLENBQUM7S0FDekwsTUFBTSxVQUFVLFlBQVk7S0FDNUIsSUFBSSxDQUFDLFNBQVM7S0FDZCxNQUFNLENBQUMsYUFBYSxlQUFlLFFBQVEsSUFBSTtLQUMvQyxNQUFNLGdCQUFnQixtQ0FBbUMsSUFBSSxTQUFTLGFBQWE7TUFDbEYsUUFBUSxZQUFZO01BQ3BCLFNBQVMsWUFBWTtLQUN0QixDQUFDLENBQUM7S0FDRixNQUFNLHFCQUFxQixJQUFJLFNBQVMsV0FBVyxDQUFDLENBQUMsWUFBWTtLQUNqRSxtQkFBbUIsWUFBWSxDQUFDLENBQUM7S0FDakMsSUFBSSxDQUFDLDRCQUE0QixvQkFBb0IsS0FBSyxHQUFHO0tBQzdELElBQUksb0JBQW9CLGNBQWMsTUFBTSxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztLQUNuRSxJQUFJLGFBQWEscUJBQXFCLHFCQUFxQix5QkFBeUIsZ0JBQWdCLFFBQVEsUUFBUSxhQUFhLENBQUMsQ0FBQztLQUNuSSxJQUFJLHdCQUF3QjtNQUMzQixNQUFNLGVBQWUsOEJBQThCLEtBQUssa0JBQWtCLFdBQVcscUNBQXFDO09BQ3pILHFCQUFxQixhQUFhO09BQ2xDLGdCQUFnQixhQUFhLGFBQWE7T0FDMUM7T0FDQTtPQUNBLGdCQUFnQixhQUFhO01BQzlCLENBQUMsQ0FBQztNQUNGLEtBQUssTUFBTSw4QkFBOEIsOEJBQThCLGFBQWEsTUFBTSxXQUFXLGdDQUFnQztPQUNwSTtPQUNBO09BQ0EsZ0JBQWdCO01BQ2pCLENBQUMsQ0FBQztNQUNGLGFBQWEsNkJBQTZCO09BQ3pDLE9BQU87T0FDUCxTQUFTLFFBQVEsUUFBUSxVQUFVO09BQ25DLFFBQVEsc0JBQXNCO09BQzlCO01BQ0QsQ0FBQyxDQUFDLENBQUMsY0FBYztPQUNoQixzQkFBc0IsUUFBUTtNQUMvQixDQUFDLENBQUMsQ0FBQyxLQUFLLGtDQUFrQztLQUMzQztLQUNBLElBQUksb0JBQW9CO01BQ3ZCLE1BQU0sV0FBVyxNQUFNO01BQ3ZCLElBQUksQ0FBQyw0QkFBNEIsb0JBQW9CLEtBQUssR0FBRztNQUM3RCxJQUFJLENBQUMsb0JBQW9CLDJCQUEyQixRQUFRLEtBQUssQ0FBQyxvQkFBb0Isc0JBQXNCLEdBQUcsUUFBUSxHQUFHO09BQ3pILHVCQUF1QjtPQUN2QjtNQUNEO01BQ0EsYUFBYSxRQUFRLFFBQVEsUUFBUTtLQUN0QztLQUNBLElBQUksa0JBQWtCO01BQ3JCLE1BQU0sdUJBQXVCLE1BQU07TUFDbkMsSUFBSSxDQUFDLDRCQUE0QixvQkFBb0IsS0FBSyxHQUFHO01BQzdELElBQUksQ0FBQywwQ0FBMEMsb0JBQW9CLEdBQUc7T0FDckUscUNBQXFDLFdBQVc7T0FDaEQ7TUFDRDtNQUNBLGFBQWEsUUFBUSxRQUFRLG9CQUFvQjtLQUNsRDtLQUNBLElBQUksQ0FBQyw0QkFBNEIsb0JBQW9CLEtBQUssR0FBRztLQUM3RCxJQUFJLGlCQUFpQjtLQUNyQixNQUFNLGdCQUFnQixNQUFNLHdCQUF3QjtNQUNuRCxZQUFZLGFBQWEsY0FBYztNQUN2QyxtQkFBbUI7TUFDbkIsc0JBQXNCLDRCQUE0QixrQkFBa0IsS0FBSztNQUN6RTtNQUNBO01BQ0EsOEJBQThCLHNEQUFzRDtPQUNuRixVQUFVO09BQ1YsaUJBQWlCLDBCQUEwQjtPQUMzQztPQUNBO09BQ0EsV0FBVztNQUNaLENBQUMsSUFBSSxxQkFBcUIsS0FBSztNQUMvQjtNQUNBLG1CQUFtQixVQUFVO09BQzVCLGlCQUFpQjtPQUNqQixzQkFBc0IsUUFBUTtNQUMvQjtNQUNBLGVBQWUsZ0JBQWdCLGNBQWM7TUFDN0MsUUFBUTtNQUNSLFNBQVMsNEJBQTRCLFVBQVU7TUFDL0MsZUFBZTtNQUNmLG9CQUFvQiw0QkFBNEIsT0FBTztNQUN2RCxpQkFBaUI7TUFDakI7TUFDQTtNQUNBO01BQ0EsWUFBWTtNQUNaLGlCQUFpQjtNQUNqQjtLQUNELENBQUM7S0FDRCxJQUFJLGtCQUFrQixpQkFBaUI7TUFDdEMsd0JBQXdCO01BQ3hCLDRCQUE0QixpQ0FBaUMsa0JBQWtCO0tBQ2hGO0tBQ0EsSUFBSSxrQkFBa0IsYUFBYTtLQUNuQyxJQUFJLHdCQUF3QjtNQUMzQiwwQkFBMEI7TUFDMUI7S0FDRDtLQUNBLG1CQUFtQixzQkFBc0I7S0FDekMsSUFBSTtNQUNILE1BQU0sbUJBQW1CLE1BQU07TUFDL0IsSUFBSSw4QkFBOEIsaUNBQWlDO01BQ25FLE1BQU0sV0FBVyxnQkFBZ0IsYUFBYSxnQkFBZ0I7TUFDOUQsSUFBSSw4QkFBOEIsaUNBQWlDO01BQ25FLE1BQU0sbUJBQW1CLDRCQUE0QixnQ0FBZ0MsYUFBYSxNQUFNLG9CQUFvQixxQkFBcUI7TUFDakosTUFBTSxrQkFBa0IsRUFBRSxpQkFBaUIscUNBQXFDLEtBQUssTUFBTSxvQ0FBb0MsUUFBUTtNQUN2SSxNQUFNLEVBQUUsa0NBQWtDLGtDQUFrQyx5QkFBeUIseUJBQXlCLEdBQUcsMkJBQTJCO01BQzVKLE1BQU0sV0FBVztPQUNoQixHQUFHLGtCQUFrQix5QkFBeUI7UUFDN0MsR0FBRztRQUNILEdBQUcsaUJBQWlCLDRCQUE0QixLQUFLLEtBQUssU0FBUyw0QkFBNEIsS0FBSyxJQUFJLEVBQUUseUJBQXlCLFNBQVMsd0JBQXdCLElBQUksQ0FBQztPQUMxSztPQUNBLG9CQUFvQix3QkFBd0IsZ0JBQWdCO01BQzdEO01BQ0EsTUFBTSxtQkFBbUIsZ0NBQWdDLFVBQVUsb0JBQW9CO01BQ3ZGLE1BQU0sc0JBQXNCLDBDQUEwQyw0QkFBNEIsU0FBUyxtQkFBbUI7TUFDOUgsSUFBSSxpQkFBaUI7T0FDcEIsSUFBSSw4QkFBOEIsaUNBQWlDO09BQ25FLDZCQUE2QixRQUFRLHFCQUFxQixVQUFVLFdBQVcsb0JBQW9CLG9CQUFvQixLQUFLLEdBQUcsTUFBTSxrQkFBa0IsSUFBSTtNQUM1SixPQUFPO09BQ04sTUFBTSxRQUFRO09BQ2QsTUFBTSxvQkFBb0I7UUFDekIsR0FBRyxNQUFNO1NBQ1IsZ0JBQWdCLEtBQUssWUFBWSxNQUFNO1NBQ3ZDLGdCQUFnQixLQUFLLG1CQUFtQixDQUFDO1NBQ3pDLGdCQUFnQixLQUFLLGVBQWUsTUFBTTtPQUM1QztPQUNBLElBQUksOEJBQThCLGlDQUFpQztPQUNuRSw2QkFBNkIsUUFBUSxxQkFBcUIsVUFBVSxXQUFXLDhCQUE4QixvQkFBb0IsbUJBQW1CLDZCQUE2QixRQUFRLEdBQUcsa0JBQWtCLHdCQUF3QixRQUFRLHFDQUFxQyxRQUFRLENBQUM7TUFDN1I7S0FDRCxRQUFRLENBQUM7S0FDVDtJQUNEO0dBQ0QsU0FBUyxPQUFPO0lBQ2YsSUFBSSxDQUFDLDRCQUE0QixvQkFBb0IsS0FBSyxHQUFHO0lBQzdELElBQUksQ0FBQyxpQkFBaUIsUUFBUSxNQUFNLGtDQUFrQyxLQUFLO0lBQzNFLHFDQUFxQyxrQkFBa0IsMkJBQTJCLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHO0dBQ3ZHLFVBQVU7SUFDVCxzQkFBc0IsUUFBUTtJQUM5Qiw0QkFBNEIsbUJBQW1CLE9BQU8sa0JBQWtCO0lBQ3hFLHNDQUFzQyxzQkFBc0I7SUFDNUQsMEJBQTBCO0lBQzFCLElBQUksdUJBQXVCLE1BQU0sNEJBQTRCO0dBQzlEO0VBQ0Q7RUFDQSxxQ0FBcUMsU0FBUyxxQkFBcUIsdUJBQXVCLG1DQUFtQyxzQkFBc0IsU0FBUyxxQkFBcUIsa0JBQWtCO0VBQ25NLDBCQUEwQixhQUFhO0dBQ3RDLElBQUksQ0FBQyx3QkFBd0IsU0FBUyxRQUFRLElBQUksK0JBQStCLENBQUMsR0FBRyxPQUFPLFFBQVEsdUJBQXVCLElBQUksTUFBTSxrREFBa0QsQ0FBQztHQUN4TCxPQUFPLHlCQUF5QixnQkFBZ0IsUUFBUSxRQUFRLFFBQVEsQ0FBQyxDQUFDO0VBQzNFO0VBQ0Esa0NBQWtDLG1CQUFtQix5QkFBeUIsa0JBQWtCLGdDQUFnQyxtQkFBbUIsb0JBQW9CO0VBQ3ZLLGtDQUFrQyxtQkFBbUIseUJBQXlCLGtCQUFrQixnQ0FBZ0MsbUJBQW1CLG9CQUFvQjtFQUN2SyxnQ0FBZ0M7R0FDL0IsSUFBSSw0QkFBNEIseUJBQXlCLGtCQUFrQix3QkFBd0IsQ0FBQyxHQUFHLDJCQUEyQixZQUFZO0VBQy9JO0VBQ0Esb0NBQW9DLDRCQUE0Qiw2QkFBNkI7Q0FDOUYsQ0FBQztDQUNELE1BQU0saUJBQWlCLDZCQUE2QjtFQUNuRCx1QkFBdUIsNEJBQTRCLHNCQUFzQixLQUFLLDJCQUEyQjtFQUN6Ryw0QkFBNEIsT0FBTztFQUNuQyxtQkFBbUIscUJBQXFCLENBQUMsRUFBRSxVQUFVO0VBQ3JELHFCQUFxQiw0QkFBNEIsb0JBQW9CLEtBQUssMkJBQTJCO0VBQ3JHLGlDQUFpQyxTQUFTO0dBQ3pDLCtCQUErQixNQUFNLFVBQVU7RUFDaEQ7RUFDQTtFQUNBLHVCQUF1QixzQkFBc0I7R0FDNUMsT0FBTyx5QkFBeUI7RUFDakM7RUFDQSwwQkFBMEIsVUFBVSxpREFBaUQ7Q0FDdEYsQ0FBQztDQUNELE9BQU8saUJBQWlCLGFBQWEsVUFBVTtFQUM5QyxNQUFNLE9BQU8sT0FBTyxTQUFTO0VBQzdCLE1BQU0seUJBQXlCLHVCQUF1QixNQUFNLEtBQUs7RUFDakUsSUFBSSx5Q0FBeUM7R0FDNUMsY0FBYyxNQUFNO0dBQ3BCLDhCQUE4QixrQkFBa0IsNkJBQTZCLE1BQU0sS0FBSztHQUN4RixzQkFBc0IsNkJBQTZCLElBQUk7RUFDeEQsQ0FBQyxHQUFHO0dBQ0gsK0JBQStCLE1BQU0sVUFBVTtHQUMvQyxrQkFBa0IscUNBQXFDLE1BQU0sS0FBSztHQUNsRSw0QkFBNEI7R0FDNUIsOEJBQThCLE1BQU0sS0FBSztHQUN6QztFQUNEO0VBQ0EsTUFBTSx1QkFBdUIsNEJBQTRCLGdCQUFnQjtFQUN6RSxJQUFJLDRCQUE0QixNQUFNLE9BQU8sNEJBQTRCO0dBQ3hFLDJCQUEyQixZQUFZO0dBQ3ZDLCtCQUErQixNQUFNLFVBQVU7RUFDaEQsR0FBRyxzQkFBc0IsR0FBRztHQUMzQixPQUFPLHlCQUF5QjtHQUNoQyx5Q0FBeUM7SUFDeEMsNkJBQTZCLDRCQUE0QixzQkFBc0I7SUFDL0Usc0JBQXNCLFVBQVUsNEJBQTRCLG9CQUFvQixLQUFLO0lBQ3JGLDRCQUE0QixVQUFVO0tBQ3JDLCtDQUErQztJQUNoRDtJQUNBO0dBQ0QsR0FBRyxNQUFNLEtBQUs7R0FDZCw0QkFBNEIsbUJBQW1CLHNCQUFzQixJQUFJO0dBQ3pFO0VBQ0Q7RUFDQSw0QkFBNEIsbUJBQW1CLHNCQUFzQixJQUFJO0VBQ3pFLGVBQWUsS0FBSztDQUNyQixDQUFDO0NBQ0QsSUFBSSxZQUFZLElBQUksT0FBTyxZQUFZLEtBQUs7RUFDM0MsTUFBTSxvQkFBb0IsT0FBTyxhQUFhO0dBQzdDLElBQUksYUFBYSxzQkFBc0I7R0FDdkMsSUFBSSxTQUFTLGdCQUFnQixPQUFPLGtCQUFrQjtJQUNyRCxPQUFPLFNBQVMsT0FBTztJQUN2QjtHQUNEO0dBQ0EsSUFBSSxzQ0FBc0MsQ0FBQyw0QkFBNEIsc0JBQXNCLEdBQUc7SUFDL0YsT0FBTyxTQUFTLE9BQU87SUFDdkI7R0FDRDtHQUNBLE1BQU0sK0JBQStCO0dBQ3JDLElBQUksYUFBYSxzQkFBc0I7R0FDdkMsSUFBSSxDQUFDLDRCQUE0QixzQkFBc0IsR0FBRztHQUMxRCw0QkFBNEI7R0FDNUIsaUJBQWlCLGVBQWU7R0FDaEMsTUFBTSxhQUFhLHdCQUF3QixFQUFFLG9CQUFvQix3QkFBd0IsNEJBQTRCLHNCQUFzQixDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7R0FDeEosTUFBTSxVQUFVLE9BQU8sU0FBUztHQUNoQyxNQUFNLFlBQVk7R0FDbEIsTUFBTSxvQkFBb0IscUJBQXFCLHFDQUFxQyxTQUFTLFNBQVMsR0FBRyw0QkFBNEIsc0JBQXNCLENBQUMsQ0FBQyxrQkFBa0I7R0FDL0ssTUFBTSxjQUFjLE1BQU0sTUFBTSxvQkFBb0IsT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLFFBQVEsVUFBVSxHQUFHLEVBQUUsU0FBUyxXQUFXLENBQUM7R0FDM0ksTUFBTSw0QkFBNEIsZUFBZSx5QkFBeUIsZ0JBQWdCLFlBQVksS0FBSyxrQ0FBa0MsQ0FBQyxDQUFDLEdBQUcsWUFBWSxNQUFNLGFBQWE7SUFDaEwsTUFBTSx3QkFBd0IsaUNBQWlDLFNBQVMsUUFBUSxJQUFJLHNDQUFzQyxDQUFDO0lBQzNILE9BQU8sMEJBQTBCLE9BQU8sb0JBQW9CLHFDQUFxQyxTQUFTLFdBQVcscUJBQXFCO0dBQzNJLENBQUMsQ0FBQztFQUNIO0VBQ0EsTUFBTSxrQkFBa0IsT0FBTyxhQUFhO0dBQzNDLElBQUk7SUFDSCxNQUFNLG9CQUFvQjtJQUMxQixNQUFNLGtCQUFrQixRQUFRO0dBQ2pDLFNBQVMsT0FBTztJQUNmLFFBQVEsTUFBTSwyQkFBMkIsS0FBSztHQUMvQztFQUNEO0VBQ0EsWUFBWSxJQUFJLEdBQUcsb0JBQW9CO0dBQ3RDLE1BQU0sV0FBVyxFQUFFO0dBQ25CLGdCQUFnQixRQUFRO0VBQ3pCLENBQUM7Q0FDRjtBQUNEO0FBQ0EsSUFBSSxPQUFPLGFBQWEsYUFBYTtDQUNwQyxrQkFBa0I7RUFDakIsUUFBUTtFQUNSLFFBQVE7Q0FDVCxDQUFDO0NBQ0QsT0FBTyxpQkFBaUIsa0JBQWtCO0VBQ3pDLGtCQUFrQjtDQUNuQixDQUFDO0NBQ0QsT0FBTyxpQkFBaUIsYUFBYSxVQUFVO0VBQzlDLGtCQUFrQjtFQUNsQixJQUFJLE1BQU0sV0FBVztHQUNwQix1QkFBdUIsTUFBTTtHQUM3QixtQkFBbUIsUUFBUTtHQUMzQixzQkFBc0IsUUFBUTtHQUM5Qix1QkFBdUI7RUFDeEI7Q0FDRCxDQUFDO0NBQ0QsS0FBSztBQUNOOztBQUVBIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImFwcC1icm93c2VyLWVudHJ5LmpzP3Y9YjQxYmVjZGQiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYWRkQmFzZVBhdGhUb1BhdGhuYW1lLCBzdHJpcEJhc2VQYXRoIH0gZnJvbSBcIi4uL3V0aWxzL2Jhc2UtcGF0aC5qc1wiO1xuaW1wb3J0IHsgVklORVhUX01PVU5URURfTEFZT1VUU19IRUFERVIsIFZJTkVYVF9QQVJBTVNfSEVBREVSLCBWSU5FWFRfUkVOREVSRURfUEFUSF9BTkRfU0VBUkNIX0hFQURFUiwgVklORVhUX1JTQ19SRURJUkVDVF9IRUFERVIsIFZJTkVYVF9SU0NfUkVESVJFQ1RfVFlQRV9IRUFERVIgfSBmcm9tIFwiLi9oZWFkZXJzLmpzXCI7XG5pbXBvcnQgeyBzcGxpdFBhdGhuYW1lRm9yUm91dGVNYXRjaCB9IGZyb20gXCIuLi9yb3V0aW5nL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBBcHBSb3V0ZXJDb250ZXh0IH0gZnJvbSBcIi4uL3NoaW1zL2ludGVybmFsL2FwcC1yb3V0ZXItY29udGV4dC5qc1wiO1xuaW1wb3J0IHsgbWF0Y2hSb3V0ZVBhdHRlcm4gfSBmcm9tIFwiLi4vcm91dGluZy9yb3V0ZS1wYXR0ZXJuLmpzXCI7XG5pbXBvcnQgeyBpbnN0YWxsV2luZG93TmV4dCwgc2V0V2luZG93TmV4dEludGVybmFsU291cmNlUGFnZSB9IGZyb20gXCIuLi9jbGllbnQvd2luZG93LW5leHQuanNcIjtcbmltcG9ydCB7IHJldHJ5U2Nyb2xsVG8sIHNjcm9sbFRvSGFzaFRhcmdldE9uTmV4dEZyYW1lIH0gZnJvbSBcIi4uL3NoaW1zL2hhc2gtc2Nyb2xsLmpzXCI7XG5pbXBvcnQgeyBWSU5FWFRfUlNDX0NPTVBBVElCSUxJVFlfSURfSEVBREVSLCBWSU5FWFRfUlNDX0NPTlRFTlRfVFlQRSwgY3JlYXRlUnNjUmVxdWVzdEhlYWRlcnMsIGNyZWF0ZVJzY1JlcXVlc3RVcmwsIGZvcm1hdFJzY1JlcXVlc3RQYXRoLCBpc1JzY0NvbXBhdGliaWxpdHlJZENvbXBhdGlibGUgfSBmcm9tIFwiLi9hcHAtcnNjLWNhY2hlLWJ1c3RpbmcuanNcIjtcbmltcG9ydCB7IGNsZWFyQXBwTmF2aWdhdGlvbkZhaWx1cmVUYXJnZXQsIGluc3RhbGxBcHBOYXZpZ2F0aW9uRmFpbHVyZUxpc3RlbmVycyB9IGZyb20gXCIuLi9jbGllbnQvYXBwLW5hdi1mYWlsdXJlLWhhbmRsZXIuanNcIjtcbmltcG9ydCB7IG5vdGlmeUFwcFJvdXRlclRyYW5zaXRpb25TdGFydCB9IGZyb20gXCIuLi9jbGllbnQvaW5zdHJ1bWVudGF0aW9uLWNsaWVudC1zdGF0ZS5qc1wiO1xuaW1wb3J0IFwiLi4vY2xpZW50L2luc3RydW1lbnRhdGlvbi1jbGllbnQuanNcIjtcbmltcG9ydCB7IGNyZWF0ZU5hdmlnYXRpb25SdW50aW1lUm91dGVNYW5pZmVzdExvYWRlciwgZ2V0TmF2aWdhdGlvblJ1bnRpbWUsIGxvYWROYXZpZ2F0aW9uUnVudGltZVJvdXRlTWFuaWZlc3QsIHJlZ2lzdGVyTmF2aWdhdGlvblJ1bnRpbWVCb290c3RyYXAsIHJlZ2lzdGVyTmF2aWdhdGlvblJ1bnRpbWVGdW5jdGlvbnMgfSBmcm9tIFwiLi4vY2xpZW50L25hdmlnYXRpb24tcnVudGltZS5qc1wiO1xuaW1wb3J0IHsgQXBwRWxlbWVudHNXaXJlIH0gZnJvbSBcIi4vYXBwLWVsZW1lbnRzLXdpcmUuanNcIjtcbmltcG9ydCB7IGdldE1vdW50ZWRTbG90SWRzSGVhZGVyLCByZXNvbHZlVmlzaXRlZFJlc3BvbnNlSW50ZXJjZXB0aW9uQ29udGV4dCB9IGZyb20gXCIuL2FwcC1lbGVtZW50cy5qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQmZjYWNoZVNlZ21lbnRJZGVudGl0eU1hcCwgY3JlYXRlSW5pdGlhbEJmY2FjaGVJZE1hcCB9IGZyb20gXCIuL2FwcC1iZmNhY2hlLWlkZW50aXR5LmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVEaXNjYXJkZWRTZXJ2ZXJBY3Rpb25SZWZyZXNoU2NoZWR1bGVyLCBjcmVhdGVTZXJ2ZXJBY3Rpb25Jbml0aWF0aW9uU25hcHNob3QsIHJlc29sdmVTZXJ2ZXJBY3Rpb25PcGVyYXRpb25MYW5lIH0gZnJvbSBcIi4vYXBwLWJyb3dzZXItYWN0aW9uLXJlc3VsdC5qc1wiO1xuaW1wb3J0IHsgcmVzb2x2ZU1hbmlmZXN0TmF2aWdhdGlvbkludGVyY2VwdGlvbkNvbnRleHQsIHJlc29sdmVNaWRkbGV3YXJlUmV3cml0ZU5hdmlnYXRpb25JbnRlcmNlcHRpb25Db250ZXh0IH0gZnJvbSBcIi4vYXBwLWJyb3dzZXItaW50ZXJjZXB0aW9uLWNvbnRleHQuanNcIjtcbmltcG9ydCB7IGlzRXh0ZXJuYWxIaXN0b3J5U3RhdGUsIHJlYWRIaXN0b3J5U3RhdGVBY3RpdmVSb3V0ZVBhdGhzLCByZWFkSGlzdG9yeVN0YXRlUHJldmlvdXNOZXh0VXJsLCByZXNvbHZlQWN0aXZlUm91dGVQYXRocyB9IGZyb20gXCIuL2FwcC1oaXN0b3J5LXN0YXRlLmpzXCI7XG5pbXBvcnQgeyBBcHBCcm93c2VyTXBhTmF2aWdhdGlvblNjaGVkdWxlciB9IGZyb20gXCIuL2FwcC1icm93c2VyLW1wYS1uYXZpZ2F0aW9uLmpzXCI7XG5pbXBvcnQgeyBzdHJpcFJzY0NvbXBsZXRpb25NZXRhZGF0YVJlc3BvbnNlIH0gZnJvbSBcIi4vcnNjLWNvbXBsZXRpb24tbWV0YWRhdGEuanNcIjtcbmltcG9ydCB7IGJsb2NrRGFuZ2Vyb3VzU3RyZWFtZWRSc2NSZWRpcmVjdCB9IGZyb20gXCIuL2FwcC1icm93c2VyLXJzYy1yZWRpcmVjdC5qc1wiO1xuaW1wb3J0IHsgbmF2aWdhdGlvblBsYW5uZXIgfSBmcm9tIFwiLi9uYXZpZ2F0aW9uLXBsYW5uZXIuanNcIjtcbmltcG9ydCB7IGRlY29kZVJlZGlyZWN0RXJyb3IsIGlzUmVkaXJlY3RFcnJvciB9IGZyb20gXCIuLi9zaGltcy9uYXZpZ2F0aW9uLWVycm9ycy5qc1wiO1xuaW1wb3J0IHsgYmVnaW5BcHBSb3V0ZXJTY3JvbGxJbnRlbnQsIGNvbnN1bWVBcHBSb3V0ZXJTY3JvbGxJbnRlbnQgfSBmcm9tIFwiLi4vc2hpbXMvYXBwLXJvdXRlci1zY3JvbGwtc3RhdGUuanNcIjtcbmltcG9ydCB7IGdldEJmY2FjaGVJZE1hcENvbnRleHQsIGdldE5hdmlnYXRpb25Db250ZXh0LCBzZXROYXZpZ2F0aW9uQ29udGV4dCB9IGZyb20gXCIuLi9zaGltcy9uYXZpZ2F0aW9uLWNvbnRleHQtc3RhdGUuanNcIjtcbmltcG9ydCB7IERZTkFNSUNfTkFWSUdBVElPTl9DQUNIRV9UVEwsIFBSRUZFVENIX0NBQ0hFX1RUTCwgX19iYXNlUGF0aCwgYXBwUm91dGVySW5zdGFuY2UsIGNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZSwgY29uc3VtZVByZWZldGNoUmVzcG9uc2UsIGNvbnN1bWVQcmVmZXRjaFJlc3BvbnNlRm9yTmF2aWdhdGlvbiwgY3JlYXRlQ2FjaGVkUnNjUmVzcG9uc2VTbmFwc2hvdCwgY3JlYXRlQ2xpZW50TmF2aWdhdGlvblJlbmRlclNuYXBzaG90LCBjcmVhdGVTbmFwc2hvdFBhdGhBbmRTZWFyY2gsIGRlbGV0ZVByZWZldGNoUmVzcG9uc2VTbmFwc2hvdCwgZGlzYWJsZU5hdmlnYXRpb25SZXNwb25zZVByZWZldGNoQ2FjaGVSZXVzZSwgZ2V0Q2xpZW50TmF2aWdhdGlvblJlbmRlckNvbnRleHQsIGdldE1vdW50ZWRTbG90c0hlYWRlciwgZ2V0UHJlZmV0Y2hDYWNoZSwgaGFzUHJlZmV0Y2hDYWNoZUVudHJ5Rm9yTmF2aWdhdGlvbiwgaW52YWxpZGF0ZUR5bmFtaWNQcmVmZXRjaENhY2hlLCBpbnZhbGlkYXRlUHJlZmV0Y2hDYWNoZSwgaW52YWxpZGF0ZVZpc2l0ZWRSZXNwb25zZVByZWZldGNoZXMsIHBhcnNlUmVuZGVyZWRQYXRoQW5kU2VhcmNoSGVhZGVyLCBwcmVsb2FkSHlicmlkQ2xpZW50Um91dGVPd25lciwgcHVzaEhpc3RvcnlTdGF0ZVdpdGhvdXROb3RpZnksIHJlcGxhY2VDbGllbnRQYXJhbXNXaXRob3V0Tm90aWZ5LCByZXBsYWNlSGlzdG9yeVN0YXRlV2l0aG91dE5vdGlmeSwgcmVzb2x2ZUxvYWRlZEh5YnJpZENsaWVudFJld3JpdGVIcmVmLCByZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5TW91bnRlZFNsb3RzSGVhZGVyLCByZXN0b3JlUnNjUmVzcG9uc2UsIHNhdmVTY3JvbGxQb3NpdGlvbiwgc2VlZFByZWZldGNoUmVzcG9uc2VTbmFwc2hvdCwgc2V0Q2xpZW50UGFyYW1zLCBzZXRNb3VudGVkU2xvdHNIZWFkZXIsIHNldFBlbmRpbmdQYXRobmFtZSwgdHJhY2tBcHBSb3V0ZXJOYXZpZ2F0aW9uSW5GbGlnaHQsIHVzZVJvdXRlciB9IGZyb20gXCIuLi9zaGltcy9uYXZpZ2F0aW9uLmpzXCI7XG5pbXBvcnQgeyBBcHBSb3V0ZXJTY3JvbGxDb21taXRQcm92aWRlciB9IGZyb20gXCIuLi9zaGltcy9hcHAtcm91dGVyLXNjcm9sbC5qc1wiO1xuaW1wb3J0IHsgY2h1bmtzVG9SZWFkYWJsZVN0cmVhbSwgY3JlYXRlUHJvZ3Jlc3NpdmVSc2NTdHJlYW0sIGdldFZpbmV4dEJyb3dzZXJHbG9iYWwgfSBmcm9tIFwiLi9hcHAtYnJvd3Nlci1zdHJlYW0uanNcIjtcbmltcG9ydCB7IGNyZWF0ZU1vdW50ZWRMYXlvdXRzSGVhZGVyLCBob2xkc1NraXBwZWRMYXlvdXRzIH0gZnJvbSBcIi4vYXBwLW1vdW50ZWQtbGF5b3V0cy5qc1wiO1xuaW1wb3J0IHsgQmZjYWNoZUlkZW50aXR5TWFwQ29udGV4dCwgYmluZEFwcEVsZW1lbnRzUmVuZGVyZWRTZWFyY2gsIHNldEFwcEVsZW1lbnRzUmVuZGVyZWRTZWFyY2ggfSBmcm9tIFwiLi4vc2hpbXMvc2xvdC5qc1wiO1xuaW1wb3J0IHsgQ09NTUlUVEVEX0NBQ0hFX0FQUF9OQVZJR0FUSU9OX1BBWUxPQURfT1JJR0lOLCBGUkVTSF9BUFBfTkFWSUdBVElPTl9QQVlMT0FEX09SSUdJTiwgVklTSVRFRF9DQUNIRV9BUFBfTkFWSUdBVElPTl9QQVlMT0FEX09SSUdJTiwgaXNDYWNoZVJlc3RvcmFibGVBcHBQYXlsb2FkTWV0YWRhdGEsIGlzQ29tcGxldGVBcHBQYXlsb2FkTWV0YWRhdGEsIHJlc29sdmVJbnRlcmNlcHRpb25Db250ZXh0RnJvbVByZXZpb3VzTmV4dFVybCB9IGZyb20gXCIuL2FwcC1icm93c2VyLXN0YXRlLmpzXCI7XG5pbXBvcnQgeyBjbGVhckhhcmROYXZpZ2F0aW9uTG9vcEd1YXJkLCBjcmVhdGVBcHBCcm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIsIGNyZWF0ZUJhc2VQYXRoU3RyaXBwZWRQYXRoQW5kU2VhcmNoLCBuYXZpZ2F0ZURvY3VtZW50RGlyZWN0bHkgfSBmcm9tIFwiLi9hcHAtYnJvd3Nlci1uYXZpZ2F0aW9uLWNvbnRyb2xsZXIuanNcIjtcbmltcG9ydCB7IGNyZWF0ZUFwcFJvdXRlVHJlZSB9IGZyb20gXCIuL2FwcC1yb3V0ZS10cmVlLmpzXCI7XG5pbXBvcnQgeyBzaG91bGRSZWNvdmVyU2FtZVBhdGhTZWFyY2hDb21taXRPblJlc3BvbnNlQ29tcGxldGlvbiB9IGZyb20gXCIuL2FwcC1icm93c2VyLW5hdmlnYXRpb24tcmVzcG9uc2UuanNcIjtcbmltcG9ydCB7IGNyZWF0ZVN1cHBsZW1lbnRhbFJlZnJlc2hDb29yZGluYXRvciwgbWVyZ2VSZWZyZXNoZWRQYXJhbGxlbFNsb3QsIHJlcXVpcmVDb21wbGV0ZVN1cHBsZW1lbnRhbFJlZnJlc2gsIHJlc29sdmVQZXJzaXN0ZWRTb3VyY2VQYWdlUmVmcmVzaGVzLCByZXNvbHZlU2VydmVyQWN0aW9uU3VwcGxlbWVudGFsUmVmcmVzaCwgcmVzb2x2ZVN1cHBsZW1lbnRhbFJlZnJlc2hlcyB9IGZyb20gXCIuL2FwcC1icm93c2VyLXN1cHBsZW1lbnRhbC1yZWZyZXNoLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVBcHBCcm93c2VyTmF2aWdhdGlvbkFib3J0Q29vcmRpbmF0b3IgfSBmcm9tIFwiLi9hcHAtYnJvd3Nlci1uYXZpZ2F0aW9uLWFib3J0LmpzXCI7XG5pbXBvcnQgeyBjb25zdW1lSW5pdGlhbEZvcm1TdGF0ZSwgY3JlYXRlVmluZXh0SHlkcmF0ZVJvb3RPcHRpb25zLCBoeWRyYXRlUm9vdEluVHJhbnNpdGlvbiwgcmVzb2x2ZUZldGNoZWRIeWRyYXRpb25Mb2NhdGlvbiB9IGZyb20gXCIuL2FwcC1icm93c2VyLWh5ZHJhdGlvbi5qc1wiO1xuaW1wb3J0IHsgQXBwQnJvd3Nlckhpc3RvcnlDb250cm9sbGVyIH0gZnJvbSBcIi4vYXBwLWJyb3dzZXItaGlzdG9yeS1jb250cm9sbGVyLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVWaXNpdGVkUmVzcG9uc2VDYWNoZUVudHJ5LCBkZWxldGVBbGxWaXNpdGVkUmVzcG9uc2VDYWNoZUVudHJpZXMsIGRlbGV0ZVZpc2l0ZWRSZXNwb25zZUNhY2hlRW50cnksIGZpbmRWaXNpdGVkUmVzcG9uc2VDYWNoZUVudHJ5LCBmaW5kVmlzaXRlZFJlc3BvbnNlRm9yRnVsbFByZWZldGNoLCBoYXNOYXZpZ2F0aW9uUmVzcG9uc2VIaXN0b3J5TGlmZXRpbWUsIGlzVmlzaXRlZFJlc3BvbnNlQ2FjaGVFbnRyeUZyZXNoLCByZXZva2VIaXN0b3J5UmVzdG9yZU5hdmlnYXRpb25SZXVzZSB9IGZyb20gXCIuL2FwcC12aXNpdGVkLXJlc3BvbnNlLWNhY2hlLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVQb3BzdGF0ZVJlc3RvcmVIYW5kbGVyLCByZXN0b3JlU3luY2hyb25vdXNQb3BzdGF0ZVNjcm9sbFBvc2l0aW9uLCBzaG91bGRDb21taXRQb3BzdGF0ZVVybFdpdGhvdXROYXZpZ2F0aW9uIH0gZnJvbSBcIi4vYXBwLWJyb3dzZXItcG9wc3RhdGUuanNcIjtcbmltcG9ydCBEZWZhdWx0R2xvYmFsRXJyb3IgZnJvbSBcIi4uL3NoaW1zL2RlZmF1bHQtZ2xvYmFsLWVycm9yLmpzXCI7XG5pbXBvcnQgeyBEZXZSZWNvdmVyeUJvdW5kYXJ5LCBHbG9iYWxFcnJvckJvdW5kYXJ5LCBSZWRpcmVjdEJvdW5kYXJ5IH0gZnJvbSBcIi4uL3NoaW1zL2Vycm9yLWJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVEZXZPbkNhdWdodEVycm9yLCBjcmVhdGVPblVuY2F1Z2h0RXJyb3IsIGNyZWF0ZVByb2RPbkNhdWdodEVycm9yLCBjcmVhdGVQcm9kT25SZWNvdmVyYWJsZUVycm9yIH0gZnJvbSBcIi4vYXBwLWJyb3dzZXItZXJyb3IuanNcIjtcbmltcG9ydCB7IGNyZWF0ZUh5ZHJhdGlvbkNhY2hlUHVibGljYXRpb24gfSBmcm9tIFwiLi9hcHAtaHlkcmF0aW9uLWNhY2hlLXB1YmxpY2F0aW9uLmpzXCI7XG5pbXBvcnQgeyBwZWVrU2V0dGxlZFByZWZldGNoUmVzcG9uc2VGb3JOYXZpZ2F0aW9uLCBwcmVwYXJlQ29uc3VtZWRQcmVmZXRjaFJlc3BvbnNlRm9yUHVibGljYXRpb24sIHByZXNlcnZlQ29tbWl0dGVkUHJlZmV0Y2hFeHBpcnksIHJlc29sdmVQcmVmZXRjaE5hdmlnYXRpb25SZXNwb25zZVVybCB9IGZyb20gXCIuL2FwcC1icm93c2VyLXByZWZldGNoLXJlc3BvbnNlLmpzXCI7XG5pbXBvcnQgeyBjYW5Db21taXRPcHRpbWlzdGljUm91dGVUZW1wbGF0ZSwgY3JlYXRlT3B0aW1pc3RpY1JvdXRlVGVtcGxhdGUsIGNyZWF0ZU9wdGltaXN0aWNSb3V0ZVRlbXBsYXRlU3RvcmUsIGdldE9wdGltaXN0aWNQcmVmZXRjaFNvdXJjZUtleSwgZ2V0T3B0aW1pc3RpY1JvdXRlVGVtcGxhdGVLZXksIGtlZXBPcHRpbWlzdGljU3RyZWFtaW5nTWV0YWRhdGEsIHJlc29sdmVPcHRpbWlzdGljTmF2aWdhdGlvblBhcmFtc0ZvckhyZWYsIHJlc29sdmVPcHRpbWlzdGljTmF2aWdhdGlvblBheWxvYWQgfSBmcm9tIFwiLi9hcHAtb3B0aW1pc3RpYy1yb3V0aW5nLmpzXCI7XG5pbXBvcnQgeyByZW1vdmVTdHlsZXNoZWV0TGlua3NDb3ZlcmVkQnlJbmxpbmVDc3MgfSBmcm9tIFwiLi9hcHAtaW5saW5lLWNzcy1jbGllbnQuanNcIjtcbmltcG9ydCB7IEZyYWdtZW50LCBjcmVhdGVFbGVtZW50LCBzdGFydFRyYW5zaXRpb24sIHVzZSwgdXNlRWZmZWN0LCB1c2VMYXlvdXRFZmZlY3QsIHVzZU1lbW8sIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZVJvb3QsIGh5ZHJhdGVSb290IH0gZnJvbSBcInJlYWN0LWRvbS9jbGllbnRcIjtcbmltcG9ydCB7IGNyZWF0ZUZyb21GZXRjaCwgY3JlYXRlRnJvbVJlYWRhYmxlU3RyZWFtLCBzZXRTZXJ2ZXJDYWxsYmFjayB9IGZyb20gXCJAdml0ZWpzL3BsdWdpbi1yc2MvYnJvd3NlclwiO1xuaW1wb3J0IHsgZmx1c2hTeW5jIH0gZnJvbSBcInJlYWN0LWRvbVwiO1xuaW1wb3J0IHsgaGFzU2VydmVyQWN0aW9ucywgbG9hZFNlcnZlckFjdGlvbkNsaWVudCB9IGZyb20gXCJ2aXJ0dWFsOnZpbmV4dC1hcHAtY2FwYWJpbGl0aWVzXCI7XG4vLyNyZWdpb24gc3JjL3NlcnZlci9hcHAtYnJvd3Nlci1lbnRyeS50c1xuY29uc3QgSEFTX0NMSUVOVF9SRVdSSVRFUyA9IHByb2Nlc3MuZW52Ll9fVklORVhUX0hBU19DTElFTlRfUkVXUklURVMgIT09IFwiZmFsc2VcIjtcbmZ1bmN0aW9uIHRvQWN0aW9uVHlwZShraW5kKSB7XG5cdHJldHVybiBraW5kID09PSBcInRyYXZlcnNlXCIgPyBcInRyYXZlcnNlXCIgOiBcIm5hdmlnYXRlXCI7XG59XG5mdW5jdGlvbiB0b09wZXJhdGlvbkxhbmUoa2luZCkge1xuXHRzd2l0Y2ggKGtpbmQpIHtcblx0XHRjYXNlIFwibmF2aWdhdGVcIjogcmV0dXJuIFwibmF2aWdhdGlvblwiO1xuXHRcdGNhc2UgXCJyZWZyZXNoXCI6IHJldHVybiBcInJlZnJlc2hcIjtcblx0XHRjYXNlIFwidHJhdmVyc2VcIjogcmV0dXJuIFwidHJhdmVyc2VcIjtcblx0XHRkZWZhdWx0OiB0aHJvdyBuZXcgRXJyb3IoXCJbdmluZXh0XSBVbmtub3duIG5hdmlnYXRpb24ga2luZDogXCIgKyBTdHJpbmcoa2luZCkpO1xuXHR9XG59XG5jb25zdCBNQVhfVklTSVRFRF9SRVNQT05TRV9DQUNIRV9TSVpFID0gNTA7XG5jb25zdCBJU19TVEFUSUNfRVhQT1JUID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiICYmIHByb2Nlc3MuZW52Ll9fTkVYVF9DT05GSUdfT1VUUFVUID09PSBcImV4cG9ydFwiO1xubGV0IGNsaWVudERlcGxveW1lbnRWZXJzaW9uID0gbnVsbDtcbmxldCBjbGllbnRSc2NDb21wYXRpYmlsaXR5SWQgPSBJU19TVEFUSUNfRVhQT1JUID8gbnVsbCA6IFwidmluZXh0Om1pc3NpbmdcIjtcbi8qKlxuKiBEZWNvZGluZyBhIHBheWxvYWQgbG9hZHMgdGhlIGNodW5rcyBpdHMgY2xpZW50IHJlZmVyZW5jZXMgbmFtZSwgc28gYVxuKiBwYXlsb2FkIHRoaXMgcGFnZSBjYW4ndCBuYXZpZ2F0ZSB0byBpcyBvbmx5IGRlY29kZWQgYnkgdGhlIG5hdmlnYXRpb24gdGhhdFxuKiBoYXJkLW5hdmlnYXRlcy4gT3RoZXJ3aXNlIGEgcHJlZmV0Y2ggYWZ0ZXIgYSBkZXBsb3kgd291bGQgbG9hZCB0aGUgbmV3XG4qIGRlcGxveW1lbnQncyBjb2RlIGFuZCBzdHlsZXNoZWV0cyBpbnRvIHRoaXMgcGFnZS5cbiovXG5mdW5jdGlvbiBpc1JzY1Jlc3BvbnNlQ29tcGF0aWJsZShjb21wYXRpYmlsaXR5SWRIZWFkZXIpIHtcblx0cmV0dXJuIGlzUnNjQ29tcGF0aWJpbGl0eUlkQ29tcGF0aWJsZShjb21wYXRpYmlsaXR5SWRIZWFkZXIsIGNsaWVudFJzY0NvbXBhdGliaWxpdHlJZCk7XG59XG5mdW5jdGlvbiBzZXRDbGllbnRSc2NDb21wYXRpYmlsaXR5SWQoY29tcGF0aWJpbGl0eUlkKSB7XG5cdGlmIChJU19TVEFUSUNfRVhQT1JUIHx8ICFjb21wYXRpYmlsaXR5SWQpIHJldHVybjtcblx0Y2xpZW50UnNjQ29tcGF0aWJpbGl0eUlkID0gY29tcGF0aWJpbGl0eUlkO1xufVxuY29uc3Qgb3B0aW1pc3RpY1JvdXRlVGVtcGxhdGVzID0gY3JlYXRlT3B0aW1pc3RpY1JvdXRlVGVtcGxhdGVTdG9yZSgpO1xuZnVuY3Rpb24gY2xhaW1Jbml0aWFsQXBwUm91dGVyQm9vdHN0cmFwKCkge1xuXHRpZiAod2luZG93Ll9fVklORVhUX1JTQ19ST09UX18gfHwgd2luZG93Ll9fVklORVhUX1JTQ19CT09UU1RSQVBfU1RBVEVfXykgcmV0dXJuIGZhbHNlO1xuXHR3aW5kb3cuX19WSU5FWFRfUlNDX0JPT1RTVFJBUF9TVEFURV9fID0gXCJzdGFydGluZ1wiO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIG1hcmtJbml0aWFsQXBwUm91dGVyQm9vdHN0cmFwSHlkcmF0ZWQoKSB7XG5cdHdpbmRvdy5fX1ZJTkVYVF9SU0NfQk9PVFNUUkFQX1NUQVRFX18gPSBcImh5ZHJhdGVkXCI7XG59XG5yZWdpc3Rlck5hdmlnYXRpb25SdW50aW1lRnVuY3Rpb25zKHsgbG9hZFJvdXRlTWFuaWZlc3Q6IGNyZWF0ZU5hdmlnYXRpb25SdW50aW1lUm91dGVNYW5pZmVzdExvYWRlcigoKSA9PiBpbXBvcnQoXCJ2aXJ0dWFsOnZpbmV4dC1hcHAtcm91dGUtbWFuaWZlc3RcIikpIH0pO1xuZnVuY3Rpb24gZ2V0QnJvd3NlclJvdXRlTWFuaWZlc3QoKSB7XG5cdHJldHVybiBnZXROYXZpZ2F0aW9uUnVudGltZSgpPy5ib290c3RyYXAucm91dGVNYW5pZmVzdCA/PyBudWxsO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVN0YXRpY0V4cG9ydFJvdXRlUGFyYW1zKGhyZWYpIHtcblx0Y29uc3Qgcm91dGVNYW5pZmVzdCA9IGdldEJyb3dzZXJSb3V0ZU1hbmlmZXN0KCk7XG5cdGlmIChyb3V0ZU1hbmlmZXN0ID09PSBudWxsKSByZXR1cm4ge307XG5cdHJldHVybiByZXNvbHZlT3B0aW1pc3RpY05hdmlnYXRpb25QYXJhbXNGb3JIcmVmKHtcblx0XHRiYXNlUGF0aDogX19iYXNlUGF0aCxcblx0XHRocmVmLFxuXHRcdHJvdXRlTWFuaWZlc3Rcblx0fSkgPz8ge307XG59XG5mdW5jdGlvbiBpc1N0YXRpY0V4cG9ydFBheWxvYWREZXBsb3ltZW50Q29tcGF0aWJsZShlbGVtZW50cykge1xuXHRpZiAoIUlTX1NUQVRJQ19FWFBPUlQpIHJldHVybiB0cnVlO1xuXHRjb25zdCBkZXBsb3ltZW50VmVyc2lvbiA9IEFwcEVsZW1lbnRzV2lyZS5yZWFkTWV0YWRhdGEoZWxlbWVudHMpLmFydGlmYWN0Q29tcGF0aWJpbGl0eS5kZXBsb3ltZW50VmVyc2lvbjtcblx0cmV0dXJuIGNsaWVudERlcGxveW1lbnRWZXJzaW9uICE9PSBudWxsICYmIGRlcGxveW1lbnRWZXJzaW9uID09PSBjbGllbnREZXBsb3ltZW50VmVyc2lvbjtcbn1cbmNvbnN0IGhpc3RvcnlDb250cm9sbGVyID0gbmV3IEFwcEJyb3dzZXJIaXN0b3J5Q29udHJvbGxlcih7XG5cdGluaXRpYWxIaXN0b3J5U3RhdGU6IHdpbmRvdy5oaXN0b3J5LnN0YXRlLFxuXHRtYXhIaXN0b3J5U3RhdGVTbmFwc2hvdHM6IDUwLFxuXHRyZWFkSGlzdG9yeVN0YXRlOiAoKSA9PiB3aW5kb3cuaGlzdG9yeS5zdGF0ZSxcblx0cmVhZEN1cnJlbnRIcmVmOiAoKSA9PiB3aW5kb3cubG9jYXRpb24uaHJlZixcblx0cHVzaEhpc3RvcnlTdGF0ZTogKHN0YXRlLCBocmVmLCBsYW5kKSA9PiBwdXNoSGlzdG9yeVN0YXRlV2l0aG91dE5vdGlmeShzdGF0ZSwgXCJcIiwgaHJlZiwgbGFuZCksXG5cdHJlcGxhY2VIaXN0b3J5U3RhdGU6IChzdGF0ZSwgaHJlZiwgbGFuZCkgPT4gcmVwbGFjZUhpc3RvcnlTdGF0ZVdpdGhvdXROb3RpZnkoc3RhdGUsIFwiXCIsIGhyZWYsIGxhbmQpLFxuXHRyZWFkVmlzaWJsZU5hdmlnYXRpb25NZXRhZGF0YTogKCkgPT4ge1xuXHRcdGlmICghaGFzQnJvd3NlclJvdXRlclN0YXRlKCkpIHJldHVybiBudWxsO1xuXHRcdGNvbnN0IHJvdXRlclN0YXRlID0gZ2V0QnJvd3NlclJvdXRlclN0YXRlKCk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGFjdGl2ZVJvdXRlUGF0aHM6IHJlc29sdmVBY3RpdmVSb3V0ZVBhdGhzKHJvdXRlclN0YXRlLnNsb3RCaW5kaW5ncyksXG5cdFx0XHRiZmNhY2hlSWRzOiByb3V0ZXJTdGF0ZS5iZmNhY2hlSWRzLFxuXHRcdFx0cHJldmlvdXNOZXh0VXJsOiByb3V0ZXJTdGF0ZS5wcmV2aW91c05leHRVcmxcblx0XHR9O1xuXHR9XG59KTtcbmNvbnN0IGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlciA9IGNyZWF0ZUFwcEJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlcih7XG5cdGJhc2VQYXRoOiBfX2Jhc2VQYXRoLFxuXHRnZXRSb3V0ZU1hbmlmZXN0OiBnZXRCcm93c2VyUm91dGVNYW5pZmVzdCxcblx0bG9hZFJvdXRlTWFuaWZlc3Q6IGxvYWROYXZpZ2F0aW9uUnVudGltZVJvdXRlTWFuaWZlc3QsXG5cdG5hdmlnYXRlRG9jdW1lbnQ6IChocmVmLCBtb2RlKSA9PiB7XG5cdFx0aWYgKG1wYU5hdmlnYXRpb25UcmVlKSB7XG5cdFx0XHRtcGFOYXZpZ2F0aW9uVHJlZS5lbnRlcihocmVmLCBtb2RlID09PSBcInJlcGxhY2VcIiA/IFwicmVwbGFjZVwiIDogXCJwdXNoXCIpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRuYXZpZ2F0ZURvY3VtZW50RGlyZWN0bHkoaHJlZiwgbW9kZSk7XG5cdH0sXG5cdHN5bmNIaXN0b3J5U3RhdGVQcmV2aW91c05leHRVcmw6IChwcmV2aW91c05leHRVcmwsIGJmY2FjaGVJZHMpID0+IGhpc3RvcnlDb250cm9sbGVyLnN5bmNDdXJyZW50SGlzdG9yeVN0YXRlUHJldmlvdXNOZXh0VXJsKHByZXZpb3VzTmV4dFVybCwgYmZjYWNoZUlkcylcbn0pO1xuY29uc3QgZGlzY2FyZGVkU2VydmVyQWN0aW9uUmVmcmVzaFNjaGVkdWxlciA9IGhhc1NlcnZlckFjdGlvbnMgPyBjcmVhdGVEaXNjYXJkZWRTZXJ2ZXJBY3Rpb25SZWZyZXNoU2NoZWR1bGVyKHsgcnVuUmVmcmVzaCgpIHtcblx0Y2xlYXJDbGllbnROYXZpZ2F0aW9uQ2FjaGVzKCk7XG5cdGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5uYXZpZ2F0ZT8uKHdpbmRvdy5sb2NhdGlvbi5ocmVmLCAwLCBcInJlZnJlc2hcIiwgdm9pZCAwLCB2b2lkIDAsIHRydWUpO1xufSB9KSA6IHtcblx0bWFya05hdmlnYXRpb25TZXR0bGVkKCkge30sXG5cdG1hcmtOYXZpZ2F0aW9uU3RhcnQoKSB7fSxcblx0c2NoZWR1bGUoKSB7fVxufTtcbmNvbnN0IHNlcnZlckFjdGlvblN1cHBsZW1lbnRhbFJlZnJlc2hDb29yZGluYXRvciA9IGNyZWF0ZVN1cHBsZW1lbnRhbFJlZnJlc2hDb29yZGluYXRvcigpO1xuY29uc3QgTmF2aWdhdGlvbkNvbW1pdFNpZ25hbCA9IGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5OYXZpZ2F0aW9uQ29tbWl0U2lnbmFsO1xuY29uc3QgTmF2aWdhdGlvbkhpc3RvcnlDb21taXQgPSBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuTmF2aWdhdGlvbkhpc3RvcnlDb21taXQ7XG5jb25zdCBBQ1RJT05fSFRUUF9GQUxMQkFDS19ST0JPVFNfTUVUQV9BVFRSID0gXCJkYXRhLXZpbmV4dC1hY3Rpb24taHR0cC1mYWxsYmFja1wiO1xuZnVuY3Rpb24gc3luY1NlcnZlckFjdGlvbkh0dHBGYWxsYmFja0hlYWQoc3RhdHVzKSB7XG5cdGRvY3VtZW50LmhlYWQucXVlcnlTZWxlY3RvckFsbChgbWV0YVske0FDVElPTl9IVFRQX0ZBTExCQUNLX1JPQk9UU19NRVRBX0FUVFJ9PVwicm9ib3RzXCJdYCkuZm9yRWFjaCgobm9kZSkgPT4gbm9kZS5yZW1vdmUoKSk7XG5cdGlmIChzdGF0dXMgIT09IDQwNCkgcmV0dXJuO1xuXHRjb25zdCByb2JvdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibWV0YVwiKTtcblx0cm9ib3RzLm5hbWUgPSBcInJvYm90c1wiO1xuXHRyb2JvdHMuY29udGVudCA9IFwibm9pbmRleFwiO1xuXHRyb2JvdHMuc2V0QXR0cmlidXRlKEFDVElPTl9IVFRQX0ZBTExCQUNLX1JPQk9UU19NRVRBX0FUVFIsIFwicm9ib3RzXCIpO1xuXHRkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHJvYm90cyk7XG59XG5jb25zdCBCZmNhY2hlSWRNYXBDb250ZXh0ID0gZ2V0QmZjYWNoZUlkTWFwQ29udGV4dCgpO1xuZnVuY3Rpb24gcGFyc2VFbmNvZGVkSnNvbkhlYWRlcih2YWx1ZSkge1xuXHRpZiAoIXZhbHVlKSByZXR1cm4gbnVsbDtcblx0dHJ5IHtcblx0XHRyZXR1cm4gSlNPTi5wYXJzZShkZWNvZGVVUklDb21wb25lbnQodmFsdWUpKTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cbn1cbmZ1bmN0aW9uIGlzUm91dGVyU3RhdGVQcm9taXNlKHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFByb21pc2U7XG59XG5sZXQgbGF0ZXN0Q2xpZW50UGFyYW1zID0ge307XG5jb25zdCB2aXNpdGVkUmVzcG9uc2VDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5sZXQgY2xpZW50TmF2aWdhdGlvbkNhY2hlR2VuZXJhdGlvbiA9IDA7XG5sZXQgYnJvd3NlclJvdXRlclN0YXRlSGFzRXZlckNvbW1pdHRlZCA9IGZhbHNlO1xubGV0IGluaXRpYWxQcmVmZXRjaFJvdXRlclN0YXRlID0gbnVsbDtcbmNvbnN0IG1wYU5hdmlnYXRpb25TY2hlZHVsZXIgPSBuZXcgQXBwQnJvd3Nlck1wYU5hdmlnYXRpb25TY2hlZHVsZXIoKTtcbmNvbnN0IHVucmVzb2x2ZWRNcGFOYXZpZ2F0aW9uID0gbmV3IFByb21pc2UoKCkgPT4ge30pO1xubGV0IG1wYU5hdmlnYXRpb25UcmVlID0gbnVsbDtcbmxldCBtcGFOYXZpZ2F0aW9uUmVzdG9yZSA9IG51bGw7XG5mdW5jdGlvbiB3YWl0Rm9yTXBhTmF2aWdhdGlvblJlc3RvcmUoKSB7XG5cdGlmICghbXBhTmF2aWdhdGlvblJlc3RvcmUpIHtcblx0XHRsZXQgcmVzb2x2ZSA9ICgpID0+IHt9O1xuXHRcdG1wYU5hdmlnYXRpb25SZXN0b3JlID0ge1xuXHRcdFx0cHJvbWlzZTogbmV3IFByb21pc2UoKHJlc29sdmVQcm9taXNlKSA9PiB7XG5cdFx0XHRcdHJlc29sdmUgPSByZXNvbHZlUHJvbWlzZTtcblx0XHRcdH0pLFxuXHRcdFx0cmVzb2x2ZVxuXHRcdH07XG5cdH1cblx0cmV0dXJuIG1wYU5hdmlnYXRpb25SZXN0b3JlLnByb21pc2U7XG59XG5jb25zdCBSU0NfSE1SX1NFVFRMRV9ERUxBWV9NUyA9IDE1MDtcbmNvbnN0IERFRkFVTFRfR0xPQkFMX0VSUk9SX0NPTVBPTkVOVCA9IERlZmF1bHRHbG9iYWxFcnJvcjtcbmxldCBsYXRlc3RSc2NIbXJVcGRhdGVJZCA9IDA7XG5sZXQgc3luY2hyb25vdXNQb3BzdGF0ZVNjcm9sbFJlc3RvcmVOYXZpZ2F0aW9uSWQgPSBudWxsO1xuZnVuY3Rpb24gd2FpdEZvclJzY0htclNldHRsZShkZWxheU1zID0gUlNDX0hNUl9TRVRUTEVfREVMQVlfTVMpIHtcblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0d2luZG93LnNldFRpbWVvdXQocmVzb2x2ZSwgZGVsYXlNcyk7XG5cdH0pO1xufVxuZnVuY3Rpb24gcmVzdG9yZUhpc3RvcnlTdGF0ZVNuYXBzaG90KGhpc3RvcnlTdGF0ZSwgbmF2SWQsIG9uQXBwcm92ZWRCZWZvcmVDb21taXQsIHJlc3RvcmVDb3BpZWRFeHRlcm5hbEhpc3RvcnlFbnRyeSA9IGZhbHNlKSB7XG5cdGxldCByZXN0b3JlZCA9IGZhbHNlO1xuXHRmbHVzaFN5bmMoKCkgPT4ge1xuXHRcdHJlc3RvcmVkID0gaGlzdG9yeUNvbnRyb2xsZXIucmVzdG9yZUhpc3RvcnlTbmFwc2hvdCh7XG5cdFx0XHRoaXN0b3J5U3RhdGUsXG5cdFx0XHRwcmVmZXJFeHRlcm5hbFNuYXBzaG90OiByZXN0b3JlQ29waWVkRXh0ZXJuYWxIaXN0b3J5RW50cnksXG5cdFx0XHRzdGFnZUNsaWVudFBhcmFtcyxcblx0XHRcdGFwcHJvdmVWaXNpYmxlUmVzdG9yZTogKHsgc3RhdGUsIGJlZm9yZUNvbW1pdCB9KSA9PiBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIucmVzdG9yZUhpc3RvcnlTbmFwc2hvdFZpc2libGVTdGF0ZSh7XG5cdFx0XHRcdHJlc3RvcmVDb3BpZWRFeHRlcm5hbEhpc3RvcnlFbnRyeSxcblx0XHRcdFx0YmVmb3JlQ29tbWl0OiAoKSA9PiB7XG5cdFx0XHRcdFx0b25BcHByb3ZlZEJlZm9yZUNvbW1pdD8uKCk7XG5cdFx0XHRcdFx0YmVmb3JlQ29tbWl0KCk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdG5hdklkLFxuXHRcdFx0XHRzdGF0ZSxcblx0XHRcdFx0dGFyZ2V0SHJlZjogd2luZG93LmxvY2F0aW9uLmhyZWZcblx0XHRcdH0pXG5cdFx0fSk7XG5cdH0pO1xuXHRpZiAoIXJlc3RvcmVkKSByZXR1cm4gZmFsc2U7XG5cdGNsaWVudE5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24gKz0gMTtcblx0cmV2b2tlSGlzdG9yeVJlc3RvcmVOYXZpZ2F0aW9uUmV1c2UodmlzaXRlZFJlc3BvbnNlQ2FjaGUpO1xuXHRkaXNhYmxlTmF2aWdhdGlvblJlc3BvbnNlUHJlZmV0Y2hDYWNoZVJldXNlKCk7XG5cdGNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZShuYXZJZCwgeyByZWxlYXNlU25hcHNob3Q6IGZhbHNlIH0pO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpIHtcblx0cmV0dXJuIGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5nZXRCcm93c2VyUm91dGVyU3RhdGUoKTtcbn1cbmZ1bmN0aW9uIGhhc0Jyb3dzZXJSb3V0ZXJTdGF0ZSgpIHtcblx0cmV0dXJuIGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5oYXNCcm93c2VyUm91dGVyU3RhdGUoKTtcbn1cbmZ1bmN0aW9uIHdhaXRGb3JCcm93c2VyUm91dGVyU3RhdGVSZWFkeSgpIHtcblx0cmV0dXJuIGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci53YWl0Rm9yQnJvd3NlclJvdXRlclN0YXRlUmVhZHkoKTtcbn1cbmZ1bmN0aW9uIGJlZ2luUGVuZGluZ0Jyb3dzZXJSb3V0ZXJTdGF0ZSgpIHtcblx0cmV0dXJuIGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5iZWdpblBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUoKTtcbn1cbmZ1bmN0aW9uIGFwcGx5Q2xpZW50UGFyYW1zKHBhcmFtcykge1xuXHRsYXRlc3RDbGllbnRQYXJhbXMgPSBwYXJhbXM7XG5cdHNldENsaWVudFBhcmFtcyhwYXJhbXMpO1xufVxuZnVuY3Rpb24gc3RhZ2VDbGllbnRQYXJhbXMocGFyYW1zKSB7XG5cdGxhdGVzdENsaWVudFBhcmFtcyA9IHBhcmFtcztcblx0cmVwbGFjZUNsaWVudFBhcmFtc1dpdGhvdXROb3RpZnkocGFyYW1zKTtcbn1cbmZ1bmN0aW9uIGNsZWFyVmlzaXRlZFJlc3BvbnNlQ2FjaGUoKSB7XG5cdHZpc2l0ZWRSZXNwb25zZUNhY2hlLmNsZWFyKCk7XG5cdGludmFsaWRhdGVWaXNpdGVkUmVzcG9uc2VQcmVmZXRjaGVzKCk7XG59XG5mdW5jdGlvbiBjbGVhclByZWZldGNoU3RhdGUob3B0aW9ucykge1xuXHRpbnZhbGlkYXRlUHJlZmV0Y2hDYWNoZShvcHRpb25zKTtcblx0b3B0aW1pc3RpY1JvdXRlVGVtcGxhdGVzLmNsZWFyKCk7XG59XG5mdW5jdGlvbiBjbGVhckNsaWVudE5hdmlnYXRpb25DYWNoZXMob3B0aW9ucykge1xuXHRjbGllbnROYXZpZ2F0aW9uQ2FjaGVHZW5lcmF0aW9uICs9IDE7XG5cdGNsZWFyVmlzaXRlZFJlc3BvbnNlQ2FjaGUoKTtcblx0Y2xlYXJQcmVmZXRjaFN0YXRlKG9wdGlvbnMpO1xuXHRoaXN0b3J5Q29udHJvbGxlci5pbnZhbGlkYXRlUmVzdG9yYWJsZUNsaWVudFN0YXRlKCk7XG59XG5mdW5jdGlvbiBjbGVhckR5bmFtaWNDbGllbnROYXZpZ2F0aW9uQ2FjaGVzKCkge1xuXHRjbGllbnROYXZpZ2F0aW9uQ2FjaGVHZW5lcmF0aW9uICs9IDE7XG5cdGNsZWFyVmlzaXRlZFJlc3BvbnNlQ2FjaGUoKTtcblx0aW52YWxpZGF0ZUR5bmFtaWNQcmVmZXRjaENhY2hlKCk7XG5cdG9wdGltaXN0aWNSb3V0ZVRlbXBsYXRlcy5jbGVhcigpO1xuXHRoaXN0b3J5Q29udHJvbGxlci5pbnZhbGlkYXRlUmVzdG9yYWJsZUNsaWVudFN0YXRlKCk7XG59XG5mdW5jdGlvbiBnZXRNYXRjaGVkVXJsUGF0aG5hbWUobWF0Y2hlZFVybCkge1xuXHRyZXR1cm4gbmV3IFVSTChtYXRjaGVkVXJsLCBcImh0dHBzOi8vdmluZXh0LmxvY2FsXCIpLnBhdGhuYW1lO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVBlcnNpc3RlZFJlZnJlc2hJbnRlcmNlcHRpb25zKHN0YXRlLCByb3V0ZU1hbmlmZXN0LCByZWZyZXNoVXJsLCByZXF1ZXN0SW50ZXJjZXB0aW9uQ29udGV4dCkge1xuXHRpZiAocm91dGVNYW5pZmVzdCA9PT0gbnVsbCkgcmV0dXJuIFtdO1xuXHRjb25zdCByZWZyZXNoUGF0aG5hbWUgPSBzdHJpcEJhc2VQYXRoKHJlZnJlc2hVcmwucGF0aG5hbWUsIF9fYmFzZVBhdGgpO1xuXHRjb25zdCByZWZyZXNoUGF0aFBhcnRzID0gc3BsaXRQYXRobmFtZUZvclJvdXRlTWF0Y2gocmVmcmVzaFBhdGhuYW1lKTtcblx0Y29uc3QgcmVzb2x2ZWQgPSBbXTtcblx0Zm9yIChjb25zdCBiaW5kaW5nIG9mIHN0YXRlLnNsb3RCaW5kaW5ncykge1xuXHRcdGlmIChiaW5kaW5nLnN0YXRlICE9PSBcImFjdGl2ZVwiIHx8ICFiaW5kaW5nLmFjdGl2ZVJvdXRlSWQpIGNvbnRpbnVlO1xuXHRcdGlmICghYmluZGluZy5pbnRlcmNlcHRpb25JZCB8fCAhYmluZGluZy5pbnRlcmNlcHRpb25Tb3VyY2VNYXRjaGVkVXJsKSBjb250aW51ZTtcblx0XHRjb25zdCBhY3RpdmVSb3V0ZSA9IEFwcEVsZW1lbnRzV2lyZS5wYXJzZUVsZW1lbnRLZXkoYmluZGluZy5hY3RpdmVSb3V0ZUlkKTtcblx0XHRpZiAoYWN0aXZlUm91dGU/LmtpbmQgIT09IFwicm91dGVcIikgY29udGludWU7XG5cdFx0Y29uc3QgbWF0Y2ggPSByb3V0ZU1hbmlmZXN0LnNlZ21lbnRHcmFwaC5pbnRlcmNlcHRpb25zLmdldChiaW5kaW5nLmludGVyY2VwdGlvbklkKTtcblx0XHRpZiAoIW1hdGNoKSBjb250aW51ZTtcblx0XHRjb25zdCByZXRhaW5lZEludGVyY2VwdGlvbiA9IHN0YXRlLmludGVyY2VwdGlvbj8uc2xvdElkID09PSBiaW5kaW5nLnNsb3RJZCAmJiBtYXRjaFJvdXRlUGF0dGVybihzcGxpdFBhdGhuYW1lRm9yUm91dGVNYXRjaChnZXRNYXRjaGVkVXJsUGF0aG5hbWUoc3RhdGUuaW50ZXJjZXB0aW9uLnRhcmdldE1hdGNoZWRVcmwpKSwgbWF0Y2gudGFyZ2V0UGF0dGVyblBhcnRzKSAhPT0gbnVsbCA/IHN0YXRlLmludGVyY2VwdGlvbiA6IG51bGw7XG5cdFx0Y29uc3QgdGFyZ2V0UGF0aG5hbWUgPSByZXRhaW5lZEludGVyY2VwdGlvbj8udGFyZ2V0TWF0Y2hlZFVybCA/PyBhY3RpdmVSb3V0ZS5wYXRoO1xuXHRcdGNvbnN0IHRhcmdldFBhcnRzID0gc3BsaXRQYXRobmFtZUZvclJvdXRlTWF0Y2goZ2V0TWF0Y2hlZFVybFBhdGhuYW1lKHRhcmdldFBhdGhuYW1lKSk7XG5cdFx0aWYgKHJlcXVlc3RJbnRlcmNlcHRpb25Db250ZXh0ICE9PSBudWxsICYmIHN0YXRlLmludGVyY2VwdGlvbj8uc2xvdElkID09PSBiaW5kaW5nLnNsb3RJZCAmJiBtYXRjaFJvdXRlUGF0dGVybihyZWZyZXNoUGF0aFBhcnRzLCBtYXRjaC50YXJnZXRQYXR0ZXJuUGFydHMpICE9PSBudWxsICYmIG1hdGNoUm91dGVQYXR0ZXJuKHRhcmdldFBhcnRzLCBtYXRjaC50YXJnZXRQYXR0ZXJuUGFydHMpICE9PSBudWxsKSBjb250aW51ZTtcblx0XHRjb25zdCB0YXJnZXRVcmwgPSBuZXcgVVJMKHRhcmdldFBhdGhuYW1lLCByZWZyZXNoVXJsKTtcblx0XHR0YXJnZXRVcmwucGF0aG5hbWUgPSBhZGRCYXNlUGF0aFRvUGF0aG5hbWUodGFyZ2V0VXJsLnBhdGhuYW1lLCBfX2Jhc2VQYXRoKTtcblx0XHR0YXJnZXRVcmwuc2VhcmNoID0gcmVmcmVzaFVybC5zZWFyY2g7XG5cdFx0cmVzb2x2ZWQucHVzaCh7XG5cdFx0XHRpbnRlcmNlcHRpb246IG1hdGNoLFxuXHRcdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogcmV0YWluZWRJbnRlcmNlcHRpb24/LnNvdXJjZU1hdGNoZWRVcmwgPz8gYmluZGluZy5pbnRlcmNlcHRpb25Tb3VyY2VNYXRjaGVkVXJsLFxuXHRcdFx0dGFyZ2V0UGF0aG5hbWU6IGAke3RhcmdldFVybC5wYXRobmFtZX0ke3RhcmdldFVybC5zZWFyY2h9YFxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiByZXNvbHZlZDtcbn1cbmFzeW5jIGZ1bmN0aW9uIGZldGNoUGVyc2lzdGVkSW50ZXJjZXB0ZWRTbG90UmVmcmVzaChvcHRpb25zKSB7XG5cdGNvbnN0IGhlYWRlcnMgPSBjcmVhdGVSc2NSZXF1ZXN0SGVhZGVycyh7XG5cdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogb3B0aW9ucy5pbnRlcmNlcHRpb25Db250ZXh0LFxuXHRcdGludGVyY2VwdGlvbklkOiBvcHRpb25zLmludGVyY2VwdGlvbklkLFxuXHRcdG1vdW50ZWRTbG90c0hlYWRlcjogb3B0aW9ucy5tb3VudGVkU2xvdHNIZWFkZXJcblx0fSk7XG5cdHJldHVybiBkZWNvZGVTdXBwbGVtZW50YWxSZWZyZXNoKGF3YWl0IGZldGNoKGF3YWl0IGNyZWF0ZVJzY1JlcXVlc3RVcmwob3B0aW9ucy50YXJnZXRQYXRobmFtZSwgaGVhZGVycyksIHtcblx0XHRjcmVkZW50aWFsczogXCJpbmNsdWRlXCIsXG5cdFx0aGVhZGVycyxcblx0XHRzaWduYWw6IG9wdGlvbnMuc2lnbmFsXG5cdH0pLCBvcHRpb25zLnRhcmdldFBhdGhuYW1lKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGZldGNoUGVyc2lzdGVkU291cmNlUGFnZVJlZnJlc2gob3B0aW9ucykge1xuXHRjb25zdCBoZWFkZXJzID0gY3JlYXRlUnNjUmVxdWVzdEhlYWRlcnMoeyBtb3VudGVkU2xvdHNIZWFkZXI6IG9wdGlvbnMubW91bnRlZFNsb3RzSGVhZGVyIH0pO1xuXHRyZXR1cm4gZGVjb2RlU3VwcGxlbWVudGFsUmVmcmVzaChhd2FpdCBmZXRjaChhd2FpdCBjcmVhdGVSc2NSZXF1ZXN0VXJsKG9wdGlvbnMudGFyZ2V0UGF0aG5hbWUsIGhlYWRlcnMpLCB7XG5cdFx0Y3JlZGVudGlhbHM6IFwiaW5jbHVkZVwiLFxuXHRcdGhlYWRlcnMsXG5cdFx0c2lnbmFsOiBvcHRpb25zLnNpZ25hbFxuXHR9KSwgb3B0aW9ucy50YXJnZXRQYXRobmFtZSk7XG59XG4vKipcbiogRGVjb2RlIGEga2VwdCBicmFuY2ggYSByZWZyZXNoIGZldGNoZWQgZnJvbSBpdHMgb3duIFVSTC4gSXRzIGNsaWVudCBwYWdlc1xuKiByZWFkIHRoZSBxdWVyeSB0aGUgc2VydmVyIHJlbmRlcmVkIGl0IHdpdGgsIG5vdCB0aGUgbmF2aWdhdGlvbidzLlxuKi9cbmFzeW5jIGZ1bmN0aW9uIGRlY29kZVN1cHBsZW1lbnRhbFJlZnJlc2gocmVzcG9uc2UsIHRhcmdldFBhdGhuYW1lKSB7XG5cdGlmICghaXNSc2NSZXNwb25zZUNvbXBhdGlibGUocmVzcG9uc2UuaGVhZGVycy5nZXQoXCJYLVZpbmV4dC1SU0MtQ29tcGF0aWJpbGl0eS1JZFwiKSkpIHtcblx0XHRyZXNwb25zZS5ib2R5Py5jYW5jZWwoKS5jYXRjaCgoKSA9PiB7fSk7XG5cdFx0dGhyb3cgbmV3IEVycm9yKFwiW3ZpbmV4dF0gUmVmcmVzaGVkIGFub3RoZXIgZGVwbG95bWVudCdzIHBheWxvYWRcIik7XG5cdH1cblx0Y29uc3QgZWxlbWVudHMgPSBhd2FpdCBkZWNvZGVBcHBFbGVtZW50c1Byb21pc2UoY3JlYXRlRnJvbUZldGNoKFByb21pc2UucmVzb2x2ZShyZXNwb25zZSkpKTtcblx0Y29uc3QgcmVuZGVyZWRQYXRoQW5kU2VhcmNoID0gcGFyc2VSZW5kZXJlZFBhdGhBbmRTZWFyY2hIZWFkZXIocmVzcG9uc2UuaGVhZGVycy5nZXQoVklORVhUX1JFTkRFUkVEX1BBVEhfQU5EX1NFQVJDSF9IRUFERVIpKTtcblx0c2V0QXBwRWxlbWVudHNSZW5kZXJlZFNlYXJjaChlbGVtZW50cywgbmV3IFVSTChyZW5kZXJlZFBhdGhBbmRTZWFyY2ggPz8gdGFyZ2V0UGF0aG5hbWUsIHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4pLnNlYXJjaCk7XG5cdHJldHVybiBlbGVtZW50cztcbn1cbmZ1bmN0aW9uIGlzU2V0dGxlZFByZWZldGNoQ2FjaGVFbnRyeShlbnRyeSkge1xuXHRyZXR1cm4gZW50cnkub3V0Y29tZSA9PT0gXCJjYWNoZS1zZWVkZWRcIiAmJiBlbnRyeS5wZW5kaW5nID09PSB2b2lkIDAgJiYgZW50cnkuc25hcHNob3QgIT09IHZvaWQgMDtcbn1cbmZ1bmN0aW9uIHBhcnNlUHJlZmV0Y2hDYWNoZUtleShjYWNoZUtleSkge1xuXHRjb25zdCBzZXBhcmF0b3JJbmRleCA9IGNhY2hlS2V5LmluZGV4T2YoXCJcXDBcIik7XG5cdGlmIChzZXBhcmF0b3JJbmRleCA9PT0gLTEpIHJldHVybiB7XG5cdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogbnVsbCxcblx0XHRyc2NVcmw6IGNhY2hlS2V5XG5cdH07XG5cdHJldHVybiB7XG5cdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogY2FjaGVLZXkuc2xpY2Uoc2VwYXJhdG9ySW5kZXggKyAxKSxcblx0XHRyc2NVcmw6IGNhY2hlS2V5LnNsaWNlKDAsIHNlcGFyYXRvckluZGV4KVxuXHR9O1xufVxuYXN5bmMgZnVuY3Rpb24gbGVhcm5PcHRpbWlzdGljUm91dGVUZW1wbGF0ZUZyb21QcmVmZXRjaChvcHRpb25zKSB7XG5cdGNvbnN0IHNvdXJjZSA9IHBhcnNlUHJlZmV0Y2hDYWNoZUtleShvcHRpb25zLmNhY2hlS2V5KTtcblx0aWYgKHNvdXJjZS5pbnRlcmNlcHRpb25Db250ZXh0ICE9PSBvcHRpb25zLmludGVyY2VwdGlvbkNvbnRleHQpIHJldHVybiBudWxsO1xuXHRpZiAocmVzb2x2ZVByZWZldGNoQ2FjaGVFbnRyeU1vdW50ZWRTbG90c0hlYWRlcihvcHRpb25zLmVudHJ5KSAhPT0gb3B0aW9ucy5tb3VudGVkU2xvdHNIZWFkZXIpIHJldHVybiBudWxsO1xuXHRpZiAob3B0aW9ucy5pbnRlcmNlcHRpb25Db250ZXh0ICE9PSBudWxsKSByZXR1cm4gbnVsbDtcblx0aWYgKCFpc1JzY1Jlc3BvbnNlQ29tcGF0aWJsZShvcHRpb25zLmVudHJ5LnNuYXBzaG90LmNvbXBhdGliaWxpdHlJZEhlYWRlcikpIHJldHVybiBudWxsO1xuXHRjb25zdCBlbGVtZW50cyA9IGF3YWl0IGRlY29kZUFwcEVsZW1lbnRzUHJvbWlzZShjcmVhdGVGcm9tRmV0Y2goUHJvbWlzZS5yZXNvbHZlKHJlc3RvcmVSc2NSZXNwb25zZShvcHRpb25zLmVudHJ5LnNuYXBzaG90KSkpKTtcblx0Y29uc3QgdGVtcGxhdGUgPSBjcmVhdGVPcHRpbWlzdGljUm91dGVUZW1wbGF0ZSh7XG5cdFx0YWxsb3dMb2FkaW5nU2hlbGw6IG9wdGlvbnMuZW50cnkub3B0aW1pc3RpY1JvdXRlU2hlbGwgPT09IHRydWUsXG5cdFx0YmFzZVBhdGg6IF9fYmFzZVBhdGgsXG5cdFx0ZWxlbWVudHMsXG5cdFx0aHJlZjogb3B0aW9ucy5lbnRyeS5zbmFwc2hvdC51cmwgfHwgc291cmNlLnJzY1VybCxcblx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiBvcHRpb25zLmludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0bW91bnRlZFNsb3RzSGVhZGVyOiBvcHRpb25zLm1vdW50ZWRTbG90c0hlYWRlcixcblx0XHRyb3V0ZU1hbmlmZXN0OiBvcHRpb25zLnJvdXRlTWFuaWZlc3Rcblx0fSk7XG5cdGlmICh0ZW1wbGF0ZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG5cdHJldHVybiB7XG5cdFx0a2V5OiBnZXRPcHRpbWlzdGljUm91dGVUZW1wbGF0ZUtleSh7XG5cdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiBvcHRpb25zLmludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0XHRtb3VudGVkU2xvdHNIZWFkZXI6IG9wdGlvbnMubW91bnRlZFNsb3RzSGVhZGVyLFxuXHRcdFx0cm91dGVJZDogdGVtcGxhdGUucm91dGVJZFxuXHRcdH0pLFxuXHRcdHRlbXBsYXRlXG5cdH07XG59XG5hc3luYyBmdW5jdGlvbiBsZWFybk9wdGltaXN0aWNSb3V0ZVRlbXBsYXRlc0Zyb21QcmVmZXRjaENhY2hlKG9wdGlvbnMpIHtcblx0Y29uc3QgeyByb3V0ZU1hbmlmZXN0IH0gPSBvcHRpb25zO1xuXHRpZiAocm91dGVNYW5pZmVzdCA9PT0gbnVsbCkgcmV0dXJuO1xuXHRjb25zdCBsZWFybmluZyA9IG9wdGltaXN0aWNSb3V0ZVRlbXBsYXRlcy5wZW5kaW5nTGVhcm5pbmcoKTtcblx0Zm9yIChjb25zdCBbY2FjaGVLZXksIGVudHJ5XSBvZiBnZXRQcmVmZXRjaENhY2hlKCkpIHtcblx0XHRjb25zdCBzb3VyY2VLZXkgPSBnZXRPcHRpbWlzdGljUHJlZmV0Y2hTb3VyY2VLZXkoe1xuXHRcdFx0Y2FjaGVLZXksXG5cdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiBvcHRpb25zLmludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0XHRtb3VudGVkU2xvdHNIZWFkZXI6IG9wdGlvbnMubW91bnRlZFNsb3RzSGVhZGVyXG5cdFx0fSk7XG5cdFx0aWYgKG9wdGltaXN0aWNSb3V0ZVRlbXBsYXRlcy5oYXNTb3VyY2Uoc291cmNlS2V5KSkgY29udGludWU7XG5cdFx0aWYgKCFpc1NldHRsZWRQcmVmZXRjaENhY2hlRW50cnkoZW50cnkpKSBjb250aW51ZTtcblx0XHRpZiAoZW50cnkucHJlZmV0Y2hLaW5kID09PSBcInJvdXRlLXRyZWVcIikgY29udGludWU7XG5cdFx0bGVhcm5pbmcucHVzaChvcHRpbWlzdGljUm91dGVUZW1wbGF0ZXMubGVhcm4oc291cmNlS2V5LCAoKSA9PiBsZWFybk9wdGltaXN0aWNSb3V0ZVRlbXBsYXRlRnJvbVByZWZldGNoKHtcblx0XHRcdGNhY2hlS2V5LFxuXHRcdFx0ZW50cnksXG5cdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiBvcHRpb25zLmludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0XHRtb3VudGVkU2xvdHNIZWFkZXI6IG9wdGlvbnMubW91bnRlZFNsb3RzSGVhZGVyLFxuXHRcdFx0cm91dGVNYW5pZmVzdFxuXHRcdH0pKSk7XG5cdH1cblx0aWYgKGxlYXJuaW5nLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXHRhd2FpdCBQcm9taXNlLmFsbFNldHRsZWQobGVhcm5pbmcpO1xufVxuZnVuY3Rpb24gY3JlYXRlQWN0aW9uSW5pdGlhdGlvblNuYXBzaG90KCkge1xuXHRjb25zdCByb3V0ZXJTdGF0ZSA9IGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpO1xuXHRyZXR1cm4gY3JlYXRlU2VydmVyQWN0aW9uSW5pdGlhdGlvblNuYXBzaG90KHtcblx0XHRocmVmOiB3aW5kb3cubG9jYXRpb24uaHJlZixcblx0XHRuYXZpZ2F0aW9uSWQ6IGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5nZXRBY3RpdmVOYXZpZ2F0aW9uSWQoKSxcblx0XHRyb3V0ZXJTdGF0ZVxuXHR9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZU5hdmlnYXRpb25Db21taXRFZmZlY3Qob3B0aW9ucykge1xuXHRjb25zdCB7IGFjdGl2ZVJvdXRlUGF0aHMsIGJmY2FjaGVJZHMsIGhyZWYsIGhpc3RvcnlVcGRhdGVNb2RlLCBuYXZJZCwgcGFyYW1zLCBwcmV2aW91c05leHRVcmwsIHRhcmdldEhpc3RvcnlJbmRleCB9ID0gb3B0aW9ucztcblx0bGV0IHdyb3RlSGlzdG9yeSA9IGZhbHNlO1xuXHRyZXR1cm4ge1xuXHRcdHdyaXRlSGlzdG9yeSh7IGtlZXBDdXJyZW50VXJsIH0pIHtcblx0XHRcdGlmICghYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmlzQ3VycmVudE5hdmlnYXRpb24obmF2SWQpKSByZXR1cm47XG5cdFx0XHRoaXN0b3J5Q29udHJvbGxlci5jb21taXROYXZpZ2F0aW9uSGlzdG9yeSh7XG5cdFx0XHRcdGFjdGl2ZVJvdXRlUGF0aHMsXG5cdFx0XHRcdGJmY2FjaGVJZHMsXG5cdFx0XHRcdGhyZWYsXG5cdFx0XHRcdGhpc3RvcnlVcGRhdGVNb2RlOiBrZWVwQ3VycmVudFVybCA/IHZvaWQgMCA6IGhpc3RvcnlVcGRhdGVNb2RlLFxuXHRcdFx0XHRwcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdHN0YWdlQ2xpZW50UGFyYW1zOiAoKSA9PiBzdGFnZUNsaWVudFBhcmFtcyhwYXJhbXMpLFxuXHRcdFx0XHR0YXJnZXRIaXN0b3J5SW5kZXhcblx0XHRcdH0pO1xuXHRcdFx0d3JvdGVIaXN0b3J5ID0gdHJ1ZTtcblx0XHR9LFxuXHRcdHB1Ymxpc2goeyByZWxlYXNlU25hcHNob3QgfSkge1xuXHRcdFx0aWYgKCF3cm90ZUhpc3RvcnkpIHtcblx0XHRcdFx0Y29tbWl0Q2xpZW50TmF2aWdhdGlvblN0YXRlKHZvaWQgMCwgeyByZWxlYXNlU25hcHNob3QgfSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNsZWFyQXBwTmF2aWdhdGlvbkZhaWx1cmVUYXJnZXQoaHJlZik7XG5cdFx0XHRjb21taXRDbGllbnROYXZpZ2F0aW9uU3RhdGUobmF2SWQsIHsgcmVsZWFzZVNuYXBzaG90IH0pO1xuXHRcdH1cblx0fTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHJlbmRlck5hdmlnYXRpb25QYXlsb2FkKG9wdGlvbnMpIHtcblx0c3luY1NlcnZlckFjdGlvbkh0dHBGYWxsYmFja0hlYWQobnVsbCk7XG5cdHJldHVybiBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIucmVuZGVyTmF2aWdhdGlvblBheWxvYWQoe1xuXHRcdGFjdGlvblR5cGU6IG9wdGlvbnMuYWN0aW9uVHlwZSA/PyBcIm5hdmlnYXRlXCIsXG5cdFx0Y3JlYXRlTmF2aWdhdGlvbkNvbW1pdEVmZmVjdCxcblx0XHRoaXN0b3J5VXBkYXRlTW9kZTogb3B0aW9ucy5oaXN0b3J5VXBkYXRlTW9kZSxcblx0XHRuYXZpZ2F0aW9uQ29tbWl0S2luZDogb3B0aW9ucy5uYXZpZ2F0aW9uQ29tbWl0S2luZCxcblx0XHRuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlOiBvcHRpb25zLm5hdmlnYXRpb25Jbml0aWF0aW9uU3RhdGUsXG5cdFx0bmF2aWdhdGlvblJlc3BvbnNlQ29tcGxldGlvbjogb3B0aW9ucy5uYXZpZ2F0aW9uUmVzcG9uc2VDb21wbGV0aW9uLFxuXHRcdG5hdmlnYXRpb25TbmFwc2hvdDogb3B0aW9ucy5uYXZpZ2F0aW9uU25hcHNob3QsXG5cdFx0bmF2SWQ6IG9wdGlvbnMubmF2SWQsXG5cdFx0bmV4dEVsZW1lbnRzOiBvcHRpb25zLnBheWxvYWQsXG5cdFx0b25Db21taXR0ZWRTdGF0ZTogb3B0aW9ucy5vbkNvbW1pdHRlZFN0YXRlLFxuXHRcdG9wZXJhdGlvbkxhbmU6IG9wdGlvbnMub3BlcmF0aW9uTGFuZSA/PyBcIm5hdmlnYXRpb25cIixcblx0XHRwYXJhbXM6IG9wdGlvbnMucGFyYW1zLFxuXHRcdHBheWxvYWRPcmlnaW46IG9wdGlvbnMucGF5bG9hZE9yaWdpbixcblx0XHRwZW5kaW5nUm91dGVyU3RhdGU6IG9wdGlvbnMucGVuZGluZ1JvdXRlclN0YXRlLFxuXHRcdHByZXZpb3VzTmV4dFVybDogb3B0aW9ucy5wcmV2aW91c05leHRVcmwsXG5cdFx0cmVzdG9yZWRCZmNhY2hlSWRzOiBvcHRpb25zLnJlc3RvcmVkQmZjYWNoZUlkcyA/PyBudWxsLFxuXHRcdHJldXNlQ3VycmVudEJmY2FjaGVJZHM6IG9wdGlvbnMucmV1c2VDdXJyZW50QmZjYWNoZUlkcyA/PyB0cnVlLFxuXHRcdHNjcm9sbEludGVudDogb3B0aW9ucy5zY3JvbGxJbnRlbnQgPz8gbnVsbCxcblx0XHR0YXJnZXRIaXN0b3J5SW5kZXg6IG9wdGlvbnMudHJhdmVyc2FsSW50ZW50Py50YXJnZXRIaXN0b3J5SW5kZXgsXG5cdFx0dGFyZ2V0SHJlZjogb3B0aW9ucy50YXJnZXRIcmVmLFxuXHRcdHZpc2libGVDb21taXRNb2RlOiBvcHRpb25zLnZpc2libGVDb21taXRNb2RlID8/IFwidHJhbnNpdGlvblwiXG5cdH0pO1xufVxuYXN5bmMgZnVuY3Rpb24gY29tbWl0U2FtZVVybE5hdmlnYXRlUGF5bG9hZChuZXh0RWxlbWVudHMsIGFjdGlvbkluaXRpYXRpb24sIHJldHVyblZhbHVlLCByZXZhbGlkYXRpb24gPSBcIm5vbmVcIiwgcmVuZGVyZWRQYXRoQW5kU2VhcmNoID0gbnVsbCkge1xuXHRsZXQgc2hvdWxkUmV0cnlTdXBwbGVtZW50YWxSZWZyZXNoID0gZmFsc2U7XG5cdGxldCBzdXBwbGVtZW50YWxIYW5kbGUgPSBudWxsO1xuXHRsZXQgcm91dGVNYW5pZmVzdExvYWRlZCA9IHRydWU7XG5cdGlmIChyZXZhbGlkYXRpb24gIT09IFwibm9uZVwiKSB7XG5cdFx0Y29uc3Qgcm91dGVNYW5pZmVzdExvYWQgPSBsb2FkTmF2aWdhdGlvblJ1bnRpbWVSb3V0ZU1hbmlmZXN0KCk7XG5cdFx0aWYgKHJvdXRlTWFuaWZlc3RMb2FkICE9PSBudWxsKSByb3V0ZU1hbmlmZXN0TG9hZGVkID0gYXdhaXQgcm91dGVNYW5pZmVzdExvYWQ7XG5cdFx0aWYgKCFyb3V0ZU1hbmlmZXN0TG9hZGVkICYmIGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5pc0N1cnJlbnROYXZpZ2F0aW9uKGFjdGlvbkluaXRpYXRpb24ubmF2aWdhdGlvbklkKSkge1xuXHRcdFx0YnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLnBlcmZvcm1IYXJkTmF2aWdhdGlvbihhY3Rpb25Jbml0aWF0aW9uLmhyZWYpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0fVxuXHRpZiAocmV2YWxpZGF0aW9uICE9PSBcIm5vbmVcIiAmJiByb3V0ZU1hbmlmZXN0TG9hZGVkKSB7XG5cdFx0Y29uc3QgcmVmcmVzaFVybCA9IG5ldyBVUkwoYWN0aW9uSW5pdGlhdGlvbi5ocmVmKTtcblx0XHRjb25zdCByZXF1ZXN0SW50ZXJjZXB0aW9uQ29udGV4dCA9IHJlc29sdmVJbnRlcmNlcHRpb25Db250ZXh0RnJvbVByZXZpb3VzTmV4dFVybChhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLnByZXZpb3VzTmV4dFVybCwgX19iYXNlUGF0aCk7XG5cdFx0Y29uc3QgcGVyc2lzdGVkSW50ZXJjZXB0aW9ucyA9IHJlc29sdmVQZXJzaXN0ZWRSZWZyZXNoSW50ZXJjZXB0aW9ucyhhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLCBnZXRCcm93c2VyUm91dGVNYW5pZmVzdCgpLCByZWZyZXNoVXJsLCByZXF1ZXN0SW50ZXJjZXB0aW9uQ29udGV4dCk7XG5cdFx0Y29uc3Qgc291cmNlUGFnZVJlZnJlc2hlcyA9IHJlc29sdmVQZXJzaXN0ZWRTb3VyY2VQYWdlUmVmcmVzaGVzKHtcblx0XHRcdGJhc2VQYXRoOiBfX2Jhc2VQYXRoLFxuXHRcdFx0cmVmcmVzaFVybCxcblx0XHRcdHN0YXRlOiBhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlXG5cdFx0fSkuZmlsdGVyKChzb3VyY2VQYXRobmFtZSkgPT4gIXBlcnNpc3RlZEludGVyY2VwdGlvbnMuc29tZSgoaW50ZXJjZXB0aW9uKSA9PiBpbnRlcmNlcHRpb24udGFyZ2V0UGF0aG5hbWUgPT09IHNvdXJjZVBhdGhuYW1lKSk7XG5cdFx0aWYgKHBlcnNpc3RlZEludGVyY2VwdGlvbnMubGVuZ3RoID4gMCB8fCBzb3VyY2VQYWdlUmVmcmVzaGVzLmxlbmd0aCA+IDApIHtcblx0XHRcdHN1cHBsZW1lbnRhbEhhbmRsZSA9IHNlcnZlckFjdGlvblN1cHBsZW1lbnRhbFJlZnJlc2hDb29yZGluYXRvci5iZWdpbih7XG5cdFx0XHRcdGFjdGl2ZU5hdmlnYXRpb25JZDogYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmdldEFjdGl2ZU5hdmlnYXRpb25JZCgpLFxuXHRcdFx0XHRzdGFydGVkTmF2aWdhdGlvbklkOiBhY3Rpb25Jbml0aWF0aW9uLm5hdmlnYXRpb25JZFxuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCBtb3VudGVkU2xvdHNIZWFkZXIgPSBnZXRNb3VudGVkU2xvdElkc0hlYWRlcihhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLmVsZW1lbnRzKTtcblx0XHRcdGNvbnN0IHN1cHBsZW1lbnRhbCA9IHBlcnNpc3RlZEludGVyY2VwdGlvbnMubWFwKChpbnRlcmNlcHRpb24pID0+IChzaWduYWwpID0+IGZldGNoUGVyc2lzdGVkSW50ZXJjZXB0ZWRTbG90UmVmcmVzaCh7XG5cdFx0XHRcdGludGVyY2VwdGlvbkNvbnRleHQ6IGludGVyY2VwdGlvbi5pbnRlcmNlcHRpb25Db250ZXh0LFxuXHRcdFx0XHRpbnRlcmNlcHRpb25JZDogaW50ZXJjZXB0aW9uLmludGVyY2VwdGlvbi5pZCxcblx0XHRcdFx0bW91bnRlZFNsb3RzSGVhZGVyLFxuXHRcdFx0XHRzaWduYWwsXG5cdFx0XHRcdHRhcmdldFBhdGhuYW1lOiBpbnRlcmNlcHRpb24udGFyZ2V0UGF0aG5hbWVcblx0XHRcdH0pKTtcblx0XHRcdGZvciAoY29uc3Qgc291cmNlUGFnZVJlZnJlc2ggb2Ygc291cmNlUGFnZVJlZnJlc2hlcykgc3VwcGxlbWVudGFsLnB1c2goKHNpZ25hbCkgPT4gZmV0Y2hQZXJzaXN0ZWRTb3VyY2VQYWdlUmVmcmVzaCh7XG5cdFx0XHRcdG1vdW50ZWRTbG90c0hlYWRlcixcblx0XHRcdFx0c2lnbmFsLFxuXHRcdFx0XHR0YXJnZXRQYXRobmFtZTogc291cmNlUGFnZVJlZnJlc2hcblx0XHRcdH0pKTtcblx0XHRcdG5leHRFbGVtZW50cyA9IHJlc29sdmVTdXBwbGVtZW50YWxSZWZyZXNoZXMoe1xuXHRcdFx0XHRtZXJnZTogbWVyZ2VSZWZyZXNoZWRQYXJhbGxlbFNsb3QsXG5cdFx0XHRcdHByaW1hcnk6IG5leHRFbGVtZW50cyxcblx0XHRcdFx0c2lnbmFsOiBzdXBwbGVtZW50YWxIYW5kbGUuc2lnbmFsLFxuXHRcdFx0XHRzdXBwbGVtZW50YWxcblx0XHRcdH0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdFx0XHRjb25zdCByZXNvbHV0aW9uID0gcmVzb2x2ZVNlcnZlckFjdGlvblN1cHBsZW1lbnRhbFJlZnJlc2gocmVzdWx0LCBhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLmVsZW1lbnRzKTtcblx0XHRcdFx0c2hvdWxkUmV0cnlTdXBwbGVtZW50YWxSZWZyZXNoIHx8PSByZXNvbHV0aW9uLnJldHJ5O1xuXHRcdFx0XHRyZXR1cm4gcmVzb2x1dGlvbi52YWx1ZTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHRjb25zdCBuYXZpZ2F0aW9uU25hcHNob3QgPSByZW5kZXJlZFBhdGhBbmRTZWFyY2ggPT09IG51bGwgPyB3aXRoUmVuZGVyZWRTZWFyY2hPZihjcmVhdGVDbGllbnROYXZpZ2F0aW9uUmVuZGVyU25hcHNob3QoYWN0aW9uSW5pdGlhdGlvbi5ocmVmLCBhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdC5wYXJhbXMpLCBhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdCkgOiBjcmVhdGVDbGllbnROYXZpZ2F0aW9uUmVuZGVyU25hcHNob3QoYWN0aW9uSW5pdGlhdGlvbi5ocmVmLCBhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdC5wYXJhbXMsIHJlbmRlcmVkUGF0aEFuZFNlYXJjaCk7XG5cdHRyeSB7XG5cdFx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmNvbW1pdFNhbWVVcmxOYXZpZ2F0ZVBheWxvYWQobmV4dEVsZW1lbnRzLCBuYXZpZ2F0aW9uU25hcHNob3QsIHJldHVyblZhbHVlLCBhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLCB7XG5cdFx0XHRvbkRpc2NhcmRlZFJldmFsaWRhdGlvbigpIHtcblx0XHRcdFx0ZGlzY2FyZGVkU2VydmVyQWN0aW9uUmVmcmVzaFNjaGVkdWxlci5zY2hlZHVsZSgpO1xuXHRcdFx0fSxcblx0XHRcdHJldmFsaWRhdGlvbixcblx0XHRcdHN0YXJ0ZWROYXZpZ2F0aW9uSWQ6IGFjdGlvbkluaXRpYXRpb24ubmF2aWdhdGlvbklkLFxuXHRcdFx0dGFyZ2V0SHJlZjogYWN0aW9uSW5pdGlhdGlvbi5ocmVmXG5cdFx0fSk7XG5cdFx0aWYgKHNob3VsZFJldHJ5U3VwcGxlbWVudGFsUmVmcmVzaCkgZGlzY2FyZGVkU2VydmVyQWN0aW9uUmVmcmVzaFNjaGVkdWxlci5zY2hlZHVsZSgpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH0gZmluYWxseSB7XG5cdFx0c3VwcGxlbWVudGFsSGFuZGxlPy5maW5pc2goKTtcblx0fVxufVxuZnVuY3Rpb24gZXZpY3RWaXNpdGVkUmVzcG9uc2VDYWNoZUlmTmVlZGVkKCkge1xuXHR3aGlsZSAodmlzaXRlZFJlc3BvbnNlQ2FjaGUuc2l6ZSA+PSBNQVhfVklTSVRFRF9SRVNQT05TRV9DQUNIRV9TSVpFKSB7XG5cdFx0Y29uc3Qgb2xkZXN0ID0gdmlzaXRlZFJlc3BvbnNlQ2FjaGUua2V5cygpLm5leHQoKS52YWx1ZTtcblx0XHRpZiAob2xkZXN0ID09PSB2b2lkIDApIHJldHVybjtcblx0XHR2aXNpdGVkUmVzcG9uc2VDYWNoZS5kZWxldGUob2xkZXN0KTtcblx0fVxufVxuZnVuY3Rpb24gcmVhZFZpc2l0ZWRSZXNwb25zZUNhY2hlQ2FuZGlkYXRlKHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyLCBuYXZpZ2F0aW9uS2luZCkge1xuXHRjb25zdCBjYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRjb25zdCBtYXRjaCA9IGZpbmRWaXNpdGVkUmVzcG9uc2VDYWNoZUVudHJ5KHZpc2l0ZWRSZXNwb25zZUNhY2hlLCByc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRpZiAoIW1hdGNoIHx8IG1hdGNoLmVudHJ5Lm5hdmlnYXRpb25SZXVzZVJldm9rZWQpIHJldHVybiB7XG5cdFx0Y2FjaGVLZXksXG5cdFx0ZW50cnk6IG51bGwsXG5cdFx0ZmFjdHM6IHtcblx0XHRcdGNhbmRpZGF0ZTogXCJtaXNzaW5nXCIsXG5cdFx0XHRuYXZpZ2F0aW9uS2luZFxuXHRcdH1cblx0fTtcblx0cmV0dXJuIHtcblx0XHRjYWNoZUtleTogbWF0Y2guY2FjaGVLZXksXG5cdFx0ZW50cnk6IG1hdGNoLmVudHJ5LFxuXHRcdGZhY3RzOiB7XG5cdFx0XHRjYW5kaWRhdGU6IFwicHJlc2VudFwiLFxuXHRcdFx0ZnJlc2g6IGlzVmlzaXRlZFJlc3BvbnNlQ2FjaGVFbnRyeUZyZXNoKG1hdGNoLmVudHJ5LCB7XG5cdFx0XHRcdG5hdmlnYXRpb25LaW5kLFxuXHRcdFx0XHRub3c6IERhdGUubm93KClcblx0XHRcdH0pLFxuXHRcdFx0bW91bnRlZFNsb3RzTWF0Y2g6IG1hdGNoLmVudHJ5LmVsZW1lbnRzICE9PSB2b2lkIDAgfHwgbWF0Y2guZW50cnkubW91bnRlZFNsb3RzSGVhZGVyID09PSBtb3VudGVkU2xvdHNIZWFkZXIsXG5cdFx0XHRuYXZpZ2F0aW9uS2luZFxuXHRcdH1cblx0fTtcbn1cbmZ1bmN0aW9uIGFwcGx5VmlzaXRlZFJlc3BvbnNlQ2FjaGVDYW5kaWRhdGVEZWNpc2lvbihjYW5kaWRhdGUsIGRlY2lzaW9uKSB7XG5cdGlmIChjYW5kaWRhdGUuZW50cnkgPT09IG51bGwpIHJldHVybiBudWxsO1xuXHRpZiAoZGVjaXNpb24ua2luZCA9PT0gXCJyZXVzZVwiKSB7XG5cdFx0dmlzaXRlZFJlc3BvbnNlQ2FjaGUuZGVsZXRlKGNhbmRpZGF0ZS5jYWNoZUtleSk7XG5cdFx0dmlzaXRlZFJlc3BvbnNlQ2FjaGUuc2V0KGNhbmRpZGF0ZS5jYWNoZUtleSwgY2FuZGlkYXRlLmVudHJ5KTtcblx0XHRyZXR1cm4gY2FuZGlkYXRlLmVudHJ5O1xuXHR9XG5cdHZpc2l0ZWRSZXNwb25zZUNhY2hlLmRlbGV0ZShjYW5kaWRhdGUuY2FjaGVLZXkpO1xuXHRyZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIGRlbGV0ZVZpc2l0ZWRSZXNwb25zZShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpIHtcblx0ZGVsZXRlVmlzaXRlZFJlc3BvbnNlQ2FjaGVFbnRyeSh2aXNpdGVkUmVzcG9uc2VDYWNoZSwgcnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0KTtcbn1cbmZ1bmN0aW9uIHN0b3JlVmlzaXRlZFJlc3BvbnNlU25hcHNob3QocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0LCBzbmFwc2hvdCwgcGFyYW1zLCBwcmVmZXRjaEZhbGxiYWNrVHRsTXMgPSBEWU5BTUlDX05BVklHQVRJT05fQ0FDSEVfVFRMLCByZXF1ZXN0TW91bnRlZFNsb3RzSGVhZGVyID0gc25hcHNob3QubW91bnRlZFNsb3RzSGVhZGVyID8/IG51bGwsIGVsZW1lbnRzLCBzZWVkUHJlZmV0Y2hDYWNoZSA9IHRydWUsIHByZWZldGNoU25hcHNob3QgPSBzbmFwc2hvdCwgcmV1c2VBZnRlckhpc3RvcnlSZXN0b3JlID0gZmFsc2UsIGZyb21IeWRyYXRpb24gPSBmYWxzZSkge1xuXHRjb25zdCBjYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRkZWxldGVBbGxWaXNpdGVkUmVzcG9uc2VDYWNoZUVudHJpZXModmlzaXRlZFJlc3BvbnNlQ2FjaGUsIHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCk7XG5cdGV2aWN0VmlzaXRlZFJlc3BvbnNlQ2FjaGVJZk5lZWRlZCgpO1xuXHRjb25zdCBlbnRyeSA9IGNyZWF0ZVZpc2l0ZWRSZXNwb25zZUNhY2hlRW50cnkoe1xuXHRcdGZhbGxiYWNrVHRsTXM6IHByZWZldGNoRmFsbGJhY2tUdGxNcyxcblx0XHRlbGVtZW50cyxcblx0XHRmcm9tSHlkcmF0aW9uLFxuXHRcdG5vdzogRGF0ZS5ub3coKSxcblx0XHRtb3VudGVkU2xvdHNIZWFkZXI6IHJlcXVlc3RNb3VudGVkU2xvdHNIZWFkZXIsXG5cdFx0cGFyYW1zLFxuXHRcdHJlc3BvbnNlOiBzbmFwc2hvdCxcblx0XHRyZXVzZUFmdGVySGlzdG9yeVJlc3RvcmVcblx0fSk7XG5cdHZpc2l0ZWRSZXNwb25zZUNhY2hlLnNldChjYWNoZUtleSwgZW50cnkpO1xuXHRpZiAoc2VlZFByZWZldGNoQ2FjaGUpIHNlZWRQcmVmZXRjaFJlc3BvbnNlU25hcHNob3QocnNjVXJsLCBwcmVmZXRjaFNuYXBzaG90LCBpbnRlcmNlcHRpb25Db250ZXh0LCByZXF1ZXN0TW91bnRlZFNsb3RzSGVhZGVyLCBwcmVmZXRjaEZhbGxiYWNrVHRsTXMsIHJldXNlQWZ0ZXJIaXN0b3J5UmVzdG9yZSk7XG5cdHJldHVybiAoKSA9PiB7XG5cdFx0aWYgKHZpc2l0ZWRSZXNwb25zZUNhY2hlLmdldChjYWNoZUtleSkgPT09IGVudHJ5KSB2aXNpdGVkUmVzcG9uc2VDYWNoZS5kZWxldGUoY2FjaGVLZXkpO1xuXHRcdGlmIChzZWVkUHJlZmV0Y2hDYWNoZSkgZGVsZXRlUHJlZmV0Y2hSZXNwb25zZVNuYXBzaG90KHJzY1VybCwgcHJlZmV0Y2hTbmFwc2hvdCwgaW50ZXJjZXB0aW9uQ29udGV4dCk7XG5cdH07XG59XG5mdW5jdGlvbiBjbGllbnROYXZpZ2F0aW9uU25hcHNob3RIcmVmKHNuYXBzaG90KSB7XG5cdHJldHVybiBgJHt3aW5kb3cubG9jYXRpb24ub3JpZ2lufSR7Y3JlYXRlU25hcHNob3RQYXRoQW5kU2VhcmNoKHNuYXBzaG90KX1gO1xufVxuZnVuY3Rpb24gZ2V0Q3VycmVudE1hdGNoZWRSb3V0ZVBhdGhuYW1lKCkge1xuXHRjb25zdCByb3V0ZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5wYXJzZUVsZW1lbnRLZXkoZ2V0QnJvd3NlclJvdXRlclN0YXRlKCkucm91dGVJZCk7XG5cdHJldHVybiByb3V0ZUtleT8ua2luZCA9PT0gXCJyb3V0ZVwiID8gcm91dGVLZXkucGF0aCA6IG51bGw7XG59XG5mdW5jdGlvbiBnZXRSZXF1ZXN0U3RhdGUobmF2aWdhdGlvbktpbmQsIHRhcmdldFBhdGhuYW1lLCBwcmV2aW91c05leHRVcmxPdmVycmlkZSwgdHJhdmVyc2VIaXN0b3J5U3RhdGUpIHtcblx0aWYgKHByZXZpb3VzTmV4dFVybE92ZXJyaWRlICE9PSB2b2lkIDApIHJldHVybiB7XG5cdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogcmVzb2x2ZUludGVyY2VwdGlvbkNvbnRleHRGcm9tUHJldmlvdXNOZXh0VXJsKHByZXZpb3VzTmV4dFVybE92ZXJyaWRlLCBfX2Jhc2VQYXRoKSxcblx0XHRwcmV2aW91c05leHRVcmw6IHByZXZpb3VzTmV4dFVybE92ZXJyaWRlXG5cdH07XG5cdHN3aXRjaCAobmF2aWdhdGlvbktpbmQpIHtcblx0XHRjYXNlIFwibmF2aWdhdGVcIjoge1xuXHRcdFx0Y29uc3QgY3VycmVudFByZXZpb3VzTmV4dFVybCA9IGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpLnByZXZpb3VzTmV4dFVybDtcblx0XHRcdGlmIChjdXJyZW50UHJldmlvdXNOZXh0VXJsICE9PSBudWxsKSByZXR1cm4ge1xuXHRcdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiByZXNvbHZlSW50ZXJjZXB0aW9uQ29udGV4dEZyb21QcmV2aW91c05leHRVcmwoY3VycmVudFByZXZpb3VzTmV4dFVybCwgX19iYXNlUGF0aCksXG5cdFx0XHRcdHByZXZpb3VzTmV4dFVybDogY3VycmVudFByZXZpb3VzTmV4dFVybFxuXHRcdFx0fTtcblx0XHRcdGNvbnN0IG1hbmlmZXN0SW50ZXJjZXB0aW9uQ29udGV4dCA9IHJlc29sdmVNYW5pZmVzdE5hdmlnYXRpb25JbnRlcmNlcHRpb25Db250ZXh0KHtcblx0XHRcdFx0YmFzZVBhdGg6IF9fYmFzZVBhdGgsXG5cdFx0XHRcdGN1cnJlbnRQYXRobmFtZTogd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLFxuXHRcdFx0XHRyb3V0ZU1hbmlmZXN0OiBnZXRCcm93c2VyUm91dGVNYW5pZmVzdCgpLFxuXHRcdFx0XHR0YXJnZXRQYXRobmFtZVxuXHRcdFx0fSk7XG5cdFx0XHRpZiAobWFuaWZlc3RJbnRlcmNlcHRpb25Db250ZXh0ICE9PSBudWxsKSByZXR1cm4ge1xuXHRcdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiBtYW5pZmVzdEludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0XHRcdHByZXZpb3VzTmV4dFVybDogd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lICsgd2luZG93LmxvY2F0aW9uLnNlYXJjaFxuXHRcdFx0fTtcblx0XHRcdGNvbnN0IG1pZGRsZXdhcmVSZXdyaXRlSW50ZXJjZXB0aW9uQ29udGV4dCA9IHJlc29sdmVNaWRkbGV3YXJlUmV3cml0ZU5hdmlnYXRpb25JbnRlcmNlcHRpb25Db250ZXh0KHtcblx0XHRcdFx0YmFzZVBhdGg6IF9fYmFzZVBhdGgsXG5cdFx0XHRcdGN1cnJlbnRNYXRjaGVkUGF0aG5hbWU6IGdldEN1cnJlbnRNYXRjaGVkUm91dGVQYXRobmFtZSgpLFxuXHRcdFx0XHRjdXJyZW50UGF0aG5hbWU6IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSxcblx0XHRcdFx0cm91dGVNYW5pZmVzdDogZ2V0QnJvd3NlclJvdXRlTWFuaWZlc3QoKSxcblx0XHRcdFx0dGFyZ2V0UGF0aG5hbWVcblx0XHRcdH0pO1xuXHRcdFx0aWYgKG1pZGRsZXdhcmVSZXdyaXRlSW50ZXJjZXB0aW9uQ29udGV4dCAhPT0gbnVsbCkgcmV0dXJuIHtcblx0XHRcdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogbWlkZGxld2FyZVJld3JpdGVJbnRlcmNlcHRpb25Db250ZXh0LFxuXHRcdFx0XHRwcmV2aW91c05leHRVcmw6IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSArIHdpbmRvdy5sb2NhdGlvbi5zZWFyY2hcblx0XHRcdH07XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiBudWxsLFxuXHRcdFx0XHRwcmV2aW91c05leHRVcmw6IG51bGxcblx0XHRcdH07XG5cdFx0fVxuXHRcdGNhc2UgXCJ0cmF2ZXJzZVwiOiB7XG5cdFx0XHRjb25zdCBwcmV2aW91c05leHRVcmwgPSByZWFkSGlzdG9yeVN0YXRlUHJldmlvdXNOZXh0VXJsKHRyYXZlcnNlSGlzdG9yeVN0YXRlID8/IHdpbmRvdy5oaXN0b3J5LnN0YXRlKTtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdGludGVyY2VwdGlvbkNvbnRleHQ6IHJlc29sdmVJbnRlcmNlcHRpb25Db250ZXh0RnJvbVByZXZpb3VzTmV4dFVybChwcmV2aW91c05leHRVcmwsIF9fYmFzZVBhdGgpLFxuXHRcdFx0XHRwcmV2aW91c05leHRVcmxcblx0XHRcdH07XG5cdFx0fVxuXHRcdGNhc2UgXCJyZWZyZXNoXCI6IHtcblx0XHRcdGNvbnN0IGN1cnJlbnRQcmV2aW91c05leHRVcmwgPSBnZXRCcm93c2VyUm91dGVyU3RhdGUoKS5wcmV2aW91c05leHRVcmw7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiByZXNvbHZlSW50ZXJjZXB0aW9uQ29udGV4dEZyb21QcmV2aW91c05leHRVcmwoY3VycmVudFByZXZpb3VzTmV4dFVybCwgX19iYXNlUGF0aCksXG5cdFx0XHRcdHByZXZpb3VzTmV4dFVybDogY3VycmVudFByZXZpb3VzTmV4dFVybFxuXHRcdFx0fTtcblx0XHR9XG5cdFx0ZGVmYXVsdDogdGhyb3cgbmV3IEVycm9yKFwiW3ZpbmV4dF0gVW5rbm93biBuYXZpZ2F0aW9uIGtpbmQ6IFwiICsgU3RyaW5nKG5hdmlnYXRpb25LaW5kKSk7XG5cdH1cbn1cbmZ1bmN0aW9uIGhhbmRsZURldlJlY292ZXJ5Qm91bmRhcnlDYXRjaChyZXNldEtleSkge1xuXHRicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuZHJhaW5QcmVQYWludEVmZmVjdHMocmVzZXRLZXkpO1xufVxuZnVuY3Rpb24gaXNNcGFOYXZpZ2F0aW9uU3RhdGUodmFsdWUpIHtcblx0cmV0dXJuIHZhbHVlICE9PSBudWxsICYmIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiAmJiBcImtpbmRcIiBpbiB2YWx1ZSAmJiB2YWx1ZS5raW5kID09PSBcIm1wYS1uYXZpZ2F0aW9uXCI7XG59XG5mdW5jdGlvbiBwZXJmb3JtTXBhTmF2aWdhdGlvbihocmVmLCBoaXN0b3J5VXBkYXRlTW9kZSkge1xuXHRtcGFOYXZpZ2F0aW9uU2NoZWR1bGVyLm5hdmlnYXRlKHdpbmRvdywgaHJlZiwgaGlzdG9yeVVwZGF0ZU1vZGUpO1xufVxuZnVuY3Rpb24gQXBwUm91dGVyUmVkaXJlY3RCcmlkZ2UoeyBjaGlsZHJlbiB9KSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHR1c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGNvbnN0IGhhbmRsZVVuaGFuZGxlZFJlZGlyZWN0ID0gKGV2ZW50KSA9PiB7XG5cdFx0XHRjb25zdCBlcnJvciA9IFwicmVhc29uXCIgaW4gZXZlbnQgPyBldmVudC5yZWFzb24gOiBldmVudC5lcnJvcjtcblx0XHRcdGlmICghaXNSZWRpcmVjdEVycm9yKGVycm9yKSkgcmV0dXJuO1xuXHRcdFx0aWYgKFwiaGFuZGxlZFwiIGluIGVycm9yICYmIGVycm9yLmhhbmRsZWQgPT09IHRydWUpIHtcblx0XHRcdFx0ZXZlbnQucHJldmVudERlZmF1bHQoKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgcmVzdWx0ID0gZGVjb2RlUmVkaXJlY3RFcnJvcihlcnJvci5kaWdlc3QpO1xuXHRcdFx0aWYgKCFyZXN1bHQpIHJldHVybjtcblx0XHRcdGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRzdGFydFRyYW5zaXRpb24oKCkgPT4ge1xuXHRcdFx0XHRpZiAocmVzdWx0LnR5cGUgPT09IFwicHVzaFwiKSByb3V0ZXIucHVzaChyZXN1bHQudXJsKTtcblx0XHRcdFx0ZWxzZSByb3V0ZXIucmVwbGFjZShyZXN1bHQudXJsKTtcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLCBoYW5kbGVVbmhhbmRsZWRSZWRpcmVjdCk7XG5cdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJ1bmhhbmRsZWRyZWplY3Rpb25cIiwgaGFuZGxlVW5oYW5kbGVkUmVkaXJlY3QpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIGhhbmRsZVVuaGFuZGxlZFJlZGlyZWN0KTtcblx0XHRcdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwidW5oYW5kbGVkcmVqZWN0aW9uXCIsIGhhbmRsZVVuaGFuZGxlZFJlZGlyZWN0KTtcblx0XHR9O1xuXHR9LCBbcm91dGVyXSk7XG5cdHJldHVybiBjaGlsZHJlbiA/PyBudWxsO1xufVxuZnVuY3Rpb24gZGVjb2RlQXBwRWxlbWVudHNQcm9taXNlKHBheWxvYWQpIHtcblx0cmV0dXJuIFByb21pc2UucmVzb2x2ZShwYXlsb2FkKS50aGVuKChlbGVtZW50cykgPT4gQXBwRWxlbWVudHNXaXJlLmRlY29kZShlbGVtZW50cykpO1xufVxuZnVuY3Rpb24gQnJvd3NlclJvb3QoeyBoeWRyYXRpb25DYWNoZVB1YmxpY2F0aW9uLCBpbml0aWFsRWxlbWVudHMsIGluaXRpYWxOYXZpZ2F0aW9uU25hcHNob3QgfSkge1xuXHRjb25zdCByZXNvbHZlZEVsZW1lbnRzID0gdXNlKGluaXRpYWxFbGVtZW50cyk7XG5cdGNvbnN0IGluaXRpYWxNZXRhZGF0YSA9IEFwcEVsZW1lbnRzV2lyZS5yZWFkTWV0YWRhdGEocmVzb2x2ZWRFbGVtZW50cyk7XG5cdGNvbnN0IFt0cmVlU3RhdGVWYWx1ZSwgc2V0VHJlZVN0YXRlVmFsdWVdID0gdXNlU3RhdGUoKCkgPT4gKHtcblx0XHRhY3RpdmVPcGVyYXRpb246IG51bGwsXG5cdFx0YmZjYWNoZUlkczogY3JlYXRlSW5pdGlhbEJmY2FjaGVJZE1hcChyZXNvbHZlZEVsZW1lbnRzKSxcblx0XHRlbGVtZW50czogcmVzb2x2ZWRFbGVtZW50cyxcblx0XHRpbnRlcmNlcHRpb246IGluaXRpYWxNZXRhZGF0YS5pbnRlcmNlcHRpb24sXG5cdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogaW5pdGlhbE1ldGFkYXRhLmludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0bGF5b3V0SWRzOiBpbml0aWFsTWV0YWRhdGEubGF5b3V0SWRzLFxuXHRcdG5hdmlnYXRpb25TbmFwc2hvdDogaW5pdGlhbE5hdmlnYXRpb25TbmFwc2hvdCxcblx0XHRwcmV2aW91c05leHRVcmw6IG51bGwsXG5cdFx0cmVuZGVySWQ6IDAsXG5cdFx0cm9vdExheW91dFRyZWVQYXRoOiBpbml0aWFsTWV0YWRhdGEucm9vdExheW91dFRyZWVQYXRoLFxuXHRcdHJvdXRlSWQ6IGluaXRpYWxNZXRhZGF0YS5yb3V0ZUlkLFxuXHRcdHNsb3RCaW5kaW5nczogaW5pdGlhbE1ldGFkYXRhLnNsb3RCaW5kaW5ncyxcblx0XHR2aXNpYmxlQ29tbWl0VmVyc2lvbjogMFxuXHR9KSk7XG5cdGlmIChpc01wYU5hdmlnYXRpb25TdGF0ZSh0cmVlU3RhdGVWYWx1ZSkpIHtcblx0XHRwZXJmb3JtTXBhTmF2aWdhdGlvbih0cmVlU3RhdGVWYWx1ZS5ocmVmLCB0cmVlU3RhdGVWYWx1ZS5oaXN0b3J5VXBkYXRlTW9kZSk7XG5cdFx0dGhyb3cgdW5yZXNvbHZlZE1wYU5hdmlnYXRpb247XG5cdH1cblx0Y29uc3QgdHJlZVN0YXRlID0gaXNSb3V0ZXJTdGF0ZVByb21pc2UodHJlZVN0YXRlVmFsdWUpID8gdXNlKHRyZWVTdGF0ZVZhbHVlKSA6IHRyZWVTdGF0ZVZhbHVlO1xuXHRjb25zdCBzdGF0ZVJlZiA9IHVzZVJlZih0cmVlU3RhdGUpO1xuXHRzdGF0ZVJlZi5jdXJyZW50ID0gdHJlZVN0YXRlO1xuXHRjb25zdCBjb21taXR0ZWRTdGF0ZVJlZiA9IHVzZVJlZih0cmVlU3RhdGUpO1xuXHR1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuXHRcdGNvbW1pdHRlZFN0YXRlUmVmLmN1cnJlbnQgPSB0cmVlU3RhdGU7XG5cdH0sIFt0cmVlU3RhdGVdKTtcblx0dXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcblx0XHRjb25zdCBzZXRBcHBSb3V0ZXJTdGF0ZVZhbHVlID0gKHZhbHVlKSA9PiB7XG5cdFx0XHRzZXRUcmVlU3RhdGVWYWx1ZSh2YWx1ZSk7XG5cdFx0fTtcblx0XHRjb25zdCBkZXRhY2ggPSBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuYXR0YWNoQnJvd3NlclJvdXRlclN0YXRlKHNldEFwcFJvdXRlclN0YXRlVmFsdWUsIHN0YXRlUmVmKTtcblx0XHRjb25zdCBzZXRNcGFOYXZpZ2F0aW9uU3RhdGUgPSAoaHJlZiwgaGlzdG9yeVVwZGF0ZU1vZGUpID0+IHtcblx0XHRcdHN0YXJ0VHJhbnNpdGlvbigoKSA9PiB7XG5cdFx0XHRcdHNldFRyZWVTdGF0ZVZhbHVlKHtcblx0XHRcdFx0XHRocmVmLFxuXHRcdFx0XHRcdGhpc3RvcnlVcGRhdGVNb2RlLFxuXHRcdFx0XHRcdGtpbmQ6IFwibXBhLW5hdmlnYXRpb25cIlxuXHRcdFx0XHR9KTtcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0Y29uc3QgY3VycmVudE1wYU5hdmlnYXRpb25UcmVlID0ge1xuXHRcdFx0ZW50ZXI6IHNldE1wYU5hdmlnYXRpb25TdGF0ZSxcblx0XHRcdHJlc3RvcmUoKSB7XG5cdFx0XHRcdHNldFRyZWVTdGF0ZVZhbHVlKChjdXJyZW50KSA9PiBpc01wYU5hdmlnYXRpb25TdGF0ZShjdXJyZW50KSA/IGNvbW1pdHRlZFN0YXRlUmVmLmN1cnJlbnQgOiBjdXJyZW50KTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdG1wYU5hdmlnYXRpb25UcmVlID0gY3VycmVudE1wYU5hdmlnYXRpb25UcmVlO1xuXHRcdHJlZ2lzdGVyTmF2aWdhdGlvblJ1bnRpbWVGdW5jdGlvbnMoeyBuYXZpZ2F0ZUV4dGVybmFsOiAoaHJlZiwgaGlzdG9yeVVwZGF0ZU1vZGUpID0+IHtcblx0XHRcdHNldE1wYU5hdmlnYXRpb25TdGF0ZShocmVmLCBoaXN0b3J5VXBkYXRlTW9kZSk7XG5cdFx0XHRyZXR1cm4gd2FpdEZvck1wYU5hdmlnYXRpb25SZXN0b3JlKCk7XG5cdFx0fSB9KTtcblx0XHRicm93c2VyUm91dGVyU3RhdGVIYXNFdmVyQ29tbWl0dGVkID0gdHJ1ZTtcblx0XHRoeWRyYXRpb25DYWNoZVB1YmxpY2F0aW9uLmNvbW1pdCgpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRoeWRyYXRpb25DYWNoZVB1YmxpY2F0aW9uLmludmFsaWRhdGUoKTtcblx0XHRcdGlmIChtcGFOYXZpZ2F0aW9uVHJlZSA9PT0gY3VycmVudE1wYU5hdmlnYXRpb25UcmVlKSBtcGFOYXZpZ2F0aW9uVHJlZSA9IG51bGw7XG5cdFx0XHRyZWdpc3Rlck5hdmlnYXRpb25SdW50aW1lRnVuY3Rpb25zKHsgbmF2aWdhdGVFeHRlcm5hbDogdm9pZCAwIH0pO1xuXHRcdFx0ZGV0YWNoKCk7XG5cdFx0XHRzZXRNb3VudGVkU2xvdHNIZWFkZXIobnVsbCk7XG5cdFx0fTtcblx0fSwgW2h5ZHJhdGlvbkNhY2hlUHVibGljYXRpb24sIHNldFRyZWVTdGF0ZVZhbHVlXSk7XG5cdHVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0aHlkcmF0aW9uQ2FjaGVQdWJsaWNhdGlvbi5jb21wbGV0ZSgpO1xuXHRcdGNvbnN0IGh5ZHJhdGVkQXQgPSBwZXJmb3JtYW5jZS5ub3coKTtcblx0XHR3aW5kb3cuX19WSU5FWFRfSFlEUkFURURfQVQgPSBoeWRyYXRlZEF0O1xuXHRcdHdpbmRvdy5fX05FWFRfSFlEUkFURUQgPSB0cnVlO1xuXHRcdHdpbmRvdy5fX05FWFRfSFlEUkFURURfQVQgPSBoeWRyYXRlZEF0O1xuXHRcdHdpbmRvdy5fX05FWFRfSFlEUkFURURfQ0I/LigpO1xuXHR9LCBbaHlkcmF0aW9uQ2FjaGVQdWJsaWNhdGlvbl0pO1xuXHR1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuXHRcdGhpc3RvcnlDb250cm9sbGVyLnJlbWVtYmVySGlzdG9yeVN0YXRlU25hcHNob3QodHJlZVN0YXRlKTtcblx0fSwgW3RyZWVTdGF0ZV0pO1xuXHR1c2VFZmZlY3QoKCkgPT4ge1xuXHRcdHNldFdpbmRvd05leHRJbnRlcm5hbFNvdXJjZVBhZ2UoQXBwRWxlbWVudHNXaXJlLnJlYWRNZXRhZGF0YSh0cmVlU3RhdGUuZWxlbWVudHMpLnNvdXJjZVBhZ2UpO1xuXHR9LCBbdHJlZVN0YXRlLmVsZW1lbnRzXSk7XG5cdHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG5cdFx0Y29uc3QgcHJldmlvdXNNb3VudGVkU2xvdHNIZWFkZXIgPSBnZXRNb3VudGVkU2xvdHNIZWFkZXIoKTtcblx0XHRjb25zdCBuZXh0TW91bnRlZFNsb3RzSGVhZGVyID0gZ2V0TW91bnRlZFNsb3RJZHNIZWFkZXIoc3RhdGVSZWYuY3VycmVudC5lbGVtZW50cyk7XG5cdFx0c2V0TW91bnRlZFNsb3RzSGVhZGVyKG5leHRNb3VudGVkU2xvdHNIZWFkZXIpO1xuXHRcdHJlbW92ZVN0eWxlc2hlZXRMaW5rc0NvdmVyZWRCeUlubGluZUNzcygpO1xuXHRcdGlmIChwcmV2aW91c01vdW50ZWRTbG90c0hlYWRlciA9PT0gbmV4dE1vdW50ZWRTbG90c0hlYWRlcikgcmV0dXJuO1xuXHRcdGNvbnN0IHBpbmdUaW1lciA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5waW5nVmlzaWJsZUxpbmtzPy4oKTtcblx0XHR9LCAwKTtcblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0d2luZG93LmNsZWFyVGltZW91dChwaW5nVGltZXIpO1xuXHRcdH07XG5cdH0sIFt0cmVlU3RhdGUuZWxlbWVudHNdKTtcblx0dXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcblx0XHRpZiAodHJlZVN0YXRlLnJlbmRlcklkICE9PSAwKSByZXR1cm47XG5cdFx0aGlzdG9yeUNvbnRyb2xsZXIud3JpdGVIeWRyYXRlZEhpc3RvcnlNZXRhZGF0YSh7XG5cdFx0XHRhY3RpdmVSb3V0ZVBhdGhzOiByZXNvbHZlQWN0aXZlUm91dGVQYXRocyh0cmVlU3RhdGUuc2xvdEJpbmRpbmdzKSxcblx0XHRcdGJmY2FjaGVJZHM6IHRyZWVTdGF0ZS5iZmNhY2hlSWRzLFxuXHRcdFx0cHJldmlvdXNOZXh0VXJsOiB0cmVlU3RhdGUucHJldmlvdXNOZXh0VXJsXG5cdFx0fSk7XG5cdH0sIFtcblx0XHR0cmVlU3RhdGUuYmZjYWNoZUlkcyxcblx0XHR0cmVlU3RhdGUucHJldmlvdXNOZXh0VXJsLFxuXHRcdHRyZWVTdGF0ZS5yZW5kZXJJZCxcblx0XHR0cmVlU3RhdGUuc2xvdEJpbmRpbmdzXG5cdF0pO1xuXHRjb25zdCByb3V0ZVRyZWUgPSBjcmVhdGVFbGVtZW50KFJlZGlyZWN0Qm91bmRhcnksIG51bGwsIGNyZWF0ZUVsZW1lbnQoTmF2aWdhdGlvbkNvbW1pdFNpZ25hbCwgeyByZW5kZXJJZDogdHJlZVN0YXRlLnJlbmRlcklkIH0sIGNyZWF0ZUFwcFJvdXRlVHJlZSh7XG5cdFx0ZWxlbWVudHM6IHRyZWVTdGF0ZS5lbGVtZW50cyxcblx0XHRoaXN0b3J5Q29tbWl0OiBjcmVhdGVFbGVtZW50KE5hdmlnYXRpb25IaXN0b3J5Q29tbWl0LCB7IHJlbmRlcklkOiB0cmVlU3RhdGUucmVuZGVySWQgfSksXG5cdFx0cm91dGVJZDogdHJlZVN0YXRlLnJvdXRlSWRcblx0fSkpKTtcblx0Y29uc3QgYmZjYWNoZVNlZ21lbnRJZGVudGl0aWVzID0gdXNlTWVtbygoKSA9PiBjcmVhdGVCZmNhY2hlU2VnbWVudElkZW50aXR5TWFwKHsgZWxlbWVudHM6IHRyZWVTdGF0ZS5lbGVtZW50cyB9KSwgW3RyZWVTdGF0ZS5lbGVtZW50c10pO1xuXHRjb25zdCBpZGVudGl0eU1hcFRyZWUgPSBjcmVhdGVFbGVtZW50KEJmY2FjaGVJZGVudGl0eU1hcENvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IGJmY2FjaGVTZWdtZW50SWRlbnRpdGllcyB9LCByb3V0ZVRyZWUpO1xuXHRjb25zdCBiZmNhY2hlVHJlZSA9IEJmY2FjaGVJZE1hcENvbnRleHQgPyBjcmVhdGVFbGVtZW50KEJmY2FjaGVJZE1hcENvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IHRyZWVTdGF0ZS5iZmNhY2hlSWRzIH0sIGlkZW50aXR5TWFwVHJlZSkgOiBpZGVudGl0eU1hcFRyZWU7XG5cdGNvbnN0IHJlZGlyZWN0ZWRUcmVlID0gY3JlYXRlRWxlbWVudChBcHBSb3V0ZXJSZWRpcmVjdEJyaWRnZSwgbnVsbCwgYmZjYWNoZVRyZWUpO1xuXHRjb25zdCBpbm5lclRyZWUgPSBBcHBSb3V0ZXJDb250ZXh0ID8gY3JlYXRlRWxlbWVudChBcHBSb3V0ZXJDb250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiBhcHBSb3V0ZXJJbnN0YW5jZSB9LCByZWRpcmVjdGVkVHJlZSkgOiByZWRpcmVjdGVkVHJlZTtcblx0Y29uc3QgY29tbWl0dGVkVHJlZSA9IGltcG9ydC5tZXRhLmVudi5ERVYgPyBjcmVhdGVFbGVtZW50KERldlJlY292ZXJ5Qm91bmRhcnksIHtcblx0XHRpc0ltcGxpY2l0Um9vdEVycm9yQm91bmRhcnk6IHRydWUsXG5cdFx0cmVzZXRLZXk6IHRyZWVTdGF0ZS5yZW5kZXJJZCxcblx0XHRvbkNhdGNoOiBoYW5kbGVEZXZSZWNvdmVyeUJvdW5kYXJ5Q2F0Y2hcblx0fSwgaW5uZXJUcmVlKSA6IGlubmVyVHJlZTtcblx0Y29uc3Qgc2Nyb2xsU2NvcGVkVHJlZSA9IGNyZWF0ZUVsZW1lbnQoQXBwUm91dGVyU2Nyb2xsQ29tbWl0UHJvdmlkZXIsIHsgY29tbWl0SWQ6IHRyZWVTdGF0ZS5yZW5kZXJJZCB9LCBjb21taXR0ZWRUcmVlKTtcblx0Y29uc3Qgcm9vdEVycm9yVHJlZSA9IGNyZWF0ZUVsZW1lbnQoR2xvYmFsRXJyb3JCb3VuZGFyeSwge1xuXHRcdGZhbGxiYWNrOiBERUZBVUxUX0dMT0JBTF9FUlJPUl9DT01QT05FTlQsXG5cdFx0Y2hpbGRyZW46IHNjcm9sbFNjb3BlZFRyZWVcblx0fSk7XG5cdGNvbnN0IENsaWVudE5hdmlnYXRpb25SZW5kZXJDb250ZXh0ID0gZ2V0Q2xpZW50TmF2aWdhdGlvblJlbmRlckNvbnRleHQoKTtcblx0aWYgKCFDbGllbnROYXZpZ2F0aW9uUmVuZGVyQ29udGV4dCkgcmV0dXJuIHJvb3RFcnJvclRyZWU7XG5cdHJldHVybiBjcmVhdGVFbGVtZW50KENsaWVudE5hdmlnYXRpb25SZW5kZXJDb250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiB0cmVlU3RhdGUubmF2aWdhdGlvblNuYXBzaG90IH0sIHJvb3RFcnJvclRyZWUpO1xufVxuZnVuY3Rpb24gcmVzdG9yZUh5ZHJhdGlvbk5hdmlnYXRpb25Db250ZXh0KHBhdGhuYW1lLCBzZWFyY2hQYXJhbXMsIHBhcmFtcykge1xuXHRzZXROYXZpZ2F0aW9uQ29udGV4dCh7XG5cdFx0cGF0aG5hbWUsXG5cdFx0c2VhcmNoUGFyYW1zOiBuZXcgVVJMU2VhcmNoUGFyYW1zKHNlYXJjaFBhcmFtcyksXG5cdFx0cGFyYW1zXG5cdH0pO1xufVxuZnVuY3Rpb24gcmVzdG9yZUVtYmVkZGVkSHlkcmF0aW9uTmF2aWdhdGlvbkNvbnRleHQocGF0aG5hbWUsIHNlYXJjaFBhcmFtcywgcGFyYW1zLCBzZWFyY2hQYXJhbXNGcm9tQnJvd3Nlcikge1xuXHRyZXN0b3JlSHlkcmF0aW9uTmF2aWdhdGlvbkNvbnRleHQocGF0aG5hbWUsIHNlYXJjaFBhcmFtc0Zyb21Ccm93c2VyID8gd2luZG93LmxvY2F0aW9uLnNlYXJjaCA6IHNlYXJjaFBhcmFtcywgcGFyYW1zKTtcbn1cbi8qKlxuKiBUaGUgcGF0aCBhbmQgcXVlcnkgU1NSIHJlbmRlcmVkLCBmcm9tIHRoZSBuYXZpZ2F0aW9uIHBheWxvYWQgdGhlIGRvY3VtZW50XG4qIGVtYmVkczogdGhlIGVmZmVjdGl2ZSBxdWVyeSwgd2hpY2ggYSByZXdyaXRlIG1heSBoYXZlIGNoYW5nZWQsIG9yIHRoZVxuKiBicm93c2VyIFVSTCdzIHdoZW4gYSBzdG9yZWQgZG9jdW1lbnQgbGVhdmVzIHRoZSBxdWVyeSBvdXQuXG4qL1xuZnVuY3Rpb24gZ2V0SHlkcmF0aW9uUmVuZGVyZWRQYXRoQW5kU2VhcmNoKCkge1xuXHRjb25zdCBjb250ZXh0ID0gZ2V0TmF2aWdhdGlvbkNvbnRleHQoKTtcblx0aWYgKCFjb250ZXh0KSByZXR1cm4gbnVsbDtcblx0Y29uc3Qgc2VhcmNoID0gY29udGV4dC5zZWFyY2hQYXJhbXMudG9TdHJpbmcoKTtcblx0cmV0dXJuIHNlYXJjaCA/IGAke2NvbnRleHQucGF0aG5hbWV9PyR7c2VhcmNofWAgOiBjb250ZXh0LnBhdGhuYW1lO1xufVxuLyoqXG4qIEEgcmVuZGVyIHRoYXQgdHVybnMgZHluYW1pYyBhZnRlciB0aGUgaGVhZCBzZW5kcyBpdHMgY2xpZW50IHBhZ2VzJyBxdWVyeVxuKiBsYXRlciBpbiB0aGUgZG9jdW1lbnQgKHNlZSBgYXBwLXNzci1lbnRyeS50c2ApLCBwb3NzaWJseSBhZnRlciBib290c3RyYXAsIHNvXG4qIHRoZSBoeWRyYXRpb24gc25hcHNob3QgcmVhZHMgaXQgd2hlbiBhIGNsaWVudCBwYWdlIGZpcnN0IHJlbmRlcnMuXG4qL1xuZnVuY3Rpb24gd2l0aExhdGVSZW5kZXJlZFNlYXJjaChzbmFwc2hvdCwgcnNjKSB7XG5cdGlmICghcnNjKSByZXR1cm4gc25hcHNob3Q7XG5cdGNvbnN0IGhlYWRSZW5kZXJlZFNlYXJjaCA9IHNuYXBzaG90LnJlbmRlcmVkU2VhcmNoO1xuXHRyZXR1cm4gT2JqZWN0LmRlZmluZVByb3BlcnR5KHNuYXBzaG90LCBcInJlbmRlcmVkU2VhcmNoXCIsIHtcblx0XHRjb25maWd1cmFibGU6IHRydWUsXG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRnZXQ6ICgpID0+IHJzYy5yZW5kZXJlZFNlYXJjaCA/PyBoZWFkUmVuZGVyZWRTZWFyY2hcblx0fSk7XG59XG4vKiogQ2FycnkgdGhlIHJlbmRlcmVkIHF1ZXJ5IG92ZXIgdG8gYSBzbmFwc2hvdCBvZiB0aGUgc2FtZSBVUkwuICovXG5mdW5jdGlvbiB3aXRoUmVuZGVyZWRTZWFyY2hPZihzbmFwc2hvdCwgc291cmNlKSB7XG5cdHJldHVybiBzb3VyY2UucmVuZGVyZWRTZWFyY2ggPT09IHZvaWQgMCA/IHNuYXBzaG90IDoge1xuXHRcdC4uLnNuYXBzaG90LFxuXHRcdHJlbmRlcmVkU2VhcmNoOiBzb3VyY2UucmVuZGVyZWRTZWFyY2hcblx0fTtcbn1cbmZ1bmN0aW9uIHJlc3RvcmVQb3BzdGF0ZVNjcm9sbFBvc2l0aW9uKHN0YXRlLCBvcHRpb25zKSB7XG5cdGNvbnN0IHNob3VsZENvbnRpbnVlID0gb3B0aW9ucz8uc2hvdWxkQ29udGludWUgPz8gKCgpID0+IHRydWUpO1xuXHRpZiAoIXNob3VsZENvbnRpbnVlKCkpIHJldHVybjtcblx0aWYgKCEoc3RhdGUgJiYgdHlwZW9mIHN0YXRlID09PSBcIm9iamVjdFwiICYmIFwiX192aW5leHRfc2Nyb2xsWVwiIGluIHN0YXRlKSkge1xuXHRcdGlmICh3aW5kb3cubG9jYXRpb24uaGFzaCkgc2Nyb2xsVG9IYXNoVGFyZ2V0T25OZXh0RnJhbWUod2luZG93LmxvY2F0aW9uLmhhc2gpO1xuXHRcdHJldHVybjtcblx0fVxuXHRjb25zdCB5ID0gTnVtYmVyKHN0YXRlLl9fdmluZXh0X3Njcm9sbFkpO1xuXHRjb25zdCB4ID0gXCJfX3ZpbmV4dF9zY3JvbGxYXCIgaW4gc3RhdGUgPyBOdW1iZXIoc3RhdGUuX192aW5leHRfc2Nyb2xsWCkgOiAwO1xuXHRyZXRyeVNjcm9sbFRvKHgsIHksIHtcblx0XHRtaW5GcmFtZXM6IDEsXG5cdFx0c2hvdWxkQ29udGludWVcblx0fSk7XG59XG5mdW5jdGlvbiBpc1NhbWVBcHBSb3V0ZVBvcHN0YXRlVGFyZ2V0KGhyZWYpIHtcblx0aWYgKCFoYXNCcm93c2VyUm91dGVyU3RhdGUoKSkgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCB0YXJnZXQgPSBuZXcgVVJMKGhyZWYsIHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4pO1xuXHRjb25zdCByb3V0ZXJTdGF0ZSA9IGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpO1xuXHRyZXR1cm4gY3JlYXRlQmFzZVBhdGhTdHJpcHBlZFBhdGhBbmRTZWFyY2godGFyZ2V0LCBfX2Jhc2VQYXRoKSA9PT0gY3JlYXRlU25hcHNob3RQYXRoQW5kU2VhcmNoKHJvdXRlclN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdCk7XG59XG5sZXQgaXNQYWdlVW5sb2FkaW5nID0gZmFsc2U7XG5jb25zdCBSU0NfUkVMT0FEX0tFWSA9IFwiX192aW5leHRfcnNjX2luaXRpYWxfcmVsb2FkX19cIjtcbmZ1bmN0aW9uIHJlYWRSZWxvYWRGbGFnKCkge1xuXHR0cnkge1xuXHRcdHJldHVybiBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKFJTQ19SRUxPQURfS0VZKTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cbn1cbmZ1bmN0aW9uIHdyaXRlUmVsb2FkRmxhZyhwYXRoKSB7XG5cdHRyeSB7XG5cdFx0c2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShSU0NfUkVMT0FEX0tFWSwgcGF0aCk7XG5cdH0gY2F0Y2gge31cbn1cbmZ1bmN0aW9uIGNsZWFyUmVsb2FkRmxhZygpIHtcblx0dHJ5IHtcblx0XHRzZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKFJTQ19SRUxPQURfS0VZKTtcblx0fSBjYXRjaCB7fVxufVxuZnVuY3Rpb24gcmVjb3ZlckZyb21CYWRJbml0aWFsUnNjUmVzcG9uc2UocmVhc29uKSB7XG5cdGNvbnN0IGN1cnJlbnRQYXRoID0gd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lICsgd2luZG93LmxvY2F0aW9uLnNlYXJjaDtcblx0aWYgKHJlYWRSZWxvYWRGbGFnKCkgPT09IGN1cnJlbnRQYXRoKSB7XG5cdFx0Y2xlYXJSZWxvYWRGbGFnKCk7XG5cdFx0Y29uc29sZS5lcnJvcihgW3ZpbmV4dF0gSW5pdGlhbCBSU0MgZmV0Y2ggJHtyZWFzb259IGFmdGVyIHJlbG9hZDsgYWJvcnRpbmcgaHlkcmF0aW9uLiBTZXJ2ZXItcmVuZGVyZWQgSFRNTCByZW1haW5zIHZpc2libGU7IGNsaWVudCBjb21wb25lbnRzIHdpbGwgbm90IGh5ZHJhdGUuYCk7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cblx0d3JpdGVSZWxvYWRGbGFnKGN1cnJlbnRQYXRoKTtcblx0aWYgKHJlYWRSZWxvYWRGbGFnKCkgIT09IGN1cnJlbnRQYXRoKSB7XG5cdFx0Y29uc29sZS5lcnJvcihgW3ZpbmV4dF0gSW5pdGlhbCBSU0MgZmV0Y2ggJHtyZWFzb259OyBzZXNzaW9uU3RvcmFnZSB1bmF2YWlsYWJsZSBzbyB0aGUgcmVsb2FkLWxvb3AgZ3VhcmQgY2Fubm90IHBlcnNpc3Qg4oCUIGFib3J0aW5nIGh5ZHJhdGlvbi4gU2VydmVyLXJlbmRlcmVkIEhUTUwgcmVtYWlucyB2aXNpYmxlOyBjbGllbnQgY29tcG9uZW50cyB3aWxsIG5vdCBoeWRyYXRlLmApO1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdGNvbnNvbGUud2FybihgW3ZpbmV4dF0gSW5pdGlhbCBSU0MgZmV0Y2ggJHtyZWFzb259OyByZWxvYWRpbmcgb25jZSB0byBsZXQgdGhlIHNlcnZlciByZW5kZXIgdGhlIEhUTUwgZXJyb3IgcGFnZWApO1xuXHR3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG5cdHJldHVybiBudWxsO1xufVxuYXN5bmMgZnVuY3Rpb24gcmVhZEluaXRpYWxSc2NTdHJlYW0oKSB7XG5cdGNvbnN0IHZpbmV4dCA9IGdldFZpbmV4dEJyb3dzZXJHbG9iYWwoKTtcblx0Y29uc3QgcnVudGltZVJzYyA9IGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmJvb3RzdHJhcC5yc2M7XG5cdGlmIChydW50aW1lUnNjIHx8IHZpbmV4dC5fX1ZJTkVYVF9SU0NfQ0hVTktTX18gfHwgdmluZXh0Ll9fVklORVhUX1JTQ19ET05FX18pIHtcblx0XHRjbGVhclJlbG9hZEZsYWcoKTtcblx0XHRjbGVhckhhcmROYXZpZ2F0aW9uTG9vcEd1YXJkKCk7XG5cdFx0aWYgKHJ1bnRpbWVSc2MpIHtcblx0XHRcdGFwcGx5UnVudGltZVJzY0Jvb3RzdHJhcChydW50aW1lUnNjKTtcblx0XHRcdGlmIChydW50aW1lUnNjLmRvbmUpIHtcblx0XHRcdFx0cmVnaXN0ZXJOYXZpZ2F0aW9uUnVudGltZUJvb3RzdHJhcCh7IHJzYzogdm9pZCAwIH0pO1xuXHRcdFx0XHRyZXR1cm4gY2h1bmtzVG9SZWFkYWJsZVN0cmVhbShydW50aW1lUnNjLnJzYyk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gY3JlYXRlUHJvZ3Jlc3NpdmVSc2NTdHJlYW0oKTtcblx0XHR9XG5cdFx0aWYgKHZpbmV4dC5fX1ZJTkVYVF9SU0NfUEFSQU1TX18pIGFwcGx5Q2xpZW50UGFyYW1zKHZpbmV4dC5fX1ZJTkVYVF9SU0NfUEFSQU1TX18pO1xuXHRcdHJldHVybiBjcmVhdGVQcm9ncmVzc2l2ZVJzY1N0cmVhbSgpO1xuXHR9XG5cdGNvbnN0IHJzY0hlYWRlcnMgPSBjcmVhdGVSc2NSZXF1ZXN0SGVhZGVycygpO1xuXHRjb25zdCByc2NSZXNwb25zZSA9IGF3YWl0IGZldGNoKGF3YWl0IGNyZWF0ZVJzY1JlcXVlc3RVcmwod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lICsgd2luZG93LmxvY2F0aW9uLnNlYXJjaCwgcnNjSGVhZGVycyksIHtcblx0XHRjcmVkZW50aWFsczogXCJpbmNsdWRlXCIsXG5cdFx0aGVhZGVyczogcnNjSGVhZGVyc1xuXHR9KTtcblx0aWYgKCFyc2NSZXNwb25zZS5vaykgcmV0dXJuIHJlY292ZXJGcm9tQmFkSW5pdGlhbFJzY1Jlc3BvbnNlKGByZXR1cm5lZCAke3JzY1Jlc3BvbnNlLnN0YXR1c31gKTtcblx0Y29uc3QgY29udGVudFR5cGUgPSByc2NSZXNwb25zZS5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKSA/PyBcIlwiO1xuXHRpZiAoIWNvbnRlbnRUeXBlLnN0YXJ0c1dpdGgoXCJ0ZXh0L3gtY29tcG9uZW50XCIpKSByZXR1cm4gcmVjb3ZlckZyb21CYWRJbml0aWFsUnNjUmVzcG9uc2UoYHJldHVybmVkIG5vbi1SU0MgY29udGVudC10eXBlIFwiJHtjb250ZW50VHlwZSB8fCBcIihtaXNzaW5nKVwifVwiYCk7XG5cdGlmICghcnNjUmVzcG9uc2UuYm9keSkgcmV0dXJuIHJlY292ZXJGcm9tQmFkSW5pdGlhbFJzY1Jlc3BvbnNlKFwicmV0dXJuZWQgZW1wdHkgYm9keVwiKTtcblx0Y2xlYXJSZWxvYWRGbGFnKCk7XG5cdGNsZWFySGFyZE5hdmlnYXRpb25Mb29wR3VhcmQoKTtcblx0c2V0Q2xpZW50UnNjQ29tcGF0aWJpbGl0eUlkKHJzY1Jlc3BvbnNlLmhlYWRlcnMuZ2V0KFZJTkVYVF9SU0NfQ09NUEFUSUJJTElUWV9JRF9IRUFERVIpKTtcblx0Y29uc3QgcGFyc2VkUGFyYW1zID0gcGFyc2VFbmNvZGVkSnNvbkhlYWRlcihyc2NSZXNwb25zZS5oZWFkZXJzLmdldChWSU5FWFRfUEFSQU1TX0hFQURFUikpO1xuXHRjb25zdCBwYXJhbXMgPSBwYXJzZWRQYXJhbXMgPz8ge307XG5cdGlmIChwYXJzZWRQYXJhbXMpIHRyeSB7XG5cdFx0YXBwbHlDbGllbnRQYXJhbXMocGFyc2VkUGFyYW1zKTtcblx0fSBjYXRjaCB7fVxuXHRjb25zdCByZW5kZXJlZCA9IHJlc29sdmVGZXRjaGVkSHlkcmF0aW9uTG9jYXRpb24ocGFyc2VSZW5kZXJlZFBhdGhBbmRTZWFyY2hIZWFkZXIocnNjUmVzcG9uc2UuaGVhZGVycy5nZXQoVklORVhUX1JFTkRFUkVEX1BBVEhfQU5EX1NFQVJDSF9IRUFERVIpKSwgd2luZG93LmxvY2F0aW9uKTtcblx0cmVzdG9yZUh5ZHJhdGlvbk5hdmlnYXRpb25Db250ZXh0KHJlbmRlcmVkLnBhdGhuYW1lLCByZW5kZXJlZC5zZWFyY2gsIHBhcmFtcyk7XG5cdHJldHVybiByc2NSZXNwb25zZS5ib2R5O1xufVxuZnVuY3Rpb24gYXBwbHlSdW50aW1lUnNjQm9vdHN0cmFwKHJzYykge1xuXHRzZXRDbGllbnRSc2NDb21wYXRpYmlsaXR5SWQocnNjLmNvbXBhdGliaWxpdHlJZCk7XG5cdGNvbnN0IHBhcmFtcyA9IHJzYy5wYXJhbXMgPz8ge307XG5cdGlmIChyc2MucGFyYW1zKSBhcHBseUNsaWVudFBhcmFtcyhyc2MucGFyYW1zKTtcblx0aWYgKHJzYy5uYXYpIHJlc3RvcmVFbWJlZGRlZEh5ZHJhdGlvbk5hdmlnYXRpb25Db250ZXh0KHJzYy5uYXYucGF0aG5hbWUsIHJzYy5uYXYuc2VhcmNoUGFyYW1zLCBwYXJhbXMsIHJzYy5zZWFyY2hQYXJhbXNGcm9tQnJvd3NlciA9PT0gdHJ1ZSk7XG59XG5mdW5jdGlvbiByZWdpc3RlclNlcnZlckFjdGlvbkNhbGxiYWNrKCkge1xuXHRzZXRTZXJ2ZXJDYWxsYmFjaygoaWQsIGFyZ3MpID0+IHtcblx0XHRjb25zdCByZWxlYXNlQ2FjaGVJbnZhbGlkYXRpb25HdWFyZCA9IGhpc3RvcnlDb250cm9sbGVyLmJlZ2luQ2FjaGVJbnZhbGlkYXRpb25HdWFyZCgpO1xuXHRcdGNvbnN0IGFjdGlvbkluaXRpYXRpb24gPSBjcmVhdGVBY3Rpb25Jbml0aWF0aW9uU25hcHNob3QoKTtcblx0XHRyZXR1cm4gbG9hZFNlcnZlckFjdGlvbkNsaWVudCgpLnRoZW4oKHsgaW52b2tlQ2xpZW50U2VydmVyQWN0aW9uIH0pID0+IGludm9rZUNsaWVudFNlcnZlckFjdGlvbihpZCwgYXJncywgYWN0aW9uSW5pdGlhdGlvbiwge1xuXHRcdFx0YmFzZVBhdGg6IF9fYmFzZVBhdGgsXG5cdFx0XHRjbGVhckNsaWVudE5hdmlnYXRpb25DYWNoZXMsXG5cdFx0XHRjbGVhckR5bmFtaWNDbGllbnROYXZpZ2F0aW9uQ2FjaGVzLFxuXHRcdFx0Y2xpZW50UnNjQ29tcGF0aWJpbGl0eUlkLFxuXHRcdFx0Y29tbWl0U2FtZVVybE5hdmlnYXRlUGF5bG9hZCxcblx0XHRcdG5hdmlnYXRpb25QbGFubmVyLFxuXHRcdFx0cGVyZm9ybUhhcmROYXZpZ2F0aW9uOiAodXJsLCBoaXN0b3J5TW9kZSkgPT4gYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLnBlcmZvcm1IYXJkTmF2aWdhdGlvbih1cmwsIGhpc3RvcnlNb2RlKSxcblx0XHRcdHJlbmRlclJlZGlyZWN0UGF5bG9hZChlbGVtZW50cywgdGFyZ2V0LCBhY3Rpb25Jbml0aWF0aW9uLCByZXZhbGlkYXRpb24pIHtcblx0XHRcdFx0aWYgKGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5pc0N1cnJlbnROYXZpZ2F0aW9uKGFjdGlvbkluaXRpYXRpb24ubmF2aWdhdGlvbklkKSkgZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLm5vdGlmeUxpbmtOYXZpZ2F0aW9uU3RhcnQ/LigpO1xuXHRcdFx0XHRjb25zdCBoYXNoSWR4ID0gdGFyZ2V0LmhyZWYuaW5kZXhPZihcIiNcIik7XG5cdFx0XHRcdGNvbnN0IGhhc2ggPSBoYXNoSWR4ICE9PSAtMSA/IHRhcmdldC5ocmVmLnNsaWNlKGhhc2hJZHgpIDogXCJcIjtcblx0XHRcdFx0Y29uc3QgYWN0aW9uU2Nyb2xsSW50ZW50ID0gYmVnaW5BcHBSb3V0ZXJTY3JvbGxJbnRlbnQoaGFzaCB8fCBudWxsKTtcblx0XHRcdFx0aWYgKHRhcmdldC50eXBlID09PSBcInB1c2hcIikgc2F2ZVNjcm9sbFBvc2l0aW9uKCk7XG5cdFx0XHRcdHJlbmRlck5hdmlnYXRpb25QYXlsb2FkKHtcblx0XHRcdFx0XHRhY3Rpb25UeXBlOiB0YXJnZXQudHlwZSA9PT0gXCJwdXNoXCIgPyBcIm5hdmlnYXRlXCIgOiBcInJlcGxhY2VcIixcblx0XHRcdFx0XHRoaXN0b3J5VXBkYXRlTW9kZTogdGFyZ2V0LnR5cGUgPT09IFwicHVzaFwiID8gXCJwdXNoXCIgOiBcInJlcGxhY2VcIixcblx0XHRcdFx0XHRuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlOiBhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLFxuXHRcdFx0XHRcdG5hdmlnYXRpb25TbmFwc2hvdDogY3JlYXRlQ2xpZW50TmF2aWdhdGlvblJlbmRlclNuYXBzaG90KHRhcmdldC5ocmVmLCBhY3Rpb25Jbml0aWF0aW9uLnJvdXRlclN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdC5wYXJhbXMsIHRhcmdldC5yZW5kZXJlZFBhdGhBbmRTZWFyY2gpLFxuXHRcdFx0XHRcdG5hdklkOiBhY3Rpb25Jbml0aWF0aW9uLm5hdmlnYXRpb25JZCxcblx0XHRcdFx0XHRvcGVyYXRpb25MYW5lOiByZXNvbHZlU2VydmVyQWN0aW9uT3BlcmF0aW9uTGFuZShyZXZhbGlkYXRpb24pLFxuXHRcdFx0XHRcdHBhcmFtczoge30sXG5cdFx0XHRcdFx0cGF5bG9hZDogUHJvbWlzZS5yZXNvbHZlKGVsZW1lbnRzKSxcblx0XHRcdFx0XHRwYXlsb2FkT3JpZ2luOiBGUkVTSF9BUFBfTkFWSUdBVElPTl9QQVlMT0FEX09SSUdJTixcblx0XHRcdFx0XHRwZW5kaW5nUm91dGVyU3RhdGU6IG51bGwsXG5cdFx0XHRcdFx0cHJldmlvdXNOZXh0VXJsOiBudWxsLFxuXHRcdFx0XHRcdHNjcm9sbEludGVudDogYWN0aW9uU2Nyb2xsSW50ZW50LFxuXHRcdFx0XHRcdHRhcmdldEhyZWY6IHRhcmdldC5ocmVmXG5cdFx0XHRcdH0pLmNhdGNoKCgpID0+IHtcblx0XHRcdFx0XHRicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIucGVyZm9ybUhhcmROYXZpZ2F0aW9uKHRhcmdldC5ocmVmKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9LFxuXHRcdFx0c3luY0N1cnJlbnRIaXN0b3J5U3RhdGU6IChwcmV2aW91c05leHRVcmwsIGJmY2FjaGVJZHMpID0+IGhpc3RvcnlDb250cm9sbGVyLnN5bmNDdXJyZW50SGlzdG9yeVN0YXRlUHJldmlvdXNOZXh0VXJsKHByZXZpb3VzTmV4dFVybCwgYmZjYWNoZUlkcyksXG5cdFx0XHRzeW5jU2VydmVyQWN0aW9uSHR0cEZhbGxiYWNrSGVhZFxuXHRcdH0pKS5maW5hbGx5KHJlbGVhc2VDYWNoZUludmFsaWRhdGlvbkd1YXJkKTtcblx0fSk7XG59XG5mdW5jdGlvbiBSZXBsYXlJbml0aWFsRGV2U2VydmVyRXJyb3JzKHsgcmVwb3J0IH0pIHtcblx0dXNlRWZmZWN0KHJlcG9ydCwgW3JlcG9ydF0pO1xuXHRyZXR1cm4gbnVsbDtcbn1cbmFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG5cdGlmICghY2xhaW1Jbml0aWFsQXBwUm91dGVyQm9vdHN0cmFwKCkpIHJldHVybjtcblx0bG9hZE5hdmlnYXRpb25SdW50aW1lUm91dGVNYW5pZmVzdCgpO1xuXHRpZiAoaGFzU2VydmVyQWN0aW9ucykgcmVnaXN0ZXJTZXJ2ZXJBY3Rpb25DYWxsYmFjaygpO1xuXHRpbnN0YWxsQXBwTmF2aWdhdGlvbkZhaWx1cmVMaXN0ZW5lcnMoKTtcblx0aWYgKEhBU19DTElFTlRfUkVXUklURVMpIGF3YWl0IHByZWxvYWRIeWJyaWRDbGllbnRSb3V0ZU93bmVyKCk7XG5cdGxldCBkZXZFcnJvck92ZXJsYXkgPSBudWxsO1xuXHRpZiAoaW1wb3J0Lm1ldGEuZW52LkRFVikge1xuXHRcdGRldkVycm9yT3ZlcmxheSA9IGF3YWl0IGltcG9ydChcIi4uL2NsaWVudC9kZXYtZXJyb3Itb3ZlcmxheS5qc1wiKTtcblx0XHRkZXZFcnJvck92ZXJsYXkuaW5zdGFsbERldkVycm9yT3ZlcmxheSgpO1xuXHRcdGRldkVycm9yT3ZlcmxheS5pbnN0YWxsVml0ZUhtckVycm9ySGFuZGxlcihpbXBvcnQubWV0YS5ob3QpO1xuXHRcdGlmIChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuaWQgIT09IFwiX19uZXh0X2Vycm9yX19cIikgZGV2RXJyb3JPdmVybGF5LnJlcG9ydEluaXRpYWxEZXZTZXJ2ZXJFcnJvcnMoKTtcblx0fVxuXHRjb25zdCBpbml0aWFsUnNjQm9vdHN0cmFwID0gZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uYm9vdHN0cmFwLnJzYztcblx0Y29uc3QgcnNjU3RyZWFtID0gYXdhaXQgcmVhZEluaXRpYWxSc2NTdHJlYW0oKTtcblx0aWYgKHJzY1N0cmVhbSA9PT0gbnVsbCkgcmV0dXJuO1xuXHRib290c3RyYXBIeWRyYXRpb24ocnNjU3RyZWFtLCBkZXZFcnJvck92ZXJsYXksIGluaXRpYWxSc2NCb290c3RyYXApO1xufVxuZnVuY3Rpb24gYm9vdHN0cmFwSHlkcmF0aW9uKHJzY1N0cmVhbSwgZGV2RXJyb3JPdmVybGF5LCBpbml0aWFsUnNjQm9vdHN0cmFwKSB7XG5cdGNvbnN0IGh5ZHJhdGlvbkNhY2hlUHVibGljYXRpb24gPSBjcmVhdGVIeWRyYXRpb25DYWNoZVB1YmxpY2F0aW9uKCk7XG5cdGNvbnN0IGNhY2hlR2VuZXJhdGlvbiA9IGNsaWVudE5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb247XG5cdGNvbnN0IFtyZWFjdEJyYW5jaCwgY2FjaGVCcmFuY2hdID0gcnNjU3RyZWFtLnRlZSgpO1xuXHRjb25zdCBpbml0aWFsTmF2aWdhdGlvblNuYXBzaG90ID0gd2l0aExhdGVSZW5kZXJlZFNlYXJjaChjcmVhdGVDbGllbnROYXZpZ2F0aW9uUmVuZGVyU25hcHNob3Qod2luZG93LmxvY2F0aW9uLmhyZWYsIGxhdGVzdENsaWVudFBhcmFtcywgZ2V0SHlkcmF0aW9uUmVuZGVyZWRQYXRoQW5kU2VhcmNoKCkpLCBpbml0aWFsUnNjQm9vdHN0cmFwKTtcblx0Y29uc3QgaW5pdGlhbFBhdGhBbmRTZWFyY2ggPSBjcmVhdGVTbmFwc2hvdFBhdGhBbmRTZWFyY2goaW5pdGlhbE5hdmlnYXRpb25TbmFwc2hvdCk7XG5cdGNvbnN0IHJvb3QgPSBkZWNvZGVBcHBFbGVtZW50c1Byb21pc2UoY3JlYXRlRnJvbVJlYWRhYmxlU3RyZWFtKHJlYWN0QnJhbmNoKSkudGhlbigoZWxlbWVudHMpID0+IHtcblx0XHRpZiAoSVNfU1RBVElDX0VYUE9SVCkgY2xpZW50RGVwbG95bWVudFZlcnNpb24gPSBBcHBFbGVtZW50c1dpcmUucmVhZE1ldGFkYXRhKGVsZW1lbnRzKS5hcnRpZmFjdENvbXBhdGliaWxpdHkuZGVwbG95bWVudFZlcnNpb247XG5cdFx0YmluZEFwcEVsZW1lbnRzUmVuZGVyZWRTZWFyY2goZWxlbWVudHMsIGluaXRpYWxOYXZpZ2F0aW9uU25hcHNob3QpO1xuXHRcdGluaXRpYWxQcmVmZXRjaFJvdXRlclN0YXRlID0ge1xuXHRcdFx0cGF0aEFuZFNlYXJjaDogaW5pdGlhbFBhdGhBbmRTZWFyY2gsXG5cdFx0XHRyb3V0ZUlkOiBBcHBFbGVtZW50c1dpcmUucmVhZE1ldGFkYXRhKGVsZW1lbnRzKS5yb3V0ZUlkXG5cdFx0fTtcblx0XHRyZXR1cm4gZWxlbWVudHM7XG5cdH0pO1xuXHRjb25zdCBpbml0aWFsUGFyYW1zID0gaW5pdGlhbE5hdmlnYXRpb25TbmFwc2hvdC5wYXJhbXM7XG5cdGNvbnN0IGluaXRpYWxDYWNoZUJ1ZmZlciA9IG5ldyBSZXNwb25zZShjYWNoZUJyYW5jaCkuYXJyYXlCdWZmZXIoKTtcblx0UHJvbWlzZS5hbGwoW3Jvb3QsIGluaXRpYWxDYWNoZUJ1ZmZlcl0pLnRoZW4oYXN5bmMgKFtlbGVtZW50cywgYnVmZmVyXSkgPT4ge1xuXHRcdGlmIChjYWNoZUdlbmVyYXRpb24gIT09IGNsaWVudE5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24pIHJldHVybjtcblx0XHRjb25zdCBtZXRhZGF0YSA9IEFwcEVsZW1lbnRzV2lyZS5yZWFkTWV0YWRhdGEoZWxlbWVudHMpO1xuXHRcdGlmICghaXNDb21wbGV0ZUFwcFBheWxvYWRNZXRhZGF0YShtZXRhZGF0YSkpIHJldHVybjtcblx0XHRjb25zdCBtb3VudGVkU2xvdHNIZWFkZXIgPSBnZXRNb3VudGVkU2xvdElkc0hlYWRlcihlbGVtZW50cyk7XG5cdFx0Y29uc3QgaGVhZGVycyA9IGNyZWF0ZVJzY1JlcXVlc3RIZWFkZXJzKHsgbW91bnRlZFNsb3RzSGVhZGVyIH0pO1xuXHRcdGNvbnN0IHJzY1VybCA9IGF3YWl0IGNyZWF0ZVJzY1JlcXVlc3RVcmwoaW5pdGlhbFBhdGhBbmRTZWFyY2gsIGhlYWRlcnMpO1xuXHRcdGlmIChjYWNoZUdlbmVyYXRpb24gIT09IGNsaWVudE5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24pIHJldHVybjtcblx0XHRjb25zdCBzbmFwc2hvdCA9IHtcblx0XHRcdGNvbXBhdGliaWxpdHlJZEhlYWRlcjogY2xpZW50UnNjQ29tcGF0aWJpbGl0eUlkLFxuXHRcdFx0YnVmZmVyLFxuXHRcdFx0Y29udGVudFR5cGU6IFZJTkVYVF9SU0NfQ09OVEVOVF9UWVBFLFxuXHRcdFx0Li4uaW5pdGlhbFJzY0Jvb3RzdHJhcD8uZHluYW1pY1N0YWxlVGltZVNlY29uZHMgIT09IHZvaWQgMCA/IHsgZHluYW1pY1N0YWxlVGltZVNlY29uZHM6IGluaXRpYWxSc2NCb290c3RyYXAuZHluYW1pY1N0YWxlVGltZVNlY29uZHMgfSA6IHt9LFxuXHRcdFx0Li4uaW5pdGlhbFJzY0Jvb3RzdHJhcD8uc3RhbGVUaW1lU2Vjb25kcyA9PT0gdm9pZCAwID8ge30gOiB7IHNlcnZlclN0YWxlVGltZToge1xuXHRcdFx0XHRraW5kOiBcInJlc29sdmVkXCIsXG5cdFx0XHRcdHNlY29uZHM6IGluaXRpYWxSc2NCb290c3RyYXAuc3RhbGVUaW1lU2Vjb25kc1xuXHRcdFx0fSB9LFxuXHRcdFx0bW91bnRlZFNsb3RzSGVhZGVyLFxuXHRcdFx0cGFyYW1zSGVhZGVyOiBlbmNvZGVVUklDb21wb25lbnQoSlNPTi5zdHJpbmdpZnkoaW5pdGlhbFBhcmFtcykpLFxuXHRcdFx0cmVuZGVyZWRQYXRoQW5kU2VhcmNoOiBudWxsLFxuXHRcdFx0dXJsOiByc2NVcmxcblx0XHR9O1xuXHRcdGNvbnN0IGZhbGxiYWNrVHRsTXMgPSBpbml0aWFsUnNjQm9vdHN0cmFwPy5pbml0aWFsQ2FjaGVLaW5kID09PSBcInN0YXRpY1wiID8gUFJFRkVUQ0hfQ0FDSEVfVFRMIDogRFlOQU1JQ19OQVZJR0FUSU9OX0NBQ0hFX1RUTDtcblx0XHRoeWRyYXRpb25DYWNoZVB1YmxpY2F0aW9uLnB1Ymxpc2goKCkgPT4ge1xuXHRcdFx0aWYgKGNhY2hlR2VuZXJhdGlvbiAhPT0gY2xpZW50TmF2aWdhdGlvbkNhY2hlR2VuZXJhdGlvbikgcmV0dXJuICgpID0+IHt9O1xuXHRcdFx0cmV0dXJuIHN0b3JlVmlzaXRlZFJlc3BvbnNlU25hcHNob3QocnNjVXJsLCBtZXRhZGF0YS5pbnRlcmNlcHRpb25Db250ZXh0LCBzbmFwc2hvdCwgaW5pdGlhbFBhcmFtcywgZmFsbGJhY2tUdGxNcywgbW91bnRlZFNsb3RzSGVhZGVyLCBlbGVtZW50cywgZmFsc2UsIHNuYXBzaG90LCBpbml0aWFsUnNjQm9vdHN0cmFwPy5pbml0aWFsQ2FjaGVLaW5kID09PSBcInN0YXRpY1wiIHx8IG1ldGFkYXRhLmludGVyY2VwdGlvbkNvbnRleHQgIT09IG51bGwsIHRydWUpO1xuXHRcdH0pO1xuXHR9KS5jYXRjaCgoKSA9PiB7fSk7XG5cdGhpc3RvcnlDb250cm9sbGVyLndyaXRlQm9vdHN0cmFwSGlzdG9yeU1ldGFkYXRhKCk7XG5cdGNvbnN0IHJlcG9ydFVuY2F1Z2h0RXJyb3IgPSBjcmVhdGVPblVuY2F1Z2h0RXJyb3IoeyBjb2VyY2VUb0Vycm9yOiBpbXBvcnQubWV0YS5lbnYuREVWIH0pO1xuXHRjb25zdCBvblVuY2F1Z2h0RXJyb3IgPSAoLi4uYXJncykgPT4ge1xuXHRcdGh5ZHJhdGlvbkNhY2hlUHVibGljYXRpb24uZmFpbCgpO1xuXHRcdHJlcG9ydFVuY2F1Z2h0RXJyb3IoLi4uYXJncyk7XG5cdH07XG5cdGNvbnN0IG9uUmVjb3ZlcmFibGVFcnJvciA9IGNyZWF0ZVByb2RPblJlY292ZXJhYmxlRXJyb3IoKCkgPT4ge1xuXHRcdGh5ZHJhdGlvbkNhY2hlUHVibGljYXRpb24uZmFpbCgpO1xuXHR9KTtcblx0Y29uc3QgaW52YWxpZGF0ZU9uQ2F1Z2h0RXJyb3IgPSAoaGFuZGxlcikgPT4gKCguLi5hcmdzKSA9PiB7XG5cdFx0aHlkcmF0aW9uQ2FjaGVQdWJsaWNhdGlvbi5mYWlsKCk7XG5cdFx0aGFuZGxlciguLi5hcmdzKTtcblx0fSk7XG5cdGNvbnN0IGZvcm1TdGF0ZSA9IGNvbnN1bWVJbml0aWFsRm9ybVN0YXRlKGdldFZpbmV4dEJyb3dzZXJHbG9iYWwoKSk7XG5cdGNvbnN0IGh5ZHJhdGVSb290T3B0aW9ucyA9IGltcG9ydC5tZXRhLmVudi5ERVYgJiYgZGV2RXJyb3JPdmVybGF5ID8gY3JlYXRlVmluZXh0SHlkcmF0ZVJvb3RPcHRpb25zKHtcblx0XHRmb3JtU3RhdGUsXG5cdFx0b25DYXVnaHRFcnJvcjogaW52YWxpZGF0ZU9uQ2F1Z2h0RXJyb3IoY3JlYXRlRGV2T25DYXVnaHRFcnJvcihkZXZFcnJvck92ZXJsYXkuZGV2T25DYXVnaHRFcnJvciwgb25VbmNhdWdodEVycm9yKSksXG5cdFx0b25VbmNhdWdodEVycm9yXG5cdH0pIDogY3JlYXRlVmluZXh0SHlkcmF0ZVJvb3RPcHRpb25zKHtcblx0XHRmb3JtU3RhdGUsXG5cdFx0b25DYXVnaHRFcnJvcjogaW52YWxpZGF0ZU9uQ2F1Z2h0RXJyb3IoY3JlYXRlUHJvZE9uQ2F1Z2h0RXJyb3Iob25VbmNhdWdodEVycm9yKSksXG5cdFx0b25SZWNvdmVyYWJsZUVycm9yLFxuXHRcdG9uVW5jYXVnaHRFcnJvclxuXHR9KTtcblx0Y29uc3QgY2hpbGRyZW4gPSBjcmVhdGVFbGVtZW50KEJyb3dzZXJSb290LCB7XG5cdFx0aHlkcmF0aW9uQ2FjaGVQdWJsaWNhdGlvbixcblx0XHRpbml0aWFsRWxlbWVudHM6IHJvb3QsXG5cdFx0aW5pdGlhbE5hdmlnYXRpb25TbmFwc2hvdFxuXHR9KTtcblx0Y29uc3QgZXJyb3JTaGVsbFN0eWxlcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJzdHlsZVtkYXRhLXZpbmV4dC1lcnJvci1zaGVsbC1zdHlsZV1cIik7XG5cdGlmIChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuaWQgPT09IFwiX19uZXh0X2Vycm9yX19cIikge1xuXHRcdGNvbnN0IHsgZm9ybVN0YXRlOiBfaW5lcnRGb3JtU3RhdGUsIC4uLmNyZWF0ZVJvb3RPcHRpb25zIH0gPSBoeWRyYXRlUm9vdE9wdGlvbnM7XG5cdFx0Zm9yIChjb25zdCBzdHlsZSBvZiBlcnJvclNoZWxsU3R5bGVzKSBzdHlsZS5yZW1vdmUoKTtcblx0XHRzdGFydFRyYW5zaXRpb24oKCkgPT4ge1xuXHRcdFx0Y29uc3QgY2xpZW50Um9vdCA9IGNyZWF0ZVJvb3QoZG9jdW1lbnQsIGNyZWF0ZVJvb3RPcHRpb25zKTtcblx0XHRcdGNsaWVudFJvb3QucmVuZGVyKGltcG9ydC5tZXRhLmVudi5ERVYgJiYgZGV2RXJyb3JPdmVybGF5ID8gY3JlYXRlRWxlbWVudChGcmFnbWVudCwgbnVsbCwgY2hpbGRyZW4sIGNyZWF0ZUVsZW1lbnQoUmVwbGF5SW5pdGlhbERldlNlcnZlckVycm9ycywgeyByZXBvcnQ6IGRldkVycm9yT3ZlcmxheS5yZXBvcnRJbml0aWFsRGV2U2VydmVyRXJyb3JzIH0pKSA6IGNoaWxkcmVuKTtcblx0XHRcdHdpbmRvdy5fX1ZJTkVYVF9SU0NfUk9PVF9fID0gY2xpZW50Um9vdDtcblx0XHR9KTtcblx0fSBlbHNlIHdpbmRvdy5fX1ZJTkVYVF9SU0NfUk9PVF9fID0gaHlkcmF0ZVJvb3RJblRyYW5zaXRpb24oe1xuXHRcdGNoaWxkcmVuLFxuXHRcdGNvbnRhaW5lcjogZG9jdW1lbnQsXG5cdFx0aHlkcmF0ZVJvb3QsXG5cdFx0b3B0aW9uczogaHlkcmF0ZVJvb3RPcHRpb25zLFxuXHRcdHN0YXJ0VHJhbnNpdGlvblxuXHR9KTtcblx0bWFya0luaXRpYWxBcHBSb3V0ZXJCb290c3RyYXBIeWRyYXRlZCgpO1xuXHRjb25zdCBuYXZpZ2F0aW9uQWJvcnRDb29yZGluYXRvciA9IGNyZWF0ZUFwcEJyb3dzZXJOYXZpZ2F0aW9uQWJvcnRDb29yZGluYXRvcigpO1xuXHRyZWdpc3Rlck5hdmlnYXRpb25SdW50aW1lRnVuY3Rpb25zKHtcblx0XHRjbGVhck5hdmlnYXRpb25DYWNoZXM6IGNsZWFyQ2xpZW50TmF2aWdhdGlvbkNhY2hlcyxcblx0XHRjb21taXRIYXNoTmF2aWdhdGlvbjogKGhyZWYsIGhpc3RvcnlVcGRhdGVNb2RlLCBzY3JvbGwpID0+IGhpc3RvcnlDb250cm9sbGVyLmNvbW1pdEhhc2hPbmx5TmF2aWdhdGlvbihocmVmLCBoaXN0b3J5VXBkYXRlTW9kZSwgc2Nyb2xsKSxcblx0XHRnZXRQcmVmZXRjaFJvdXRlclN0YXRlOiAoKSA9PiB7XG5cdFx0XHRpZiAoIWJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5oYXNCcm93c2VyUm91dGVyU3RhdGUoKSkgcmV0dXJuIGluaXRpYWxQcmVmZXRjaFJvdXRlclN0YXRlO1xuXHRcdFx0Y29uc3Qgc3RhdGUgPSBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuZ2V0QnJvd3NlclJvdXRlclN0YXRlKCk7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRwYXRoQW5kU2VhcmNoOiBjcmVhdGVTbmFwc2hvdFBhdGhBbmRTZWFyY2goc3RhdGUubmF2aWdhdGlvblNuYXBzaG90KSxcblx0XHRcdFx0cm91dGVJZDogc3RhdGUucm91dGVJZFxuXHRcdFx0fTtcblx0XHR9LFxuXHRcdG5hdmlnYXRlOiBhc3luYyBmdW5jdGlvbiBuYXZpZ2F0ZVJzYyhocmVmLCByZWRpcmVjdERlcHRoID0gMCwgbmF2aWdhdGlvbktpbmQgPSBcIm5hdmlnYXRlXCIsIGhpc3RvcnlVcGRhdGVNb2RlLCBwcmV2aW91c05leHRVcmxPdmVycmlkZSwgcHJvZ3JhbW1hdGljVHJhbnNpdGlvbiA9IGZhbHNlLCB0cmF2ZXJzYWxJbnRlbnQsIHNjcm9sbEludGVudCwgdmlzaWJsZUNvbW1pdE1vZGUgPSBcInRyYW5zaXRpb25cIiwgaW5pdGlhbEJ5cGFzc05hdmlnYXRpb25DYWNoZSkge1xuXHRcdFx0c2VydmVyQWN0aW9uU3VwcGxlbWVudGFsUmVmcmVzaENvb3JkaW5hdG9yLmFib3J0QWxsKCk7XG5cdFx0XHRjb25zdCBuYXZpZ2F0aW9uQWJvcnRIYW5kbGUgPSBuYXZpZ2F0aW9uQWJvcnRDb29yZGluYXRvci5iZWdpbigpO1xuXHRcdFx0bGV0IHBlbmRpbmdSb3V0ZXJTdGF0ZSA9IG51bGw7XG5cdFx0XHRjb25zdCBuYXZJZCA9IGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5iZWdpbk5hdmlnYXRpb24oKTtcblx0XHRcdGNvbnN0IG5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24gPSBjbGllbnROYXZpZ2F0aW9uQ2FjaGVHZW5lcmF0aW9uO1xuXHRcdFx0ZGlzY2FyZGVkU2VydmVyQWN0aW9uUmVmcmVzaFNjaGVkdWxlci5tYXJrTmF2aWdhdGlvblN0YXJ0KCk7XG5cdFx0XHRsZXQgY3VycmVudEhyZWYgPSBocmVmO1xuXHRcdFx0bGV0IGN1cnJlbnRIaXN0b3J5TW9kZSA9IGhpc3RvcnlVcGRhdGVNb2RlO1xuXHRcdFx0bGV0IGN1cnJlbnRQcmV2TmV4dFVybCA9IHByZXZpb3VzTmV4dFVybE92ZXJyaWRlO1xuXHRcdFx0bGV0IHJlZGlyZWN0Q291bnQgPSByZWRpcmVjdERlcHRoO1xuXHRcdFx0bGV0IGRldGFjaGVkTmF2aWdhdGlvbkNvbW1pdHMgPSBmYWxzZTtcblx0XHRcdGxldCBvcHRpbWlzdGljU2hlbGxFbGVtZW50cyA9IG51bGw7XG5cdFx0XHRjb25zdCBrZWVwT3B0aW1pc3RpY1NoZWxsTWV0YWRhdGEgPSAocGF5bG9hZCkgPT4ge1xuXHRcdFx0XHRjb25zdCBzaGVsbEVsZW1lbnRzID0gb3B0aW1pc3RpY1NoZWxsRWxlbWVudHM7XG5cdFx0XHRcdGlmIChzaGVsbEVsZW1lbnRzID09PSBudWxsKSByZXR1cm4gcGF5bG9hZDtcblx0XHRcdFx0cmV0dXJuIHBheWxvYWQgaW5zdGFuY2VvZiBQcm9taXNlID8gcGF5bG9hZC50aGVuKChlbGVtZW50cykgPT4ga2VlcE9wdGltaXN0aWNTdHJlYW1pbmdNZXRhZGF0YShlbGVtZW50cywgc2hlbGxFbGVtZW50cywgU3RyaW5nKG5hdklkKSkpIDoga2VlcE9wdGltaXN0aWNTdHJlYW1pbmdNZXRhZGF0YShwYXlsb2FkLCBzaGVsbEVsZW1lbnRzLCBTdHJpbmcobmF2SWQpKTtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBhY3RpdmVUcmF2ZXJzYWxJbnRlbnQgPSBuYXZpZ2F0aW9uS2luZCA9PT0gXCJ0cmF2ZXJzZVwiID8gdHJhdmVyc2FsSW50ZW50ID8/IGhpc3RvcnlDb250cm9sbGVyLnJlc29sdmVUcmF2ZXJzYWxJbnRlbnQod2luZG93Lmhpc3Rvcnkuc3RhdGUpIDogbnVsbDtcblx0XHRcdGxldCBzdGFydGVkSGFyZE5hdmlnYXRpb24gPSBmYWxzZTtcblx0XHRcdGNvbnN0IHBlcmZvcm1IYXJkTmF2aWdhdGlvbkZvclNjcm9sbEludGVudCA9ICh0YXJnZXRIcmVmLCBtb2RlKSA9PiB7XG5cdFx0XHRcdGNvbnN1bWVBcHBSb3V0ZXJTY3JvbGxJbnRlbnQoc2Nyb2xsSW50ZW50ID8/IG51bGwpO1xuXHRcdFx0XHRjb25zdCBkaWROYXZpZ2F0ZSA9IGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5wZXJmb3JtSGFyZE5hdmlnYXRpb24odGFyZ2V0SHJlZiwgbW9kZSA/PyAoY3VycmVudEhpc3RvcnlNb2RlID09PSBcInB1c2hcIiA/IFwiYXNzaWduXCIgOiBcInJlcGxhY2VcIikpO1xuXHRcdFx0XHRpZiAoZGlkTmF2aWdhdGUpIHtcblx0XHRcdFx0XHRzdGFydGVkSGFyZE5hdmlnYXRpb24gPSB0cnVlO1xuXHRcdFx0XHRcdGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5hYmFuZG9uUGVuZGluZ0Jyb3dzZXJSb3V0ZXJTdGF0ZShwZW5kaW5nUm91dGVyU3RhdGUpO1xuXHRcdFx0XHR9IGVsc2UgY2xlYXJBcHBOYXZpZ2F0aW9uRmFpbHVyZVRhcmdldCh0YXJnZXRIcmVmKTtcblx0XHRcdFx0cmV0dXJuIGRpZE5hdmlnYXRlO1xuXHRcdFx0fTtcblx0XHRcdGxldCByZXN0b3JlZEJmY2FjaGVJZHMgPSBuYXZpZ2F0aW9uS2luZCA9PT0gXCJ0cmF2ZXJzZVwiID8gaGlzdG9yeUNvbnRyb2xsZXIucmVhZEN1cnJlbnRCZmNhY2hlVmVyc2lvbkhpc3RvcnlJZHMoYWN0aXZlVHJhdmVyc2FsSW50ZW50Py5oaXN0b3J5U3RhdGUgPz8gd2luZG93Lmhpc3Rvcnkuc3RhdGUpIDogbnVsbDtcblx0XHRcdGNvbnN0IHJldXNlQ3VycmVudEJmY2FjaGVJZHMgPSBuYXZpZ2F0aW9uS2luZCAhPT0gXCJ0cmF2ZXJzZVwiIHx8ICFoaXN0b3J5Q29udHJvbGxlci5pc0NhY2hlSW52YWxpZGF0aW9uR3VhcmRlZCgpICYmIGhpc3RvcnlDb250cm9sbGVyLmlzQ3VycmVudEJmY2FjaGVWZXJzaW9uKGFjdGl2ZVRyYXZlcnNhbEludGVudD8uaGlzdG9yeVN0YXRlID8/IHdpbmRvdy5oaXN0b3J5LnN0YXRlKTtcblx0XHRcdGNvbnN0IHJlbGVhc2VOYXZpZ2F0aW9uSW5GbGlnaHQgPSB0cmFja0FwcFJvdXRlck5hdmlnYXRpb25JbkZsaWdodCgpO1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3Qgc2hvdWxkVXNlUGVuZGluZ1JvdXRlclN0YXRlID0gcHJvZ3JhbW1hdGljVHJhbnNpdGlvbjtcblx0XHRcdFx0aWYgKGhhc0Jyb3dzZXJSb3V0ZXJTdGF0ZSgpKSB7XG5cdFx0XHRcdFx0aWYgKHNob3VsZFVzZVBlbmRpbmdSb3V0ZXJTdGF0ZSkgcGVuZGluZ1JvdXRlclN0YXRlID0gYmVnaW5QZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlKCk7XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0YXdhaXQgd2FpdEZvckJyb3dzZXJSb3V0ZXJTdGF0ZVJlYWR5KCk7XG5cdFx0XHRcdFx0aWYgKCFicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbihuYXZJZCkpIHJldHVybjtcblx0XHRcdFx0XHRpZiAoc2hvdWxkVXNlUGVuZGluZ1JvdXRlclN0YXRlKSBwZW5kaW5nUm91dGVyU3RhdGUgPSBiZWdpblBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCByb3V0ZU1hbmlmZXN0TG9hZCA9IGxvYWROYXZpZ2F0aW9uUnVudGltZVJvdXRlTWFuaWZlc3QoKTtcblx0XHRcdFx0aWYgKHJvdXRlTWFuaWZlc3RMb2FkICE9PSBudWxsKSB7XG5cdFx0XHRcdFx0Y29uc3Qgcm91dGVNYW5pZmVzdExvYWRlZCA9IGF3YWl0IHJvdXRlTWFuaWZlc3RMb2FkO1xuXHRcdFx0XHRcdGlmICghYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmlzQ3VycmVudE5hdmlnYXRpb24obmF2SWQpKSByZXR1cm47XG5cdFx0XHRcdFx0aWYgKCFyb3V0ZU1hbmlmZXN0TG9hZGVkKSB7XG5cdFx0XHRcdFx0XHRwZXJmb3JtSGFyZE5hdmlnYXRpb25Gb3JTY3JvbGxJbnRlbnQoY3VycmVudEhyZWYpO1xuXHRcdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCBuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlID0gZ2V0QnJvd3NlclJvdXRlclN0YXRlKCk7XG5cdFx0XHRcdGNvbnN0IG1vdW50ZWRTbG90c0hlYWRlciA9IGdldE1vdW50ZWRTbG90SWRzSGVhZGVyKG5hdmlnYXRpb25Jbml0aWF0aW9uU3RhdGUuZWxlbWVudHMpO1xuXHRcdFx0XHRsZXQgbW91bnRlZExheW91dHNIZWFkZXIgPSBuYXZpZ2F0aW9uS2luZCA9PT0gXCJuYXZpZ2F0ZVwiID8gY3JlYXRlTW91bnRlZExheW91dHNIZWFkZXIobmF2aWdhdGlvbkluaXRpYXRpb25TdGF0ZS5lbGVtZW50cywgbmF2aWdhdGlvbkluaXRpYXRpb25TdGF0ZS5sYXlvdXRJZHMpIDogbnVsbDtcblx0XHRcdFx0d2hpbGUgKHRydWUpIHtcblx0XHRcdFx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKGN1cnJlbnRIcmVmLCB3aW5kb3cubG9jYXRpb24ub3JpZ2luKTtcblx0XHRcdFx0XHRjb25zdCByZXF1ZXN0U3RhdGUgPSBnZXRSZXF1ZXN0U3RhdGUobmF2aWdhdGlvbktpbmQsIHVybC5wYXRobmFtZSwgY3VycmVudFByZXZOZXh0VXJsLCBhY3RpdmVUcmF2ZXJzYWxJbnRlbnQ/Lmhpc3RvcnlTdGF0ZSk7XG5cdFx0XHRcdFx0Y29uc3QgcmVxdWVzdEludGVyY2VwdGlvbkNvbnRleHQgPSByZXF1ZXN0U3RhdGUuaW50ZXJjZXB0aW9uQ29udGV4dDtcblx0XHRcdFx0XHRjb25zdCByZXF1ZXN0UHJldmlvdXNOZXh0VXJsID0gcmVxdWVzdFN0YXRlLnByZXZpb3VzTmV4dFVybDtcblx0XHRcdFx0XHRjb25zdCBzaG91bGRTdXBwbGVtZW50VmlzaWJsZUJyYW5jaGVzID0gbmF2aWdhdGlvbktpbmQgPT09IFwicmVmcmVzaFwiIHx8IG5hdmlnYXRpb25LaW5kID09PSBcInRyYXZlcnNlXCIgJiYgIXJldXNlQ3VycmVudEJmY2FjaGVJZHM7XG5cdFx0XHRcdFx0Y29uc3QgcGVyc2lzdGVkUmVmcmVzaEludGVyY2VwdGlvbnMgPSBuYXZpZ2F0aW9uS2luZCA9PT0gXCJyZWZyZXNoXCIgPyByZXNvbHZlUGVyc2lzdGVkUmVmcmVzaEludGVyY2VwdGlvbnMobmF2aWdhdGlvbkluaXRpYXRpb25TdGF0ZSwgZ2V0QnJvd3NlclJvdXRlTWFuaWZlc3QoKSwgdXJsLCByZXF1ZXN0SW50ZXJjZXB0aW9uQ29udGV4dCkgOiBbXTtcblx0XHRcdFx0XHRjb25zdCBwZXJzaXN0ZWRTb3VyY2VQYWdlUmVmcmVzaGVzID0gc2hvdWxkU3VwcGxlbWVudFZpc2libGVCcmFuY2hlcyA/IHJlc29sdmVQZXJzaXN0ZWRTb3VyY2VQYWdlUmVmcmVzaGVzKHtcblx0XHRcdFx0XHRcdGFjdGl2ZVJvdXRlUGF0aHM6IG5hdmlnYXRpb25LaW5kID09PSBcInRyYXZlcnNlXCIgPyByZWFkSGlzdG9yeVN0YXRlQWN0aXZlUm91dGVQYXRocyhhY3RpdmVUcmF2ZXJzYWxJbnRlbnQ/Lmhpc3RvcnlTdGF0ZSkgPz8gW10gOiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRiYXNlUGF0aDogX19iYXNlUGF0aCxcblx0XHRcdFx0XHRcdHJlZnJlc2hVcmw6IHVybCxcblx0XHRcdFx0XHRcdHN0YXRlOiBuYXZpZ2F0aW9uS2luZCA9PT0gXCJ0cmF2ZXJzZVwiID8ge1xuXHRcdFx0XHRcdFx0XHRwcmV2aW91c05leHRVcmw6IHJlcXVlc3RQcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdFx0XHRcdHNsb3RCaW5kaW5nczogW11cblx0XHRcdFx0XHRcdH0gOiBuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlXG5cdFx0XHRcdFx0fSkuZmlsdGVyKChzb3VyY2VQYXRoQW5kU2VhcmNoKSA9PiB7XG5cdFx0XHRcdFx0XHRpZiAocGVyc2lzdGVkUmVmcmVzaEludGVyY2VwdGlvbnMuc29tZSgoaW50ZXJjZXB0aW9uKSA9PiBpbnRlcmNlcHRpb24udGFyZ2V0UGF0aG5hbWUgPT09IHNvdXJjZVBhdGhBbmRTZWFyY2gpKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdFx0XHR9KSA6IFtdO1xuXHRcdFx0XHRcdGNvbnN0IGhhc1N1cHBsZW1lbnRhbFJlZnJlc2ggPSBwZXJzaXN0ZWRSZWZyZXNoSW50ZXJjZXB0aW9ucy5sZW5ndGggPiAwIHx8IHBlcnNpc3RlZFNvdXJjZVBhZ2VSZWZyZXNoZXMubGVuZ3RoID4gMDtcblx0XHRcdFx0XHRpZiAobmF2aWdhdGlvbktpbmQgPT09IFwicmVmcmVzaFwiKSBoaXN0b3J5Q29udHJvbGxlci5zeW5jQ3VycmVudEhpc3RvcnlTdGF0ZVByZXZpb3VzTmV4dFVybChyZXF1ZXN0UHJldmlvdXNOZXh0VXJsLCBnZXRCcm93c2VyUm91dGVyU3RhdGUoKS5iZmNhY2hlSWRzLCByZXNvbHZlQWN0aXZlUm91dGVQYXRocyhnZXRCcm93c2VyUm91dGVyU3RhdGUoKS5zbG90QmluZGluZ3MpKTtcblx0XHRcdFx0XHRzZXRQZW5kaW5nUGF0aG5hbWUodXJsLnBhdGhuYW1lLCBuYXZJZCk7XG5cdFx0XHRcdFx0Y29uc3QgdXNlc0luaXRpYWxOYXZpZ2F0aW9uQ2FjaGVQb2xpY3kgPSBuYXZpZ2F0aW9uS2luZCA9PT0gXCJuYXZpZ2F0ZVwiICYmIGN1cnJlbnRIcmVmID09PSBocmVmICYmIHJlZGlyZWN0Q291bnQgPT09IHJlZGlyZWN0RGVwdGggJiYgaW5pdGlhbEJ5cGFzc05hdmlnYXRpb25DYWNoZSAhPT0gdm9pZCAwO1xuXHRcdFx0XHRcdGNvbnN0IGVhcmx5SW50ZW50RGVjaXNpb24gPSBuYXZpZ2F0aW9uS2luZCA9PT0gXCJuYXZpZ2F0ZVwiICYmICF1c2VzSW5pdGlhbE5hdmlnYXRpb25DYWNoZVBvbGljeSA/IG5hdmlnYXRpb25QbGFubmVyLmNsYXNzaWZ5RWFybHlOYXZpZ2F0aW9uSW50ZW50KHtcblx0XHRcdFx0XHRcdGJhc2VQYXRoOiBfX2Jhc2VQYXRoLFxuXHRcdFx0XHRcdFx0Y3VycmVudFVybFNwYWNlOiBcImFwcFJlbGF0aXZlU25hcHNob3RcIixcblx0XHRcdFx0XHRcdGN1cnJlbnRIcmVmOiBjbGllbnROYXZpZ2F0aW9uU25hcHNob3RIcmVmKG5hdmlnYXRpb25Jbml0aWF0aW9uU3RhdGUubmF2aWdhdGlvblNuYXBzaG90KSxcblx0XHRcdFx0XHRcdG1vZGU6IFwicHVzaFwiLFxuXHRcdFx0XHRcdFx0c2Nyb2xsOiBmYWxzZSxcblx0XHRcdFx0XHRcdHRhcmdldEhyZWY6IHVybC5ocmVmXG5cdFx0XHRcdFx0fSkgOiBudWxsO1xuXHRcdFx0XHRcdGNvbnN0IHNob3VsZEJ5cGFzc05hdmlnYXRpb25DYWNoZSA9IHVzZXNJbml0aWFsTmF2aWdhdGlvbkNhY2hlUG9saWN5ID8gaW5pdGlhbEJ5cGFzc05hdmlnYXRpb25DYWNoZSA6IGVhcmx5SW50ZW50RGVjaXNpb24/LmtpbmQgPT09IFwiZmxpZ2h0TmF2aWdhdGlvblwiICYmIGVhcmx5SW50ZW50RGVjaXNpb24uYnlwYXNzTmF2aWdhdGlvbkNhY2hlO1xuXHRcdFx0XHRcdGNvbnN0IHJlcXVlc3RIZWFkZXJzID0gY3JlYXRlUnNjUmVxdWVzdEhlYWRlcnMoe1xuXHRcdFx0XHRcdFx0ZmV0Y2hQcmlvcml0eTogXCJhdXRvXCIsXG5cdFx0XHRcdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiByZXF1ZXN0SW50ZXJjZXB0aW9uQ29udGV4dCxcblx0XHRcdFx0XHRcdG1vdW50ZWRTbG90c0hlYWRlcixcblx0XHRcdFx0XHRcdHJvdXRlclN0YXRlOiB7XG5cdFx0XHRcdFx0XHRcdHBhdGhBbmRTZWFyY2g6IGNyZWF0ZVNuYXBzaG90UGF0aEFuZFNlYXJjaChuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdCksXG5cdFx0XHRcdFx0XHRcdHJvdXRlSWQ6IG5hdmlnYXRpb25Jbml0aWF0aW9uU3RhdGUucm91dGVJZFxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGNvbnN0IHJld3JpdHRlbk5hdmlnYXRpb25IcmVmID0gbmF2aWdhdGlvbktpbmQgPT09IFwibmF2aWdhdGVcIiAmJiBIQVNfQ0xJRU5UX1JFV1JJVEVTID8gcmVzb2x2ZUxvYWRlZEh5YnJpZENsaWVudFJld3JpdGVIcmVmKGN1cnJlbnRIcmVmLCBfX2Jhc2VQYXRoKSA6IG51bGw7XG5cdFx0XHRcdFx0Y29uc3QgdGFyZ2V0UGF0aEFuZFNlYXJjaCA9IGZvcm1hdFJzY1JlcXVlc3RQYXRoKHVybCk7XG5cdFx0XHRcdFx0Y29uc3QgYWRkaXRpb25hbFByZWZldGNoUGF0aEFuZFNlYXJjaCA9IHJld3JpdHRlbk5hdmlnYXRpb25IcmVmICYmIHJld3JpdHRlbk5hdmlnYXRpb25IcmVmICE9PSBjdXJyZW50SHJlZiA/IFtyZXdyaXR0ZW5OYXZpZ2F0aW9uSHJlZl0gOiBbXTtcblx0XHRcdFx0XHRjb25zdCBzZXR0bGVkUHJlZmV0Y2hlZFJlc3BvbnNlID0gcGVla1NldHRsZWRQcmVmZXRjaFJlc3BvbnNlRm9yTmF2aWdhdGlvbih7XG5cdFx0XHRcdFx0XHRhZGRpdGlvbmFsUnNjVXJsczogYWRkaXRpb25hbFByZWZldGNoUGF0aEFuZFNlYXJjaCxcblx0XHRcdFx0XHRcdGJ5cGFzc05hdmlnYXRpb25DYWNoZTogc2hvdWxkQnlwYXNzTmF2aWdhdGlvbkNhY2hlLFxuXHRcdFx0XHRcdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogcmVxdWVzdEludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0XHRcdFx0XHRtb3VudGVkU2xvdHNIZWFkZXIsXG5cdFx0XHRcdFx0XHRuYXZpZ2F0aW9uS2luZCxcblx0XHRcdFx0XHRcdHRhcmdldFBhdGhBbmRTZWFyY2hcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRjb25zdCByc2NVcmwgPSBzZXR0bGVkUHJlZmV0Y2hlZFJlc3BvbnNlID8gcmVzb2x2ZVByZWZldGNoTmF2aWdhdGlvblJlc3BvbnNlVXJsKHtcblx0XHRcdFx0XHRcdGFkZGl0aW9uYWxSc2NVcmxzOiBhZGRpdGlvbmFsUHJlZmV0Y2hQYXRoQW5kU2VhcmNoLFxuXHRcdFx0XHRcdFx0b3JpZ2luOiB3aW5kb3cubG9jYXRpb24ub3JpZ2luLFxuXHRcdFx0XHRcdFx0cmVzcG9uc2VVcmw6IHNldHRsZWRQcmVmZXRjaGVkUmVzcG9uc2UudXJsLFxuXHRcdFx0XHRcdFx0dmlzaWJsZVJzY1VybDogdGFyZ2V0UGF0aEFuZFNlYXJjaFxuXHRcdFx0XHRcdH0pIDogYXdhaXQgY3JlYXRlUnNjUmVxdWVzdFVybCh0YXJnZXRQYXRoQW5kU2VhcmNoLCByZXF1ZXN0SGVhZGVycyk7XG5cdFx0XHRcdFx0Y29uc3QgYWRkaXRpb25hbFByZWZldGNoUnNjVXJscyA9IHNldHRsZWRQcmVmZXRjaGVkUmVzcG9uc2UgPyBhZGRpdGlvbmFsUHJlZmV0Y2hQYXRoQW5kU2VhcmNoIDogYXdhaXQgUHJvbWlzZS5hbGwoYWRkaXRpb25hbFByZWZldGNoUGF0aEFuZFNlYXJjaC5tYXAoKGhyZWYpID0+IGNyZWF0ZVJzY1JlcXVlc3RVcmwoaHJlZiwgcmVxdWVzdEhlYWRlcnMpKSk7XG5cdFx0XHRcdFx0Y29uc3QgdmlzaXRlZFJlc3BvbnNlQ2FuZGlkYXRlID0gc2hvdWxkQnlwYXNzTmF2aWdhdGlvbkNhY2hlID8ge1xuXHRcdFx0XHRcdFx0Y2FjaGVLZXk6IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIHJlcXVlc3RJbnRlcmNlcHRpb25Db250ZXh0KSxcblx0XHRcdFx0XHRcdGVudHJ5OiBudWxsLFxuXHRcdFx0XHRcdFx0ZmFjdHM6IHtcblx0XHRcdFx0XHRcdFx0Y2FuZGlkYXRlOiBcIm1pc3NpbmdcIixcblx0XHRcdFx0XHRcdFx0bmF2aWdhdGlvbktpbmRcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9IDogcmVhZFZpc2l0ZWRSZXNwb25zZUNhY2hlQ2FuZGlkYXRlKHJzY1VybCwgcmVxdWVzdEludGVyY2VwdGlvbkNvbnRleHQsIG1vdW50ZWRTbG90c0hlYWRlciwgbmF2aWdhdGlvbktpbmQpO1xuXHRcdFx0XHRcdGNvbnN0IGNhY2hlZFJvdXRlID0gYXBwbHlWaXNpdGVkUmVzcG9uc2VDYWNoZUNhbmRpZGF0ZURlY2lzaW9uKHZpc2l0ZWRSZXNwb25zZUNhbmRpZGF0ZSwgbmF2aWdhdGlvblBsYW5uZXIuY2xhc3NpZnlWaXNpdGVkUmVzcG9uc2VDYWNoZUNhbmRpZGF0ZSh2aXNpdGVkUmVzcG9uc2VDYW5kaWRhdGUuZmFjdHMpKTtcblx0XHRcdFx0XHRjb25zdCB2aXNpdGVkUmVzcG9uc2UgPSBjYWNoZWRSb3V0ZSA9PT0gbnVsbCA/IHsgc3RhdHVzOiBcInVuYXZhaWxhYmxlXCIgfSA6IHsgc3RhdHVzOiBcImF2YWlsYWJsZVwiIH07XG5cdFx0XHRcdFx0Y29uc3QgcHJlZmV0Y2hQcm9iZURlY2lzaW9uID0gbmF2aWdhdGlvblBsYW5uZXIuY2xhc3NpZnlOYXZpZ2F0aW9uUHJlZmV0Y2hQcm9iZSh7XG5cdFx0XHRcdFx0XHRieXBhc3NOYXZpZ2F0aW9uQ2FjaGU6IHNob3VsZEJ5cGFzc05hdmlnYXRpb25DYWNoZSxcblx0XHRcdFx0XHRcdG5hdmlnYXRpb25LaW5kLFxuXHRcdFx0XHRcdFx0dmlzaXRlZFJlc3BvbnNlXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0bGV0IHJvdXRlTWFuaWZlc3QgPSBuYXZpZ2F0aW9uS2luZCA9PT0gXCJuYXZpZ2F0ZVwiID8gZ2V0QnJvd3NlclJvdXRlTWFuaWZlc3QoKSA6IG51bGw7XG5cdFx0XHRcdFx0Y29uc3QgaGFzUHJlZmV0Y2hDYW5kaWRhdGUgPSBzZXR0bGVkUHJlZmV0Y2hlZFJlc3BvbnNlICE9PSBudWxsIHx8IHByZWZldGNoUHJvYmVEZWNpc2lvbi5raW5kID09PSBcInByb2JlXCIgJiYgaGFzUHJlZmV0Y2hDYWNoZUVudHJ5Rm9yTmF2aWdhdGlvbihyc2NVcmwsIHJlcXVlc3RJbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIsIHtcblx0XHRcdFx0XHRcdGFkZGl0aW9uYWxSc2NVcmxzOiBhZGRpdGlvbmFsUHJlZmV0Y2hSc2NVcmxzLFxuXHRcdFx0XHRcdFx0bm90aWZ5SW52YWxpZGF0aW9uOiBmYWxzZVxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGNvbnN0IHJldXNlRGVjaXNpb24gPSBuYXZpZ2F0aW9uUGxhbm5lci5jbGFzc2lmeU5hdmlnYXRpb25SZXVzZSh7XG5cdFx0XHRcdFx0XHRieXBhc3NOYXZpZ2F0aW9uQ2FjaGU6IHNob3VsZEJ5cGFzc05hdmlnYXRpb25DYWNoZSxcblx0XHRcdFx0XHRcdG5hdmlnYXRpb25LaW5kLFxuXHRcdFx0XHRcdFx0b3B0aW1pc3RpY1JvdXRlU2hlbGw6IHJvdXRlTWFuaWZlc3QgPT09IG51bGwgPyB7XG5cdFx0XHRcdFx0XHRcdHJlYXNvbjogXCJyb3V0ZU1hbmlmZXN0TWlzc2luZ1wiLFxuXHRcdFx0XHRcdFx0XHRzdGF0dXM6IFwidW5hdmFpbGFibGVcIlxuXHRcdFx0XHRcdFx0fSA6IHsgc3RhdHVzOiBcImF2YWlsYWJsZVwiIH0sXG5cdFx0XHRcdFx0XHRwcmVmZXRjaDogaGFzUHJlZmV0Y2hDYW5kaWRhdGUgPyB7IHN0YXR1czogXCJhdmFpbGFibGVcIiB9IDogeyBzdGF0dXM6IFwidW5hdmFpbGFibGVcIiB9LFxuXHRcdFx0XHRcdFx0dGFyZ2V0SHJlZjogY3VycmVudEhyZWYsXG5cdFx0XHRcdFx0XHR2aXNpdGVkUmVzcG9uc2Vcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRpZiAocmV1c2VEZWNpc2lvbi5raW5kID09PSBcInJldXNlVmlzaXRlZFJlc3BvbnNlXCIgJiYgY2FjaGVkUm91dGUpIHtcblx0XHRcdFx0XHRcdGNvbnN0IGNhY2hlZEZldGNoRGVjaXNpb24gPSBuYXZpZ2F0aW9uUGxhbm5lci5jbGFzc2lmeVJzY0ZldGNoUmVzdWx0KHtcblx0XHRcdFx0XHRcdFx0Y2xpZW50Q29tcGF0aWJpbGl0eUlkOiBjbGllbnRSc2NDb21wYXRpYmlsaXR5SWQsXG5cdFx0XHRcdFx0XHRcdGNvbXBhdGliaWxpdHlJZEhlYWRlcjogY2FjaGVkUm91dGUucmVzcG9uc2UuY29tcGF0aWJpbGl0eUlkSGVhZGVyID8/IG51bGwsXG5cdFx0XHRcdFx0XHRcdGN1cnJlbnRIcmVmLFxuXHRcdFx0XHRcdFx0XHRlZmZlY3RpdmVIaXN0b3J5VXBkYXRlTW9kZTogY3VycmVudEhpc3RvcnlNb2RlID8/IFwicmVwbGFjZVwiLFxuXHRcdFx0XHRcdFx0XHRoYXNCb2R5OiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRpc1JzY0NvbnRlbnRUeXBlOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRvcmlnaW46IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4sXG5cdFx0XHRcdFx0XHRcdHJlZGlyZWN0RGVwdGg6IHJlZGlyZWN0Q291bnQsXG5cdFx0XHRcdFx0XHRcdHJlcXVlc3RQcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdFx0XHRcdHJlc3BvbnNlT2s6IHRydWUsXG5cdFx0XHRcdFx0XHRcdHJlc3BvbnNlVXJsOiBJU19TVEFUSUNfRVhQT1JUID8gY3VycmVudEhyZWYgOiBjYWNoZWRSb3V0ZS5yZXNwb25zZS51cmwsXG5cdFx0XHRcdFx0XHRcdHNvdXJjZTogXCJjYWNoZWRcIixcblx0XHRcdFx0XHRcdFx0c3RyZWFtZWRSZWRpcmVjdFRhcmdldDogbnVsbFxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHRpZiAoY2FjaGVkRmV0Y2hEZWNpc2lvbi5raW5kID09PSBcImhhcmROYXZpZ2F0ZVwiKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChjYWNoZWRGZXRjaERlY2lzaW9uLnJlYXNvbiA9PT0gXCJyZWRpcmVjdERlcHRoRXhoYXVzdGVkXCIpIGNvbnNvbGUuZXJyb3IoXCJbdmluZXh0XSBUb28gbWFueSBSU0MgcmVkaXJlY3RzIOKAlCBhYm9ydGluZyBuYXZpZ2F0aW9uIHRvIHByZXZlbnQgaW5maW5pdGUgbG9vcC5cIik7XG5cdFx0XHRcdFx0XHRcdHBlcmZvcm1IYXJkTmF2aWdhdGlvbkZvclNjcm9sbEludGVudChjYWNoZWRGZXRjaERlY2lzaW9uLnVybCk7XG5cdFx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmIChjYWNoZWRGZXRjaERlY2lzaW9uLmtpbmQgPT09IFwiZm9sbG93UmVkaXJlY3RcIikge1xuXHRcdFx0XHRcdFx0XHRpZiAobmF2aWdhdGlvbktpbmQgPT09IFwidHJhdmVyc2VcIikgcmVzdG9yZWRCZmNhY2hlSWRzID0gbnVsbDtcblx0XHRcdFx0XHRcdFx0Y3VycmVudEhyZWYgPSBjYWNoZWRGZXRjaERlY2lzaW9uLnJlZGlyZWN0LmhyZWY7XG5cdFx0XHRcdFx0XHRcdGN1cnJlbnRIaXN0b3J5TW9kZSA9IGNhY2hlZEZldGNoRGVjaXNpb24ucmVkaXJlY3QuaGlzdG9yeVVwZGF0ZU1vZGU7XG5cdFx0XHRcdFx0XHRcdGN1cnJlbnRQcmV2TmV4dFVybCA9IGNhY2hlZEZldGNoRGVjaXNpb24ucmVkaXJlY3QucHJldmlvdXNOZXh0VXJsO1xuXHRcdFx0XHRcdFx0XHRyZWRpcmVjdENvdW50ID0gY2FjaGVkRmV0Y2hEZWNpc2lvbi5yZWRpcmVjdC5yZWRpcmVjdERlcHRoO1xuXHRcdFx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICghYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmlzQ3VycmVudE5hdmlnYXRpb24obmF2SWQpKSByZXR1cm47XG5cdFx0XHRcdFx0XHRjb25zdCBjYWNoZWRQYXJhbXMgPSBjYWNoZWRSb3V0ZS5wYXJhbXM7XG5cdFx0XHRcdFx0XHRjb25zdCBjYWNoZWROYXZpZ2F0aW9uU25hcHNob3QgPSBjcmVhdGVDbGllbnROYXZpZ2F0aW9uUmVuZGVyU25hcHNob3QoY3VycmVudEhyZWYsIGNhY2hlZFBhcmFtcywgY2FjaGVkUm91dGUucmVzcG9uc2UucmVuZGVyZWRQYXRoQW5kU2VhcmNoKTtcblx0XHRcdFx0XHRcdGNvbnN0IGNhY2hlZFBheWxvYWQgPSBjYWNoZWRSb3V0ZS5lbGVtZW50cyA/IFByb21pc2UucmVzb2x2ZShjYWNoZWRSb3V0ZS5lbGVtZW50cykgOiBkZWNvZGVBcHBFbGVtZW50c1Byb21pc2UoY3JlYXRlRnJvbUZldGNoKFByb21pc2UucmVzb2x2ZShyZXN0b3JlUnNjUmVzcG9uc2UoY2FjaGVkUm91dGUucmVzcG9uc2UpKSkpO1xuXHRcdFx0XHRcdFx0aWYgKCFicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbihuYXZJZCkpIHJldHVybjtcblx0XHRcdFx0XHRcdGNvbnN0IGNhY2hlZFJlbmRlck91dGNvbWUgPSBhd2FpdCByZW5kZXJOYXZpZ2F0aW9uUGF5bG9hZCh7XG5cdFx0XHRcdFx0XHRcdGFjdGlvblR5cGU6IHRvQWN0aW9uVHlwZShuYXZpZ2F0aW9uS2luZCksXG5cdFx0XHRcdFx0XHRcdGhpc3RvcnlVcGRhdGVNb2RlOiBjdXJyZW50SGlzdG9yeU1vZGUsXG5cdFx0XHRcdFx0XHRcdG5hdmlnYXRpb25Db21taXRLaW5kOiBkZXRhY2hlZE5hdmlnYXRpb25Db21taXRzID8gXCJhdXRob3JpdGF0aXZlXCIgOiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRcdG5hdmlnYXRpb25Jbml0aWF0aW9uU3RhdGUsXG5cdFx0XHRcdFx0XHRcdG5hdmlnYXRpb25TbmFwc2hvdDogY2FjaGVkTmF2aWdhdGlvblNuYXBzaG90LFxuXHRcdFx0XHRcdFx0XHRuYXZJZCxcblx0XHRcdFx0XHRcdFx0b3BlcmF0aW9uTGFuZTogdG9PcGVyYXRpb25MYW5lKG5hdmlnYXRpb25LaW5kKSxcblx0XHRcdFx0XHRcdFx0cGFyYW1zOiBjYWNoZWRQYXJhbXMsXG5cdFx0XHRcdFx0XHRcdHBheWxvYWQ6IGtlZXBPcHRpbWlzdGljU2hlbGxNZXRhZGF0YShjYWNoZWRQYXlsb2FkKSxcblx0XHRcdFx0XHRcdFx0cGF5bG9hZE9yaWdpbjogY2FjaGVkUm91dGUuZWxlbWVudHMgPyBDT01NSVRURURfQ0FDSEVfQVBQX05BVklHQVRJT05fUEFZTE9BRF9PUklHSU4gOiBWSVNJVEVEX0NBQ0hFX0FQUF9OQVZJR0FUSU9OX1BBWUxPQURfT1JJR0lOLFxuXHRcdFx0XHRcdFx0XHRwZW5kaW5nUm91dGVyU3RhdGU6IGRldGFjaGVkTmF2aWdhdGlvbkNvbW1pdHMgPyBudWxsIDogcGVuZGluZ1JvdXRlclN0YXRlLFxuXHRcdFx0XHRcdFx0XHRwcmV2aW91c05leHRVcmw6IHJlcXVlc3RQcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdFx0XHRcdHJlc3RvcmVkQmZjYWNoZUlkcyxcblx0XHRcdFx0XHRcdFx0cmV1c2VDdXJyZW50QmZjYWNoZUlkcyxcblx0XHRcdFx0XHRcdFx0c2Nyb2xsSW50ZW50LFxuXHRcdFx0XHRcdFx0XHR0YXJnZXRIcmVmOiBjdXJyZW50SHJlZixcblx0XHRcdFx0XHRcdFx0dHJhdmVyc2FsSW50ZW50OiBhY3RpdmVUcmF2ZXJzYWxJbnRlbnQsXG5cdFx0XHRcdFx0XHRcdHZpc2libGVDb21taXRNb2RlXG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdGlmIChjYWNoZWRSZW5kZXJPdXRjb21lID09PSBcImhhcmQtbmF2aWdhdGVcIikge1xuXHRcdFx0XHRcdFx0XHRzdGFydGVkSGFyZE5hdmlnYXRpb24gPSB0cnVlO1xuXHRcdFx0XHRcdFx0XHRicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuYWJhbmRvblBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUocGVuZGluZ1JvdXRlclN0YXRlKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmIChjYWNoZWRSZW5kZXJPdXRjb21lID09PSBcIm5vLWNvbW1pdFwiKSB7XG5cdFx0XHRcdFx0XHRcdGlmICghYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmlzQ3VycmVudE5hdmlnYXRpb24obmF2SWQpKSByZXR1cm47XG5cdFx0XHRcdFx0XHRcdGRlbGV0ZVZpc2l0ZWRSZXNwb25zZShyc2NVcmwsIHJlcXVlc3RJbnRlcmNlcHRpb25Db250ZXh0KTtcblx0XHRcdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGxldCBuYXZSZXNwb25zZTtcblx0XHRcdFx0XHRsZXQgbmF2UmVzcG9uc2VFeHBpcmVzQXQ7XG5cdFx0XHRcdFx0bGV0IG5hdlJlc3BvbnNlVXJsID0gbnVsbDtcblx0XHRcdFx0XHRsZXQgY29uc3VtZWRQcmVmZXRjaFNuYXBzaG90O1xuXHRcdFx0XHRcdGxldCBwcmVmZXRjaGVkRWxlbWVudHM7XG5cdFx0XHRcdFx0bGV0IGZhbGxiYWNrUmV1c2VEZWNpc2lvbiA9IHJldXNlRGVjaXNpb247XG5cdFx0XHRcdFx0aWYgKHJldXNlRGVjaXNpb24ua2luZCA9PT0gXCJjb25zdW1lUHJlZmV0Y2hcIikge1xuXHRcdFx0XHRcdFx0Y29uc3QgcHJlZmV0Y2hlZFJlc3BvbnNlID0gc2V0dGxlZFByZWZldGNoZWRSZXNwb25zZSA/IGNvbnN1bWVQcmVmZXRjaFJlc3BvbnNlKHRhcmdldFBhdGhBbmRTZWFyY2gsIHJlcXVlc3RJbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIsIHsgYWRkaXRpb25hbFJzY1VybHM6IGFkZGl0aW9uYWxQcmVmZXRjaFBhdGhBbmRTZWFyY2ggfSkgOiBhd2FpdCBjb25zdW1lUHJlZmV0Y2hSZXNwb25zZUZvck5hdmlnYXRpb24ocnNjVXJsLCByZXF1ZXN0SW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyLCB7XG5cdFx0XHRcdFx0XHRcdGFkZGl0aW9uYWxSc2NVcmxzOiBhZGRpdGlvbmFsUHJlZmV0Y2hSc2NVcmxzLFxuXHRcdFx0XHRcdFx0XHRzaG91bGRDb25zdW1lOiAoKSA9PiBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbihuYXZJZClcblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0aWYgKCFicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbihuYXZJZCkpIHJldHVybjtcblx0XHRcdFx0XHRcdGlmIChwcmVmZXRjaGVkUmVzcG9uc2UpIHtcblx0XHRcdFx0XHRcdFx0bmF2UmVzcG9uc2UgPSByZXN0b3JlUnNjUmVzcG9uc2UocHJlZmV0Y2hlZFJlc3BvbnNlLCBmYWxzZSk7XG5cdFx0XHRcdFx0XHRcdG5hdlJlc3BvbnNlVXJsID0gcmVzb2x2ZVByZWZldGNoTmF2aWdhdGlvblJlc3BvbnNlVXJsKHtcblx0XHRcdFx0XHRcdFx0XHRhZGRpdGlvbmFsUnNjVXJsczogYWRkaXRpb25hbFByZWZldGNoUnNjVXJscyxcblx0XHRcdFx0XHRcdFx0XHRvcmlnaW46IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4sXG5cdFx0XHRcdFx0XHRcdFx0cmVzcG9uc2VVcmw6IHByZWZldGNoZWRSZXNwb25zZS51cmwsXG5cdFx0XHRcdFx0XHRcdFx0dmlzaWJsZVJzY1VybDogcnNjVXJsXG5cdFx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0XHRjb25zdCBwdWJsaWNhdGlvbiA9IHByZXBhcmVDb25zdW1lZFByZWZldGNoUmVzcG9uc2VGb3JQdWJsaWNhdGlvbihwcmVmZXRjaGVkUmVzcG9uc2UsIG5hdlJlc3BvbnNlVXJsKTtcblx0XHRcdFx0XHRcdFx0Y29uc3VtZWRQcmVmZXRjaFNuYXBzaG90ID0gcHVibGljYXRpb24uc25hcHNob3Q7XG5cdFx0XHRcdFx0XHRcdHByZWZldGNoZWRFbGVtZW50cyA9IHB1YmxpY2F0aW9uLnByZXBhcmVkRWxlbWVudHM7XG5cdFx0XHRcdFx0XHRcdG5hdlJlc3BvbnNlRXhwaXJlc0F0ID0gcHVibGljYXRpb24uZXhwaXJlc0F0O1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKCFuYXZSZXNwb25zZSkge1xuXHRcdFx0XHRcdFx0XHRyb3V0ZU1hbmlmZXN0ID0gbmF2aWdhdGlvbktpbmQgPT09IFwibmF2aWdhdGVcIiA/IGdldEJyb3dzZXJSb3V0ZU1hbmlmZXN0KCkgOiBudWxsO1xuXHRcdFx0XHRcdFx0XHRmYWxsYmFja1JldXNlRGVjaXNpb24gPSBuYXZpZ2F0aW9uUGxhbm5lci5jbGFzc2lmeU5hdmlnYXRpb25SZXVzZSh7XG5cdFx0XHRcdFx0XHRcdFx0YnlwYXNzTmF2aWdhdGlvbkNhY2hlOiBzaG91bGRCeXBhc3NOYXZpZ2F0aW9uQ2FjaGUsXG5cdFx0XHRcdFx0XHRcdFx0bmF2aWdhdGlvbktpbmQsXG5cdFx0XHRcdFx0XHRcdFx0b3B0aW1pc3RpY1JvdXRlU2hlbGw6IHJvdXRlTWFuaWZlc3QgPT09IG51bGwgPyB7XG5cdFx0XHRcdFx0XHRcdFx0XHRyZWFzb246IFwicm91dGVNYW5pZmVzdE1pc3NpbmdcIixcblx0XHRcdFx0XHRcdFx0XHRcdHN0YXR1czogXCJ1bmF2YWlsYWJsZVwiXG5cdFx0XHRcdFx0XHRcdFx0fSA6IHsgc3RhdHVzOiBcImF2YWlsYWJsZVwiIH0sXG5cdFx0XHRcdFx0XHRcdFx0cHJlZmV0Y2g6IHsgc3RhdHVzOiBcInVuYXZhaWxhYmxlXCIgfSxcblx0XHRcdFx0XHRcdFx0XHR0YXJnZXRIcmVmOiBjdXJyZW50SHJlZixcblx0XHRcdFx0XHRcdFx0XHR2aXNpdGVkUmVzcG9uc2U6IHsgc3RhdHVzOiBcInVuYXZhaWxhYmxlXCIgfVxuXHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCFuYXZSZXNwb25zZSAmJiBmYWxsYmFja1JldXNlRGVjaXNpb24ua2luZCA9PT0gXCJhdHRlbXB0T3B0aW1pc3RpY1JvdXRlU2hlbGxcIikge1xuXHRcdFx0XHRcdFx0YXdhaXQgbGVhcm5PcHRpbWlzdGljUm91dGVUZW1wbGF0ZXNGcm9tUHJlZmV0Y2hDYWNoZSh7XG5cdFx0XHRcdFx0XHRcdGludGVyY2VwdGlvbkNvbnRleHQ6IHJlcXVlc3RJbnRlcmNlcHRpb25Db250ZXh0LFxuXHRcdFx0XHRcdFx0XHRtb3VudGVkU2xvdHNIZWFkZXIsXG5cdFx0XHRcdFx0XHRcdHJvdXRlTWFuaWZlc3Rcblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0aWYgKCFicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbihuYXZJZCkpIHJldHVybjtcblx0XHRcdFx0XHRcdGlmIChyb3V0ZU1hbmlmZXN0ICE9PSBudWxsKSB7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IG9wdGltaXN0aWNQYXlsb2FkID0gcmVzb2x2ZU9wdGltaXN0aWNOYXZpZ2F0aW9uUGF5bG9hZCh7XG5cdFx0XHRcdFx0XHRcdFx0YmFzZVBhdGg6IF9fYmFzZVBhdGgsXG5cdFx0XHRcdFx0XHRcdFx0aHJlZjogY3VycmVudEhyZWYsXG5cdFx0XHRcdFx0XHRcdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogcmVxdWVzdEludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0XHRcdFx0XHRcdFx0bW91bnRlZFNsb3RzSGVhZGVyLFxuXHRcdFx0XHRcdFx0XHRcdHJvdXRlTWFuaWZlc3QsXG5cdFx0XHRcdFx0XHRcdFx0dGVtcGxhdGVzOiBvcHRpbWlzdGljUm91dGVUZW1wbGF0ZXMudGVtcGxhdGVzXG5cdFx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0XHRpZiAob3B0aW1pc3RpY1BheWxvYWQgIT09IG51bGwgJiYgY2FuQ29tbWl0T3B0aW1pc3RpY1JvdXRlVGVtcGxhdGUoe1xuXHRcdFx0XHRcdFx0XHRcdGN1cnJlbnRFbGVtZW50czogbmF2aWdhdGlvbkluaXRpYXRpb25TdGF0ZS5lbGVtZW50cyxcblx0XHRcdFx0XHRcdFx0XHRjdXJyZW50TGF5b3V0SWRzOiBuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlLmxheW91dElkcyxcblx0XHRcdFx0XHRcdFx0XHRjdXJyZW50UGFyYW1zOiBuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdC5wYXJhbXMsXG5cdFx0XHRcdFx0XHRcdFx0cm91dGVNYW5pZmVzdCxcblx0XHRcdFx0XHRcdFx0XHR0YXJnZXRSb3V0ZVBhcmFtczogb3B0aW1pc3RpY1BheWxvYWQucm91dGVQYXJhbXMsXG5cdFx0XHRcdFx0XHRcdFx0dGFyZ2V0VXJsUGFydHM6IG9wdGltaXN0aWNQYXlsb2FkLnVybFBhcnRzLFxuXHRcdFx0XHRcdFx0XHRcdHRlbXBsYXRlOiBvcHRpbWlzdGljUGF5bG9hZC50ZW1wbGF0ZVxuXHRcdFx0XHRcdFx0XHR9KSkge1xuXHRcdFx0XHRcdFx0XHRcdGRldGFjaGVkTmF2aWdhdGlvbkNvbW1pdHMgPSB0cnVlO1xuXHRcdFx0XHRcdFx0XHRcdG9wdGltaXN0aWNTaGVsbEVsZW1lbnRzID0gb3B0aW1pc3RpY1BheWxvYWQuZWxlbWVudHM7XG5cdFx0XHRcdFx0XHRcdFx0Y29uc3Qgb3B0aW1pc3RpY05hdmlnYXRpb25TbmFwc2hvdCA9IGNyZWF0ZUNsaWVudE5hdmlnYXRpb25SZW5kZXJTbmFwc2hvdChjdXJyZW50SHJlZiwgb3B0aW1pc3RpY1BheWxvYWQucGFyYW1zKTtcblx0XHRcdFx0XHRcdFx0XHRyZW5kZXJOYXZpZ2F0aW9uUGF5bG9hZCh7XG5cdFx0XHRcdFx0XHRcdFx0XHRhY3Rpb25UeXBlOiB0b0FjdGlvblR5cGUobmF2aWdhdGlvbktpbmQpLFxuXHRcdFx0XHRcdFx0XHRcdFx0aGlzdG9yeVVwZGF0ZU1vZGU6IGN1cnJlbnRIaXN0b3J5TW9kZSxcblx0XHRcdFx0XHRcdFx0XHRcdG5hdmlnYXRpb25Db21taXRLaW5kOiBcImRldGFjaGVkXCIsXG5cdFx0XHRcdFx0XHRcdFx0XHRuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlLFxuXHRcdFx0XHRcdFx0XHRcdFx0bmF2aWdhdGlvblNuYXBzaG90OiBvcHRpbWlzdGljTmF2aWdhdGlvblNuYXBzaG90LFxuXHRcdFx0XHRcdFx0XHRcdFx0bmF2SWQsXG5cdFx0XHRcdFx0XHRcdFx0XHRvcGVyYXRpb25MYW5lOiB0b09wZXJhdGlvbkxhbmUobmF2aWdhdGlvbktpbmQpLFxuXHRcdFx0XHRcdFx0XHRcdFx0cGFyYW1zOiBvcHRpbWlzdGljUGF5bG9hZC5wYXJhbXMsXG5cdFx0XHRcdFx0XHRcdFx0XHRwYXlsb2FkOiBQcm9taXNlLnJlc29sdmUob3B0aW1pc3RpY1BheWxvYWQuZWxlbWVudHMpLFxuXHRcdFx0XHRcdFx0XHRcdFx0cGF5bG9hZE9yaWdpbjogRlJFU0hfQVBQX05BVklHQVRJT05fUEFZTE9BRF9PUklHSU4sXG5cdFx0XHRcdFx0XHRcdFx0XHRwZW5kaW5nUm91dGVyU3RhdGU6IG51bGwsXG5cdFx0XHRcdFx0XHRcdFx0XHRwcmV2aW91c05leHRVcmw6IHJlcXVlc3RQcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdFx0XHRcdFx0XHRyZXN0b3JlZEJmY2FjaGVJZHMsXG5cdFx0XHRcdFx0XHRcdFx0XHRyZXVzZUN1cnJlbnRCZmNhY2hlSWRzLFxuXHRcdFx0XHRcdFx0XHRcdFx0c2Nyb2xsSW50ZW50LFxuXHRcdFx0XHRcdFx0XHRcdFx0dGFyZ2V0SHJlZjogY3VycmVudEhyZWYsXG5cdFx0XHRcdFx0XHRcdFx0XHR0cmF2ZXJzYWxJbnRlbnQ6IGFjdGl2ZVRyYXZlcnNhbEludGVudCxcblx0XHRcdFx0XHRcdFx0XHRcdHZpc2libGVDb21taXRNb2RlXG5cdFx0XHRcdFx0XHRcdFx0fSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0XHRpZiAoYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmlzQ3VycmVudE5hdmlnYXRpb24obmF2SWQpKSBjb25zb2xlLmVycm9yKFwiW3ZpbmV4dF0gT3B0aW1pc3RpYyBSU0MgbmF2aWdhdGlvbiBlcnJvcjpcIiwgZXJyb3IpO1xuXHRcdFx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGxldCBzZW50TW91bnRlZExheW91dHMgPSBmYWxzZTtcblx0XHRcdFx0XHRpZiAoIW5hdlJlc3BvbnNlKSB7XG5cdFx0XHRcdFx0XHRsZXQgbGl2ZVJlcXVlc3RIZWFkZXJzID0gcmVxdWVzdEhlYWRlcnM7XG5cdFx0XHRcdFx0XHRpZiAobW91bnRlZExheW91dHNIZWFkZXIgIT09IG51bGwgJiYgcmVxdWVzdEludGVyY2VwdGlvbkNvbnRleHQgPT09IG51bGwpIHtcblx0XHRcdFx0XHRcdFx0bGl2ZVJlcXVlc3RIZWFkZXJzID0gbmV3IEhlYWRlcnMocmVxdWVzdEhlYWRlcnMpO1xuXHRcdFx0XHRcdFx0XHRsaXZlUmVxdWVzdEhlYWRlcnMuc2V0KFZJTkVYVF9NT1VOVEVEX0xBWU9VVFNfSEVBREVSLCBtb3VudGVkTGF5b3V0c0hlYWRlcik7XG5cdFx0XHRcdFx0XHRcdHNlbnRNb3VudGVkTGF5b3V0cyA9IHRydWU7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRuYXZSZXNwb25zZSA9IGF3YWl0IGZldGNoKHJzY1VybCwge1xuXHRcdFx0XHRcdFx0XHRoZWFkZXJzOiBsaXZlUmVxdWVzdEhlYWRlcnMsXG5cdFx0XHRcdFx0XHRcdGNyZWRlbnRpYWxzOiBcImluY2x1ZGVcIixcblx0XHRcdFx0XHRcdFx0cHJpb3JpdHk6IFwiYXV0b1wiLFxuXHRcdFx0XHRcdFx0XHRzaWduYWw6IG5hdmlnYXRpb25BYm9ydEhhbmRsZS5zaWduYWxcblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5pc0N1cnJlbnROYXZpZ2F0aW9uKG5hdklkKSkgcmV0dXJuO1xuXHRcdFx0XHRcdGNvbnN0IG5hdkNvbnRlbnRUeXBlID0gbmF2UmVzcG9uc2UuaGVhZGVycy5nZXQoXCJjb250ZW50LXR5cGVcIikgPz8gXCJcIjtcblx0XHRcdFx0XHRjb25zdCBpc05hdmlnYXRpb25Sc2NDb250ZW50VHlwZSA9IG5hdkNvbnRlbnRUeXBlLnN0YXJ0c1dpdGgoXCJ0ZXh0L3gtY29tcG9uZW50XCIpIHx8IElTX1NUQVRJQ19FWFBPUlQgJiYgbmF2Q29udGVudFR5cGUuc3RhcnRzV2l0aChcInRleHQvcGxhaW5cIik7XG5cdFx0XHRcdFx0Y29uc3QgbmF2aWdhdGlvblJlc3BvbnNlVXJsID0gSVNfU1RBVElDX0VYUE9SVCA/IGN1cnJlbnRIcmVmIDogbmF2UmVzcG9uc2VVcmwgPz8gbmF2UmVzcG9uc2UudXJsO1xuXHRcdFx0XHRcdGNvbnN0IHN0cmVhbWVkUmVkaXJlY3RUYXJnZXQgPSBuYXZSZXNwb25zZS5oZWFkZXJzLmdldChWSU5FWFRfUlNDX1JFRElSRUNUX0hFQURFUik7XG5cdFx0XHRcdFx0Y29uc3Qgc3RyZWFtZWRSZWRpcmVjdFR5cGVIZWFkZXIgPSBuYXZSZXNwb25zZS5oZWFkZXJzLmdldChWSU5FWFRfUlNDX1JFRElSRUNUX1RZUEVfSEVBREVSKTtcblx0XHRcdFx0XHRjb25zdCBzdHJlYW1lZFJlZGlyZWN0VHlwZSA9IHN0cmVhbWVkUmVkaXJlY3RUeXBlSGVhZGVyID09PSBcInB1c2hcIiB8fCBzdHJlYW1lZFJlZGlyZWN0VHlwZUhlYWRlciA9PT0gXCJyZXBsYWNlXCIgPyBzdHJlYW1lZFJlZGlyZWN0VHlwZUhlYWRlciA6IG51bGw7XG5cdFx0XHRcdFx0aWYgKGJsb2NrRGFuZ2Vyb3VzU3RyZWFtZWRSc2NSZWRpcmVjdChuYXZSZXNwb25zZSwgc3RyZWFtZWRSZWRpcmVjdFRhcmdldCkpIHJldHVybjtcblx0XHRcdFx0XHRjb25zdCBsaXZlRmV0Y2hEZWNpc2lvbiA9IG5hdmlnYXRpb25QbGFubmVyLmNsYXNzaWZ5UnNjRmV0Y2hSZXN1bHQoe1xuXHRcdFx0XHRcdFx0Y2xpZW50Q29tcGF0aWJpbGl0eUlkOiBjbGllbnRSc2NDb21wYXRpYmlsaXR5SWQsXG5cdFx0XHRcdFx0XHRjb21wYXRpYmlsaXR5SWRIZWFkZXI6IG5hdlJlc3BvbnNlLmhlYWRlcnMuZ2V0KFZJTkVYVF9SU0NfQ09NUEFUSUJJTElUWV9JRF9IRUFERVIpLFxuXHRcdFx0XHRcdFx0Y3VycmVudEhyZWYsXG5cdFx0XHRcdFx0XHRlZmZlY3RpdmVIaXN0b3J5VXBkYXRlTW9kZTogY3VycmVudEhpc3RvcnlNb2RlID8/IFwicmVwbGFjZVwiLFxuXHRcdFx0XHRcdFx0aGFzQm9keTogbmF2UmVzcG9uc2UuYm9keSAhPT0gbnVsbCxcblx0XHRcdFx0XHRcdGlzUnNjQ29udGVudFR5cGU6IGlzTmF2aWdhdGlvblJzY0NvbnRlbnRUeXBlLFxuXHRcdFx0XHRcdFx0b3JpZ2luOiB3aW5kb3cubG9jYXRpb24ub3JpZ2luLFxuXHRcdFx0XHRcdFx0cmVkaXJlY3REZXB0aDogcmVkaXJlY3RDb3VudCxcblx0XHRcdFx0XHRcdHJlcXVlc3RQcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdFx0XHRyZXNwb25zZU9rOiBuYXZSZXNwb25zZS5vayxcblx0XHRcdFx0XHRcdHJlc3BvbnNlVXJsOiBuYXZpZ2F0aW9uUmVzcG9uc2VVcmwsXG5cdFx0XHRcdFx0XHRzb3VyY2U6IFwibGl2ZVwiLFxuXHRcdFx0XHRcdFx0c3RyZWFtZWRSZWRpcmVjdFRhcmdldCxcblx0XHRcdFx0XHRcdHN0cmVhbWVkUmVkaXJlY3RUeXBlXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0aWYgKGxpdmVGZXRjaERlY2lzaW9uLmtpbmQgPT09IFwiaGFyZE5hdmlnYXRlXCIpIHtcblx0XHRcdFx0XHRcdGlmIChsaXZlRmV0Y2hEZWNpc2lvbi5kaXNjYXJkQm9keSkgbmF2UmVzcG9uc2UuYm9keT8uY2FuY2VsKCkuY2F0Y2goKCkgPT4ge30pO1xuXHRcdFx0XHRcdFx0aWYgKGxpdmVGZXRjaERlY2lzaW9uLnJlYXNvbiA9PT0gXCJyZWRpcmVjdERlcHRoRXhoYXVzdGVkXCIpIGNvbnNvbGUuZXJyb3IoXCJbdmluZXh0XSBUb28gbWFueSBSU0MgcmVkaXJlY3RzIOKAlCBhYm9ydGluZyBuYXZpZ2F0aW9uIHRvIHByZXZlbnQgaW5maW5pdGUgbG9vcC5cIik7XG5cdFx0XHRcdFx0XHRpZiAobGl2ZUZldGNoRGVjaXNpb24ucmVhc29uID09PSBcInN0cmVhbWVkUmVkaXJlY3RMb29wXCIpIGNvbnNvbGUuZXJyb3IoXCJbdmluZXh0XSBSU0Mgc3RyZWFtZWQgcmVkaXJlY3QgcmVzb2x2ZWQgdG8gdGhlIGN1cnJlbnQgVVJMIOKAlCBhYm9ydGluZyBuYXZpZ2F0aW9uIHRvIHByZXZlbnQgaW5maW5pdGUgbG9vcC5cIik7XG5cdFx0XHRcdFx0XHRwZXJmb3JtSGFyZE5hdmlnYXRpb25Gb3JTY3JvbGxJbnRlbnQobGl2ZUZldGNoRGVjaXNpb24udXJsLCBsaXZlRmV0Y2hEZWNpc2lvbi5oYXJkTmF2aWdhdGlvbk1vZGUpO1xuXHRcdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAobGl2ZUZldGNoRGVjaXNpb24ua2luZCA9PT0gXCJmb2xsb3dSZWRpcmVjdFwiKSB7XG5cdFx0XHRcdFx0XHRpZiAobGl2ZUZldGNoRGVjaXNpb24uZGlzY2FyZEJvZHkpIG5hdlJlc3BvbnNlLmJvZHk/LmNhbmNlbCgpLmNhdGNoKCgpID0+IHt9KTtcblx0XHRcdFx0XHRcdGlmIChuYXZpZ2F0aW9uS2luZCA9PT0gXCJ0cmF2ZXJzZVwiKSByZXN0b3JlZEJmY2FjaGVJZHMgPSBudWxsO1xuXHRcdFx0XHRcdFx0Y3VycmVudEhyZWYgPSBsaXZlRmV0Y2hEZWNpc2lvbi5yZWRpcmVjdC5ocmVmO1xuXHRcdFx0XHRcdFx0Y3VycmVudEhpc3RvcnlNb2RlID0gbGl2ZUZldGNoRGVjaXNpb24ucmVkaXJlY3QuaGlzdG9yeVVwZGF0ZU1vZGU7XG5cdFx0XHRcdFx0XHRjdXJyZW50UHJldk5leHRVcmwgPSBsaXZlRmV0Y2hEZWNpc2lvbi5yZWRpcmVjdC5wcmV2aW91c05leHRVcmw7XG5cdFx0XHRcdFx0XHRyZWRpcmVjdENvdW50ID0gbGl2ZUZldGNoRGVjaXNpb24ucmVkaXJlY3QucmVkaXJlY3REZXB0aDtcblx0XHRcdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoIWhhc1N1cHBsZW1lbnRhbFJlZnJlc2gpIG5hdmlnYXRpb25BYm9ydEhhbmRsZS5yZWxlYXNlKCk7XG5cdFx0XHRcdFx0Y29uc3QgbmF2UGFyYW1zID0gcGFyc2VFbmNvZGVkSnNvbkhlYWRlcihuYXZSZXNwb25zZS5oZWFkZXJzLmdldChcIlgtVmluZXh0LVBhcmFtc1wiKSkgPz8gKElTX1NUQVRJQ19FWFBPUlQgPyByZXNvbHZlU3RhdGljRXhwb3J0Um91dGVQYXJhbXMoY3VycmVudEhyZWYpIDoge30pO1xuXHRcdFx0XHRcdGNvbnN0IG5hdmlnYXRpb25TbmFwc2hvdCA9IGNyZWF0ZUNsaWVudE5hdmlnYXRpb25SZW5kZXJTbmFwc2hvdChjdXJyZW50SHJlZiwgbmF2UGFyYW1zLCBwYXJzZVJlbmRlcmVkUGF0aEFuZFNlYXJjaEhlYWRlcihuYXZSZXNwb25zZS5oZWFkZXJzLmdldChWSU5FWFRfUkVOREVSRURfUEFUSF9BTkRfU0VBUkNIX0hFQURFUikpKTtcblx0XHRcdFx0XHRjb25zdCBuYXZCb2R5ID0gbmF2UmVzcG9uc2UuYm9keTtcblx0XHRcdFx0XHRpZiAoIW5hdkJvZHkpIHJldHVybjtcblx0XHRcdFx0XHRjb25zdCBbcmVhY3RCcmFuY2gsIGNhY2hlQnJhbmNoXSA9IG5hdkJvZHkudGVlKCk7XG5cdFx0XHRcdFx0Y29uc3QgcmVhY3RSZXNwb25zZSA9IHN0cmlwUnNjQ29tcGxldGlvbk1ldGFkYXRhUmVzcG9uc2UobmV3IFJlc3BvbnNlKHJlYWN0QnJhbmNoLCB7XG5cdFx0XHRcdFx0XHRzdGF0dXM6IG5hdlJlc3BvbnNlLnN0YXR1cyxcblx0XHRcdFx0XHRcdGhlYWRlcnM6IG5hdlJlc3BvbnNlLmhlYWRlcnNcblx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0Y29uc3QgY2FjaGVCdWZmZXJQcm9taXNlID0gbmV3IFJlc3BvbnNlKGNhY2hlQnJhbmNoKS5hcnJheUJ1ZmZlcigpO1xuXHRcdFx0XHRcdGNhY2hlQnVmZmVyUHJvbWlzZS5jYXRjaCgoKSA9PiB7fSk7XG5cdFx0XHRcdFx0aWYgKCFicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbihuYXZJZCkpIHJldHVybjtcblx0XHRcdFx0XHRpZiAocHJlZmV0Y2hlZEVsZW1lbnRzKSByZWFjdFJlc3BvbnNlLmJvZHk/LmNhbmNlbCgpLmNhdGNoKCgpID0+IHt9KTtcblx0XHRcdFx0XHRsZXQgcnNjUGF5bG9hZCA9IHByZWZldGNoZWRFbGVtZW50cyA/IHByZWZldGNoZWRFbGVtZW50cyA6IGRlY29kZUFwcEVsZW1lbnRzUHJvbWlzZShjcmVhdGVGcm9tRmV0Y2goUHJvbWlzZS5yZXNvbHZlKHJlYWN0UmVzcG9uc2UpKSk7XG5cdFx0XHRcdFx0aWYgKGhhc1N1cHBsZW1lbnRhbFJlZnJlc2gpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHN1cHBsZW1lbnRhbCA9IHBlcnNpc3RlZFJlZnJlc2hJbnRlcmNlcHRpb25zLm1hcCgoaW50ZXJjZXB0aW9uKSA9PiAoc2lnbmFsKSA9PiBmZXRjaFBlcnNpc3RlZEludGVyY2VwdGVkU2xvdFJlZnJlc2goe1xuXHRcdFx0XHRcdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0OiBpbnRlcmNlcHRpb24uaW50ZXJjZXB0aW9uQ29udGV4dCxcblx0XHRcdFx0XHRcdFx0aW50ZXJjZXB0aW9uSWQ6IGludGVyY2VwdGlvbi5pbnRlcmNlcHRpb24uaWQsXG5cdFx0XHRcdFx0XHRcdG1vdW50ZWRTbG90c0hlYWRlcixcblx0XHRcdFx0XHRcdFx0c2lnbmFsLFxuXHRcdFx0XHRcdFx0XHR0YXJnZXRQYXRobmFtZTogaW50ZXJjZXB0aW9uLnRhcmdldFBhdGhuYW1lXG5cdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHRmb3IgKGNvbnN0IHBlcnNpc3RlZFNvdXJjZVBhZ2VSZWZyZXNoIG9mIHBlcnNpc3RlZFNvdXJjZVBhZ2VSZWZyZXNoZXMpIHN1cHBsZW1lbnRhbC5wdXNoKChzaWduYWwpID0+IGZldGNoUGVyc2lzdGVkU291cmNlUGFnZVJlZnJlc2goe1xuXHRcdFx0XHRcdFx0XHRtb3VudGVkU2xvdHNIZWFkZXIsXG5cdFx0XHRcdFx0XHRcdHNpZ25hbCxcblx0XHRcdFx0XHRcdFx0dGFyZ2V0UGF0aG5hbWU6IHBlcnNpc3RlZFNvdXJjZVBhZ2VSZWZyZXNoXG5cdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHRyc2NQYXlsb2FkID0gcmVzb2x2ZVN1cHBsZW1lbnRhbFJlZnJlc2hlcyh7XG5cdFx0XHRcdFx0XHRcdG1lcmdlOiBtZXJnZVJlZnJlc2hlZFBhcmFsbGVsU2xvdCxcblx0XHRcdFx0XHRcdFx0cHJpbWFyeTogUHJvbWlzZS5yZXNvbHZlKHJzY1BheWxvYWQpLFxuXHRcdFx0XHRcdFx0XHRzaWduYWw6IG5hdmlnYXRpb25BYm9ydEhhbmRsZS5zaWduYWwsXG5cdFx0XHRcdFx0XHRcdHN1cHBsZW1lbnRhbFxuXHRcdFx0XHRcdFx0fSkuZmluYWxseSgoKSA9PiB7XG5cdFx0XHRcdFx0XHRcdG5hdmlnYXRpb25BYm9ydEhhbmRsZS5yZWxlYXNlKCk7XG5cdFx0XHRcdFx0XHR9KS50aGVuKHJlcXVpcmVDb21wbGV0ZVN1cHBsZW1lbnRhbFJlZnJlc2gpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAoc2VudE1vdW50ZWRMYXlvdXRzKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBlbGVtZW50cyA9IGF3YWl0IHJzY1BheWxvYWQ7XG5cdFx0XHRcdFx0XHRpZiAoIWJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5pc0N1cnJlbnROYXZpZ2F0aW9uKG5hdklkKSkgcmV0dXJuO1xuXHRcdFx0XHRcdFx0aWYgKCFob2xkc1NraXBwZWRMYXlvdXRzKG5hdmlnYXRpb25Jbml0aWF0aW9uU3RhdGUsIGVsZW1lbnRzKSB8fCAhaG9sZHNTa2lwcGVkTGF5b3V0cyhnZXRCcm93c2VyUm91dGVyU3RhdGUoKSwgZWxlbWVudHMpKSB7XG5cdFx0XHRcdFx0XHRcdG1vdW50ZWRMYXlvdXRzSGVhZGVyID0gbnVsbDtcblx0XHRcdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRyc2NQYXlsb2FkID0gUHJvbWlzZS5yZXNvbHZlKGVsZW1lbnRzKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKElTX1NUQVRJQ19FWFBPUlQpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHN0YXRpY0V4cG9ydEVsZW1lbnRzID0gYXdhaXQgcnNjUGF5bG9hZDtcblx0XHRcdFx0XHRcdGlmICghYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmlzQ3VycmVudE5hdmlnYXRpb24obmF2SWQpKSByZXR1cm47XG5cdFx0XHRcdFx0XHRpZiAoIWlzU3RhdGljRXhwb3J0UGF5bG9hZERlcGxveW1lbnRDb21wYXRpYmxlKHN0YXRpY0V4cG9ydEVsZW1lbnRzKSkge1xuXHRcdFx0XHRcdFx0XHRwZXJmb3JtSGFyZE5hdmlnYXRpb25Gb3JTY3JvbGxJbnRlbnQoY3VycmVudEhyZWYpO1xuXHRcdFx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRyc2NQYXlsb2FkID0gUHJvbWlzZS5yZXNvbHZlKHN0YXRpY0V4cG9ydEVsZW1lbnRzKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCFicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbihuYXZJZCkpIHJldHVybjtcblx0XHRcdFx0XHRsZXQgY29tbWl0dGVkU3RhdGUgPSBudWxsO1xuXHRcdFx0XHRcdGNvbnN0IHJlbmRlck91dGNvbWUgPSBhd2FpdCByZW5kZXJOYXZpZ2F0aW9uUGF5bG9hZCh7XG5cdFx0XHRcdFx0XHRhY3Rpb25UeXBlOiB0b0FjdGlvblR5cGUobmF2aWdhdGlvbktpbmQpLFxuXHRcdFx0XHRcdFx0aGlzdG9yeVVwZGF0ZU1vZGU6IGN1cnJlbnRIaXN0b3J5TW9kZSxcblx0XHRcdFx0XHRcdG5hdmlnYXRpb25Db21taXRLaW5kOiBkZXRhY2hlZE5hdmlnYXRpb25Db21taXRzID8gXCJhdXRob3JpdGF0aXZlXCIgOiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlLFxuXHRcdFx0XHRcdFx0bmF2aWdhdGlvblNuYXBzaG90LFxuXHRcdFx0XHRcdFx0bmF2aWdhdGlvblJlc3BvbnNlQ29tcGxldGlvbjogc2hvdWxkUmVjb3ZlclNhbWVQYXRoU2VhcmNoQ29tbWl0T25SZXNwb25zZUNvbXBsZXRpb24oe1xuXHRcdFx0XHRcdFx0XHRiYXNlUGF0aDogX19iYXNlUGF0aCxcblx0XHRcdFx0XHRcdFx0Y3VycmVudFNuYXBzaG90OiBuYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdCxcblx0XHRcdFx0XHRcdFx0bmF2aWdhdGlvbktpbmQsXG5cdFx0XHRcdFx0XHRcdHByb2dyYW1tYXRpY1RyYW5zaXRpb24sXG5cdFx0XHRcdFx0XHRcdHRhcmdldFVybDogdXJsXG5cdFx0XHRcdFx0XHR9KSA/IGNhY2hlQnVmZmVyUHJvbWlzZSA6IHZvaWQgMCxcblx0XHRcdFx0XHRcdG5hdklkLFxuXHRcdFx0XHRcdFx0b25Db21taXR0ZWRTdGF0ZTogKHN0YXRlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdGNvbW1pdHRlZFN0YXRlID0gc3RhdGU7XG5cdFx0XHRcdFx0XHRcdG5hdmlnYXRpb25BYm9ydEhhbmRsZS5yZWxlYXNlKCk7XG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFx0b3BlcmF0aW9uTGFuZTogdG9PcGVyYXRpb25MYW5lKG5hdmlnYXRpb25LaW5kKSxcblx0XHRcdFx0XHRcdHBhcmFtczogbmF2UGFyYW1zLFxuXHRcdFx0XHRcdFx0cGF5bG9hZDoga2VlcE9wdGltaXN0aWNTaGVsbE1ldGFkYXRhKHJzY1BheWxvYWQpLFxuXHRcdFx0XHRcdFx0cGF5bG9hZE9yaWdpbjogRlJFU0hfQVBQX05BVklHQVRJT05fUEFZTE9BRF9PUklHSU4sXG5cdFx0XHRcdFx0XHRwZW5kaW5nUm91dGVyU3RhdGU6IGRldGFjaGVkTmF2aWdhdGlvbkNvbW1pdHMgPyBudWxsIDogcGVuZGluZ1JvdXRlclN0YXRlLFxuXHRcdFx0XHRcdFx0cHJldmlvdXNOZXh0VXJsOiByZXF1ZXN0UHJldmlvdXNOZXh0VXJsLFxuXHRcdFx0XHRcdFx0cmVzdG9yZWRCZmNhY2hlSWRzLFxuXHRcdFx0XHRcdFx0cmV1c2VDdXJyZW50QmZjYWNoZUlkcyxcblx0XHRcdFx0XHRcdHNjcm9sbEludGVudCxcblx0XHRcdFx0XHRcdHRhcmdldEhyZWY6IGN1cnJlbnRIcmVmLFxuXHRcdFx0XHRcdFx0dHJhdmVyc2FsSW50ZW50OiBhY3RpdmVUcmF2ZXJzYWxJbnRlbnQsXG5cdFx0XHRcdFx0XHR2aXNpYmxlQ29tbWl0TW9kZVxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGlmIChyZW5kZXJPdXRjb21lID09PSBcImhhcmQtbmF2aWdhdGVcIikge1xuXHRcdFx0XHRcdFx0c3RhcnRlZEhhcmROYXZpZ2F0aW9uID0gdHJ1ZTtcblx0XHRcdFx0XHRcdGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5hYmFuZG9uUGVuZGluZ0Jyb3dzZXJSb3V0ZXJTdGF0ZShwZW5kaW5nUm91dGVyU3RhdGUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRpZiAocmVuZGVyT3V0Y29tZSAhPT0gXCJjb21taXR0ZWRcIikgcmV0dXJuO1xuXHRcdFx0XHRcdGlmIChoYXNTdXBwbGVtZW50YWxSZWZyZXNoKSB7XG5cdFx0XHRcdFx0XHRjbGVhclZpc2l0ZWRSZXNwb25zZUNhY2hlKCk7XG5cdFx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGNvbW1pdHRlZFN0YXRlID8/PSBnZXRCcm93c2VyUm91dGVyU3RhdGUoKTtcblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0Y29uc3QgcmVuZGVyZWRFbGVtZW50cyA9IGF3YWl0IHJzY1BheWxvYWQ7XG5cdFx0XHRcdFx0XHRpZiAobmF2aWdhdGlvbkNhY2hlR2VuZXJhdGlvbiAhPT0gY2xpZW50TmF2aWdhdGlvbkNhY2hlR2VuZXJhdGlvbikgcmV0dXJuO1xuXHRcdFx0XHRcdFx0Y29uc3QgbWV0YWRhdGEgPSBBcHBFbGVtZW50c1dpcmUucmVhZE1ldGFkYXRhKHJlbmRlcmVkRWxlbWVudHMpO1xuXHRcdFx0XHRcdFx0aWYgKG5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24gIT09IGNsaWVudE5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24pIHJldHVybjtcblx0XHRcdFx0XHRcdGNvbnN0IHJlc3BvbnNlU25hcHNob3QgPSBjb25zdW1lZFByZWZldGNoU25hcHNob3QgPz8gY3JlYXRlQ2FjaGVkUnNjUmVzcG9uc2VTbmFwc2hvdChuYXZSZXNwb25zZSwgYXdhaXQgY2FjaGVCdWZmZXJQcm9taXNlLCBuYXZpZ2F0aW9uUmVzcG9uc2VVcmwpO1xuXHRcdFx0XHRcdFx0Y29uc3QgY2FjaGVSZXN0b3JhYmxlID0gIShyZXNwb25zZVNuYXBzaG90LmNvbXBsZXRlZER5bmFtaWNTdGFsZVRpbWVTZWNvbmRzICE9PSB2b2lkIDApICYmIGlzQ2FjaGVSZXN0b3JhYmxlQXBwUGF5bG9hZE1ldGFkYXRhKG1ldGFkYXRhKTtcblx0XHRcdFx0XHRcdGNvbnN0IHsgY29tcGxldGVkRHluYW1pY1N0YWxlVGltZVNlY29uZHM6IF9zdGF0aWNDb21wbGV0ZWREeW5hbWljU3RhbGVUaW1lLCBkeW5hbWljU3RhbGVUaW1lU2Vjb25kczogX3N0YXRpY0R5bmFtaWNTdGFsZVRpbWUsIC4uLnN0YXRpY1Jlc3BvbnNlU25hcHNob3QgfSA9IHJlc3BvbnNlU25hcHNob3Q7XG5cdFx0XHRcdFx0XHRjb25zdCBzbmFwc2hvdCA9IHtcblx0XHRcdFx0XHRcdFx0Li4uY2FjaGVSZXN0b3JhYmxlID8gc3RhdGljUmVzcG9uc2VTbmFwc2hvdCA6IHtcblx0XHRcdFx0XHRcdFx0XHQuLi5yZXNwb25zZVNuYXBzaG90LFxuXHRcdFx0XHRcdFx0XHRcdC4uLnJlc3BvbnNlU25hcHNob3QuZHluYW1pY1N0YWxlVGltZVNlY29uZHMgPT09IHZvaWQgMCAmJiBtZXRhZGF0YS5keW5hbWljU3RhbGVUaW1lU2Vjb25kcyAhPT0gdm9pZCAwID8geyBkeW5hbWljU3RhbGVUaW1lU2Vjb25kczogbWV0YWRhdGEuZHluYW1pY1N0YWxlVGltZVNlY29uZHMgfSA6IHt9XG5cdFx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0XHRcdG1vdW50ZWRTbG90c0hlYWRlcjogZ2V0TW91bnRlZFNsb3RJZHNIZWFkZXIocmVuZGVyZWRFbGVtZW50cylcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRjb25zdCBwcmVmZXRjaFNuYXBzaG90ID0gcHJlc2VydmVDb21taXR0ZWRQcmVmZXRjaEV4cGlyeShzbmFwc2hvdCwgbmF2UmVzcG9uc2VFeHBpcmVzQXQpO1xuXHRcdFx0XHRcdFx0Y29uc3QgaW50ZXJjZXB0aW9uQ29udGV4dCA9IHJlc29sdmVWaXNpdGVkUmVzcG9uc2VJbnRlcmNlcHRpb25Db250ZXh0KHJlcXVlc3RJbnRlcmNlcHRpb25Db250ZXh0LCBtZXRhZGF0YS5pbnRlcmNlcHRpb25Db250ZXh0KTtcblx0XHRcdFx0XHRcdGlmIChjYWNoZVJlc3RvcmFibGUpIHtcblx0XHRcdFx0XHRcdFx0aWYgKG5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24gIT09IGNsaWVudE5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24pIHJldHVybjtcblx0XHRcdFx0XHRcdFx0c3RvcmVWaXNpdGVkUmVzcG9uc2VTbmFwc2hvdChyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQsIHNuYXBzaG90LCBuYXZQYXJhbXMsIFBSRUZFVENIX0NBQ0hFX1RUTCwgbW91bnRlZFNsb3RzSGVhZGVyLCB2b2lkIDAsIHRydWUsIHByZWZldGNoU25hcHNob3QsIHRydWUpO1xuXHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0Y29uc3Qgc3RhdGUgPSBjb21taXR0ZWRTdGF0ZTtcblx0XHRcdFx0XHRcdFx0Y29uc3QgY29tbWl0dGVkRWxlbWVudHMgPSB7XG5cdFx0XHRcdFx0XHRcdFx0Li4uc3RhdGUuZWxlbWVudHMsXG5cdFx0XHRcdFx0XHRcdFx0W0FwcEVsZW1lbnRzV2lyZS5rZXlzLmxheW91dElkc106IHN0YXRlLmxheW91dElkcyxcblx0XHRcdFx0XHRcdFx0XHRbQXBwRWxlbWVudHNXaXJlLmtleXMuc2tpcHBlZExheW91dElkc106IFtdLFxuXHRcdFx0XHRcdFx0XHRcdFtBcHBFbGVtZW50c1dpcmUua2V5cy5zbG90QmluZGluZ3NdOiBzdGF0ZS5zbG90QmluZGluZ3Ncblx0XHRcdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRcdFx0aWYgKG5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24gIT09IGNsaWVudE5hdmlnYXRpb25DYWNoZUdlbmVyYXRpb24pIHJldHVybjtcblx0XHRcdFx0XHRcdFx0c3RvcmVWaXNpdGVkUmVzcG9uc2VTbmFwc2hvdChyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQsIHNuYXBzaG90LCBuYXZQYXJhbXMsIERZTkFNSUNfTkFWSUdBVElPTl9DQUNIRV9UVEwsIG1vdW50ZWRTbG90c0hlYWRlciwgY29tbWl0dGVkRWxlbWVudHMsIGlzQ29tcGxldGVBcHBQYXlsb2FkTWV0YWRhdGEobWV0YWRhdGEpLCBwcmVmZXRjaFNuYXBzaG90LCBpbnRlcmNlcHRpb25Db250ZXh0ICE9PSBudWxsIHx8IGhhc05hdmlnYXRpb25SZXNwb25zZUhpc3RvcnlMaWZldGltZShzbmFwc2hvdCkpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0gY2F0Y2gge31cblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRcdGlmICghYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmlzQ3VycmVudE5hdmlnYXRpb24obmF2SWQpKSByZXR1cm47XG5cdFx0XHRcdGlmICghaXNQYWdlVW5sb2FkaW5nKSBjb25zb2xlLmVycm9yKFwiW3ZpbmV4dF0gUlNDIG5hdmlnYXRpb24gZXJyb3I6XCIsIGVycm9yKTtcblx0XHRcdFx0cGVyZm9ybUhhcmROYXZpZ2F0aW9uRm9yU2Nyb2xsSW50ZW50KG5hdmlnYXRpb25QbGFubmVyLmNsYXNzaWZ5UnNjTmF2aWdhdGlvbkVycm9yKHsgY3VycmVudEhyZWYgfSkudXJsKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdG5hdmlnYXRpb25BYm9ydEhhbmRsZS5yZWxlYXNlKCk7XG5cdFx0XHRcdGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5maW5hbGl6ZU5hdmlnYXRpb24obmF2SWQsIHBlbmRpbmdSb3V0ZXJTdGF0ZSk7XG5cdFx0XHRcdGRpc2NhcmRlZFNlcnZlckFjdGlvblJlZnJlc2hTY2hlZHVsZXIubWFya05hdmlnYXRpb25TZXR0bGVkKCk7XG5cdFx0XHRcdHJlbGVhc2VOYXZpZ2F0aW9uSW5GbGlnaHQoKTtcblx0XHRcdFx0aWYgKHN0YXJ0ZWRIYXJkTmF2aWdhdGlvbikgYXdhaXQgd2FpdEZvck1wYU5hdmlnYXRpb25SZXN0b3JlKCk7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHRyZWFkVmlzaXRlZFJlc3BvbnNlRm9yRnVsbFByZWZldGNoOiAocnNjVXJscywgaW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyKSA9PiBmaW5kVmlzaXRlZFJlc3BvbnNlRm9yRnVsbFByZWZldGNoKHZpc2l0ZWRSZXNwb25zZUNhY2hlLCByc2NVcmxzLCBpbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIpLFxuXHRcdHByZXBhcmVQcmVmZXRjaFJlc3BvbnNlOiAocmVzcG9uc2UpID0+IHtcblx0XHRcdGlmICghaXNSc2NSZXNwb25zZUNvbXBhdGlibGUocmVzcG9uc2UuaGVhZGVycy5nZXQoXCJYLVZpbmV4dC1SU0MtQ29tcGF0aWJpbGl0eS1JZFwiKSkpIHJldHVybiBQcm9taXNlLnJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKFwiW3ZpbmV4dF0gUHJlZmV0Y2hlZCBhbm90aGVyIGRlcGxveW1lbnQncyBwYXlsb2FkXCIpKTtcblx0XHRcdHJldHVybiBkZWNvZGVBcHBFbGVtZW50c1Byb21pc2UoY3JlYXRlRnJvbUZldGNoKFByb21pc2UucmVzb2x2ZShyZXNwb25zZSkpKTtcblx0XHR9LFxuXHRcdGNsYWltQ3VycmVudEhpc3RvcnlUcmVlU25hcHNob3Q6IChoaXN0b3J5VXBkYXRlTW9kZSwgcHJldmlvdXNIaXN0b3J5U3RhdGUpID0+IGhpc3RvcnlDb250cm9sbGVyLmNsYWltQ3VycmVudEhpc3RvcnlUcmVlU25hcHNob3QoaGlzdG9yeVVwZGF0ZU1vZGUsIHByZXZpb3VzSGlzdG9yeVN0YXRlKSxcblx0XHRjb21taXRBcHBPd25lZEhpc3RvcnlTdGF0ZVdyaXRlOiAoaGlzdG9yeVVwZGF0ZU1vZGUsIHByZXZpb3VzSGlzdG9yeVN0YXRlKSA9PiBoaXN0b3J5Q29udHJvbGxlci5jb21taXRBcHBPd25lZEhpc3RvcnlTdGF0ZVdyaXRlKGhpc3RvcnlVcGRhdGVNb2RlLCBwcmV2aW91c0hpc3RvcnlTdGF0ZSksXG5cdFx0ZGlzY2FyZFBlbmRpbmdOYXZpZ2F0aW9uOiAoKSA9PiB7XG5cdFx0XHRpZiAoYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmRpc2NhcmRQZW5kaW5nTmF2aWdhdGlvbihoaXN0b3J5Q29udHJvbGxlci5yZWFkQ3VycmVudFRyZWVTbmFwc2hvdCgpKSkgbmF2aWdhdGlvbkFib3J0Q29vcmRpbmF0b3IuYWJvcnRBY3RpdmUoKTtcblx0XHR9LFxuXHRcdGZsdXNoQ29tbWl0dGluZ05hdmlnYXRpb25Vcmw6ICgpID0+IGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5mbHVzaENvbW1pdHRpbmdOYXZpZ2F0aW9uVXJsKClcblx0fSk7XG5cdGNvbnN0IGhhbmRsZVBvcHN0YXRlID0gY3JlYXRlUG9wc3RhdGVSZXN0b3JlSGFuZGxlcih7XG5cdFx0Z2V0QWN0aXZlTmF2aWdhdGlvbklkOiBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuZ2V0QWN0aXZlTmF2aWdhdGlvbklkLmJpbmQoYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyKSxcblx0XHRnZXRQZW5kaW5nTmF2aWdhdGlvbjogKCkgPT4gd2luZG93Ll9fVklORVhUX1JTQ19QRU5ESU5HX18sXG5cdFx0Z2V0TmF2aWdhdGU6ICgpID0+IGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5uYXZpZ2F0ZSxcblx0XHRpc0N1cnJlbnROYXZpZ2F0aW9uOiBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbi5iaW5kKGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlciksXG5cdFx0bm90aWZ5QXBwUm91dGVyVHJhbnNpdGlvblN0YXJ0OiAoaHJlZikgPT4ge1xuXHRcdFx0bm90aWZ5QXBwUm91dGVyVHJhbnNpdGlvblN0YXJ0KGhyZWYsIFwidHJhdmVyc2VcIik7XG5cdFx0fSxcblx0XHRyZXN0b3JlUG9wc3RhdGVTY3JvbGxQb3NpdGlvbixcblx0XHRzZXRQZW5kaW5nTmF2aWdhdGlvbjogKHBlbmRpbmdOYXZpZ2F0aW9uKSA9PiB7XG5cdFx0XHR3aW5kb3cuX19WSU5FWFRfUlNDX1BFTkRJTkdfXyA9IHBlbmRpbmdOYXZpZ2F0aW9uO1xuXHRcdH0sXG5cdFx0c2hvdWxkU2tpcFNjcm9sbFJlc3RvcmU6IChuYXZJZCkgPT4gc3luY2hyb25vdXNQb3BzdGF0ZVNjcm9sbFJlc3RvcmVOYXZpZ2F0aW9uSWQgPT09IG5hdklkXG5cdH0pO1xuXHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBvcHN0YXRlXCIsIChldmVudCkgPT4ge1xuXHRcdGNvbnN0IGhyZWYgPSB3aW5kb3cubG9jYXRpb24uaHJlZjtcblx0XHRjb25zdCBpc0V4dGVybmFsSGlzdG9yeUVudHJ5ID0gaXNFeHRlcm5hbEhpc3RvcnlTdGF0ZShldmVudC5zdGF0ZSk7XG5cdFx0aWYgKHNob3VsZENvbW1pdFBvcHN0YXRlVXJsV2l0aG91dE5hdmlnYXRpb24oe1xuXHRcdFx0aGlzdG9yeVN0YXRlOiBldmVudC5zdGF0ZSxcblx0XHRcdGlzQ3VycmVudEV4dGVybmFsSGlzdG9yeVRyZWU6IGhpc3RvcnlDb250cm9sbGVyLmlzQ3VycmVudEV4dGVybmFsSGlzdG9yeVRyZWUoZXZlbnQuc3RhdGUpLFxuXHRcdFx0aXNTYW1lQXBwUm91dGVUYXJnZXQ6IGlzU2FtZUFwcFJvdXRlUG9wc3RhdGVUYXJnZXQoaHJlZilcblx0XHR9KSkge1xuXHRcdFx0bm90aWZ5QXBwUm91dGVyVHJhbnNpdGlvblN0YXJ0KGhyZWYsIFwidHJhdmVyc2VcIik7XG5cdFx0XHRoaXN0b3J5Q29udHJvbGxlci5jb21taXRUcmF2ZXJzYWxJbmRleEZyb21IaXN0b3J5U3RhdGUoZXZlbnQuc3RhdGUpO1xuXHRcdFx0Y29tbWl0Q2xpZW50TmF2aWdhdGlvblN0YXRlKCk7XG5cdFx0XHRyZXN0b3JlUG9wc3RhdGVTY3JvbGxQb3NpdGlvbihldmVudC5zdGF0ZSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGNvbnN0IHNuYXBzaG90TmF2aWdhdGlvbklkID0gYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmJlZ2luTmF2aWdhdGlvbigpO1xuXHRcdGlmIChyZXN0b3JlSGlzdG9yeVN0YXRlU25hcHNob3QoZXZlbnQuc3RhdGUsIHNuYXBzaG90TmF2aWdhdGlvbklkLCAoKSA9PiB7XG5cdFx0XHRuYXZpZ2F0aW9uQWJvcnRDb29yZGluYXRvci5hYm9ydEFjdGl2ZSgpO1xuXHRcdFx0bm90aWZ5QXBwUm91dGVyVHJhbnNpdGlvblN0YXJ0KGhyZWYsIFwidHJhdmVyc2VcIik7XG5cdFx0fSwgaXNFeHRlcm5hbEhpc3RvcnlFbnRyeSkpIHtcblx0XHRcdHdpbmRvdy5fX1ZJTkVYVF9SU0NfUEVORElOR19fID0gbnVsbDtcblx0XHRcdHJlc3RvcmVTeW5jaHJvbm91c1BvcHN0YXRlU2Nyb2xsUG9zaXRpb24oe1xuXHRcdFx0XHRnZXRBY3RpdmVOYXZpZ2F0aW9uSWQ6ICgpID0+IGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5nZXRBY3RpdmVOYXZpZ2F0aW9uSWQoKSxcblx0XHRcdFx0aXNDdXJyZW50TmF2aWdhdGlvbjogKG5hdklkKSA9PiBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaXNDdXJyZW50TmF2aWdhdGlvbihuYXZJZCksXG5cdFx0XHRcdG1hcmtTY3JvbGxSZXN0b3JlQ29uc3VtZWQ6IChuYXZJZCkgPT4ge1xuXHRcdFx0XHRcdHN5bmNocm9ub3VzUG9wc3RhdGVTY3JvbGxSZXN0b3JlTmF2aWdhdGlvbklkID0gbmF2SWQ7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlc3RvcmVQb3BzdGF0ZVNjcm9sbFBvc2l0aW9uXG5cdFx0XHR9LCBldmVudC5zdGF0ZSk7XG5cdFx0XHRicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuZmluYWxpemVOYXZpZ2F0aW9uKHNuYXBzaG90TmF2aWdhdGlvbklkLCBudWxsKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0YnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmZpbmFsaXplTmF2aWdhdGlvbihzbmFwc2hvdE5hdmlnYXRpb25JZCwgbnVsbCk7XG5cdFx0aGFuZGxlUG9wc3RhdGUoZXZlbnQpO1xuXHR9KTtcblx0aWYgKGltcG9ydC5tZXRhLmVudi5ERVYgJiYgaW1wb3J0Lm1ldGEuaG90KSB7XG5cdFx0Y29uc3QgYXBwbHlSc2NIbXJVcGRhdGUgPSBhc3luYyAodXBkYXRlSWQpID0+IHtcblx0XHRcdGlmICh1cGRhdGVJZCAhPT0gbGF0ZXN0UnNjSG1yVXBkYXRlSWQpIHJldHVybjtcblx0XHRcdGlmIChkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuaWQgPT09IFwiX19uZXh0X2Vycm9yX19cIikge1xuXHRcdFx0XHR3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGlmIChicm93c2VyUm91dGVyU3RhdGVIYXNFdmVyQ29tbWl0dGVkICYmICFicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaGFzQnJvd3NlclJvdXRlclN0YXRlKCkpIHtcblx0XHRcdFx0d2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRhd2FpdCB3YWl0Rm9yQnJvd3NlclJvdXRlclN0YXRlUmVhZHkoKTtcblx0XHRcdGlmICh1cGRhdGVJZCAhPT0gbGF0ZXN0UnNjSG1yVXBkYXRlSWQpIHJldHVybjtcblx0XHRcdGlmICghYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmhhc0Jyb3dzZXJSb3V0ZXJTdGF0ZSgpKSByZXR1cm47XG5cdFx0XHRjbGVhckNsaWVudE5hdmlnYXRpb25DYWNoZXMoKTtcblx0XHRcdGRldkVycm9yT3ZlcmxheT8uZGlzbWlzc092ZXJsYXkoKTtcblx0XHRcdGNvbnN0IGhtckhlYWRlcnMgPSBjcmVhdGVSc2NSZXF1ZXN0SGVhZGVycyh7IG1vdW50ZWRTbG90c0hlYWRlcjogZ2V0TW91bnRlZFNsb3RJZHNIZWFkZXIoYnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLmdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpLmVsZW1lbnRzKSB9KTtcblx0XHRcdGNvbnN0IGhtckhyZWYgPSB3aW5kb3cubG9jYXRpb24uaHJlZjtcblx0XHRcdGNvbnN0IGhtclBhcmFtcyA9IGxhdGVzdENsaWVudFBhcmFtcztcblx0XHRcdGNvbnN0IHNhbWVRdWVyeVNuYXBzaG90ID0gd2l0aFJlbmRlcmVkU2VhcmNoT2YoY3JlYXRlQ2xpZW50TmF2aWdhdGlvblJlbmRlclNuYXBzaG90KGhtckhyZWYsIGhtclBhcmFtcyksIGJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlci5nZXRCcm93c2VyUm91dGVyU3RhdGUoKS5uYXZpZ2F0aW9uU25hcHNob3QpO1xuXHRcdFx0Y29uc3QgaG1yUmVzcG9uc2UgPSBmZXRjaChhd2FpdCBjcmVhdGVSc2NSZXF1ZXN0VXJsKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSArIHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gsIGhtckhlYWRlcnMpLCB7IGhlYWRlcnM6IGhtckhlYWRlcnMgfSk7XG5cdFx0XHRhd2FpdCBicm93c2VyTmF2aWdhdGlvbkNvbnRyb2xsZXIuaG1yUmVwbGFjZVRyZWUoZGVjb2RlQXBwRWxlbWVudHNQcm9taXNlKGNyZWF0ZUZyb21GZXRjaChobXJSZXNwb25zZS50aGVuKHN0cmlwUnNjQ29tcGxldGlvbk1ldGFkYXRhUmVzcG9uc2UpKSksIGhtclJlc3BvbnNlLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlbmRlcmVkUGF0aEFuZFNlYXJjaCA9IHBhcnNlUmVuZGVyZWRQYXRoQW5kU2VhcmNoSGVhZGVyKHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFZJTkVYVF9SRU5ERVJFRF9QQVRIX0FORF9TRUFSQ0hfSEVBREVSKSk7XG5cdFx0XHRcdHJldHVybiByZW5kZXJlZFBhdGhBbmRTZWFyY2ggPT09IG51bGwgPyBzYW1lUXVlcnlTbmFwc2hvdCA6IGNyZWF0ZUNsaWVudE5hdmlnYXRpb25SZW5kZXJTbmFwc2hvdChobXJIcmVmLCBobXJQYXJhbXMsIHJlbmRlcmVkUGF0aEFuZFNlYXJjaCk7XG5cdFx0XHR9KSk7XG5cdFx0fTtcblx0XHRjb25zdCBoYW5kbGVSc2NVcGRhdGUgPSBhc3luYyAodXBkYXRlSWQpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHdhaXRGb3JSc2NIbXJTZXR0bGUoKTtcblx0XHRcdFx0YXdhaXQgYXBwbHlSc2NIbXJVcGRhdGUodXBkYXRlSWQpO1xuXHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdFx0Y29uc29sZS5lcnJvcihcIlt2aW5leHRdIFJTQyBITVIgZXJyb3I6XCIsIGVycm9yKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdGltcG9ydC5tZXRhLmhvdC5vbihcInJzYzp1cGRhdGVcIiwgKCkgPT4ge1xuXHRcdFx0Y29uc3QgdXBkYXRlSWQgPSArK2xhdGVzdFJzY0htclVwZGF0ZUlkO1xuXHRcdFx0aGFuZGxlUnNjVXBkYXRlKHVwZGF0ZUlkKTtcblx0XHR9KTtcblx0fVxufVxuaWYgKHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIikge1xuXHRpbnN0YWxsV2luZG93TmV4dCh7XG5cdFx0YXBwRGlyOiB0cnVlLFxuXHRcdHJvdXRlcjogYXBwUm91dGVySW5zdGFuY2Vcblx0fSk7XG5cdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgKCkgPT4ge1xuXHRcdGlzUGFnZVVubG9hZGluZyA9IHRydWU7XG5cdH0pO1xuXHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VzaG93XCIsIChldmVudCkgPT4ge1xuXHRcdGlzUGFnZVVubG9hZGluZyA9IGZhbHNlO1xuXHRcdGlmIChldmVudC5wZXJzaXN0ZWQpIHtcblx0XHRcdG1wYU5hdmlnYXRpb25TY2hlZHVsZXIucmVzZXQoKTtcblx0XHRcdG1wYU5hdmlnYXRpb25UcmVlPy5yZXN0b3JlKCk7XG5cdFx0XHRtcGFOYXZpZ2F0aW9uUmVzdG9yZT8ucmVzb2x2ZSgpO1xuXHRcdFx0bXBhTmF2aWdhdGlvblJlc3RvcmUgPSBudWxsO1xuXHRcdH1cblx0fSk7XG5cdG1haW4oKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHt9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=