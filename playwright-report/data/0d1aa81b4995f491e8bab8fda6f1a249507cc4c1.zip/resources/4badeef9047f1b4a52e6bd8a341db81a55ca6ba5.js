const React$1 = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport32_react, 1);import { isBotUserAgent } from "/node_modules/vinext/dist/utils/html-limited-bots.js?v=b41becdd";
import { isExternalUrl } from "/node_modules/vinext/dist/utils/external-url.js?v=b41becdd";
import { stripBasePath } from "/node_modules/vinext/dist/utils/base-path.js?v=b41becdd";
import { NEXT_ROUTER_PREFETCH_HEADER, NEXT_ROUTER_SEGMENT_PREFETCH_HEADER, VINEXT_INTERCEPTION_CONTEXT_HEADER, VINEXT_MOUNTED_SLOTS_HEADER, VINEXT_RSC_RENDER_MODE_HEADER } from "/node_modules/vinext/dist/server/app-rsc-vary.js?v=b41becdd";
import { NEXT_ROUTER_STALE_TIME_HEADER, VINEXT_DYNAMIC_STALE_TIME_HEADER, VINEXT_PARAMS_HEADER, VINEXT_RENDERED_PATH_AND_SEARCH_HEADER, VINEXT_RSC_COMPLETION_METADATA_HEADER, VINEXT_RSC_REDIRECT_HEADER, VINEXT_RSC_REDIRECT_TYPE_HEADER, VINEXT_STALE_TIME_PENDING_HEADER } from "/node_modules/vinext/dist/server/headers.js?v=b41becdd";
import { assertSafeNavigationUrl } from "/node_modules/vinext/dist/shims/url-safety.js?v=b41becdd";
import { APP_RSC_RENDER_MODE_PREFETCH_DYNAMIC_SHELL, APP_RSC_RENDER_MODE_PREFETCH_LOADING_SHELL } from "/node_modules/vinext/dist/server/app-rsc-render-mode.js?v=b41becdd";
import { getPprFallbackShellState, markPprFallbackShellDynamicBoundary } from "/node_modules/vinext/dist/shims/ppr-fallback-shell.js?v=b41becdd";
import { AppRouterContext } from "/node_modules/vinext/dist/shims/internal/app-router-context.js?v=b41becdd";
import { resolveDirectHybridClientRouteOwner } from "/node_modules/vinext/dist/shims/internal/hybrid-client-route-owner-direct.js?v=b41becdd";
import { isHashOnlyBrowserUrlChange, toCanonicalBrowserNavigationHref, toSameOriginAppPath, withBasePath } from "/node_modules/vinext/dist/shims/url-utils.js?v=b41becdd";
import { disableSmoothScrollDuringRouteTransition } from "/node_modules/vinext/dist/shims/disable-smooth-scroll.js?v=b41becdd";
import { retryScrollTo, scrollToHashTarget } from "/node_modules/vinext/dist/shims/hash-scroll.js?v=b41becdd";
import { VINEXT_RSC_COMPATIBILITY_ID_HEADER, VINEXT_RSC_CONTENT_TYPE, createRscRequestHeaders, createRscRequestUrl, formatRscRequestPath, parseRscRequestPath, stripRscCacheBustingSearchParam } from "/node_modules/vinext/dist/server/app-rsc-cache-busting.js?v=b41becdd";
import { clearAppNavigationFailureTarget, stageAppNavigationFailureTarget } from "/node_modules/vinext/dist/client/app-nav-failure-handler.js?v=b41becdd";
import { notifyAppRouterTransitionStart } from "/node_modules/vinext/dist/client/instrumentation-client-state.js?v=b41becdd";
import { getNavigationRuntime, hasAppNavigationRuntime, loadNavigationRuntimeRouteManifest } from "/node_modules/vinext/dist/client/navigation-runtime.js?v=b41becdd";
import { UnrecognizedActionError, unstable_isUnrecognizedActionError } from "/node_modules/vinext/dist/shims/unrecognized-action-error.js?v=b41becdd";
import { AppElementsWire } from "/node_modules/vinext/dist/server/app-elements-wire.js?v=b41becdd";
import "/node_modules/vinext/dist/server/app-elements.js?v=b41becdd";
import { PUBLIC_INITIAL_BFCACHE_ID } from "/node_modules/vinext/dist/server/app-bfcache-id.js?v=b41becdd";
import { resolveManifestNavigationInterceptionContext } from "/node_modules/vinext/dist/server/app-browser-interception-context.js?v=b41becdd";
import { createExternalHistoryStatePreservingMetadata, createHashOnlyHistoryStatePreservingNavigationMetadata, isAppOwnedHistoryState, readHistoryStateTraversalIndex } from "/node_modules/vinext/dist/server/app-history-state.js?v=b41becdd";
import { hasPendingAppRouterPageRedirect } from "/node_modules/vinext/dist/server/app-browser-mpa-navigation.js?v=b41becdd";
import { extractRscCompletionMetadata } from "/node_modules/vinext/dist/server/rsc-completion-metadata.js?v=b41becdd";
import { navigationPlanner } from "/node_modules/vinext/dist/server/navigation-planner.js?v=b41becdd";
import { ReadonlyURLSearchParams } from "/node_modules/vinext/dist/shims/readonly-url-search-params.js?v=b41becdd";
import { BailoutToCSRError, DynamicServerError, HTTP_ERROR_FALLBACK_ERROR_CODE, RedirectType, decodeRedirectError, forbidden, getAccessFallbackHTTPStatus, isBailoutToCSRError, isDynamicServerError, isHTTPAccessFallbackError, isNextRouterError, isRedirectError, notFound, permanentRedirect, redirect, unauthorized, unstable_rethrow } from "/node_modules/vinext/dist/shims/navigation-errors.js?v=b41becdd";
import { getPagesNavigationContext } from "/node_modules/vinext/dist/shims/internal/pages-router-accessor.js?v=b41becdd";
import { beginAppRouterScrollIntent, clearAppRouterScrollIntent, consumeAppRouterScrollIntent, getPendingAppRouterScrollIntent, isLatestAppRouterScrollIntent } from "/node_modules/vinext/dist/shims/app-router-scroll-state.js?v=b41becdd";
import { GLOBAL_ACCESSORS_KEY, ServerInsertedHTMLContext, _registerStateAccessors, clearClientHydrationContext, clearServerInsertedHTML, flushServerInsertedHTML, getBfcacheIdMapContext, getBfcacheSegmentIdContext, getLayoutSegmentContext, getNavigationContext, registerServerInsertedHTMLCallback, renderServerInsertedHTML, setNavigationContext } from "/node_modules/vinext/dist/shims/navigation-context-state.js?v=b41becdd";
import { cancelAppPrefetchFetch, promoteAppPrefetchFetch, releaseAppPrefetchFetchSlot, scheduleAppPrefetchFetch } from "/node_modules/vinext/dist/shims/internal/app-prefetch-fetch-queue.js?v=b41becdd";
import __vite__cjsImport32_react from "/node_modules/.vite/deps/react.js?v=b41becdd";
//#region src/shims/navigation.ts
/**
* next/navigation shim
*
* App Router navigation hooks. These work on both server (RSC) and client.
* Server-side: reads from a request context set by the RSC handler.
* Client-side: reads from browser Location API and provides navigation.
*/
const HAS_PAGES_ROUTER = process.env.__VINEXT_HAS_PAGES_ROUTER !== "false";
const HAS_CLIENT_REWRITES = process.env.__VINEXT_HAS_CLIENT_REWRITES !== "false";
let hybridClientRouteOwnerModule = null;
let hybridClientRouteOwnerModulePromise = null;
/** Load rewrite-aware hybrid route ownership before navigation becomes interactive. */
async function preloadHybridClientRouteOwner() {
	if (hybridClientRouteOwnerModule) return;
	hybridClientRouteOwnerModulePromise ??= import("/node_modules/vinext/dist/shims/internal/hybrid-client-route-owner.js?v=b41becdd");
	hybridClientRouteOwnerModule = await hybridClientRouteOwnerModulePromise;
}
function resolveLoadedHybridClientRewriteHref(href, basePath) {
	return hybridClientRouteOwnerModule?.resolveHybridClientRewriteHref(href, basePath) ?? null;
}
function resolveHybridClientRouteOwner(href) {
	if (!HAS_PAGES_ROUTER) return null;
	return hybridClientRouteOwnerModule ? hybridClientRouteOwnerModule.resolveHybridClientRouteOwner(href, __basePath) : resolveDirectHybridClientRouteOwner(href, __basePath);
}
/**
* Read the child segments for a parallel route below the current layout.
* Returns [] if no context is available (RSC environment, outside React tree)
* or if the requested key is not present in the segment map.
*/
function useChildSegments(parallelRoutesKey = "children") {
	const ctx = getLayoutSegmentContext();
	if (!ctx) return [];
	try {
		return (React$1.useContext(ctx)[parallelRoutesKey] ?? []).filter((segment) => !segment.startsWith("__PAGE__"));
	} catch {
		return [];
	}
}
const _READONLY_SEARCH_PARAMS = Symbol.for("vinext.navigation.readonlySearchParams");
const _READONLY_SEARCH_PARAMS_SOURCE = Symbol.for("vinext.navigation.readonlySearchParamsSource");
const _READONLY_SEARCH_PARAMS_SOURCE_KEY = Symbol.for("vinext.navigation.readonlySearchParamsSourceKey");
const PAGES_NAVIGATION_NOTIFY_KEY = Symbol.for("vinext.navigation.pagesNavigationNotify");
const isServer = typeof window === "undefined";
/** basePath from next.config.js, injected by the plugin at build time */
const __basePath = process.env.__NEXT_ROUTER_BASEPATH ?? "";
/** trailingSlash from next.config.js, injected by the plugin at build time */
const __trailingSlash = process.env.__VINEXT_TRAILING_SLASH === "true";
/** prefetch inlining (Segment Cache wire mode), injected by the plugin at build time */
const __prefetchInlining = process.env.__VINEXT_PREFETCH_INLINING === "true";
/** Maximum buffered bytes in the RSC prefetch cache. Mirrors Next.js' 50 MB LRU. */
const MAX_PREFETCH_CACHE_SIZE = 52428800;
const PREFETCH_CACHE_EVICTION_TARGET_SIZE = MAX_PREFETCH_CACHE_SIZE * .9;
/**
* TTL for prefetch cache entries in ms.
*
* Mirrors Next.js' `STATIC_STALETIME_MS` derivation. The plugin injects
* `process.env.__NEXT_CLIENT_ROUTER_STATIC_STALETIME` from
* `experimental.staleTimes.static` (in seconds) at build time; we convert
* to ms here.
*
* Falls back to vinext's historical default of 30s when the env var is
* absent (e.g. unit tests that import this module without going through
* the plugin's `define` pipeline). When the plugin is active and the user
* has not set `experimental.staleTimes`, Next.js' 300s default applies
* (see `resolveStaleTimes` in `config/next-config.ts`).
*/
function resolveClientRouterStaleTime(raw, fallbackMs) {
	if (raw === void 0 || raw === "") return fallbackMs;
	const seconds = Number(raw);
	if (!Number.isFinite(seconds) || seconds < 0) return fallbackMs;
	return seconds * 1e3;
}
const DYNAMIC_NAVIGATION_CACHE_TTL = resolveClientRouterStaleTime(process.env.__NEXT_CLIENT_ROUTER_DYNAMIC_STALETIME, 3e4);
const PREFETCH_CACHE_TTL = resolveClientRouterStaleTime(process.env.__NEXT_CLIENT_ROUTER_STATIC_STALETIME, 3e4);
/**
* Floor for any server-declared `cacheLife` stale time, mirroring Next.js's
* `getStaleTimeMs` (`Math.max(staleTimeSeconds, 30) * 1000`). One rule for
* both client caches, so behavior does not depend on which cache a route hit.
*/
const MIN_SERVER_STALE_TIME_SECONDS = 30;
const MIN_PREFETCH_STALE_TIME_MS = MIN_SERVER_STALE_TIME_SECONDS * 1e3;
function getCurrentInterceptionContext() {
	if (isServer) return null;
	return stripBasePath(window.location.pathname, __basePath);
}
function getPrefetchInterceptionContext(targetHref, currentPathname) {
	if (isServer) return null;
	let targetUrl;
	try {
		targetUrl = new URL(targetHref, window.location.href);
	} catch {
		return null;
	}
	return resolveManifestNavigationInterceptionContext({
		basePath: __basePath,
		currentPathname: currentPathname ?? window.location.pathname,
		routeManifest: getNavigationRuntime()?.bootstrap.routeManifest ?? null,
		targetPathname: targetUrl.pathname
	});
}
function getCurrentNextUrl() {
	if (isServer) return "/";
	return window.location.pathname + window.location.search;
}
function createAppPrefetchRequestHeaders(options) {
	const prefetchRouterState = getNavigationRuntime()?.functions.getPrefetchRouterState?.() ?? null;
	return createRscRequestHeaders({
		...options,
		nextUrl: getCurrentNextUrl(),
		includePrefetchHeader: options.prefetchKind !== "full",
		prefetchRouterState
	});
}
/** Get or create the shared in-memory RSC prefetch cache on window. */
function getPrefetchCache() {
	if (isServer) return /* @__PURE__ */ new Map();
	if (!window.__VINEXT_RSC_PREFETCH_CACHE__) window.__VINEXT_RSC_PREFETCH_CACHE__ = /* @__PURE__ */ new Map();
	return window.__VINEXT_RSC_PREFETCH_CACHE__;
}
/**
* Read an exact prefetch entry without allowing a settled stale value to
* steer a later request. Timers are an eviction optimization, not a freshness
* guarantee: background throttling can leave an expired route-tree entry in
* the Map until the next foreground read.
*/
function getFreshPrefetchCacheEntry(cacheKey) {
	const cache = getPrefetchCache();
	const entry = cache.get(cacheKey);
	if (entry === void 0 || entry.pending) return entry;
	if (resolvePrefetchCacheEntryExpiresAt(entry) > Date.now()) return entry;
	deletePrefetchCacheEntry(cache, getPrefetchedUrls(), cacheKey, entry, true);
}
/**
* Get or create the shared set of already-prefetched RSC URLs on window.
* Keyed by interception-aware cache key so distinct source routes do not alias.
*/
function getPrefetchedUrls() {
	if (isServer) return /* @__PURE__ */ new Set();
	if (!window.__VINEXT_RSC_PREFETCHED_URLS__) window.__VINEXT_RSC_PREFETCHED_URLS__ = /* @__PURE__ */ new Set();
	return window.__VINEXT_RSC_PREFETCHED_URLS__;
}
function isStaleTimeSeconds(value) {
	return typeof value === "number" && Number.isFinite(value) && Number.isInteger(value) && value >= 0;
}
function isCacheExpiresAt(value) {
	return typeof value === "number" && Number.isFinite(value) && value >= 0;
}
function parseStaleTimeSecondsHeader(value) {
	if (value === null || value === "") return void 0;
	const seconds = Number(value);
	return isStaleTimeSeconds(seconds) ? seconds : void 0;
}
/**
* The floor a `cacheLife` claim licenses. A pending claim contributes exactly
* the floor — the least any resolution of it could have granted.
*/
function serverStaleTimeSeconds(server) {
	if (server === void 0) return void 0;
	if (server.kind === "pending") return MIN_SERVER_STALE_TIME_SECONDS;
	return Math.max(server.seconds, MIN_SERVER_STALE_TIME_SECONDS);
}
/**
* Min-combine the two independent staleness lattices a response can carry:
* `dynamicStaleTimeSeconds` (from `experimental.staleTimes` config) and
* `serverStaleTime` (from the render's `cacheLife`) — neither may override
* the other. The cacheLife value is floored *before* the min so the floor
* never raises the config bound. Undefined = no signal; the caller's
* fallback TTL stays in force.
*/
function resolveRscResponseStaleTimeSeconds(cached) {
	const dynamic = cached.dynamicStaleTimeSeconds;
	const server = serverStaleTimeSeconds(cached.serverStaleTime);
	if (!isStaleTimeSeconds(dynamic)) return server;
	return server === void 0 ? dynamic : Math.min(dynamic, server);
}
function resolveCachedRscResponseTtlMs(cached, fallbackTtlMs) {
	const seconds = resolveRscResponseStaleTimeSeconds(cached);
	if (seconds === void 0) return fallbackTtlMs;
	return seconds * 1e3;
}
function resolveCachedRscResponseExpiresAt(timestamp, cached, fallbackTtlMs) {
	if (isCacheExpiresAt(cached.expiresAt)) return cached.expiresAt;
	return timestamp + resolveCachedRscResponseTtlMs(cached, fallbackTtlMs);
}
function resolvePrefetchedRscResponseExpiresAt(timestamp, cached, fallbackTtlMs, dynamicStaleTime) {
	if (isCacheExpiresAt(cached.expiresAt)) return cached.expiresAt;
	const serverSeconds = cached.serverStaleTime?.kind === "pending" && dynamicStaleTime !== "verbatim" ? void 0 : serverStaleTimeSeconds(cached.serverStaleTime);
	if (serverSeconds !== void 0) return timestamp + serverSeconds * 1e3;
	if (dynamicStaleTime === "ignore") return timestamp + Math.max(fallbackTtlMs, MIN_PREFETCH_STALE_TIME_MS);
	const seconds = isStaleTimeSeconds(cached.dynamicStaleTimeSeconds) ? cached.dynamicStaleTimeSeconds : void 0;
	if (seconds === void 0) return timestamp + Math.max(fallbackTtlMs, MIN_PREFETCH_STALE_TIME_MS);
	return dynamicStaleTime === "verbatim" ? timestamp + seconds * 1e3 : timestamp + (seconds === 0 ? Math.max(fallbackTtlMs, MIN_PREFETCH_STALE_TIME_MS) : Math.max(seconds * 1e3, MIN_PREFETCH_STALE_TIME_MS));
}
function resolvePrefetchCacheEntryExpiresAt(entry) {
	if (entry.expiresAt !== void 0) return entry.expiresAt;
	if (entry.snapshot) return resolveCachedRscResponseExpiresAt(entry.timestamp, entry.snapshot, PREFETCH_CACHE_TTL);
	return entry.timestamp + PREFETCH_CACHE_TTL;
}
function resolvePrefetchCacheEntryMountedSlotsHeader(entry) {
	if (entry.mountedSlotsHeader !== void 0) return entry.mountedSlotsHeader;
	return entry.snapshot?.mountedSlotsHeader ?? null;
}
function normalizeRscCacheLookupUrl(rscUrl) {
	try {
		const url = parseRscRequestPath(rscUrl);
		stripRscCacheBustingSearchParam(url);
		return `${url.pathname}${url.search}`;
	} catch {
		return null;
	}
}
function normalizeRscCacheLookupPathname(rscUrl) {
	try {
		return parseRscRequestPath(rscUrl).pathname;
	} catch {
		return null;
	}
}
function parsePrefetchCacheKey(cacheKey) {
	const separatorIndex = cacheKey.indexOf("\0");
	if (separatorIndex === -1) return {
		interceptionContext: null,
		rscUrl: cacheKey
	};
	return {
		interceptionContext: cacheKey.slice(separatorIndex + 1),
		rscUrl: cacheKey.slice(0, separatorIndex)
	};
}
function isPrefetchCacheEntryCompatibleWithMountedSlots(entry, mountedSlotsHeader) {
	if (resolvePrefetchCacheEntryMountedSlotsHeader(entry) === mountedSlotsHeader) return true;
	return (entry.snapshot?.mountedSlotsHeader ?? null) === mountedSlotsHeader;
}
function findPrefetchCacheEntryForNavigation(rscUrl, interceptionContext, mountedSlotsHeader, additionalRscUrls = []) {
	const cache = getPrefetchCache();
	const rscUrls = [rscUrl, ...additionalRscUrls];
	for (const lookupRscUrl of rscUrls) {
		const exactCacheKey = AppElementsWire.encodeCacheKey(lookupRscUrl, interceptionContext);
		const exactEntry = cache.get(exactCacheKey);
		if (exactEntry && exactEntry.cacheForNavigation !== false && isPrefetchCacheEntryCompatibleWithMountedSlots(exactEntry, mountedSlotsHeader)) return {
			cacheKey: exactCacheKey,
			entry: exactEntry
		};
	}
	const normalizedTargets = new Set(rscUrls.map((lookupRscUrl) => normalizeRscCacheLookupUrl(lookupRscUrl)).filter((lookupRscUrl) => lookupRscUrl !== null));
	if (normalizedTargets.size === 0) return null;
	for (const [cacheKey, entry] of cache) {
		if (entry.cacheForNavigation === false) continue;
		const source = parsePrefetchCacheKey(cacheKey);
		if (source.interceptionContext !== interceptionContext) continue;
		const normalizedSource = normalizeRscCacheLookupUrl(source.rscUrl);
		if (normalizedSource === null || !normalizedTargets.has(normalizedSource)) continue;
		if (!isPrefetchCacheEntryCompatibleWithMountedSlots(entry, mountedSlotsHeader)) continue;
		return {
			cacheKey,
			entry
		};
	}
	return null;
}
function hasPrefetchCacheEntryForNavigation(rscUrl, interceptionContext = null, mountedSlotsHeader = null, options = {}) {
	const match = findPrefetchCacheEntryForNavigation(rscUrl, interceptionContext, mountedSlotsHeader, options.additionalRscUrls);
	if (match === null) return false;
	if (match.entry.pending !== void 0 && options.reusePending === false) return false;
	if (match.entry.pending !== void 0 || resolvePrefetchCacheEntryExpiresAt(match.entry) > Date.now()) {
		touchPrefetchCacheEntry(getPrefetchCache(), match.cacheKey, match.entry);
		attachPrefetchInvalidationToEntry(match.cacheKey, match.entry, options.onInvalidate);
		options.onReuse?.(match.entry, match.cacheKey);
		return true;
	}
	deletePrefetchCacheEntry(getPrefetchCache(), getPrefetchedUrls(), match.cacheKey, match.entry, options.notifyInvalidation ?? true);
	return false;
}
/**
* Return whether the exact learning-only Link prefetch is still usable.
* Pending entries dedupe concurrent Links; settled entries only suppress a
* remount while their response-derived freshness window remains active.
*/
function hasFreshLearningOnlyPrefetchCacheEntry(rscUrl, interceptionContext = null) {
	const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	const cache = getPrefetchCache();
	const entry = cache.get(cacheKey);
	if (entry?.cacheForNavigation !== false) return false;
	if (entry.pending !== void 0 || resolvePrefetchCacheEntryExpiresAt(entry) > Date.now()) {
		touchPrefetchCacheEntry(cache, cacheKey, entry);
		return true;
	}
	deletePrefetchCacheEntry(cache, getPrefetchedUrls(), cacheKey, entry, true);
	return false;
}
function hasSearchAgnosticPrefetchShellForRoute(rscUrl, interceptionContext = null, mountedSlotsHeader = null) {
	const normalizedTargetPathname = normalizeRscCacheLookupPathname(rscUrl);
	if (normalizedTargetPathname === null) return false;
	const cache = getPrefetchCache();
	for (const [cacheKey, entry] of cache) {
		if (entry.searchAgnosticShell !== true) continue;
		const source = parsePrefetchCacheKey(cacheKey);
		if (source.interceptionContext !== interceptionContext) continue;
		if (normalizeRscCacheLookupPathname(source.rscUrl) !== normalizedTargetPathname) continue;
		if (!isPrefetchCacheEntryCompatibleWithMountedSlots(entry, mountedSlotsHeader)) continue;
		if (entry.pending !== void 0) return true;
		if (resolvePrefetchCacheEntryExpiresAt(entry) > Date.now()) return true;
		deletePrefetchCacheEntry(cache, getPrefetchedUrls(), cacheKey, entry, true);
	}
	return false;
}
function getPrefetchCacheEntrySize(entry) {
	return entry.snapshot?.buffer.byteLength ?? entry.size ?? 0;
}
let trackedPrefetchCache = null;
let trackedPrefetchCacheByteSize = 0;
function getPrefetchCacheByteSize(cache) {
	if (trackedPrefetchCache === cache) return trackedPrefetchCacheByteSize;
	let total = 0;
	const seen = /* @__PURE__ */ new Set();
	for (const entry of cache.values()) {
		if (seen.has(entry)) continue;
		seen.add(entry);
		total += getPrefetchCacheEntrySize(entry);
	}
	trackedPrefetchCache = cache;
	trackedPrefetchCacheByteSize = total;
	return total;
}
function adjustPrefetchCacheByteSize(cache, delta) {
	if (trackedPrefetchCache !== cache) return;
	trackedPrefetchCacheByteSize = Math.max(0, trackedPrefetchCacheByteSize + delta);
}
function touchPrefetchCacheEntry(cache, cacheKey, entry) {
	if (cache.get(cacheKey) !== entry) return;
	cache.delete(cacheKey);
	cache.set(cacheKey, entry);
	for (const key of entry.cacheKeys ?? []) {
		if (key === cacheKey || cache.get(key) !== entry) continue;
		cache.delete(key);
		cache.set(key, entry);
	}
}
/**
* Evict prefetch cache entries if buffered payloads exceed the byte budget.
* Sweeps expired entries only after the cheap byte-budget check says cleanup is
* needed, then evicts least-recently-used entries down to the target size.
*/
function evictPrefetchCacheIfNeeded() {
	const cache = getPrefetchCache();
	let totalSize = getPrefetchCacheByteSize(cache);
	if (totalSize <= 52428800) return;
	const now = Date.now();
	const prefetched = getPrefetchedUrls();
	for (const [key, entry] of cache) if (resolvePrefetchCacheEntryExpiresAt(entry) <= now) deletePrefetchCacheEntry(cache, prefetched, key, entry, true);
	totalSize = getPrefetchCacheByteSize(cache);
	if (totalSize <= 52428800) return;
	let inspectedEntries = 0;
	while (totalSize > PREFETCH_CACHE_EVICTION_TARGET_SIZE && inspectedEntries < cache.size) {
		const oldest = cache.keys().next().value;
		if (oldest !== void 0) {
			const entry = cache.get(oldest);
			if (entry) {
				const entrySize = getPrefetchCacheEntrySize(entry);
				if (entry.pending !== void 0 && entrySize === 0) {
					touchPrefetchCacheEntry(cache, oldest, entry);
					inspectedEntries += 1;
					continue;
				}
				totalSize -= entrySize;
				deletePrefetchCacheEntry(cache, prefetched, oldest, entry, true);
				inspectedEntries = 0;
			} else {
				cache.delete(oldest);
				prefetched.delete(oldest);
				inspectedEntries += 1;
			}
		} else break;
	}
}
const pendingPrefetchSetups = /* @__PURE__ */ new Set();
function beginPrefetchSetup(destination) {
	const setup = {
		destination,
		cancelled: false
	};
	pendingPrefetchSetups.add(setup);
	return setup;
}
/** Passing `null` cancels every pending setup regardless of destination. */
function cancelPendingPrefetchSetups(destination) {
	for (const setup of pendingPrefetchSetups) if (destination === null || setup.destination === destination) setup.cancelled = true;
}
/**
* Normalize a navigation or prefetch target to the browser href both sides
* compare on. Returns null when the target is not same-origin — no same-origin
* prefetch can be a duplicate of it — and on the server, where
* `navigateClientSide` can still be reached but there is nothing to cancel.
*/
function toAppPrefetchDestination(href) {
	if (isServer) return null;
	let localHref = href;
	if (isExternalUrl(href)) {
		const localPath = toSameOriginAppPath(href, __basePath);
		if (localPath == null) return null;
		localHref = localPath;
	}
	const browserHref = toCanonicalBrowserNavigationHref(localHref, window.location.href, __basePath, __trailingSlash);
	try {
		return formatRscRequestPath(new URL(browserHref, window.location.href));
	} catch {
		return browserHref.split("#", 1)[0];
	}
}
function clearPrefetchInvalidation(entry) {
	if (entry.invalidationTimer !== void 0) {
		clearTimeout(entry.invalidationTimer);
		entry.invalidationTimer = void 0;
	}
}
function runInvalidationCallback(onInvalidate) {
	try {
		onInvalidate();
	} catch (error) {
		if (typeof reportError === "function") reportError(error);
		else console.error(error);
	}
}
function notifyPrefetchInvalidated(entry) {
	clearPrefetchInvalidation(entry);
	const callbacks = entry.onInvalidateCallbacks;
	entry.onInvalidateCallbacks = void 0;
	if (callbacks === void 0) return;
	for (const onInvalidate of callbacks) runInvalidationCallback(onInvalidate);
}
const retainedPrefetchInvalidations = /* @__PURE__ */ new Set();
function retainPrefetchInvalidationAfterConsume(entry) {
	const callbacks = entry.onInvalidateCallbacks;
	if (callbacks === void 0 || callbacks.size === 0) return;
	retainPrefetchInvalidation(callbacks, resolvePrefetchCacheEntryExpiresAt(entry));
}
function retainPrefetchInvalidation(callbacks, expiresAt, forVisitedResponse = false) {
	const delay = Math.max(0, expiresAt - Date.now());
	const retained = {
		callbacks,
		...forVisitedResponse ? { forVisitedResponse: true } : {},
		timer: setTimeout(() => fireRetainedPrefetchInvalidation(retained), delay)
	};
	retainedPrefetchInvalidations.add(retained);
}
function fireRetainedPrefetchInvalidation(retained) {
	if (!retainedPrefetchInvalidations.delete(retained)) return;
	clearTimeout(retained.timer);
	for (const onInvalidate of retained.callbacks) runInvalidationCallback(onInvalidate);
}
function deletePrefetchCacheEntry(cache, prefetched, cacheKey, entry, notify) {
	const cacheKeys = entry.cacheKeys ?? /* @__PURE__ */ new Set([cacheKey]);
	let removedOwnedKey = false;
	for (const key of cacheKeys) if (cache.get(key) === entry) {
		cache.delete(key);
		prefetched.delete(key);
		removedOwnedKey = true;
	}
	if (!removedOwnedKey) return;
	adjustPrefetchCacheByteSize(cache, -getPrefetchCacheEntrySize(entry));
	entry.cacheKeys = void 0;
	if (notify) notifyPrefetchInvalidated(entry);
	else {
		clearPrefetchInvalidation(entry);
		entry.onInvalidateCallbacks = void 0;
	}
}
function discardLearningOnlyPrefetchCacheEntry(rscUrl, interceptionContext = null, mountedSlotsHeader = null) {
	const cache = getPrefetchCache();
	const prefetched = getPrefetchedUrls();
	const normalizedTarget = normalizeRscCacheLookupUrl(rscUrl);
	if (normalizedTarget === null) return false;
	const superseded = [];
	for (const [cacheKey, entry] of cache) {
		if (entry.cacheForNavigation !== false || entry.prefetchKind !== "navigation") continue;
		const source = parsePrefetchCacheKey(cacheKey);
		if (source.interceptionContext !== interceptionContext) continue;
		if (normalizeRscCacheLookupUrl(source.rscUrl) !== normalizedTarget) continue;
		if (!isPrefetchCacheEntryCompatibleWithMountedSlots(entry, mountedSlotsHeader)) continue;
		superseded.push([cacheKey, entry]);
	}
	for (const [cacheKey, entry] of superseded) {
		cancelAppPrefetchFetch(entry.fetchPromise);
		deletePrefetchCacheEntry(cache, prefetched, cacheKey, entry, true);
	}
	return superseded.length > 0;
}
/**
* Make a prefetch reusable by a navigation, as an `unstable_dynamicOnHover`
* hover does. A pending one that would be kept as learning-only becomes a full
* prefetch and takes the full-prefetch lifetime. One already kept as
* learning-only because its page rendered dynamically is left for the full
* prefetch to replace: Next.js refetches it with `FetchStrategy.Full`, so the
* page reflects the cookies and headers at hover time.
*/
function promotePrefetchCacheEntryForNavigation(cacheKey, entry) {
	if (entry.dynamicStaleTime !== "learning-only") {
		entry.cacheForNavigation = true;
		return;
	}
	if (entry.cacheForNavigation === false) return;
	entry.dynamicStaleTime = "full-prefetch";
	if (entry.snapshot === void 0) return;
	entry.expiresAt = resolvePrefetchedRscResponseExpiresAt(entry.timestamp, entry.snapshot, entry.fallbackTtlMs ?? PREFETCH_CACHE_TTL, "full-prefetch");
	schedulePrefetchInvalidation(cacheKey, entry);
}
function invalidatePrefetchCacheEntry(cacheKey) {
	const cache = getPrefetchCache();
	const entry = cache.get(cacheKey);
	if (!entry) return;
	deletePrefetchCacheEntry(cache, getPrefetchedUrls(), cacheKey, entry, true);
}
function schedulePrefetchInvalidation(cacheKey, entry) {
	if (entry.onInvalidateCallbacks === void 0 || entry.onInvalidateCallbacks.size === 0) return;
	clearPrefetchInvalidation(entry);
	const delay = Math.max(0, resolvePrefetchCacheEntryExpiresAt(entry) - Date.now());
	entry.invalidationTimer = setTimeout(() => {
		invalidatePrefetchCacheEntry(cacheKey);
	}, delay);
}
function addPrefetchInvalidationCallback(entry, onInvalidate) {
	if (onInvalidate === void 0) return;
	if (entry.onInvalidateCallbacks === void 0) entry.onInvalidateCallbacks = /* @__PURE__ */ new Set();
	entry.onInvalidateCallbacks.add(onInvalidate);
}
/**
* Attach `onInvalidate` to an entry the caller already holds. A settled entry
* needs its invalidation timer started here — nothing else will schedule one
* once `prefetchRscResponse` has finished with it.
*/
function attachPrefetchInvalidationToEntry(cacheKey, entry, onInvalidate) {
	if (onInvalidate === void 0) return;
	addPrefetchInvalidationCallback(entry, onInvalidate);
	if (entry.outcome === "cache-seeded") schedulePrefetchInvalidation(cacheKey, entry);
}
function attachPrefetchInvalidationCallback(cacheKey, onInvalidate) {
	if (onInvalidate === void 0) return;
	const entry = getPrefetchCache().get(cacheKey);
	if (!entry) return;
	attachPrefetchInvalidationToEntry(cacheKey, entry, onInvalidate);
}
function invalidatePrefetchCache(options = {}) {
	cancelPendingPrefetchSetups(null);
	const cache = getPrefetchCache();
	const prefetched = getPrefetchedUrls();
	for (const [cacheKey, entry] of cache) deletePrefetchCacheEntry(cache, prefetched, cacheKey, entry, true);
	prefetched.clear();
	for (const retained of retainedPrefetchInvalidations) fireRetainedPrefetchInvalidation(retained);
	if (!isServer && options.pingVisibleLinks !== false) getNavigationRuntime()?.functions.pingVisibleLinks?.();
}
/**
* Evict the prefetch entries that may hold dynamic data, for a Server Action
* that called `refresh()`. Like Next.js's dynamic-only revalidation, which
* evicts its BFCache but keeps its prefetch cache, this keeps route trees,
* static prefetches and full prefetches. It drops navigation responses, and
* automatic prefetches whose page rendered dynamically or hasn't finished
* rendering, including those only kept to learn a route: Next.js's automatic
* prefetches never hold dynamic data.
*/
function invalidateDynamicPrefetchCache() {
	const cache = getPrefetchCache();
	const prefetched = getPrefetchedUrls();
	const evicted = [];
	for (const [cacheKey, entry] of cache) if (!(entry.prefetchKind === "route-tree" || entry.prefetchKind !== void 0 && (entry.dynamicStaleTime === "full-prefetch" || entry.snapshot !== void 0 && !isStaleTimeSeconds(entry.snapshot.dynamicStaleTimeSeconds)))) evicted.push([cacheKey, entry]);
	for (const [cacheKey, entry] of evicted) deletePrefetchCacheEntry(cache, prefetched, cacheKey, entry, true);
}
/**
* Notify the prefetches that stood in for a visited response (see
* `hasNavigationFreshVisitedResponse`), as the visited responses are cleared.
*/
function invalidateVisitedResponsePrefetches() {
	for (const retained of retainedPrefetchInvalidations) if (retained.forVisitedResponse === true) fireRetainedPrefetchInvalidation(retained);
}
/**
* Prevent completed navigation responses from becoming authoritative again
* after restoring a history snapshot. Explicit Link/router prefetches remain
* consumable. Responses with a positive cache lifetime and interception
* responses retain the cache reuse licensed by Next's segment cache.
*/
function disableNavigationResponsePrefetchCacheReuse() {
	let didDemote = false;
	for (const entry of new Set(getPrefetchCache().values())) if (entry.prefetchKind === void 0 && entry.reuseAfterHistoryRestore !== true) {
		didDemote ||= entry.cacheForNavigation !== false;
		entry.cacheForNavigation = false;
	}
	if (didDemote && !isServer) getNavigationRuntime()?.functions.pingVisibleLinks?.();
}
function seedPrefetchResponseSnapshot(rscUrl, snapshot, interceptionContext = null, mountedSlotsHeader = null, fallbackTtlMs = DYNAMIC_NAVIGATION_CACHE_TTL, reuseAfterHistoryRestore = false, expiresAt = resolveCachedRscResponseExpiresAt(Date.now(), snapshot, fallbackTtlMs)) {
	const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	const cache = getPrefetchCache();
	const existing = cache.get(cacheKey);
	if (existing) deletePrefetchCacheEntry(cache, getPrefetchedUrls(), cacheKey, existing, false);
	const timestamp = Date.now();
	const entry = {
		cacheForNavigation: true,
		cacheKeys: /* @__PURE__ */ new Set([cacheKey]),
		expiresAt,
		mountedSlotsHeader,
		outcome: "cache-seeded",
		reuseAfterHistoryRestore,
		size: snapshot.buffer.byteLength,
		snapshot,
		timestamp
	};
	cache.set(cacheKey, entry);
	adjustPrefetchCacheByteSize(cache, snapshot.buffer.byteLength);
	getPrefetchedUrls().add(cacheKey);
	schedulePrefetchInvalidation(cacheKey, entry);
	evictPrefetchCacheIfNeeded();
}
/**
* Fulfill a full prefetch from the visited response of an earlier navigation,
* as Next.js does from its BFCache, instead of issuing a request. The data is
* fresh for the static stale time from the navigation, not the dynamic one
* (`attemptToFulfillDynamicSegmentFromBFCache`).
*/
function seedFullPrefetchFromVisitedResponse(rscUrl, interceptionContext, mountedSlotsHeader, additionalRscUrls = [], onInvalidate) {
	const visited = getNavigationRuntime()?.functions.readVisitedResponseForFullPrefetch?.([rscUrl, ...additionalRscUrls], interceptionContext, mountedSlotsHeader);
	if (!visited) return false;
	const expiresAt = visited.navigatedAt + Math.max(PREFETCH_CACHE_TTL, MIN_PREFETCH_STALE_TIME_MS);
	if (expiresAt <= Date.now()) return false;
	seedPrefetchResponseSnapshot(rscUrl, visited.response, interceptionContext, mountedSlotsHeader, void 0, true, expiresAt);
	const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	if (getPrefetchCache().get(cacheKey)?.snapshot !== visited.response) return false;
	attachPrefetchInvalidationCallback(cacheKey, onInvalidate);
	return true;
}
/**
* Whether a navigation to the URL would reuse the response of an earlier one,
* so a prefetch has nothing to fetch. Like Next.js, whose navigation keeps the
* route and its segments for `staleTimes.dynamic`. `onInvalidate` fires when
* that reuse ends.
*/
function hasNavigationFreshVisitedResponse(rscUrl, interceptionContext, mountedSlotsHeader, additionalRscUrls = [], onInvalidate) {
	const freshUntil = getNavigationRuntime()?.functions.readVisitedResponseForFullPrefetch?.([rscUrl, ...additionalRscUrls], interceptionContext, mountedSlotsHeader)?.navigationFreshUntil;
	if (freshUntil === void 0 || freshUntil === null) return false;
	if (onInvalidate !== void 0) retainPrefetchInvalidation(/* @__PURE__ */ new Set([onInvalidate]), freshUntil, true);
	return true;
}
function deletePrefetchResponseSnapshot(rscUrl, snapshot, interceptionContext = null) {
	const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	const cache = getPrefetchCache();
	const entry = cache.get(cacheKey);
	if (entry?.snapshot !== snapshot) return;
	deletePrefetchCacheEntry(cache, getPrefetchedUrls(), cacheKey, entry, false);
}
/**
* Store a prefetched RSC response in the cache by snapshotting it to an
* ArrayBuffer.  The snapshot completes asynchronously; during that window
* the entry is marked `pending` so consumePrefetchResponse() will skip it
* (the caller falls back to a fresh fetch, which is acceptable).
*
* Prefer prefetchRscResponse() for new call-sites — it handles the full
* prefetch lifecycle including dedup and explicit slot context.
* storePrefetchResponse() is kept for backward compatibility and test
* helpers. It is slot-unaware: the snapshot's mountedSlotsHeader comes
* from the response headers, not the caller, so consumePrefetchResponse
* may reject the entry if the caller's slot context differs.
*
* NB: Caller is responsible for managing getPrefetchedUrls() — this
* function only stores the response in the prefetch cache.
*/
function storePrefetchResponse(rscUrl, response, interceptionContext = null, options) {
	const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	const cache = getPrefetchCache();
	const prefetched = getPrefetchedUrls();
	const existing = cache.get(cacheKey);
	if (existing) deletePrefetchCacheEntry(cache, prefetched, cacheKey, existing, false);
	const entry = {
		cacheKeys: /* @__PURE__ */ new Set([cacheKey]),
		mountedSlotsHeader: null,
		outcome: "pending",
		timestamp: Date.now()
	};
	addPrefetchInvalidationCallback(entry, options?.onInvalidate);
	entry.pending = snapshotRscResponse(response).then((snapshot) => {
		if (cache.get(cacheKey) !== entry) return;
		const previousSize = getPrefetchCacheEntrySize(entry);
		entry.mountedSlotsHeader = snapshot.mountedSlotsHeader ?? null;
		entry.snapshot = snapshot;
		entry.size = snapshot.buffer.byteLength;
		adjustPrefetchCacheByteSize(cache, entry.size - previousSize);
		entry.expiresAt = resolveCachedRscResponseExpiresAt(entry.timestamp, snapshot, PREFETCH_CACHE_TTL);
		evictPrefetchCacheIfNeeded();
	}).catch(() => {
		deletePrefetchCacheEntry(cache, prefetched, cacheKey, entry, false);
	}).finally(() => {
		if (cache.get(cacheKey) !== entry) return;
		entry.pending = void 0;
		if (entry.snapshot) {
			entry.outcome = "cache-seeded";
			schedulePrefetchInvalidation(cacheKey, entry);
		}
	});
	cache.set(cacheKey, entry);
}
function createCachedRscResponseSnapshot(response, buffer, responseUrl = null) {
	const headerDynamicStaleTimeSeconds = parseStaleTimeSecondsHeader(response.headers.get(VINEXT_DYNAMIC_STALE_TIME_HEADER));
	const completionMode = response.headers.get(VINEXT_RSC_COMPLETION_METADATA_HEADER);
	const extracted = completionMode === "1" ? extractRscCompletionMetadata(buffer) : { buffer };
	const completedDynamicStaleTimeSeconds = completionMode === "resolved" ? headerDynamicStaleTimeSeconds : extracted.metadata?.dynamicStaleTimeSeconds ?? headerDynamicStaleTimeSeconds;
	const dynamicStaleTimeSeconds = completedDynamicStaleTimeSeconds ?? headerDynamicStaleTimeSeconds;
	const parsedServerStaleTime = parseServerStaleTimeHeaders(response.headers);
	const serverStaleTime = extracted.metadata !== void 0 && Object.hasOwn(extracted.metadata, "serverStaleTimeSeconds") ? extracted.metadata?.serverStaleTimeSeconds === null ? void 0 : {
		kind: "resolved",
		seconds: extracted.metadata.serverStaleTimeSeconds
	} : parsedServerStaleTime;
	const redirectHeader = response.headers.get(VINEXT_RSC_REDIRECT_HEADER);
	const redirectTypeHeader = response.headers.get(VINEXT_RSC_REDIRECT_TYPE_HEADER);
	return {
		compatibilityIdHeader: response.headers.get(VINEXT_RSC_COMPATIBILITY_ID_HEADER),
		buffer: extracted.buffer,
		...completedDynamicStaleTimeSeconds !== void 0 ? { completedDynamicStaleTimeSeconds } : {},
		contentType: response.headers.get("content-type") ?? "text/x-component",
		...dynamicStaleTimeSeconds !== void 0 ? { dynamicStaleTimeSeconds } : {},
		mountedSlotsHeader: response.headers.get(VINEXT_MOUNTED_SLOTS_HEADER),
		paramsHeader: response.headers.get(VINEXT_PARAMS_HEADER),
		receivedAt: Date.now(),
		...redirectHeader === null ? {} : { redirectHeader },
		...redirectTypeHeader === null ? {} : { redirectTypeHeader },
		renderedPathAndSearch: parseRenderedPathAndSearchHeader(response.headers.get(VINEXT_RENDERED_PATH_AND_SEARCH_HEADER)),
		...serverStaleTime === void 0 ? {} : { serverStaleTime },
		url: responseUrl ?? response.url
	};
}
/**
* Collapse the two mutually-exclusive wire headers into one state. A pending
* marker wins: it says the render committed headers before `cacheLife` settled,
* so any resolved value alongside it cannot describe the completed render.
*/
function parseServerStaleTimeHeaders(headers) {
	if (headers.get("X-Vinext-Stale-Time-Pending") === "1") return { kind: "pending" };
	const seconds = parseStaleTimeSecondsHeader(headers.get(NEXT_ROUTER_STALE_TIME_HEADER));
	return seconds === void 0 ? void 0 : {
		kind: "resolved",
		seconds
	};
}
/** Decode an `X-Vinext-Rendered-Path-And-Search` header value. */
function parseRenderedPathAndSearchHeader(value) {
	if (value === null || value === "") return null;
	try {
		const decoded = decodeURIComponent(value);
		return decoded.startsWith("/") ? decoded : null;
	} catch {
		return null;
	}
}
/**
* Snapshot an RSC response to an ArrayBuffer for caching and replay.
* Consumes the response body and stores it with content-type and URL metadata.
*/
async function snapshotRscResponse(response) {
	try {
		const snapshot = createCachedRscResponseSnapshot(response, await response.arrayBuffer());
		const expiresAt = restoredRscResponseExpiresAt.get(response);
		return expiresAt === void 0 ? snapshot : {
			...snapshot,
			expiresAt
		};
	} finally {
		releaseAppPrefetchFetchSlot(response);
	}
}
const restoredRscResponseExpiresAt = /* @__PURE__ */ new WeakMap();
/**
* Reconstruct a Response from a cached RSC snapshot.
* Creates a new Response with the original ArrayBuffer so createFromFetch
* can consume the stream from scratch.
*
* NOTE: The reconstructed Response always has `url === ""` — the Response
* constructor does not accept a `url` option, and `response.url` is read-only
* set by the fetch infrastructure. Callers that need the original URL should
* read it from `cached.url` directly rather than from the restored Response.
*
* @param copy - When true (default), copies the ArrayBuffer so the cached
*   snapshot remains replayable (needed for the visited-response cache).
*   Pass false for single-consumption paths (e.g. prefetch cache entries
*   that are deleted after consumption) to avoid the extra allocation.
*/
function restoreRscResponse(cached, copy = true) {
	const headers = new Headers({ "content-type": cached.contentType });
	if (cached.mountedSlotsHeader != null) headers.set(VINEXT_MOUNTED_SLOTS_HEADER, cached.mountedSlotsHeader);
	if (cached.compatibilityIdHeader != null) headers.set(VINEXT_RSC_COMPATIBILITY_ID_HEADER, cached.compatibilityIdHeader);
	if (isStaleTimeSeconds(cached.dynamicStaleTimeSeconds)) headers.set(VINEXT_DYNAMIC_STALE_TIME_HEADER, String(cached.dynamicStaleTimeSeconds));
	if (isStaleTimeSeconds(cached.completedDynamicStaleTimeSeconds)) headers.set(VINEXT_RSC_COMPLETION_METADATA_HEADER, "resolved");
	if (cached.serverStaleTime?.kind === "pending") headers.set(VINEXT_STALE_TIME_PENDING_HEADER, "1");
	else if (cached.serverStaleTime !== void 0) headers.set(NEXT_ROUTER_STALE_TIME_HEADER, String(cached.serverStaleTime.seconds));
	if (cached.paramsHeader != null) headers.set(VINEXT_PARAMS_HEADER, cached.paramsHeader);
	if (cached.redirectHeader !== void 0) headers.set(VINEXT_RSC_REDIRECT_HEADER, cached.redirectHeader);
	if (cached.redirectTypeHeader !== void 0) headers.set(VINEXT_RSC_REDIRECT_TYPE_HEADER, cached.redirectTypeHeader);
	if (cached.renderedPathAndSearch != null) headers.set(VINEXT_RENDERED_PATH_AND_SEARCH_HEADER, encodeURIComponent(cached.renderedPathAndSearch));
	const response = new Response(copy ? cached.buffer.slice(0) : cached.buffer, {
		status: 200,
		headers
	});
	if (isCacheExpiresAt(cached.expiresAt)) restoredRscResponseExpiresAt.set(response, cached.expiresAt);
	return response;
}
/**
* `prefetchRscResponse`'s `prepareSnapshot` for navigation-reusable entries:
* decode the cached payload through the App Router runtime so a later
* navigation can commit it without re-parsing. Shared by `<Link>` and
* `router.prefetch()`.
*/
async function prepareNavigationPrefetchSnapshot(snapshot) {
	const preparePrefetchResponse = getNavigationRuntime()?.functions.preparePrefetchResponse;
	if (!preparePrefetchResponse) throw new Error("App Router prefetch preparation is unavailable");
	return await preparePrefetchResponse(restoreRscResponse(snapshot));
}
/**
* Gate a navigation-reusable prefetch behind the route-tree request shared by
* `<Link>` and `router.prefetch()`. Callers retain control of fetch scheduling
* and request-only options while freshness, deduplication, and alias reuse stay
* identical across both entry points.
*/
async function fetchRouteTreeGatedPrefetch(options) {
	const { fetchFullRscPayload, fetchRouteTree, fullHref, headers, interceptionContext, mountedSlotsHeader } = options;
	const routeTreeHeaders = new Headers(headers);
	routeTreeHeaders.set(NEXT_ROUTER_PREFETCH_HEADER, "1");
	routeTreeHeaders.set(NEXT_ROUTER_SEGMENT_PREFETCH_HEADER, "/_tree");
	const routeTreeRscUrl = await createRscRequestUrl(fullHref, routeTreeHeaders);
	const routeTreeCacheKey = AppElementsWire.encodeCacheKey(routeTreeRscUrl, interceptionContext);
	let routeTreeEntry = getFreshPrefetchCacheEntry(routeTreeCacheKey);
	if (routeTreeEntry === void 0) {
		getPrefetchedUrls().add(routeTreeCacheKey);
		prefetchRscResponse(routeTreeRscUrl, fetchRouteTree(routeTreeRscUrl, routeTreeHeaders), interceptionContext, mountedSlotsHeader, void 0, {
			cacheForNavigation: false,
			optimisticRouteShell: false,
			prefetchKind: "route-tree"
		});
		routeTreeEntry = getFreshPrefetchCacheEntry(routeTreeCacheKey);
	}
	await routeTreeEntry?.pending?.catch(() => {});
	routeTreeEntry = getFreshPrefetchCacheEntry(routeTreeCacheKey);
	const renderedPathAndSearch = routeTreeEntry?.snapshot?.renderedPathAndSearch;
	if (renderedPathAndSearch) {
		const cachedRenderedResponse = peekPrefetchResponseForNavigation(await createRscRequestUrl(renderedPathAndSearch, headers), interceptionContext, mountedSlotsHeader);
		if (cachedRenderedResponse) return restoreRscResponse(cachedRenderedResponse);
	}
	return fetchFullRscPayload();
}
/**
* Whether a prefetch response may be decoded as Flight. A successful response
* that is not Flight (e.g. a Route Handler's text download) is a miss: decoding
* its bytes would let text shaped like Flight resource hints insert scripts.
* Navigation then fetches it and falls back to a document navigation.
*
* Ported from Next.js: fetchPrefetchResponse in
* packages/next/src/client/components/segment-cache/cache.ts, which skips the
* check in `output: "export"` because a static host, not Next.js, chooses the
* MIME type of the exported `.txt` payloads.
*/
function isFlightPrefetchResponse(response) {
	if (!response.ok) return false;
	if ("development" === "production" && process.env.__NEXT_CONFIG_OUTPUT === "export") return true;
	return response.headers.get("content-type")?.toLowerCase().startsWith(VINEXT_RSC_CONTENT_TYPE) === true;
}
/**
* Prefetch an RSC response and snapshot it for later consumption.
* Stores the in-flight promise so immediate clicks can await it instead
* of firing a duplicate fetch.
* Enforces a maximum cache size to prevent unbounded memory growth on
* link-heavy pages.
*/
function prefetchRscResponse(rscUrl, fetchPromise, interceptionContext = null, mountedSlotsHeader = null, options, behavior = {}) {
	const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	const cache = getPrefetchCache();
	const prefetched = getPrefetchedUrls();
	const now = Date.now();
	const existing = cache.get(cacheKey);
	const cacheForNavigation = behavior.cacheForNavigation ?? true;
	if (existing) deletePrefetchCacheEntry(cache, prefetched, cacheKey, existing, false);
	const entry = {
		cacheForNavigation,
		cacheKeys: /* @__PURE__ */ new Set([cacheKey]),
		mountedSlotsHeader,
		optimisticRouteShell: behavior.optimisticRouteShell === true,
		outcome: "pending",
		prefetchKind: behavior.prefetchKind ?? (behavior.optimisticRouteShell === true ? "loading-shell" : "navigation"),
		searchAgnosticShell: behavior.searchAgnosticShell === true,
		timestamp: now
	};
	if (behavior.dynamicStaleTime === "learning-only" && behavior.searchAgnosticShell !== true) {
		entry.dynamicStaleTime = "learning-only";
		entry.fallbackTtlMs = behavior.fallbackTtlMs ?? PREFETCH_CACHE_TTL;
	} else if (behavior.dynamicStaleTime === "full-prefetch") entry.dynamicStaleTime = "full-prefetch";
	addPrefetchInvalidationCallback(entry, options?.onInvalidate);
	entry.fetchPromise = fetchPromise;
	entry.pending = fetchPromise.then(async (response) => {
		if (isFlightPrefetchResponse(response)) {
			const snapshot = await snapshotRscResponse(response);
			if (cache.get(cacheKey) !== entry) return;
			const previousSize = getPrefetchCacheEntrySize(entry);
			entry.snapshot = snapshot;
			entry.size = snapshot.buffer.byteLength;
			adjustPrefetchCacheByteSize(cache, entry.size - previousSize);
			const fallbackTtlMs = behavior.fallbackTtlMs ?? PREFETCH_CACHE_TTL;
			const dynamicStaleTime = behavior.searchAgnosticShell === true ? "ignore" : entry.dynamicStaleTime ?? behavior.dynamicStaleTime ?? (behavior.optimisticRouteShell === true ? "ignore" : "verbatim");
			if (dynamicStaleTime === "learning-only" && isStaleTimeSeconds(snapshot.dynamicStaleTimeSeconds)) {
				entry.cacheForNavigation = false;
				entry.expiresAt = entry.timestamp + Math.max(fallbackTtlMs, MIN_PREFETCH_STALE_TIME_MS);
			} else entry.expiresAt = resolvePrefetchedRscResponseExpiresAt(entry.timestamp, entry.snapshot, fallbackTtlMs, dynamicStaleTime === "learning-only" ? "verbatim" : dynamicStaleTime);
			if (behavior.prepareSnapshot && entry.cacheForNavigation && snapshot.redirectHeader === void 0) try {
				const preparedElements = await behavior.prepareSnapshot(snapshot);
				if (cache.get(cacheKey) !== entry) return;
				entry.preparedElements = preparedElements;
			} catch {}
			addRenderedPathAndSearchPrefetchAlias(cache, prefetched, cacheKey, entry);
			evictPrefetchCacheIfNeeded();
		} else {
			releaseAppPrefetchFetchSlot(response);
			response.body?.cancel().catch(() => {});
			deletePrefetchCacheEntry(cache, prefetched, cacheKey, entry, false);
		}
	}).catch(() => {
		deletePrefetchCacheEntry(cache, prefetched, cacheKey, entry, false);
	}).finally(() => {
		if (cache.get(cacheKey) !== entry) return;
		entry.pending = void 0;
		entry.fetchPromise = void 0;
		if (entry.snapshot) {
			entry.outcome = "cache-seeded";
			schedulePrefetchInvalidation(cacheKey, entry);
		}
	});
	cache.set(cacheKey, entry);
	evictPrefetchCacheIfNeeded();
}
function addRenderedPathAndSearchPrefetchAlias(cache, prefetched, primaryCacheKey, entry) {
	if (entry.cacheForNavigation === false) return;
	const renderedPathAndSearch = entry.snapshot?.renderedPathAndSearch;
	if (!renderedPathAndSearch) return;
	const source = parsePrefetchCacheKey(primaryCacheKey);
	const aliasCacheKey = AppElementsWire.encodeCacheKey(renderedPathAndSearch, source.interceptionContext);
	if (aliasCacheKey === primaryCacheKey) return;
	const existing = cache.get(aliasCacheKey);
	if (existing && existing !== entry) deletePrefetchCacheEntry(cache, prefetched, aliasCacheKey, existing, false);
	entry.cacheKeys ??= /* @__PURE__ */ new Set([primaryCacheKey]);
	entry.cacheKeys.add(aliasCacheKey);
	cache.set(aliasCacheKey, entry);
	prefetched.add(aliasCacheKey);
}
function peekPrefetchResponseForNavigation(rscUrl, interceptionContext = null, mountedSlotsHeader = null, options) {
	const match = findPrefetchCacheEntryForNavigation(rscUrl, interceptionContext, mountedSlotsHeader, options?.additionalRscUrls);
	if (!match) return null;
	const { cacheKey, entry } = match;
	if (entry.pending || entry.outcome !== "cache-seeded") return null;
	if (entry.cacheForNavigation === false || !entry.snapshot) return null;
	if (resolvePrefetchCacheEntryExpiresAt(entry) <= Date.now()) {
		deletePrefetchCacheEntry(getPrefetchCache(), getPrefetchedUrls(), cacheKey, entry, true);
		return null;
	}
	if (entry.expiresAt !== void 0 || entry.snapshot.expiresAt !== void 0) return {
		...entry.snapshot,
		expiresAt: resolvePrefetchCacheEntryExpiresAt(entry)
	};
	return entry.snapshot;
}
/**
* Consume a prefetched response for a given rscUrl.
* Only returns settled (non-pending) snapshots synchronously.
* Returns null if the entry is still in flight or doesn't exist.
*/
function consumePrefetchResponse(rscUrl, interceptionContext = null, mountedSlotsHeader = null, options) {
	const cache = getPrefetchCache();
	const exactCacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
	const exactEntry = cache.get(exactCacheKey);
	if (exactEntry && exactEntry.cacheForNavigation !== false && !isPrefetchCacheEntryCompatibleWithMountedSlots(exactEntry, mountedSlotsHeader)) deletePrefetchCacheEntry(cache, getPrefetchedUrls(), exactCacheKey, exactEntry, false);
	const match = findPrefetchCacheEntryForNavigation(rscUrl, interceptionContext, mountedSlotsHeader, options?.additionalRscUrls);
	if (!match) return null;
	const { cacheKey, entry } = match;
	return consumeMatchedPrefetchResponse(cacheKey, entry, mountedSlotsHeader);
}
function consumeMatchedPrefetchResponse(cacheKey, entry, mountedSlotsHeader, allowExpiredInFlightHandoff = false) {
	const cache = getPrefetchCache();
	if (entry.pending || entry.outcome !== "cache-seeded") return null;
	if (entry.cacheForNavigation === false) return null;
	if (entry.snapshot) {
		if (!isPrefetchCacheEntryCompatibleWithMountedSlots(entry, mountedSlotsHeader)) return null;
		if (!allowExpiredInFlightHandoff && resolvePrefetchCacheEntryExpiresAt(entry) <= Date.now()) {
			deletePrefetchCacheEntry(cache, getPrefetchedUrls(), cacheKey, entry, true);
			return null;
		}
		retainPrefetchInvalidationAfterConsume(entry);
		deletePrefetchCacheEntry(cache, getPrefetchedUrls(), cacheKey, entry, false);
		const snapshot = entry.snapshot;
		if (entry.expiresAt !== void 0 || entry.snapshot.expiresAt !== void 0) return {
			...snapshot,
			expiresAt: resolvePrefetchCacheEntryExpiresAt(entry),
			...entry.preparedElements ? { preparedElements: entry.preparedElements } : {}
		};
		return entry.preparedElements ? {
			...snapshot,
			preparedElements: entry.preparedElements
		} : snapshot;
	}
	return null;
}
async function consumePrefetchResponseForNavigation(rscUrl, interceptionContext = null, mountedSlotsHeader = null, options) {
	const cache = getPrefetchCache();
	const match = findPrefetchCacheEntryForNavigation(rscUrl, interceptionContext, mountedSlotsHeader, options?.additionalRscUrls);
	if (!match) return null;
	const { cacheKey, entry } = match;
	if (options?.shouldConsume?.() === false) return null;
	const allowExpiredInFlightHandoff = entry.pending !== void 0;
	if (entry.pending !== void 0) {
		const releaseClaim = promoteAppPrefetchFetch(entry.fetchPromise, options?.shouldConsume);
		try {
			await entry.pending.catch(() => {});
		} finally {
			releaseClaim();
		}
		if (cache.get(cacheKey) !== entry) return null;
		if (options?.shouldConsume?.() === false) return null;
	}
	return consumeMatchedPrefetchResponse(cacheKey, entry, mountedSlotsHeader, allowExpiredInFlightHandoff);
}
const _CLIENT_NAV_STATE_KEY = Symbol.for("vinext.clientNavigationState");
const _MOUNTED_SLOTS_HEADER_KEY = Symbol.for("vinext.mountedSlotsHeader");
function setMountedSlotsHeader(header) {
	if (isServer) return;
	const globalState = window;
	globalState[_MOUNTED_SLOTS_HEADER_KEY] = header;
}
function getMountedSlotsHeader() {
	if (isServer) return null;
	return window[_MOUNTED_SLOTS_HEADER_KEY] ?? null;
}
function getClientNavigationState() {
	if (isServer) return null;
	const globalState = window;
	globalState[_CLIENT_NAV_STATE_KEY] ??= {
		listeners: /* @__PURE__ */ new Set(),
		cachedSearch: window.location.search,
		cachedReadonlySearchParams: new ReadonlyURLSearchParams(window.location.search),
		cachedPathname: stripBasePath(window.location.pathname, __basePath),
		clientParams: {},
		clientParamsJson: "{}",
		pendingClientParams: null,
		pendingClientParamsJson: null,
		pendingPathname: null,
		pendingPathnameNavId: null,
		originalPushState: window.history.pushState.bind(window.history),
		originalReplaceState: window.history.replaceState.bind(window.history),
		patchInstalled: false,
		routerHistoryWriteDepth: 0,
		routerHistoryWrite: null,
		hasPendingNavigationUpdate: false,
		suppressUrlNotifyCount: 0,
		navigationSnapshotActiveCount: 0
	};
	return globalState[_CLIENT_NAV_STATE_KEY];
}
function notifyNavigationListeners() {
	const state = getClientNavigationState();
	if (!state) return;
	for (const fn of state.listeners) fn();
}
if (!isServer) globalThis[PAGES_NAVIGATION_NOTIFY_KEY] = notifyNavigationListeners;
let _cachedEmptyServerSearchParams = null;
const _readonlyPagesSearchParamsCache = /* @__PURE__ */ new WeakMap();
let _cachedReadonlyPagesSearchParamsKey = null;
let _cachedReadonlyPagesSearchParams = null;
function getReadonlyPagesSearchParams(searchParams) {
	const cached = _readonlyPagesSearchParamsCache.get(searchParams);
	if (cached) return cached;
	const key = searchParams.toString();
	if (_cachedReadonlyPagesSearchParamsKey === key && _cachedReadonlyPagesSearchParams) {
		_readonlyPagesSearchParamsCache.set(searchParams, _cachedReadonlyPagesSearchParams);
		return _cachedReadonlyPagesSearchParams;
	}
	const readonly = new ReadonlyURLSearchParams(searchParams);
	_readonlyPagesSearchParamsCache.set(searchParams, readonly);
	_cachedReadonlyPagesSearchParamsKey = key;
	_cachedReadonlyPagesSearchParams = readonly;
	return readonly;
}
/**
* Get cached pathname snapshot for useSyncExternalStore.
* Note: Returns cached value from ClientNavigationState, not live window.location.
* The cache is updated by syncCommittedUrlStateFromLocation() after navigation commits.
* This ensures referential stability and prevents infinite re-renders.
* External pushState/replaceState while URL notifications are suppressed won't
* be visible until the next commit.
*/
function getPathnameSnapshot() {
	const pagesCtx = getPagesNavigationContext();
	if (pagesCtx) return pagesCtx.pathname;
	return getClientNavigationState()?.cachedPathname ?? "/";
}
let _cachedEmptyClientSearchParams = null;
/**
* Get cached search params snapshot for useSyncExternalStore.
* Note: Returns cached value from ClientNavigationState, not live window.location.search.
* The cache is updated by syncCommittedUrlStateFromLocation() after navigation commits.
* This ensures referential stability and prevents infinite re-renders.
* External pushState/replaceState while URL notifications are suppressed won't
* be visible until the next commit.
*/
function getSearchParamsSnapshot() {
	const hasAppContext = getNavigationContext() !== null;
	const pagesCtx = getPagesNavigationContext();
	if (!hasAppContext && pagesCtx) return getReadonlyPagesSearchParams(pagesCtx.searchParams);
	const state = getClientNavigationState();
	if (state) {
		if (hasAppContext) adoptHydrationSearchParams(state);
		return state.cachedReadonlySearchParams;
	}
	if (_cachedEmptyClientSearchParams === null) _cachedEmptyClientSearchParams = new ReadonlyURLSearchParams();
	return _cachedEmptyClientSearchParams;
}
let _comparedHydrationSearchParams = null;
/**
* Keep the hydrated search params object when the browser URL has the same
* query. React compares the two snapshots by identity once hydrated, so a new
* object would re-render every useSearchParams() caller and re-run effects
* keyed on it, where Next.js keeps one object from the first render.
*/
function adoptHydrationSearchParams(state) {
	const hydrated = getServerSearchParamsSnapshot();
	if (hydrated === state.cachedReadonlySearchParams) return;
	if (hydrated === _comparedHydrationSearchParams) return;
	_comparedHydrationSearchParams = hydrated;
	if (hydrated.toString() === state.cachedReadonlySearchParams.toString()) state.cachedReadonlySearchParams = hydrated;
}
function syncCommittedUrlStateFromLocation() {
	const state = getClientNavigationState();
	if (!state) return false;
	let changed = false;
	const pathname = stripBasePath(window.location.pathname, __basePath);
	if (pathname !== state.cachedPathname) {
		state.cachedPathname = pathname;
		changed = true;
	}
	const search = window.location.search;
	if (search !== state.cachedSearch) {
		state.cachedSearch = search;
		state.cachedReadonlySearchParams = new ReadonlyURLSearchParams(search);
		changed = true;
	}
	return changed;
}
function getServerSearchParamsSnapshot() {
	const ctx = getNavigationContext();
	if (!ctx) {
		const pagesCtx = getPagesNavigationContext();
		if (pagesCtx) return getReadonlyPagesSearchParams(pagesCtx.searchParams);
		if (_cachedEmptyServerSearchParams === null) _cachedEmptyServerSearchParams = new ReadonlyURLSearchParams();
		return _cachedEmptyServerSearchParams;
	}
	const source = ctx.searchParams;
	const cached = ctx[_READONLY_SEARCH_PARAMS];
	const cachedSource = ctx[_READONLY_SEARCH_PARAMS_SOURCE];
	if (cached && cachedSource === source) return cached;
	const sourceKey = source.toString();
	if (cached && ctx[_READONLY_SEARCH_PARAMS_SOURCE_KEY] === sourceKey) {
		ctx[_READONLY_SEARCH_PARAMS_SOURCE] = source;
		return cached;
	}
	const readonly = new ReadonlyURLSearchParams(source);
	ctx[_READONLY_SEARCH_PARAMS] = readonly;
	ctx[_READONLY_SEARCH_PARAMS_SOURCE] = source;
	ctx[_READONLY_SEARCH_PARAMS_SOURCE_KEY] = sourceKey;
	return readonly;
}
/**
* Mark a navigation snapshot as active. Called before startTransition
* in renderNavigationPayload. While active, hooks prefer the snapshot
* context value over useSyncExternalStore. Uses a counter (not boolean)
* to handle overlapping navigations — rapid clicks can interleave
* activate/deactivate if multiple transitions are in flight.
*/
function activateNavigationSnapshot() {
	const state = getClientNavigationState();
	if (state) state.navigationSnapshotActiveCount++;
}
const _EMPTY_PARAMS = {};
const _CLIENT_NAV_RENDER_CTX_KEY = Symbol.for("vinext.clientNavigationRenderContext");
function getClientNavigationRenderContext() {
	if (typeof React$1.createContext !== "function") return null;
	const globalState = globalThis;
	if (!globalState[_CLIENT_NAV_RENDER_CTX_KEY]) globalState[_CLIENT_NAV_RENDER_CTX_KEY] = React$1.createContext(null);
	return globalState[_CLIENT_NAV_RENDER_CTX_KEY] ?? null;
}
/** @internal */
function useClientNavigationRenderSnapshot() {
	const ctx = getClientNavigationRenderContext();
	if (!ctx || typeof React$1.useContext !== "function") return null;
	try {
		return React$1.useContext(ctx);
	} catch {
		return null;
	}
}
/**
* @param renderedPathAndSearch The path and query the server rendered for this
* navigation (`X-Vinext-Rendered-Path-And-Search`), when known.
*/
function createClientNavigationRenderSnapshot(href, params, renderedPathAndSearch) {
	const origin = typeof window !== "undefined" ? window.location.origin : "http://localhost";
	const url = new URL(href, origin);
	return {
		pathname: stripBasePath(url.pathname, __basePath),
		search: url.search,
		searchParams: new ReadonlyURLSearchParams(url.search),
		params,
		...renderedPathAndSearch != null ? { renderedSearch: new URL(renderedPathAndSearch, origin).search } : {}
	};
}
function createSnapshotPathAndSearch(snapshot) {
	return snapshot.pathname + snapshot.search;
}
let _fallbackClientParams = _EMPTY_PARAMS;
let _fallbackClientParamsJson = "{}";
function setClientParams(params) {
	const state = getClientNavigationState();
	if (!state) {
		const json = JSON.stringify(params);
		if (json !== _fallbackClientParamsJson) {
			_fallbackClientParams = params;
			_fallbackClientParamsJson = json;
		}
		return;
	}
	const json = JSON.stringify(params);
	if (json !== state.clientParamsJson) {
		state.clientParams = params;
		state.clientParamsJson = json;
		state.pendingClientParams = null;
		state.pendingClientParamsJson = null;
		notifyNavigationListeners();
	}
}
function replaceClientParamsWithoutNotify(params) {
	const state = getClientNavigationState();
	if (!state) return;
	const json = JSON.stringify(params);
	if (json !== state.clientParamsJson && json !== state.pendingClientParamsJson) {
		state.pendingClientParams = params;
		state.pendingClientParamsJson = json;
		state.hasPendingNavigationUpdate = true;
	}
}
/** Get the current client params (for testing referential stability). */
function getClientParams() {
	return getClientNavigationState()?.clientParams ?? _fallbackClientParams;
}
/**
* Set the pending pathname for client-side navigation.
* Strips the base path before storing. Associates the pathname with the given navId
* so only that navigation (or a newer one) can clear it.
*/
function setPendingPathname(pathname, navId) {
	const state = getClientNavigationState();
	if (!state) return;
	state.pendingPathname = stripBasePath(pathname, __basePath);
	state.pendingPathnameNavId = navId;
}
/**
* Clear the pending pathname, but only if the given navId matches the one
* that set it, or if pendingPathnameNavId is null (no active owner).
* This prevents superseded navigations from clearing state belonging to newer navigations.
*/
function clearPendingPathname(navId) {
	const state = getClientNavigationState();
	if (!state) return;
	if (state.pendingPathnameNavId === null || state.pendingPathnameNavId === navId) {
		state.pendingPathname = null;
		state.pendingPathnameNavId = null;
	}
}
function getClientParamsSnapshot() {
	const state = getClientNavigationState();
	const ctx = getNavigationContext();
	if (ctx) return ctx.params;
	const pagesCtx = getPagesNavigationContext();
	if (pagesCtx) return pagesCtx.params;
	return state?.clientParams ?? _EMPTY_PARAMS;
}
function getServerParamsSnapshot() {
	const ctx = getNavigationContext();
	if (ctx) return ctx.params;
	const pagesCtx = getPagesNavigationContext();
	if (pagesCtx) return pagesCtx.params;
	return _EMPTY_PARAMS;
}
function subscribeToNavigation(cb) {
	const state = getClientNavigationState();
	if (!state) return () => {};
	state.listeners.add(cb);
	return () => {
		state.listeners.delete(cb);
	};
}
/**
* Returns the current pathname.
* Server: from request context. Client: from window.location.
*/
function usePathname() {
	if (isServer) {
		markPprFallbackShellDynamicBoundary();
		const ctx = getNavigationContext();
		if (ctx) return ctx.pathname;
		const pagesCtx = getPagesNavigationContext();
		return pagesCtx ? pagesCtx.pathname : "/";
	}
	const renderSnapshot = useClientNavigationRenderSnapshot();
	const pathname = React$1.useSyncExternalStore(subscribeToNavigation, getPathnameSnapshot, () => {
		const ctx = getNavigationContext();
		if (ctx) return ctx.pathname;
		const pagesCtx = getPagesNavigationContext();
		return pagesCtx ? pagesCtx.pathname : "/";
	});
	if (renderSnapshot && (getClientNavigationState()?.navigationSnapshotActiveCount ?? 0) > 0) return renderSnapshot.pathname;
	return pathname;
}
/**
* Returns the current search params as a read-only URLSearchParams.
*/
function useSearchParams() {
	if (isServer) {
		const ctx = getNavigationContext();
		if (ctx?.isStaticGeneration === true && ctx.isForceStatic !== true && getPprFallbackShellState() === null) throw new BailoutToCSRError("useSearchParams()");
		const gate = ctx?.searchParamsGate;
		if (gate) {
			React$1.use(gate.decided);
			if (gate.decision === "bailout") throw new BailoutToCSRError("useSearchParams()");
		}
		markPprFallbackShellDynamicBoundary();
		return getServerSearchParamsSnapshot();
	}
	const renderSnapshot = useClientNavigationRenderSnapshot();
	const searchParams = React$1.useSyncExternalStore(subscribeToNavigation, getSearchParamsSnapshot, getServerSearchParamsSnapshot);
	if (renderSnapshot && (getClientNavigationState()?.navigationSnapshotActiveCount ?? 0) > 0) return renderSnapshot.searchParams;
	return searchParams;
}
/**
* Returns the dynamic params for the current route.
*/
function useParams() {
	if (isServer) {
		markPprFallbackShellDynamicBoundary();
		return getServerParamsSnapshot();
	}
	const renderSnapshot = useClientNavigationRenderSnapshot();
	const params = React$1.useSyncExternalStore(subscribeToNavigation, getClientParamsSnapshot, getServerParamsSnapshot);
	if (renderSnapshot && (getClientNavigationState()?.navigationSnapshotActiveCount ?? 0) > 0) return renderSnapshot.params;
	return params;
}
function withSuppressedUrlNotifications(fn) {
	const state = getClientNavigationState();
	if (!state) return fn();
	state.suppressUrlNotifyCount += 1;
	try {
		return fn();
	} finally {
		state.suppressUrlNotifyCount -= 1;
	}
}
/**
* Commit pending client navigation state to committed snapshots.
*
* navId is optional: callers that don't own pendingPathname (for example,
* superseded pre-paint cleanup) may pass undefined to flush URL/params state
* without clearing pendingPathname owned by the active navigation. Such callers
* must opt in explicitly if they also own an activated render snapshot.
*/
function commitClientNavigationState(navId, options) {
	if (isServer) return;
	const state = getClientNavigationState();
	if (!state) return;
	if ((options?.releaseSnapshot ?? navId !== void 0) && state.navigationSnapshotActiveCount > 0) state.navigationSnapshotActiveCount -= 1;
	const urlChanged = syncCommittedUrlStateFromLocation();
	let paramsChanged = false;
	if (state.pendingClientParams !== null && state.pendingClientParamsJson !== null) {
		state.clientParams = state.pendingClientParams;
		state.clientParamsJson = state.pendingClientParamsJson;
		state.pendingClientParams = null;
		state.pendingClientParamsJson = null;
		paramsChanged = true;
	}
	if (state.pendingPathnameNavId === null || navId !== void 0 && state.pendingPathnameNavId === navId) {
		state.pendingPathname = null;
		state.pendingPathnameNavId = null;
	}
	const shouldNotify = urlChanged || state.hasPendingNavigationUpdate;
	state.hasPendingNavigationUpdate = false;
	if (urlChanged || paramsChanged) clearClientHydrationContext();
	if (shouldNotify) notifyNavigationListeners();
}
/** Whether a history entry's state is the data written to it, cloned by the browser. */
function isSameHistoryStateData(historyState, data) {
	try {
		return JSON.stringify(historyState) === JSON.stringify(data);
	} catch {
		return false;
	}
}
/** Writes the in-progress router write if this call is it, consuming its marker. */
function forwardRouterHistoryWrite(state, method, data, unused, url) {
	const write = state.routerHistoryWrite;
	if (write?.method !== method) return false;
	if (write.threw) {
		if (url == null || new URL(url, window.location.href).href !== write.href) return false;
		if (write.data !== data && !(isAppOwnedHistoryState(data) && readHistoryStateTraversalIndex(data) === readHistoryStateTraversalIndex(write.data))) return false;
	} else if (write.data !== data || write.url !== url) return false;
	if (write.landed) return true;
	state.routerHistoryWrite = null;
	const landing = write.land?.(data);
	const original = method === "pushState" ? state.originalPushState : state.originalReplaceState;
	const writtenData = landing ? landing.data : data;
	const historyStateBeforeWrite = window.history.state;
	try {
		original.call(window.history, writtenData, unused, url);
	} catch (error) {
		const landed = window.history.state !== historyStateBeforeWrite && window.location.href === write.href && isSameHistoryStateData(window.history.state, writtenData);
		if (landed) landing?.commit();
		state.routerHistoryWrite = {
			...write,
			threw: true,
			landed
		};
		throw error;
	}
	landing?.commit();
	if (write.threw) state.routerHistoryWrite = {
		...write,
		landed: true
	};
	return true;
}
function writeRouterHistoryState(method, data, unused, url, land) {
	withSuppressedUrlNotifications(() => {
		const state = getClientNavigationState();
		if (!state) return;
		if (url == null) {
			(method === "pushState" ? state.originalPushState : state.originalReplaceState).call(window.history, data, unused, url);
			return;
		}
		const previousWrite = state.routerHistoryWrite;
		state.routerHistoryWriteDepth += 1;
		state.routerHistoryWrite = {
			method,
			data,
			url,
			href: new URL(url, window.location.href).href,
			land,
			threw: false,
			landed: false
		};
		try {
			window.history[method](data, unused, url);
		} finally {
			state.routerHistoryWriteDepth -= 1;
			state.routerHistoryWrite = previousWrite;
		}
	});
}
function pushHistoryStateWithoutNotify(data, unused, url, land) {
	writeRouterHistoryState("pushState", data, unused, url, land);
}
function replaceHistoryStateWithoutNotify(data, unused, url, land) {
	writeRouterHistoryState("replaceState", data, unused, url, land);
}
/**
* Save the current scroll position into the current history state.
* Called before every navigation to enable scroll restoration on back/forward.
*
* Uses replaceHistoryStateWithoutNotify to avoid triggering the patched
* history.replaceState interception (which would cause spurious re-renders).
*/
function saveScrollPosition() {
	replaceHistoryStateWithoutNotify({
		...window.history.state ?? {},
		__vinext_scrollX: window.scrollX,
		__vinext_scrollY: window.scrollY
	}, "");
}
function commitHashOnlyHistoryState(href, mode, scroll) {
	const commitAppRouterHashNavigation = getNavigationRuntime()?.functions.commitHashNavigation;
	if (commitAppRouterHashNavigation) {
		commitAppRouterHashNavigation(href, mode, scroll);
		return;
	}
	const historyState = createHashOnlyHistoryStatePreservingNavigationMetadata(window.history.state);
	if (mode === "replace") replaceHistoryStateWithoutNotify(historyState, "", href);
	else pushHistoryStateWithoutNotify(historyState, "", href);
}
function applyAppRouterScrollFallback(intent) {
	if (typeof document === "undefined" || typeof window === "undefined") return;
	if (intent.hash !== null) {
		const hash = intent.hash;
		requestAnimationFrame(() => {
			if (!isLatestAppRouterScrollIntent(intent)) return;
			disableSmoothScrollDuringRouteTransition(() => {
				scrollToHashTarget(hash);
			});
		});
		return;
	}
	if (intent.targetHoistedInHead) return;
	disableSmoothScrollDuringRouteTransition(() => {
		document.documentElement.scrollTop = 0;
	});
}
function scheduleAppRouterScrollFallback(intent) {
	queueMicrotask(() => {
		const pendingIntent = getPendingAppRouterScrollIntent();
		if (pendingIntent === null || pendingIntent.id !== intent.id) return;
		const fallbackIntent = consumeAppRouterScrollIntent(intent);
		if (fallbackIntent) applyAppRouterScrollFallback(fallbackIntent);
	});
}
/**
* Restore scroll position from a history state object (used on popstate).
*
* When an RSC navigation is in flight (back/forward triggers both this
* handler and the browser entry's popstate handler which calls the registered
* navigation runtime), we must wait for the new content to render
* before scrolling. Otherwise the user sees old content flash at the
* restored scroll position.
*
* This handler fires before the browser entry's popstate handler (because
* navigation.ts is loaded before hydration completes), so we defer via a
* microtask to give the browser entry handler a chance to set
* __VINEXT_RSC_PENDING__. Promise.resolve() schedules a microtask
* that runs after all synchronous event listeners have completed.
*/
function restoreScrollPosition(state) {
	if (state && typeof state === "object" && "__vinext_scrollY" in state) {
		const { __vinext_scrollX: x, __vinext_scrollY: y } = state;
		Promise.resolve().then(() => {
			const pending = window.__VINEXT_RSC_PENDING__ ?? null;
			if (pending) pending.then(() => retryScrollTo(x, y));
			else retryScrollTo(x, y);
		});
	}
}
/**
* Hard-navigate to a URL via `window.location`, preserving push/replace
* semantics. Used for URLs the App Router cannot serve (Pages-owned
* targets in a hybrid build) and for catch-all RSC failures.
*/
function hardNavigateTo(fullHref, mode) {
	if (mode === "replace") window.location.replace(fullHref);
	else window.location.assign(fullHref);
}
/**
* Reset any link still showing a `useLinkStatus()` pending state that did not
* initiate the navigation now starting (e.g. a programmatic router.push, a form
* submit, or a raw history update). A <Link> click registers itself first, so
* the hook keeps that link pending.
*/
function resetStaleLinkStatus() {
	getNavigationRuntime()?.functions.notifyLinkNavigationStart?.();
}
/**
* Signal that a navigation to `href` is starting, for the callers that will
* fetch the destination. Separate from `resetStaleLinkStatus()` because a raw
* `history.pushState` also supersedes a pending link but issues no request —
* cancelling a prefetch there would drop it with nothing to take its place.
*/
function notifyAppNavigationStart(href) {
	const destination = toAppPrefetchDestination(href);
	if (destination !== null && !isHashOnlyBrowserUrlChange(href, window.location.href, __basePath)) cancelPendingPrefetchSetups(destination);
	resetStaleLinkStatus();
}
/**
* popstate variant. The browser has already applied the history entry by the
* time this runs, so the pre-navigation URL that `isHashOnlyBrowserUrlChange`
* needs is gone. Back/forward across a route boundary does drive an RSC fetch
* (`app-browser-entry.ts`'s popstate handler), so cancelling by destination is
* right; a hash-only entry over-cancels, which costs one re-prefetch and can
* never cause a duplicate request.
*/
function notifyAppPopstateNavigationStart() {
	const destination = toAppPrefetchDestination(window.location.href);
	if (destination !== null) cancelPendingPrefetchSetups(destination);
	resetStaleLinkStatus();
}
/**
* Navigate to a URL, handling external URLs, hash-only changes, and RSC navigation.
*/
async function navigateClientSide(href, mode, scroll, programmaticTransition = false, visibleCommitMode = "transition") {
	notifyAppNavigationStart(href);
	let normalizedHref = href;
	if (isExternalUrl(href)) {
		const localPath = toSameOriginAppPath(href, __basePath);
		if (localPath == null) {
			notifyAppRouterTransitionStart(href, mode);
			const externalNavigate = getNavigationRuntime()?.functions.navigateExternal;
			if (externalNavigate) {
				await externalNavigate(href, mode);
				return;
			}
			hardNavigateTo(href, mode);
			await new Promise(() => {});
			return;
		}
		normalizedHref = localPath;
	}
	const hybridOwner = resolveHybridClientRouteOwner(normalizedHref);
	if (hybridOwner === "pages" || hybridOwner === "document") {
		const fullHref = toCanonicalBrowserNavigationHref(normalizedHref, window.location.href, __basePath, __trailingSlash);
		notifyAppRouterTransitionStart(fullHref, mode);
		if (mode === "push") saveScrollPosition();
		const mpaNavigate = getNavigationRuntime()?.functions.navigateExternal;
		if (mpaNavigate) {
			await mpaNavigate(fullHref, mode);
			return;
		}
		hardNavigateTo(fullHref, mode);
		await new Promise(() => {});
		return;
	}
	const fullHref = toCanonicalBrowserNavigationHref(normalizedHref, window.location.href, __basePath, __trailingSlash);
	stageAppNavigationFailureTarget(fullHref);
	notifyAppRouterTransitionStart(fullHref, mode);
	if (mode === "push") saveScrollPosition();
	const earlyIntent = navigationPlanner.classifyEarlyNavigationIntent({
		basePath: __basePath,
		currentUrlSpace: "browser",
		currentHref: window.location.href,
		mode,
		scroll,
		targetHref: fullHref
	});
	if (earlyIntent.kind === "sameDocumentScroll") {
		clearAppRouterScrollIntent();
		commitHashOnlyHistoryState(fullHref, earlyIntent.mode, earlyIntent.scroll);
		clearAppNavigationFailureTarget(fullHref);
		commitClientNavigationState();
		if (earlyIntent.scroll) scrollToHashTarget(earlyIntent.hash);
		return;
	}
	if (hasPendingAppRouterPageRedirect(typeof document === "undefined" ? void 0 : document)) {
		const mpaNavigate = getNavigationRuntime()?.functions.navigateExternal;
		if (mpaNavigate) {
			await mpaNavigate(fullHref, mode);
			return;
		}
		hardNavigateTo(fullHref, mode);
		await new Promise(() => {});
		return;
	}
	const hashIdx = fullHref.indexOf("#");
	const hash = hashIdx !== -1 ? fullHref.slice(hashIdx) : "";
	const scrollIntent = scroll ? beginAppRouterScrollIntent(hash || null) : null;
	if (!scroll) clearAppRouterScrollIntent();
	const appNavigate = getNavigationRuntime()?.functions.navigate;
	try {
		if (appNavigate) await appNavigate(fullHref, 0, "navigate", mode, void 0, programmaticTransition, void 0, scrollIntent, visibleCommitMode, earlyIntent.bypassNavigationCache);
		else {
			if (mode === "replace") replaceHistoryStateWithoutNotify(null, "", fullHref);
			else pushHistoryStateWithoutNotify(null, "", fullHref);
			commitClientNavigationState();
		}
	} catch (error) {
		if (scrollIntent) consumeAppRouterScrollIntent(scrollIntent);
		throw error;
	}
	if (scrollIntent) scheduleAppRouterScrollFallback(scrollIntent);
}
let scheduledAppRouterNavigationCount = 0;
function trackScheduledAppRouterNavigation() {
	scheduledAppRouterNavigationCount += 1;
	let released = false;
	return () => {
		if (released) return;
		released = true;
		scheduledAppRouterNavigationCount = Math.max(0, scheduledAppRouterNavigationCount - 1);
	};
}
function hasScheduledAppRouterNavigation() {
	return scheduledAppRouterNavigationCount > 0;
}
function releaseScheduledAppRouterNavigationAfterCurrentTask(release) {
	queueMicrotask(release);
}
let inFlightAppRouterNavigationCount = 0;
let visibleLinkPingAwaitsNavigations = false;
/**
* Called by the App Router browser entry for each RSC navigation it runs.
* Returns a release callback for the navigation's settlement.
*/
function trackAppRouterNavigationInFlight() {
	inFlightAppRouterNavigationCount += 1;
	let released = false;
	return () => {
		if (released) return;
		released = true;
		inFlightAppRouterNavigationCount = Math.max(0, inFlightAppRouterNavigationCount - 1);
		if (inFlightAppRouterNavigationCount === 0 && visibleLinkPingAwaitsNavigations) {
			visibleLinkPingAwaitsNavigations = false;
			getNavigationRuntime()?.functions.pingVisibleLinks?.();
		}
	};
}
function pingVisibleLinksOnceNavigationsSettle() {
	if (inFlightAppRouterNavigationCount > 0) {
		visibleLinkPingAwaitsNavigations = true;
		return;
	}
	getNavigationRuntime()?.functions.pingVisibleLinks?.();
}
/**
* App Router public router instance. Mirrors Next.js's
* `publicAppRouterInstance` from
* `packages/next/src/client/components/app-router-instance.ts`.
*
* Exported so the App Router browser entry can install it on
* `window.next.router` for Next.js parity (see `client/window-next.ts`).
* Internal callers in this file continue to use `_appRouter` for brevity.
*/
const _appRouter = {
	bfcacheId: "0",
	push(href, options) {
		assertSafeNavigationUrl(href);
		if (isServer) return;
		notifyAppNavigationStart(href);
		const releaseNavigation = trackScheduledAppRouterNavigation();
		try {
			React$1.startTransition(() => {
				navigateClientSide(href, "push", options?.scroll !== false, true);
			});
		} catch (error) {
			releaseNavigation();
			throw error;
		}
		releaseScheduledAppRouterNavigationAfterCurrentTask(releaseNavigation);
	},
	replace(href, options) {
		assertSafeNavigationUrl(href);
		if (isServer) return;
		notifyAppNavigationStart(href);
		const releaseNavigation = trackScheduledAppRouterNavigation();
		try {
			React$1.startTransition(() => {
				navigateClientSide(href, "replace", options?.scroll !== false, true);
			});
		} catch (error) {
			releaseNavigation();
			throw error;
		}
		releaseScheduledAppRouterNavigationAfterCurrentTask(releaseNavigation);
	},
	back() {
		if (isServer) return;
		window.history.back();
	},
	forward() {
		if (isServer) return;
		window.history.forward();
	},
	refresh() {
		if (isServer) return;
		getNavigationRuntime()?.functions.clearNavigationCaches?.({ pingVisibleLinks: false });
		const rscNavigate = getNavigationRuntime()?.functions.navigate;
		if (hasScheduledAppRouterNavigation() || !rscNavigate) {
			getNavigationRuntime()?.functions.pingVisibleLinks?.();
			return;
		}
		const navigate = () => {
			rscNavigate(window.location.href, 0, "refresh", void 0, void 0, true).finally(pingVisibleLinksOnceNavigationsSettle);
		};
		React$1.startTransition(navigate);
	},
	prefetch(href, options) {
		assertSafeNavigationUrl(href);
		if (isServer) return;
		if (isBotUserAgent(window.navigator?.userAgent ?? "")) return;
		try {
			new URL(withBasePath(href, __basePath), window.location.href);
		} catch {
			throw new Error(`Cannot prefetch '${href}' because it cannot be converted to a URL.`);
		}
		const prefetchHref = isExternalUrl(href) ? toSameOriginAppPath(href, __basePath) : href;
		if (prefetchHref == null) return;
		const fullHref = toAppPrefetchDestination(prefetchHref);
		if (fullHref === null) return;
		const currentPathname = window.location.pathname;
		let interceptionContext = getPrefetchInterceptionContext(fullHref, currentPathname);
		const mountedSlotsHeader = getMountedSlotsHeader();
		const headers = createAppPrefetchRequestHeaders({
			fetchPriority: "low",
			interceptionContext,
			mountedSlotsHeader: mountedSlotsHeader || null
		});
		const setup = beginPrefetchSetup(fullHref);
		(async () => {
			const routeManifestLoad = loadNavigationRuntimeRouteManifest();
			if (routeManifestLoad !== null) {
				if (!await routeManifestLoad || setup.cancelled) return;
				interceptionContext = getPrefetchInterceptionContext(fullHref, currentPathname);
				if (interceptionContext !== null) headers.set(VINEXT_INTERCEPTION_CONTEXT_HEADER, interceptionContext);
			}
			if (HAS_CLIENT_REWRITES) await preloadHybridClientRouteOwner();
			const hybridOwner = resolveHybridClientRouteOwner(fullHref);
			if (hybridOwner === "pages" || hybridOwner === "document") return;
			const rewrittenPrefetchHref = HAS_CLIENT_REWRITES ? resolveLoadedHybridClientRewriteHref(fullHref, __basePath) : null;
			const kind = options?.kind === "full" ? "full" : "auto";
			const [{ resolveAutoAppRoutePrefetch, resolveFullAppRoutePrefetch }, { resolveAppPrefetchRscRequest }] = await Promise.all([import("/node_modules/vinext/dist/shims/internal/app-route-prefetch-policy.js?v=b41becdd"), import("/node_modules/vinext/dist/shims/internal/app-prefetch-rsc-request.js?v=b41becdd")]);
			if (setup.cancelled) return;
			const policy = kind === "full" ? resolveFullAppRoutePrefetch() : resolveAutoAppRoutePrefetch(rewrittenPrefetchHref ?? fullHref, interceptionContext);
			const reusable = policy.shouldPrefetch && policy.cacheForNavigation;
			const requiresRouteTreePrefetch = policy.requiresRouteTreePrefetch === true;
			if (reusable && kind === "full") headers.delete(NEXT_ROUTER_PREFETCH_HEADER);
			if (reusable && kind === "auto") {
				headers.set(NEXT_ROUTER_PREFETCH_HEADER, "1");
				headers.set(NEXT_ROUTER_SEGMENT_PREFETCH_HEADER, __prefetchInlining || requiresRouteTreePrefetch ? "/__PAGE__" : "1");
			}
			const hasSearchParams = new URL(fullHref, window.location.href).search !== "";
			if (!reusable && kind === "auto") {
				headers.set(NEXT_ROUTER_PREFETCH_HEADER, "1");
				headers.set(NEXT_ROUTER_SEGMENT_PREFETCH_HEADER, "1");
				headers.set(VINEXT_RSC_RENDER_MODE_HEADER, hasSearchParams && policy.rendersDynamically !== true ? APP_RSC_RENDER_MODE_PREFETCH_DYNAMIC_SHELL : APP_RSC_RENDER_MODE_PREFETCH_LOADING_SHELL);
			}
			const { additionalRscUrls, rscUrl } = await resolveAppPrefetchRscRequest({
				fullHref,
				headers,
				rewrittenPrefetchHref
			});
			if (setup.cancelled) return;
			const cacheKey = AppElementsWire.encodeCacheKey(rscUrl, interceptionContext);
			const prefetched = getPrefetchedUrls();
			if (policy.dynamicStaleTime !== "full-prefetch" && hasFreshLearningOnlyPrefetchCacheEntry(rscUrl, interceptionContext)) {
				attachPrefetchInvalidationCallback(cacheKey, options?.onInvalidate);
				return;
			}
			if (reusable) {
				discardLearningOnlyPrefetchCacheEntry(rscUrl, interceptionContext, mountedSlotsHeader);
				if (hasPrefetchCacheEntryForNavigation(rscUrl, interceptionContext, mountedSlotsHeader, {
					additionalRscUrls,
					onInvalidate: options?.onInvalidate,
					onReuse: policy.dynamicStaleTime === "full-prefetch" ? (entry, matchedCacheKey) => promotePrefetchCacheEntryForNavigation(matchedCacheKey, entry) : void 0
				})) return;
				if (policy.dynamicStaleTime === "full-prefetch" && seedFullPrefetchFromVisitedResponse(rscUrl, interceptionContext, mountedSlotsHeader, additionalRscUrls, options?.onInvalidate)) return;
			}
			if (policy.dynamicStaleTime !== "full-prefetch" && hasNavigationFreshVisitedResponse(rscUrl, interceptionContext, mountedSlotsHeader, additionalRscUrls, options?.onInvalidate)) return;
			prefetched.add(cacheKey);
			const fetchFullRscPayload = () => scheduleAppPrefetchFetch((signal) => fetch(rscUrl, {
				headers,
				credentials: "include",
				priority: "low",
				signal
			}), "low");
			prefetchRscResponse(rscUrl, reusable && kind === "auto" && requiresRouteTreePrefetch ? fetchRouteTreeGatedPrefetch({
				fetchFullRscPayload,
				fetchRouteTree: (routeTreeRscUrl, routeTreeHeaders) => scheduleAppPrefetchFetch((signal) => fetch(routeTreeRscUrl, {
					headers: routeTreeHeaders,
					credentials: "include",
					priority: "low",
					signal
				}), "low"),
				fullHref,
				headers,
				interceptionContext,
				mountedSlotsHeader
			}) : fetchFullRscPayload(), interceptionContext, mountedSlotsHeader, options, reusable ? {
				cacheForNavigation: true,
				fallbackTtlMs: policy.fallbackTtl === "dynamic" ? DYNAMIC_NAVIGATION_CACHE_TTL : PREFETCH_CACHE_TTL,
				dynamicStaleTime: policy.dynamicStaleTime,
				optimisticRouteShell: false,
				prefetchKind: "navigation",
				prepareSnapshot: prepareNavigationPrefetchSnapshot
			} : {
				cacheForNavigation: false,
				fallbackTtlMs: policy.fallbackTtl === "dynamic" ? DYNAMIC_NAVIGATION_CACHE_TTL : PREFETCH_CACHE_TTL,
				dynamicStaleTime: policy.dynamicStaleTime,
				optimisticRouteShell: true,
				prefetchKind: "navigation"
			});
		})().catch((error) => {
			console.error("[vinext] RSC prefetch setup error:", error);
		}).finally(() => {
			pendingPrefetchSetups.delete(setup);
		});
	}
};
if (process.env.__NEXT_GESTURE_TRANSITION) _appRouter.experimental_gesturePush = (href, options) => {
	assertSafeNavigationUrl(href);
	if (isServer) return;
	if (!getNavigationRuntime()?.functions.navigate) return;
	let appHref = href;
	if (isExternalUrl(href)) {
		const localPath = toSameOriginAppPath(href, __basePath);
		if (localPath === null) return;
		appHref = localPath;
	}
	const releaseNavigation = trackScheduledAppRouterNavigation();
	navigateClientSide(appHref, "push", options?.scroll !== false, false, "synchronous");
	releaseScheduledAppRouterNavigationAfterCurrentTask(releaseNavigation);
};
function formatPublicBfcacheId(value) {
	if (!value || value === "0") return PUBLIC_INITIAL_BFCACHE_ID;
	return value;
}
function readBfcacheIdFromContext() {
	const segmentContext = getBfcacheSegmentIdContext();
	const idMapContext = getBfcacheIdMapContext();
	if (!segmentContext || !idMapContext || typeof React$1.useContext !== "function") return formatPublicBfcacheId(null);
	try {
		const segmentId = React$1.useContext(segmentContext);
		const idMap = React$1.useContext(idMapContext);
		return formatPublicBfcacheId(segmentId !== null ? idMap?.[segmentId] : null);
	} catch (error) {
		if ("development" !== "production") console.warn("[vinext] readBfcacheIdFromContext failed:", error);
		return formatPublicBfcacheId(null);
	}
}
/**
* Public App Router instance, exposed for the browser entry so it can wire
* `window.next.router` to the same singleton returned from `useRouter()`.
*
* Mirrors `publicAppRouterInstance` from Next.js's
* `packages/next/src/client/components/app-router-instance.ts` (line 392).
*/
const appRouterInstance = _appRouter;
/**
* App Router's useRouter — returns push/replace/back/forward/refresh.
* Different from Pages Router's useRouter (next/router).
*
* Preserves the mounted AppRouterContext router as the authority for methods
* and layers the nearest segment's contextual `bfcacheId` on top.
*/
function useRouter() {
	if (!AppRouterContext || typeof React$1.useContext !== "function" || typeof React$1.useMemo !== "function") throw new Error("invariant expected app router to be mounted");
	const router = React$1.useContext(AppRouterContext);
	if (router === null) throw new Error("invariant expected app router to be mounted");
	const bfcacheId = readBfcacheIdFromContext();
	return React$1.useMemo(() => ({
		...router,
		bfcacheId
	}), [router, bfcacheId]);
}
/**
* Returns the active child segment one level below the layout where it's called.
*
* Returns the first segment from the route tree below this layout, including
* route groups (e.g., "(marketing)") and resolved dynamic params. Returns null
* if at the leaf (no child segments).
*
* @param parallelRoutesKey - Which parallel route to read (default: "children")
*/
function useSelectedLayoutSegment(parallelRoutesKey) {
	const segments = useSelectedLayoutSegments(parallelRoutesKey);
	if (segments.length === 0) return null;
	return parallelRoutesKey === void 0 || parallelRoutesKey === "children" ? segments[0] : segments[segments.length - 1];
}
/**
* Returns all active segments below the layout where it's called.
*
* Each layout in the App Router tree wraps its children with a
* LayoutSegmentProvider whose value is a map of parallel route key to
* segment arrays. The "children" key is the default parallel route.
*
* @param parallelRoutesKey - Which parallel route to read (default: "children")
*/
function useSelectedLayoutSegments(parallelRoutesKey) {
	if (isServer) markPprFallbackShellDynamicBoundary();
	return useChildSegments(parallelRoutesKey);
}
/**
* useServerInsertedHTML — inject HTML during SSR from client components.
*
* Used by CSS-in-JS libraries (styled-components, emotion, StyleX) to inject
* <style> tags during SSR so styles appear in the initial HTML (no FOUC).
*
* The callback is called once after each SSR render pass. The returned JSX/HTML
* is serialized and injected into the HTML stream.
*
* Usage (in a "use client" component wrapping children):
*   useServerInsertedHTML(() => {
*     const styles = sheet.getStyleElement();
*     sheet.instance.clearTag();
*     return <>{styles}</>;
*   });
*/
function useServerInsertedHTML(callback) {
	if (typeof document !== "undefined") return;
	registerServerInsertedHTMLCallback(callback);
}
if (!isServer) {
	const state = getClientNavigationState();
	if (state && !state.patchInstalled) {
		state.patchInstalled = true;
		window.addEventListener("popstate", () => {
			notifyAppPopstateNavigationStart();
		});
		window.addEventListener("popstate", (event) => {
			if (!hasAppNavigationRuntime()) {
				commitClientNavigationState();
				restoreScrollPosition(event.state);
			}
		});
		window.history.pushState = function patchedPushState(data, unused, url) {
			if (forwardRouterHistoryWrite(state, "pushState", data, unused, url)) return;
			if (state.routerHistoryWriteDepth === 0) getNavigationRuntime()?.functions.flushCommittingNavigationUrl?.();
			if (isAppOwnedHistoryState(data)) {
				const previousHistoryState = window.history.state;
				state.originalPushState.call(window.history, data, unused, url);
				getNavigationRuntime()?.functions.commitAppOwnedHistoryStateWrite?.("push", previousHistoryState);
				return;
			}
			const previousHistoryState = window.history.state;
			state.originalPushState.call(window.history, createExternalHistoryStatePreservingMetadata(data, window.history.state), unused, url);
			getNavigationRuntime()?.functions.claimCurrentHistoryTreeSnapshot?.("push", previousHistoryState);
			if (state.suppressUrlNotifyCount === 0) {
				resetStaleLinkStatus();
				if (url) getNavigationRuntime()?.functions.discardPendingNavigation?.();
				commitClientNavigationState();
			}
		};
		window.history.replaceState = function patchedReplaceState(data, unused, url) {
			if (forwardRouterHistoryWrite(state, "replaceState", data, unused, url)) return;
			if (state.routerHistoryWriteDepth === 0) getNavigationRuntime()?.functions.flushCommittingNavigationUrl?.();
			if (isAppOwnedHistoryState(data)) {
				const previousHistoryState = window.history.state;
				state.originalReplaceState.call(window.history, data, unused, url);
				getNavigationRuntime()?.functions.commitAppOwnedHistoryStateWrite?.("replace", previousHistoryState);
				return;
			}
			const previousHistoryState = window.history.state;
			state.originalReplaceState.call(window.history, createExternalHistoryStatePreservingMetadata(data, window.history.state), unused, url);
			getNavigationRuntime()?.functions.claimCurrentHistoryTreeSnapshot?.("replace", previousHistoryState);
			if (state.suppressUrlNotifyCount === 0) {
				resetStaleLinkStatus();
				if (url) getNavigationRuntime()?.functions.discardPendingNavigation?.();
				commitClientNavigationState();
			}
		};
	}
}
//#endregion
export { BailoutToCSRError, DYNAMIC_NAVIGATION_CACHE_TTL, DynamicServerError, GLOBAL_ACCESSORS_KEY, HTTP_ERROR_FALLBACK_ERROR_CODE, MAX_PREFETCH_CACHE_SIZE, PREFETCH_CACHE_TTL, ReadonlyURLSearchParams, RedirectType, ServerInsertedHTMLContext, UnrecognizedActionError, __basePath, _registerStateAccessors, activateNavigationSnapshot, appRouterInstance, applyAppRouterScrollFallback, clearPendingPathname, clearServerInsertedHTML, commitClientNavigationState, consumePrefetchResponse, consumePrefetchResponseForNavigation, createAppPrefetchRequestHeaders, createCachedRscResponseSnapshot, createClientNavigationRenderSnapshot, createSnapshotPathAndSearch, decodeRedirectError, deletePrefetchResponseSnapshot, disableNavigationResponsePrefetchCacheReuse, discardLearningOnlyPrefetchCacheEntry, fetchRouteTreeGatedPrefetch, flushServerInsertedHTML, forbidden, getAccessFallbackHTTPStatus, getBfcacheIdMapContext, getBfcacheSegmentIdContext, getClientNavigationRenderContext, getClientNavigationState, getClientParams, getCurrentInterceptionContext, getCurrentNextUrl, getFreshPrefetchCacheEntry, getLayoutSegmentContext, getMountedSlotsHeader, getNavigationContext, getPrefetchCache, getPrefetchInterceptionContext, getPrefetchedUrls, hasFreshLearningOnlyPrefetchCacheEntry, hasNavigationFreshVisitedResponse, hasPrefetchCacheEntryForNavigation, hasSearchAgnosticPrefetchShellForRoute, invalidateDynamicPrefetchCache, invalidatePrefetchCache, invalidateVisitedResponsePrefetches, isBailoutToCSRError, isDynamicServerError, isHTTPAccessFallbackError, isNextRouterError, isRedirectError, navigateClientSide, notFound, parseRenderedPathAndSearchHeader, peekPrefetchResponseForNavigation, permanentRedirect, prefetchRscResponse, preloadHybridClientRouteOwner, prepareNavigationPrefetchSnapshot, promotePrefetchCacheEntryForNavigation, pushHistoryStateWithoutNotify, redirect, renderServerInsertedHTML, replaceClientParamsWithoutNotify, replaceHistoryStateWithoutNotify, resolveCachedRscResponseExpiresAt, resolveCachedRscResponseTtlMs, resolveLoadedHybridClientRewriteHref, resolvePrefetchCacheEntryMountedSlotsHeader, restoreRscResponse, saveScrollPosition, seedFullPrefetchFromVisitedResponse, seedPrefetchResponseSnapshot, setClientParams, setMountedSlotsHeader, setNavigationContext, setPendingPathname, snapshotRscResponse, storePrefetchResponse, trackAppRouterNavigationInFlight, unauthorized, unstable_isUnrecognizedActionError, unstable_rethrow, useClientNavigationRenderSnapshot, useParams, usePathname, useRouter, useSearchParams, useSelectedLayoutSegment, useSelectedLayoutSegments, useServerInsertedHTML };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyw2QkFBNkIscUNBQXFDLG9DQUFvQyw2QkFBNkIscUNBQXFDO0FBQ2pMLFNBQVMsK0JBQStCLGtDQUFrQyxzQkFBc0Isd0NBQXdDLHVDQUF1Qyw0QkFBNEIsaUNBQWlDLHdDQUF3QztBQUNwUixTQUFTLCtCQUErQjtBQUN4QyxTQUFTLDRDQUE0QyxrREFBa0Q7QUFDdkcsU0FBUywwQkFBMEIsMkNBQTJDO0FBQzlFLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsMkNBQTJDO0FBQ3BELFNBQVMsNEJBQTRCLGtDQUFrQyxxQkFBcUIsb0JBQW9CO0FBQ2hILFNBQVMsZ0RBQWdEO0FBQ3pELFNBQVMsZUFBZSwwQkFBMEI7QUFDbEQsU0FBUyxvQ0FBb0MseUJBQXlCLHlCQUF5QixxQkFBcUIsc0JBQXNCLHFCQUFxQix1Q0FBdUM7QUFDdE0sU0FBUyxpQ0FBaUMsdUNBQXVDO0FBQ2pGLFNBQVMsc0NBQXNDO0FBQy9DLFNBQVMsc0JBQXNCLHlCQUF5QiwwQ0FBMEM7QUFDbEcsU0FBUyx5QkFBeUIsMENBQTBDO0FBQzVFLFNBQVMsdUJBQXVCO0FBQ2hDLE9BQU87QUFDUCxTQUFTLGlDQUFpQztBQUMxQyxTQUFTLG9EQUFvRDtBQUM3RCxTQUFTLDhDQUE4Qyx3REFBd0Qsd0JBQXdCLHNDQUFzQztBQUM3SyxTQUFTLHVDQUF1QztBQUNoRCxTQUFTLG9DQUFvQztBQUM3QyxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLCtCQUErQjtBQUN4QyxTQUFTLG1CQUFtQixvQkFBb0IsZ0NBQWdDLGNBQWMscUJBQXFCLFdBQVcsNkJBQTZCLHFCQUFxQixzQkFBc0IsMkJBQTJCLG1CQUFtQixpQkFBaUIsVUFBVSxtQkFBbUIsVUFBVSxjQUFjLHdCQUF3QjtBQUNsVixTQUFTLGlDQUFpQztBQUMxQyxTQUFTLDRCQUE0Qiw0QkFBNEIsOEJBQThCLGlDQUFpQyxxQ0FBcUM7QUFDckssU0FBUyxzQkFBc0IsMkJBQTJCLHlCQUF5Qiw2QkFBNkIseUJBQXlCLHlCQUF5Qix3QkFBd0IsNEJBQTRCLHlCQUF5QixzQkFBc0Isb0NBQW9DLDBCQUEwQiw0QkFBNEI7QUFDL1YsU0FBUyx3QkFBd0IseUJBQXlCLDZCQUE2QixnQ0FBZ0M7QUFDdkgsWUFBWSxhQUFhOzs7Ozs7Ozs7QUFTekIsTUFBTSxtQkFBbUIsUUFBUSxJQUFJLDhCQUE4QjtBQUNuRSxNQUFNLHNCQUFzQixRQUFRLElBQUksaUNBQWlDO0FBQ3pFLElBQUksK0JBQStCO0FBQ25DLElBQUksc0NBQXNDOztBQUUxQyxlQUFlLGdDQUFnQztDQUM5QyxJQUFJLDhCQUE4QjtDQUNsQyx3Q0FBd0MsT0FBTztDQUMvQywrQkFBK0IsTUFBTTtBQUN0QztBQUNBLFNBQVMscUNBQXFDLE1BQU0sVUFBVTtDQUM3RCxPQUFPLDhCQUE4QiwrQkFBK0IsTUFBTSxRQUFRLEtBQUs7QUFDeEY7QUFDQSxTQUFTLDhCQUE4QixNQUFNO0NBQzVDLElBQUksQ0FBQyxrQkFBa0IsT0FBTztDQUM5QixPQUFPLCtCQUErQiw2QkFBNkIsOEJBQThCLE1BQU0sVUFBVSxJQUFJLG9DQUFvQyxNQUFNLFVBQVU7QUFDMUs7Ozs7OztBQU1BLFNBQVMsaUJBQWlCLG9CQUFvQixZQUFZO0NBQ3pELE1BQU0sTUFBTSx3QkFBd0I7Q0FDcEMsSUFBSSxDQUFDLEtBQUssT0FBTyxDQUFDO0NBQ2xCLElBQUk7RUFDSCxRQUFRLFFBQVEsV0FBVyxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFDLENBQUUsUUFBUSxZQUFZLENBQUMsUUFBUSxXQUFXLFVBQVUsQ0FBQztDQUM5RyxRQUFRO0VBQ1AsT0FBTyxDQUFDO0NBQ1Q7QUFDRDtBQUNBLE1BQU0sMEJBQTBCLE9BQU8sSUFBSSx3Q0FBd0M7QUFDbkYsTUFBTSxpQ0FBaUMsT0FBTyxJQUFJLDhDQUE4QztBQUNoRyxNQUFNLHFDQUFxQyxPQUFPLElBQUksaURBQWlEO0FBQ3ZHLE1BQU0sOEJBQThCLE9BQU8sSUFBSSx5Q0FBeUM7QUFDeEYsTUFBTSxXQUFXLE9BQU8sV0FBVzs7QUFFbkMsTUFBTSxhQUFhLFFBQVEsSUFBSSwwQkFBMEI7O0FBRXpELE1BQU0sa0JBQWtCLFFBQVEsSUFBSSw0QkFBNEI7O0FBRWhFLE1BQU0scUJBQXFCLFFBQVEsSUFBSSwrQkFBK0I7O0FBRXRFLE1BQU0sMEJBQTBCO0FBQ2hDLE1BQU0sc0NBQXNDLDBCQUEwQjs7Ozs7Ozs7Ozs7Ozs7O0FBZXRFLFNBQVMsNkJBQTZCLEtBQUssWUFBWTtDQUN0RCxJQUFJLFFBQVEsS0FBSyxLQUFLLFFBQVEsSUFBSSxPQUFPO0NBQ3pDLE1BQU0sVUFBVSxPQUFPLEdBQUc7Q0FDMUIsSUFBSSxDQUFDLE9BQU8sU0FBUyxPQUFPLEtBQUssVUFBVSxHQUFHLE9BQU87Q0FDckQsT0FBTyxVQUFVO0FBQ2xCO0FBQ0EsTUFBTSwrQkFBK0IsNkJBQTZCLFFBQVEsSUFBSSx3Q0FBd0MsR0FBRztBQUN6SCxNQUFNLHFCQUFxQiw2QkFBNkIsUUFBUSxJQUFJLHVDQUF1QyxHQUFHOzs7Ozs7QUFNOUcsTUFBTSxnQ0FBZ0M7QUFDdEMsTUFBTSw2QkFBNkIsZ0NBQWdDO0FBQ25FLFNBQVMsZ0NBQWdDO0NBQ3hDLElBQUksVUFBVSxPQUFPO0NBQ3JCLE9BQU8sY0FBYyxPQUFPLFNBQVMsVUFBVSxVQUFVO0FBQzFEO0FBQ0EsU0FBUywrQkFBK0IsWUFBWSxpQkFBaUI7Q0FDcEUsSUFBSSxVQUFVLE9BQU87Q0FDckIsSUFBSTtDQUNKLElBQUk7RUFDSCxZQUFZLElBQUksSUFBSSxZQUFZLE9BQU8sU0FBUyxJQUFJO0NBQ3JELFFBQVE7RUFDUCxPQUFPO0NBQ1I7Q0FDQSxPQUFPLDZDQUE2QztFQUNuRCxVQUFVO0VBQ1YsaUJBQWlCLG1CQUFtQixPQUFPLFNBQVM7RUFDcEQsZUFBZSxxQkFBcUIsQ0FBQyxFQUFFLFVBQVUsaUJBQWlCO0VBQ2xFLGdCQUFnQixVQUFVO0NBQzNCLENBQUM7QUFDRjtBQUNBLFNBQVMsb0JBQW9CO0NBQzVCLElBQUksVUFBVSxPQUFPO0NBQ3JCLE9BQU8sT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTO0FBQ25EO0FBQ0EsU0FBUyxnQ0FBZ0MsU0FBUztDQUNqRCxNQUFNLHNCQUFzQixxQkFBcUIsQ0FBQyxFQUFFLFVBQVUseUJBQXlCLEtBQUs7Q0FDNUYsT0FBTyx3QkFBd0I7RUFDOUIsR0FBRztFQUNILFNBQVMsa0JBQWtCO0VBQzNCLHVCQUF1QixRQUFRLGlCQUFpQjtFQUNoRDtDQUNELENBQUM7QUFDRjs7QUFFQSxTQUFTLG1CQUFtQjtDQUMzQixJQUFJLFVBQVUsdUJBQXVCLElBQUksSUFBSTtDQUM3QyxJQUFJLENBQUMsT0FBTywrQkFBK0IsT0FBTyxnREFBZ0QsSUFBSSxJQUFJO0NBQzFHLE9BQU8sT0FBTztBQUNmOzs7Ozs7O0FBT0EsU0FBUywyQkFBMkIsVUFBVTtDQUM3QyxNQUFNLFFBQVEsaUJBQWlCO0NBQy9CLE1BQU0sUUFBUSxNQUFNLElBQUksUUFBUTtDQUNoQyxJQUFJLFVBQVUsS0FBSyxLQUFLLE1BQU0sU0FBUyxPQUFPO0NBQzlDLElBQUksbUNBQW1DLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxPQUFPO0NBQ25FLHlCQUF5QixPQUFPLGtCQUFrQixHQUFHLFVBQVUsT0FBTyxJQUFJO0FBQzNFOzs7OztBQUtBLFNBQVMsb0JBQW9CO0NBQzVCLElBQUksVUFBVSx1QkFBdUIsSUFBSSxJQUFJO0NBQzdDLElBQUksQ0FBQyxPQUFPLGdDQUFnQyxPQUFPLGlEQUFpRCxJQUFJLElBQUk7Q0FDNUcsT0FBTyxPQUFPO0FBQ2Y7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2xDLE9BQU8sT0FBTyxVQUFVLFlBQVksT0FBTyxTQUFTLEtBQUssS0FBSyxPQUFPLFVBQVUsS0FBSyxLQUFLLFNBQVM7QUFDbkc7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0NBQ2hDLE9BQU8sT0FBTyxVQUFVLFlBQVksT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTO0FBQ3hFO0FBQ0EsU0FBUyw0QkFBNEIsT0FBTztDQUMzQyxJQUFJLFVBQVUsUUFBUSxVQUFVLElBQUksT0FBTyxLQUFLO0NBQ2hELE1BQU0sVUFBVSxPQUFPLEtBQUs7Q0FDNUIsT0FBTyxtQkFBbUIsT0FBTyxJQUFJLFVBQVUsS0FBSztBQUNyRDs7Ozs7QUFLQSxTQUFTLHVCQUF1QixRQUFRO0NBQ3ZDLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxLQUFLO0NBQ25DLElBQUksT0FBTyxTQUFTLFdBQVcsT0FBTztDQUN0QyxPQUFPLEtBQUssSUFBSSxPQUFPLFNBQVMsNkJBQTZCO0FBQzlEOzs7Ozs7Ozs7QUFTQSxTQUFTLG1DQUFtQyxRQUFRO0NBQ25ELE1BQU0sVUFBVSxPQUFPO0NBQ3ZCLE1BQU0sU0FBUyx1QkFBdUIsT0FBTyxlQUFlO0NBQzVELElBQUksQ0FBQyxtQkFBbUIsT0FBTyxHQUFHLE9BQU87Q0FDekMsT0FBTyxXQUFXLEtBQUssSUFBSSxVQUFVLEtBQUssSUFBSSxTQUFTLE1BQU07QUFDOUQ7QUFDQSxTQUFTLDhCQUE4QixRQUFRLGVBQWU7Q0FDN0QsTUFBTSxVQUFVLG1DQUFtQyxNQUFNO0NBQ3pELElBQUksWUFBWSxLQUFLLEdBQUcsT0FBTztDQUMvQixPQUFPLFVBQVU7QUFDbEI7QUFDQSxTQUFTLGtDQUFrQyxXQUFXLFFBQVEsZUFBZTtDQUM1RSxJQUFJLGlCQUFpQixPQUFPLFNBQVMsR0FBRyxPQUFPLE9BQU87Q0FDdEQsT0FBTyxZQUFZLDhCQUE4QixRQUFRLGFBQWE7QUFDdkU7QUFDQSxTQUFTLHNDQUFzQyxXQUFXLFFBQVEsZUFBZSxrQkFBa0I7Q0FDbEcsSUFBSSxpQkFBaUIsT0FBTyxTQUFTLEdBQUcsT0FBTyxPQUFPO0NBQ3RELE1BQU0sZ0JBQWdCLE9BQU8saUJBQWlCLFNBQVMsYUFBYSxxQkFBcUIsYUFBYSxLQUFLLElBQUksdUJBQXVCLE9BQU8sZUFBZTtDQUM1SixJQUFJLGtCQUFrQixLQUFLLEdBQUcsT0FBTyxZQUFZLGdCQUFnQjtDQUNqRSxJQUFJLHFCQUFxQixVQUFVLE9BQU8sWUFBWSxLQUFLLElBQUksZUFBZSwwQkFBMEI7Q0FDeEcsTUFBTSxVQUFVLG1CQUFtQixPQUFPLHVCQUF1QixJQUFJLE9BQU8sMEJBQTBCLEtBQUs7Q0FDM0csSUFBSSxZQUFZLEtBQUssR0FBRyxPQUFPLFlBQVksS0FBSyxJQUFJLGVBQWUsMEJBQTBCO0NBQzdGLE9BQU8scUJBQXFCLGFBQWEsWUFBWSxVQUFVLE1BQU0sYUFBYSxZQUFZLElBQUksS0FBSyxJQUFJLGVBQWUsMEJBQTBCLElBQUksS0FBSyxJQUFJLFVBQVUsS0FBSywwQkFBMEI7QUFDM007QUFDQSxTQUFTLG1DQUFtQyxPQUFPO0NBQ2xELElBQUksTUFBTSxjQUFjLEtBQUssR0FBRyxPQUFPLE1BQU07Q0FDN0MsSUFBSSxNQUFNLFVBQVUsT0FBTyxrQ0FBa0MsTUFBTSxXQUFXLE1BQU0sVUFBVSxrQkFBa0I7Q0FDaEgsT0FBTyxNQUFNLFlBQVk7QUFDMUI7QUFDQSxTQUFTLDRDQUE0QyxPQUFPO0NBQzNELElBQUksTUFBTSx1QkFBdUIsS0FBSyxHQUFHLE9BQU8sTUFBTTtDQUN0RCxPQUFPLE1BQU0sVUFBVSxzQkFBc0I7QUFDOUM7QUFDQSxTQUFTLDJCQUEyQixRQUFRO0NBQzNDLElBQUk7RUFDSCxNQUFNLE1BQU0sb0JBQW9CLE1BQU07RUFDdEMsZ0NBQWdDLEdBQUc7RUFDbkMsT0FBTyxHQUFHLElBQUksV0FBVyxJQUFJO0NBQzlCLFFBQVE7RUFDUCxPQUFPO0NBQ1I7QUFDRDtBQUNBLFNBQVMsZ0NBQWdDLFFBQVE7Q0FDaEQsSUFBSTtFQUNILE9BQU8sb0JBQW9CLE1BQU0sQ0FBQyxDQUFDO0NBQ3BDLFFBQVE7RUFDUCxPQUFPO0NBQ1I7QUFDRDtBQUNBLFNBQVMsc0JBQXNCLFVBQVU7Q0FDeEMsTUFBTSxpQkFBaUIsU0FBUyxRQUFRLElBQUk7Q0FDNUMsSUFBSSxtQkFBbUIsQ0FBQyxHQUFHLE9BQU87RUFDakMscUJBQXFCO0VBQ3JCLFFBQVE7Q0FDVDtDQUNBLE9BQU87RUFDTixxQkFBcUIsU0FBUyxNQUFNLGlCQUFpQixDQUFDO0VBQ3RELFFBQVEsU0FBUyxNQUFNLEdBQUcsY0FBYztDQUN6QztBQUNEO0FBQ0EsU0FBUywrQ0FBK0MsT0FBTyxvQkFBb0I7Q0FDbEYsSUFBSSw0Q0FBNEMsS0FBSyxNQUFNLG9CQUFvQixPQUFPO0NBQ3RGLFFBQVEsTUFBTSxVQUFVLHNCQUFzQixVQUFVO0FBQ3pEO0FBQ0EsU0FBUyxvQ0FBb0MsUUFBUSxxQkFBcUIsb0JBQW9CLG9CQUFvQixDQUFDLEdBQUc7Q0FDckgsTUFBTSxRQUFRLGlCQUFpQjtDQUMvQixNQUFNLFVBQVUsQ0FBQyxRQUFRLEdBQUcsaUJBQWlCO0NBQzdDLEtBQUssTUFBTSxnQkFBZ0IsU0FBUztFQUNuQyxNQUFNLGdCQUFnQixnQkFBZ0IsZUFBZSxjQUFjLG1CQUFtQjtFQUN0RixNQUFNLGFBQWEsTUFBTSxJQUFJLGFBQWE7RUFDMUMsSUFBSSxjQUFjLFdBQVcsdUJBQXVCLFNBQVMsK0NBQStDLFlBQVksa0JBQWtCLEdBQUcsT0FBTztHQUNuSixVQUFVO0dBQ1YsT0FBTztFQUNSO0NBQ0Q7Q0FDQSxNQUFNLG9CQUFvQixJQUFJLElBQUksUUFBUSxLQUFLLGlCQUFpQiwyQkFBMkIsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLGlCQUFpQixpQkFBaUIsSUFBSSxDQUFDO0NBQ3pKLElBQUksa0JBQWtCLFNBQVMsR0FBRyxPQUFPO0NBQ3pDLEtBQUssTUFBTSxDQUFDLFVBQVUsVUFBVSxPQUFPO0VBQ3RDLElBQUksTUFBTSx1QkFBdUIsT0FBTztFQUN4QyxNQUFNLFNBQVMsc0JBQXNCLFFBQVE7RUFDN0MsSUFBSSxPQUFPLHdCQUF3QixxQkFBcUI7RUFDeEQsTUFBTSxtQkFBbUIsMkJBQTJCLE9BQU8sTUFBTTtFQUNqRSxJQUFJLHFCQUFxQixRQUFRLENBQUMsa0JBQWtCLElBQUksZ0JBQWdCLEdBQUc7RUFDM0UsSUFBSSxDQUFDLCtDQUErQyxPQUFPLGtCQUFrQixHQUFHO0VBQ2hGLE9BQU87R0FDTjtHQUNBO0VBQ0Q7Q0FDRDtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsbUNBQW1DLFFBQVEsc0JBQXNCLE1BQU0scUJBQXFCLE1BQU0sVUFBVSxDQUFDLEdBQUc7Q0FDeEgsTUFBTSxRQUFRLG9DQUFvQyxRQUFRLHFCQUFxQixvQkFBb0IsUUFBUSxpQkFBaUI7Q0FDNUgsSUFBSSxVQUFVLE1BQU0sT0FBTztDQUMzQixJQUFJLE1BQU0sTUFBTSxZQUFZLEtBQUssS0FBSyxRQUFRLGlCQUFpQixPQUFPLE9BQU87Q0FDN0UsSUFBSSxNQUFNLE1BQU0sWUFBWSxLQUFLLEtBQUssbUNBQW1DLE1BQU0sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHO0VBQ25HLHdCQUF3QixpQkFBaUIsR0FBRyxNQUFNLFVBQVUsTUFBTSxLQUFLO0VBQ3ZFLGtDQUFrQyxNQUFNLFVBQVUsTUFBTSxPQUFPLFFBQVEsWUFBWTtFQUNuRixRQUFRLFVBQVUsTUFBTSxPQUFPLE1BQU0sUUFBUTtFQUM3QyxPQUFPO0NBQ1I7Q0FDQSx5QkFBeUIsaUJBQWlCLEdBQUcsa0JBQWtCLEdBQUcsTUFBTSxVQUFVLE1BQU0sT0FBTyxRQUFRLHNCQUFzQixJQUFJO0NBQ2pJLE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyx1Q0FBdUMsUUFBUSxzQkFBc0IsTUFBTTtDQUNuRixNQUFNLFdBQVcsZ0JBQWdCLGVBQWUsUUFBUSxtQkFBbUI7Q0FDM0UsTUFBTSxRQUFRLGlCQUFpQjtDQUMvQixNQUFNLFFBQVEsTUFBTSxJQUFJLFFBQVE7Q0FDaEMsSUFBSSxPQUFPLHVCQUF1QixPQUFPLE9BQU87Q0FDaEQsSUFBSSxNQUFNLFlBQVksS0FBSyxLQUFLLG1DQUFtQyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUc7RUFDdkYsd0JBQXdCLE9BQU8sVUFBVSxLQUFLO0VBQzlDLE9BQU87Q0FDUjtDQUNBLHlCQUF5QixPQUFPLGtCQUFrQixHQUFHLFVBQVUsT0FBTyxJQUFJO0NBQzFFLE9BQU87QUFDUjtBQUNBLFNBQVMsdUNBQXVDLFFBQVEsc0JBQXNCLE1BQU0scUJBQXFCLE1BQU07Q0FDOUcsTUFBTSwyQkFBMkIsZ0NBQWdDLE1BQU07Q0FDdkUsSUFBSSw2QkFBNkIsTUFBTSxPQUFPO0NBQzlDLE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsS0FBSyxNQUFNLENBQUMsVUFBVSxVQUFVLE9BQU87RUFDdEMsSUFBSSxNQUFNLHdCQUF3QixNQUFNO0VBQ3hDLE1BQU0sU0FBUyxzQkFBc0IsUUFBUTtFQUM3QyxJQUFJLE9BQU8sd0JBQXdCLHFCQUFxQjtFQUN4RCxJQUFJLGdDQUFnQyxPQUFPLE1BQU0sTUFBTSwwQkFBMEI7RUFDakYsSUFBSSxDQUFDLCtDQUErQyxPQUFPLGtCQUFrQixHQUFHO0VBQ2hGLElBQUksTUFBTSxZQUFZLEtBQUssR0FBRyxPQUFPO0VBQ3JDLElBQUksbUNBQW1DLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxPQUFPO0VBQ25FLHlCQUF5QixPQUFPLGtCQUFrQixHQUFHLFVBQVUsT0FBTyxJQUFJO0NBQzNFO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUywwQkFBMEIsT0FBTztDQUN6QyxPQUFPLE1BQU0sVUFBVSxPQUFPLGNBQWMsTUFBTSxRQUFRO0FBQzNEO0FBQ0EsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSwrQkFBK0I7QUFDbkMsU0FBUyx5QkFBeUIsT0FBTztDQUN4QyxJQUFJLHlCQUF5QixPQUFPLE9BQU87Q0FDM0MsSUFBSSxRQUFRO0NBQ1osTUFBTSx1QkFBdUIsSUFBSSxJQUFJO0NBQ3JDLEtBQUssTUFBTSxTQUFTLE1BQU0sT0FBTyxHQUFHO0VBQ25DLElBQUksS0FBSyxJQUFJLEtBQUssR0FBRztFQUNyQixLQUFLLElBQUksS0FBSztFQUNkLFNBQVMsMEJBQTBCLEtBQUs7Q0FDekM7Q0FDQSx1QkFBdUI7Q0FDdkIsK0JBQStCO0NBQy9CLE9BQU87QUFDUjtBQUNBLFNBQVMsNEJBQTRCLE9BQU8sT0FBTztDQUNsRCxJQUFJLHlCQUF5QixPQUFPO0NBQ3BDLCtCQUErQixLQUFLLElBQUksR0FBRywrQkFBK0IsS0FBSztBQUNoRjtBQUNBLFNBQVMsd0JBQXdCLE9BQU8sVUFBVSxPQUFPO0NBQ3hELElBQUksTUFBTSxJQUFJLFFBQVEsTUFBTSxPQUFPO0NBQ25DLE1BQU0sT0FBTyxRQUFRO0NBQ3JCLE1BQU0sSUFBSSxVQUFVLEtBQUs7Q0FDekIsS0FBSyxNQUFNLE9BQU8sTUFBTSxhQUFhLENBQUMsR0FBRztFQUN4QyxJQUFJLFFBQVEsWUFBWSxNQUFNLElBQUksR0FBRyxNQUFNLE9BQU87RUFDbEQsTUFBTSxPQUFPLEdBQUc7RUFDaEIsTUFBTSxJQUFJLEtBQUssS0FBSztDQUNyQjtBQUNEOzs7Ozs7QUFNQSxTQUFTLDZCQUE2QjtDQUNyQyxNQUFNLFFBQVEsaUJBQWlCO0NBQy9CLElBQUksWUFBWSx5QkFBeUIsS0FBSztDQUM5QyxJQUFJLGFBQWEsVUFBVTtDQUMzQixNQUFNLE1BQU0sS0FBSyxJQUFJO0NBQ3JCLE1BQU0sYUFBYSxrQkFBa0I7Q0FDckMsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLE9BQU8sSUFBSSxtQ0FBbUMsS0FBSyxLQUFLLEtBQUsseUJBQXlCLE9BQU8sWUFBWSxLQUFLLE9BQU8sSUFBSTtDQUNwSixZQUFZLHlCQUF5QixLQUFLO0NBQzFDLElBQUksYUFBYSxVQUFVO0NBQzNCLElBQUksbUJBQW1CO0NBQ3ZCLE9BQU8sWUFBWSx1Q0FBdUMsbUJBQW1CLE1BQU0sTUFBTTtFQUN4RixNQUFNLFNBQVMsTUFBTSxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztFQUNuQyxJQUFJLFdBQVcsS0FBSyxHQUFHO0dBQ3RCLE1BQU0sUUFBUSxNQUFNLElBQUksTUFBTTtHQUM5QixJQUFJLE9BQU87SUFDVixNQUFNLFlBQVksMEJBQTBCLEtBQUs7SUFDakQsSUFBSSxNQUFNLFlBQVksS0FBSyxLQUFLLGNBQWMsR0FBRztLQUNoRCx3QkFBd0IsT0FBTyxRQUFRLEtBQUs7S0FDNUMsb0JBQW9CO0tBQ3BCO0lBQ0Q7SUFDQSxhQUFhO0lBQ2IseUJBQXlCLE9BQU8sWUFBWSxRQUFRLE9BQU8sSUFBSTtJQUMvRCxtQkFBbUI7R0FDcEIsT0FBTztJQUNOLE1BQU0sT0FBTyxNQUFNO0lBQ25CLFdBQVcsT0FBTyxNQUFNO0lBQ3hCLG9CQUFvQjtHQUNyQjtFQUNELE9BQU87Q0FDUjtBQUNEO0FBQ0EsTUFBTSx3Q0FBd0MsSUFBSSxJQUFJO0FBQ3RELFNBQVMsbUJBQW1CLGFBQWE7Q0FDeEMsTUFBTSxRQUFRO0VBQ2I7RUFDQSxXQUFXO0NBQ1o7Q0FDQSxzQkFBc0IsSUFBSSxLQUFLO0NBQy9CLE9BQU87QUFDUjs7QUFFQSxTQUFTLDRCQUE0QixhQUFhO0NBQ2pELEtBQUssTUFBTSxTQUFTLHVCQUF1QixJQUFJLGdCQUFnQixRQUFRLE1BQU0sZ0JBQWdCLGFBQWEsTUFBTSxZQUFZO0FBQzdIOzs7Ozs7O0FBT0EsU0FBUyx5QkFBeUIsTUFBTTtDQUN2QyxJQUFJLFVBQVUsT0FBTztDQUNyQixJQUFJLFlBQVk7Q0FDaEIsSUFBSSxjQUFjLElBQUksR0FBRztFQUN4QixNQUFNLFlBQVksb0JBQW9CLE1BQU0sVUFBVTtFQUN0RCxJQUFJLGFBQWEsTUFBTSxPQUFPO0VBQzlCLFlBQVk7Q0FDYjtDQUNBLE1BQU0sY0FBYyxpQ0FBaUMsV0FBVyxPQUFPLFNBQVMsTUFBTSxZQUFZLGVBQWU7Q0FDakgsSUFBSTtFQUNILE9BQU8scUJBQXFCLElBQUksSUFBSSxhQUFhLE9BQU8sU0FBUyxJQUFJLENBQUM7Q0FDdkUsUUFBUTtFQUNQLE9BQU8sWUFBWSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUM7Q0FDbEM7QUFDRDtBQUNBLFNBQVMsMEJBQTBCLE9BQU87Q0FDekMsSUFBSSxNQUFNLHNCQUFzQixLQUFLLEdBQUc7RUFDdkMsYUFBYSxNQUFNLGlCQUFpQjtFQUNwQyxNQUFNLG9CQUFvQixLQUFLO0NBQ2hDO0FBQ0Q7QUFDQSxTQUFTLHdCQUF3QixjQUFjO0NBQzlDLElBQUk7RUFDSCxhQUFhO0NBQ2QsU0FBUyxPQUFPO0VBQ2YsSUFBSSxPQUFPLGdCQUFnQixZQUFZLFlBQVksS0FBSztPQUNuRCxRQUFRLE1BQU0sS0FBSztDQUN6QjtBQUNEO0FBQ0EsU0FBUywwQkFBMEIsT0FBTztDQUN6QywwQkFBMEIsS0FBSztDQUMvQixNQUFNLFlBQVksTUFBTTtDQUN4QixNQUFNLHdCQUF3QixLQUFLO0NBQ25DLElBQUksY0FBYyxLQUFLLEdBQUc7Q0FDMUIsS0FBSyxNQUFNLGdCQUFnQixXQUFXLHdCQUF3QixZQUFZO0FBQzNFO0FBQ0EsTUFBTSxnREFBZ0QsSUFBSSxJQUFJO0FBQzlELFNBQVMsdUNBQXVDLE9BQU87Q0FDdEQsTUFBTSxZQUFZLE1BQU07Q0FDeEIsSUFBSSxjQUFjLEtBQUssS0FBSyxVQUFVLFNBQVMsR0FBRztDQUNsRCwyQkFBMkIsV0FBVyxtQ0FBbUMsS0FBSyxDQUFDO0FBQ2hGO0FBQ0EsU0FBUywyQkFBMkIsV0FBVyxXQUFXLHFCQUFxQixPQUFPO0NBQ3JGLE1BQU0sUUFBUSxLQUFLLElBQUksR0FBRyxZQUFZLEtBQUssSUFBSSxDQUFDO0NBQ2hELE1BQU0sV0FBVztFQUNoQjtFQUNBLEdBQUcscUJBQXFCLEVBQUUsb0JBQW9CLEtBQUssSUFBSSxDQUFDO0VBQ3hELE9BQU8saUJBQWlCLGlDQUFpQyxRQUFRLEdBQUcsS0FBSztDQUMxRTtDQUNBLDhCQUE4QixJQUFJLFFBQVE7QUFDM0M7QUFDQSxTQUFTLGlDQUFpQyxVQUFVO0NBQ25ELElBQUksQ0FBQyw4QkFBOEIsT0FBTyxRQUFRLEdBQUc7Q0FDckQsYUFBYSxTQUFTLEtBQUs7Q0FDM0IsS0FBSyxNQUFNLGdCQUFnQixTQUFTLFdBQVcsd0JBQXdCLFlBQVk7QUFDcEY7QUFDQSxTQUFTLHlCQUF5QixPQUFPLFlBQVksVUFBVSxPQUFPLFFBQVE7Q0FDN0UsTUFBTSxZQUFZLE1BQU0sNkJBQTZCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQztDQUN2RSxJQUFJLGtCQUFrQjtDQUN0QixLQUFLLE1BQU0sT0FBTyxXQUFXLElBQUksTUFBTSxJQUFJLEdBQUcsTUFBTSxPQUFPO0VBQzFELE1BQU0sT0FBTyxHQUFHO0VBQ2hCLFdBQVcsT0FBTyxHQUFHO0VBQ3JCLGtCQUFrQjtDQUNuQjtDQUNBLElBQUksQ0FBQyxpQkFBaUI7Q0FDdEIsNEJBQTRCLE9BQU8sQ0FBQywwQkFBMEIsS0FBSyxDQUFDO0NBQ3BFLE1BQU0sWUFBWSxLQUFLO0NBQ3ZCLElBQUksUUFBUSwwQkFBMEIsS0FBSztNQUN0QztFQUNKLDBCQUEwQixLQUFLO0VBQy9CLE1BQU0sd0JBQXdCLEtBQUs7Q0FDcEM7QUFDRDtBQUNBLFNBQVMsc0NBQXNDLFFBQVEsc0JBQXNCLE1BQU0scUJBQXFCLE1BQU07Q0FDN0csTUFBTSxRQUFRLGlCQUFpQjtDQUMvQixNQUFNLGFBQWEsa0JBQWtCO0NBQ3JDLE1BQU0sbUJBQW1CLDJCQUEyQixNQUFNO0NBQzFELElBQUkscUJBQXFCLE1BQU0sT0FBTztDQUN0QyxNQUFNLGFBQWEsQ0FBQztDQUNwQixLQUFLLE1BQU0sQ0FBQyxVQUFVLFVBQVUsT0FBTztFQUN0QyxJQUFJLE1BQU0sdUJBQXVCLFNBQVMsTUFBTSxpQkFBaUIsY0FBYztFQUMvRSxNQUFNLFNBQVMsc0JBQXNCLFFBQVE7RUFDN0MsSUFBSSxPQUFPLHdCQUF3QixxQkFBcUI7RUFDeEQsSUFBSSwyQkFBMkIsT0FBTyxNQUFNLE1BQU0sa0JBQWtCO0VBQ3BFLElBQUksQ0FBQywrQ0FBK0MsT0FBTyxrQkFBa0IsR0FBRztFQUNoRixXQUFXLEtBQUssQ0FBQyxVQUFVLEtBQUssQ0FBQztDQUNsQztDQUNBLEtBQUssTUFBTSxDQUFDLFVBQVUsVUFBVSxZQUFZO0VBQzNDLHVCQUF1QixNQUFNLFlBQVk7RUFDekMseUJBQXlCLE9BQU8sWUFBWSxVQUFVLE9BQU8sSUFBSTtDQUNsRTtDQUNBLE9BQU8sV0FBVyxTQUFTO0FBQzVCOzs7Ozs7Ozs7QUFTQSxTQUFTLHVDQUF1QyxVQUFVLE9BQU87Q0FDaEUsSUFBSSxNQUFNLHFCQUFxQixpQkFBaUI7RUFDL0MsTUFBTSxxQkFBcUI7RUFDM0I7Q0FDRDtDQUNBLElBQUksTUFBTSx1QkFBdUIsT0FBTztDQUN4QyxNQUFNLG1CQUFtQjtDQUN6QixJQUFJLE1BQU0sYUFBYSxLQUFLLEdBQUc7Q0FDL0IsTUFBTSxZQUFZLHNDQUFzQyxNQUFNLFdBQVcsTUFBTSxVQUFVLE1BQU0saUJBQWlCLG9CQUFvQixlQUFlO0NBQ25KLDZCQUE2QixVQUFVLEtBQUs7QUFDN0M7QUFDQSxTQUFTLDZCQUE2QixVQUFVO0NBQy9DLE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsTUFBTSxRQUFRLE1BQU0sSUFBSSxRQUFRO0NBQ2hDLElBQUksQ0FBQyxPQUFPO0NBQ1oseUJBQXlCLE9BQU8sa0JBQWtCLEdBQUcsVUFBVSxPQUFPLElBQUk7QUFDM0U7QUFDQSxTQUFTLDZCQUE2QixVQUFVLE9BQU87Q0FDdEQsSUFBSSxNQUFNLDBCQUEwQixLQUFLLEtBQUssTUFBTSxzQkFBc0IsU0FBUyxHQUFHO0NBQ3RGLDBCQUEwQixLQUFLO0NBQy9CLE1BQU0sUUFBUSxLQUFLLElBQUksR0FBRyxtQ0FBbUMsS0FBSyxJQUFJLEtBQUssSUFBSSxDQUFDO0NBQ2hGLE1BQU0sb0JBQW9CLGlCQUFpQjtFQUMxQyw2QkFBNkIsUUFBUTtDQUN0QyxHQUFHLEtBQUs7QUFDVDtBQUNBLFNBQVMsZ0NBQWdDLE9BQU8sY0FBYztDQUM3RCxJQUFJLGlCQUFpQixLQUFLLEdBQUc7Q0FDN0IsSUFBSSxNQUFNLDBCQUEwQixLQUFLLEdBQUcsTUFBTSx3Q0FBd0MsSUFBSSxJQUFJO0NBQ2xHLE1BQU0sc0JBQXNCLElBQUksWUFBWTtBQUM3Qzs7Ozs7O0FBTUEsU0FBUyxrQ0FBa0MsVUFBVSxPQUFPLGNBQWM7Q0FDekUsSUFBSSxpQkFBaUIsS0FBSyxHQUFHO0NBQzdCLGdDQUFnQyxPQUFPLFlBQVk7Q0FDbkQsSUFBSSxNQUFNLFlBQVksZ0JBQWdCLDZCQUE2QixVQUFVLEtBQUs7QUFDbkY7QUFDQSxTQUFTLG1DQUFtQyxVQUFVLGNBQWM7Q0FDbkUsSUFBSSxpQkFBaUIsS0FBSyxHQUFHO0NBQzdCLE1BQU0sUUFBUSxpQkFBaUIsQ0FBQyxDQUFDLElBQUksUUFBUTtDQUM3QyxJQUFJLENBQUMsT0FBTztDQUNaLGtDQUFrQyxVQUFVLE9BQU8sWUFBWTtBQUNoRTtBQUNBLFNBQVMsd0JBQXdCLFVBQVUsQ0FBQyxHQUFHO0NBQzlDLDRCQUE0QixJQUFJO0NBQ2hDLE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsTUFBTSxhQUFhLGtCQUFrQjtDQUNyQyxLQUFLLE1BQU0sQ0FBQyxVQUFVLFVBQVUsT0FBTyx5QkFBeUIsT0FBTyxZQUFZLFVBQVUsT0FBTyxJQUFJO0NBQ3hHLFdBQVcsTUFBTTtDQUNqQixLQUFLLE1BQU0sWUFBWSwrQkFBK0IsaUNBQWlDLFFBQVE7Q0FDL0YsSUFBSSxDQUFDLFlBQVksUUFBUSxxQkFBcUIsT0FBTyxxQkFBcUIsQ0FBQyxFQUFFLFVBQVUsbUJBQW1CO0FBQzNHOzs7Ozs7Ozs7O0FBVUEsU0FBUyxpQ0FBaUM7Q0FDekMsTUFBTSxRQUFRLGlCQUFpQjtDQUMvQixNQUFNLGFBQWEsa0JBQWtCO0NBQ3JDLE1BQU0sVUFBVSxDQUFDO0NBQ2pCLEtBQUssTUFBTSxDQUFDLFVBQVUsVUFBVSxPQUFPLElBQUksRUFBRSxNQUFNLGlCQUFpQixnQkFBZ0IsTUFBTSxpQkFBaUIsS0FBSyxNQUFNLE1BQU0scUJBQXFCLG1CQUFtQixNQUFNLGFBQWEsS0FBSyxLQUFLLENBQUMsbUJBQW1CLE1BQU0sU0FBUyx1QkFBdUIsS0FBSyxRQUFRLEtBQUssQ0FBQyxVQUFVLEtBQUssQ0FBQztDQUM5UixLQUFLLE1BQU0sQ0FBQyxVQUFVLFVBQVUsU0FBUyx5QkFBeUIsT0FBTyxZQUFZLFVBQVUsT0FBTyxJQUFJO0FBQzNHOzs7OztBQUtBLFNBQVMsc0NBQXNDO0NBQzlDLEtBQUssTUFBTSxZQUFZLCtCQUErQixJQUFJLFNBQVMsdUJBQXVCLE1BQU0saUNBQWlDLFFBQVE7QUFDMUk7Ozs7Ozs7QUFPQSxTQUFTLDhDQUE4QztDQUN0RCxJQUFJLFlBQVk7Q0FDaEIsS0FBSyxNQUFNLFNBQVMsSUFBSSxJQUFJLGlCQUFpQixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxNQUFNLGlCQUFpQixLQUFLLEtBQUssTUFBTSw2QkFBNkIsTUFBTTtFQUN2SSxjQUFjLE1BQU0sdUJBQXVCO0VBQzNDLE1BQU0scUJBQXFCO0NBQzVCO0NBQ0EsSUFBSSxhQUFhLENBQUMsVUFBVSxxQkFBcUIsQ0FBQyxFQUFFLFVBQVUsbUJBQW1CO0FBQ2xGO0FBQ0EsU0FBUyw2QkFBNkIsUUFBUSxVQUFVLHNCQUFzQixNQUFNLHFCQUFxQixNQUFNLGdCQUFnQiw4QkFBOEIsMkJBQTJCLE9BQU8sWUFBWSxrQ0FBa0MsS0FBSyxJQUFJLEdBQUcsVUFBVSxhQUFhLEdBQUc7Q0FDbFIsTUFBTSxXQUFXLGdCQUFnQixlQUFlLFFBQVEsbUJBQW1CO0NBQzNFLE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsTUFBTSxXQUFXLE1BQU0sSUFBSSxRQUFRO0NBQ25DLElBQUksVUFBVSx5QkFBeUIsT0FBTyxrQkFBa0IsR0FBRyxVQUFVLFVBQVUsS0FBSztDQUM1RixNQUFNLFlBQVksS0FBSyxJQUFJO0NBQzNCLE1BQU0sUUFBUTtFQUNiLG9CQUFvQjtFQUNwQiwyQkFBMkIsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDO0VBQzdDO0VBQ0E7RUFDQSxTQUFTO0VBQ1Q7RUFDQSxNQUFNLFNBQVMsT0FBTztFQUN0QjtFQUNBO0NBQ0Q7Q0FDQSxNQUFNLElBQUksVUFBVSxLQUFLO0NBQ3pCLDRCQUE0QixPQUFPLFNBQVMsT0FBTyxVQUFVO0NBQzdELGtCQUFrQixDQUFDLENBQUMsSUFBSSxRQUFRO0NBQ2hDLDZCQUE2QixVQUFVLEtBQUs7Q0FDNUMsMkJBQTJCO0FBQzVCOzs7Ozs7O0FBT0EsU0FBUyxvQ0FBb0MsUUFBUSxxQkFBcUIsb0JBQW9CLG9CQUFvQixDQUFDLEdBQUcsY0FBYztDQUNuSSxNQUFNLFVBQVUscUJBQXFCLENBQUMsRUFBRSxVQUFVLHFDQUFxQyxDQUFDLFFBQVEsR0FBRyxpQkFBaUIsR0FBRyxxQkFBcUIsa0JBQWtCO0NBQzlKLElBQUksQ0FBQyxTQUFTLE9BQU87Q0FDckIsTUFBTSxZQUFZLFFBQVEsY0FBYyxLQUFLLElBQUksb0JBQW9CLDBCQUEwQjtDQUMvRixJQUFJLGFBQWEsS0FBSyxJQUFJLEdBQUcsT0FBTztDQUNwQyw2QkFBNkIsUUFBUSxRQUFRLFVBQVUscUJBQXFCLG9CQUFvQixLQUFLLEdBQUcsTUFBTSxTQUFTO0NBQ3ZILE1BQU0sV0FBVyxnQkFBZ0IsZUFBZSxRQUFRLG1CQUFtQjtDQUMzRSxJQUFJLGlCQUFpQixDQUFDLENBQUMsSUFBSSxRQUFRLENBQUMsRUFBRSxhQUFhLFFBQVEsVUFBVSxPQUFPO0NBQzVFLG1DQUFtQyxVQUFVLFlBQVk7Q0FDekQsT0FBTztBQUNSOzs7Ozs7O0FBT0EsU0FBUyxrQ0FBa0MsUUFBUSxxQkFBcUIsb0JBQW9CLG9CQUFvQixDQUFDLEdBQUcsY0FBYztDQUNqSSxNQUFNLGFBQWEscUJBQXFCLENBQUMsRUFBRSxVQUFVLHFDQUFxQyxDQUFDLFFBQVEsR0FBRyxpQkFBaUIsR0FBRyxxQkFBcUIsa0JBQWtCLENBQUMsRUFBRTtDQUNwSyxJQUFJLGVBQWUsS0FBSyxLQUFLLGVBQWUsTUFBTSxPQUFPO0NBQ3pELElBQUksaUJBQWlCLEtBQUssR0FBRywyQ0FBMkMsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsWUFBWSxJQUFJO0NBQ2pILE9BQU87QUFDUjtBQUNBLFNBQVMsK0JBQStCLFFBQVEsVUFBVSxzQkFBc0IsTUFBTTtDQUNyRixNQUFNLFdBQVcsZ0JBQWdCLGVBQWUsUUFBUSxtQkFBbUI7Q0FDM0UsTUFBTSxRQUFRLGlCQUFpQjtDQUMvQixNQUFNLFFBQVEsTUFBTSxJQUFJLFFBQVE7Q0FDaEMsSUFBSSxPQUFPLGFBQWEsVUFBVTtDQUNsQyx5QkFBeUIsT0FBTyxrQkFBa0IsR0FBRyxVQUFVLE9BQU8sS0FBSztBQUM1RTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBUyxzQkFBc0IsUUFBUSxVQUFVLHNCQUFzQixNQUFNLFNBQVM7Q0FDckYsTUFBTSxXQUFXLGdCQUFnQixlQUFlLFFBQVEsbUJBQW1CO0NBQzNFLE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsTUFBTSxhQUFhLGtCQUFrQjtDQUNyQyxNQUFNLFdBQVcsTUFBTSxJQUFJLFFBQVE7Q0FDbkMsSUFBSSxVQUFVLHlCQUF5QixPQUFPLFlBQVksVUFBVSxVQUFVLEtBQUs7Q0FDbkYsTUFBTSxRQUFRO0VBQ2IsMkJBQTJCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQztFQUM3QyxvQkFBb0I7RUFDcEIsU0FBUztFQUNULFdBQVcsS0FBSyxJQUFJO0NBQ3JCO0NBQ0EsZ0NBQWdDLE9BQU8sU0FBUyxZQUFZO0NBQzVELE1BQU0sVUFBVSxvQkFBb0IsUUFBUSxDQUFDLENBQUMsTUFBTSxhQUFhO0VBQ2hFLElBQUksTUFBTSxJQUFJLFFBQVEsTUFBTSxPQUFPO0VBQ25DLE1BQU0sZUFBZSwwQkFBMEIsS0FBSztFQUNwRCxNQUFNLHFCQUFxQixTQUFTLHNCQUFzQjtFQUMxRCxNQUFNLFdBQVc7RUFDakIsTUFBTSxPQUFPLFNBQVMsT0FBTztFQUM3Qiw0QkFBNEIsT0FBTyxNQUFNLE9BQU8sWUFBWTtFQUM1RCxNQUFNLFlBQVksa0NBQWtDLE1BQU0sV0FBVyxVQUFVLGtCQUFrQjtFQUNqRywyQkFBMkI7Q0FDNUIsQ0FBQyxDQUFDLENBQUMsWUFBWTtFQUNkLHlCQUF5QixPQUFPLFlBQVksVUFBVSxPQUFPLEtBQUs7Q0FDbkUsQ0FBQyxDQUFDLENBQUMsY0FBYztFQUNoQixJQUFJLE1BQU0sSUFBSSxRQUFRLE1BQU0sT0FBTztFQUNuQyxNQUFNLFVBQVUsS0FBSztFQUNyQixJQUFJLE1BQU0sVUFBVTtHQUNuQixNQUFNLFVBQVU7R0FDaEIsNkJBQTZCLFVBQVUsS0FBSztFQUM3QztDQUNELENBQUM7Q0FDRCxNQUFNLElBQUksVUFBVSxLQUFLO0FBQzFCO0FBQ0EsU0FBUyxnQ0FBZ0MsVUFBVSxRQUFRLGNBQWMsTUFBTTtDQUM5RSxNQUFNLGdDQUFnQyw0QkFBNEIsU0FBUyxRQUFRLElBQUksZ0NBQWdDLENBQUM7Q0FDeEgsTUFBTSxpQkFBaUIsU0FBUyxRQUFRLElBQUkscUNBQXFDO0NBQ2pGLE1BQU0sWUFBWSxtQkFBbUIsTUFBTSw2QkFBNkIsTUFBTSxJQUFJLEVBQUUsT0FBTztDQUMzRixNQUFNLG1DQUFtQyxtQkFBbUIsYUFBYSxnQ0FBZ0MsVUFBVSxVQUFVLDJCQUEyQjtDQUN4SixNQUFNLDBCQUEwQixvQ0FBb0M7Q0FDcEUsTUFBTSx3QkFBd0IsNEJBQTRCLFNBQVMsT0FBTztDQUMxRSxNQUFNLGtCQUFrQixVQUFVLGFBQWEsS0FBSyxLQUFLLE9BQU8sT0FBTyxVQUFVLFVBQVUsd0JBQXdCLElBQUksVUFBVSxVQUFVLDJCQUEyQixPQUFPLEtBQUssSUFBSTtFQUNyTCxNQUFNO0VBQ04sU0FBUyxVQUFVLFNBQVM7Q0FDN0IsSUFBSTtDQUNKLE1BQU0saUJBQWlCLFNBQVMsUUFBUSxJQUFJLDBCQUEwQjtDQUN0RSxNQUFNLHFCQUFxQixTQUFTLFFBQVEsSUFBSSwrQkFBK0I7Q0FDL0UsT0FBTztFQUNOLHVCQUF1QixTQUFTLFFBQVEsSUFBSSxrQ0FBa0M7RUFDOUUsUUFBUSxVQUFVO0VBQ2xCLEdBQUcscUNBQXFDLEtBQUssSUFBSSxFQUFFLGlDQUFpQyxJQUFJLENBQUM7RUFDekYsYUFBYSxTQUFTLFFBQVEsSUFBSSxjQUFjLEtBQUs7RUFDckQsR0FBRyw0QkFBNEIsS0FBSyxJQUFJLEVBQUUsd0JBQXdCLElBQUksQ0FBQztFQUN2RSxvQkFBb0IsU0FBUyxRQUFRLElBQUksMkJBQTJCO0VBQ3BFLGNBQWMsU0FBUyxRQUFRLElBQUksb0JBQW9CO0VBQ3ZELFlBQVksS0FBSyxJQUFJO0VBQ3JCLEdBQUcsbUJBQW1CLE9BQU8sQ0FBQyxJQUFJLEVBQUUsZUFBZTtFQUNuRCxHQUFHLHVCQUF1QixPQUFPLENBQUMsSUFBSSxFQUFFLG1CQUFtQjtFQUMzRCx1QkFBdUIsaUNBQWlDLFNBQVMsUUFBUSxJQUFJLHNDQUFzQyxDQUFDO0VBQ3BILEdBQUcsb0JBQW9CLEtBQUssSUFBSSxDQUFDLElBQUksRUFBRSxnQkFBZ0I7RUFDdkQsS0FBSyxlQUFlLFNBQVM7Q0FDOUI7QUFDRDs7Ozs7O0FBTUEsU0FBUyw0QkFBNEIsU0FBUztDQUM3QyxJQUFJLFFBQVEsSUFBSSw2QkFBNkIsTUFBTSxLQUFLLE9BQU8sRUFBRSxNQUFNLFVBQVU7Q0FDakYsTUFBTSxVQUFVLDRCQUE0QixRQUFRLElBQUksNkJBQTZCLENBQUM7Q0FDdEYsT0FBTyxZQUFZLEtBQUssSUFBSSxLQUFLLElBQUk7RUFDcEMsTUFBTTtFQUNOO0NBQ0Q7QUFDRDs7QUFFQSxTQUFTLGlDQUFpQyxPQUFPO0NBQ2hELElBQUksVUFBVSxRQUFRLFVBQVUsSUFBSSxPQUFPO0NBQzNDLElBQUk7RUFDSCxNQUFNLFVBQVUsbUJBQW1CLEtBQUs7RUFDeEMsT0FBTyxRQUFRLFdBQVcsR0FBRyxJQUFJLFVBQVU7Q0FDNUMsUUFBUTtFQUNQLE9BQU87Q0FDUjtBQUNEOzs7OztBQUtBLGVBQWUsb0JBQW9CLFVBQVU7Q0FDNUMsSUFBSTtFQUNILE1BQU0sV0FBVyxnQ0FBZ0MsVUFBVSxNQUFNLFNBQVMsWUFBWSxDQUFDO0VBQ3ZGLE1BQU0sWUFBWSw2QkFBNkIsSUFBSSxRQUFRO0VBQzNELE9BQU8sY0FBYyxLQUFLLElBQUksV0FBVztHQUN4QyxHQUFHO0dBQ0g7RUFDRDtDQUNELFVBQVU7RUFDVCw0QkFBNEIsUUFBUTtDQUNyQztBQUNEO0FBQ0EsTUFBTSwrQ0FBK0MsSUFBSSxRQUFROzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JqRSxTQUFTLG1CQUFtQixRQUFRLE9BQU8sTUFBTTtDQUNoRCxNQUFNLFVBQVUsSUFBSSxRQUFRLEVBQUUsZ0JBQWdCLE9BQU8sWUFBWSxDQUFDO0NBQ2xFLElBQUksT0FBTyxzQkFBc0IsTUFBTSxRQUFRLElBQUksNkJBQTZCLE9BQU8sa0JBQWtCO0NBQ3pHLElBQUksT0FBTyx5QkFBeUIsTUFBTSxRQUFRLElBQUksb0NBQW9DLE9BQU8scUJBQXFCO0NBQ3RILElBQUksbUJBQW1CLE9BQU8sdUJBQXVCLEdBQUcsUUFBUSxJQUFJLGtDQUFrQyxPQUFPLE9BQU8sdUJBQXVCLENBQUM7Q0FDNUksSUFBSSxtQkFBbUIsT0FBTyxnQ0FBZ0MsR0FBRyxRQUFRLElBQUksdUNBQXVDLFVBQVU7Q0FDOUgsSUFBSSxPQUFPLGlCQUFpQixTQUFTLFdBQVcsUUFBUSxJQUFJLGtDQUFrQyxHQUFHO01BQzVGLElBQUksT0FBTyxvQkFBb0IsS0FBSyxHQUFHLFFBQVEsSUFBSSwrQkFBK0IsT0FBTyxPQUFPLGdCQUFnQixPQUFPLENBQUM7Q0FDN0gsSUFBSSxPQUFPLGdCQUFnQixNQUFNLFFBQVEsSUFBSSxzQkFBc0IsT0FBTyxZQUFZO0NBQ3RGLElBQUksT0FBTyxtQkFBbUIsS0FBSyxHQUFHLFFBQVEsSUFBSSw0QkFBNEIsT0FBTyxjQUFjO0NBQ25HLElBQUksT0FBTyx1QkFBdUIsS0FBSyxHQUFHLFFBQVEsSUFBSSxpQ0FBaUMsT0FBTyxrQkFBa0I7Q0FDaEgsSUFBSSxPQUFPLHlCQUF5QixNQUFNLFFBQVEsSUFBSSx3Q0FBd0MsbUJBQW1CLE9BQU8scUJBQXFCLENBQUM7Q0FDOUksTUFBTSxXQUFXLElBQUksU0FBUyxPQUFPLE9BQU8sT0FBTyxNQUFNLENBQUMsSUFBSSxPQUFPLFFBQVE7RUFDNUUsUUFBUTtFQUNSO0NBQ0QsQ0FBQztDQUNELElBQUksaUJBQWlCLE9BQU8sU0FBUyxHQUFHLDZCQUE2QixJQUFJLFVBQVUsT0FBTyxTQUFTO0NBQ25HLE9BQU87QUFDUjs7Ozs7OztBQU9BLGVBQWUsa0NBQWtDLFVBQVU7Q0FDMUQsTUFBTSwwQkFBMEIscUJBQXFCLENBQUMsRUFBRSxVQUFVO0NBQ2xFLElBQUksQ0FBQyx5QkFBeUIsTUFBTSxJQUFJLE1BQU0sZ0RBQWdEO0NBQzlGLE9BQU8sTUFBTSx3QkFBd0IsbUJBQW1CLFFBQVEsQ0FBQztBQUNsRTs7Ozs7OztBQU9BLGVBQWUsNEJBQTRCLFNBQVM7Q0FDbkQsTUFBTSxFQUFFLHFCQUFxQixnQkFBZ0IsVUFBVSxTQUFTLHFCQUFxQix1QkFBdUI7Q0FDNUcsTUFBTSxtQkFBbUIsSUFBSSxRQUFRLE9BQU87Q0FDNUMsaUJBQWlCLElBQUksNkJBQTZCLEdBQUc7Q0FDckQsaUJBQWlCLElBQUkscUNBQXFDLFFBQVE7Q0FDbEUsTUFBTSxrQkFBa0IsTUFBTSxvQkFBb0IsVUFBVSxnQkFBZ0I7Q0FDNUUsTUFBTSxvQkFBb0IsZ0JBQWdCLGVBQWUsaUJBQWlCLG1CQUFtQjtDQUM3RixJQUFJLGlCQUFpQiwyQkFBMkIsaUJBQWlCO0NBQ2pFLElBQUksbUJBQW1CLEtBQUssR0FBRztFQUM5QixrQkFBa0IsQ0FBQyxDQUFDLElBQUksaUJBQWlCO0VBQ3pDLG9CQUFvQixpQkFBaUIsZUFBZSxpQkFBaUIsZ0JBQWdCLEdBQUcscUJBQXFCLG9CQUFvQixLQUFLLEdBQUc7R0FDeEksb0JBQW9CO0dBQ3BCLHNCQUFzQjtHQUN0QixjQUFjO0VBQ2YsQ0FBQztFQUNELGlCQUFpQiwyQkFBMkIsaUJBQWlCO0NBQzlEO0NBQ0EsTUFBTSxnQkFBZ0IsU0FBUyxZQUFZLENBQUMsQ0FBQztDQUM3QyxpQkFBaUIsMkJBQTJCLGlCQUFpQjtDQUM3RCxNQUFNLHdCQUF3QixnQkFBZ0IsVUFBVTtDQUN4RCxJQUFJLHVCQUF1QjtFQUMxQixNQUFNLHlCQUF5QixrQ0FBa0MsTUFBTSxvQkFBb0IsdUJBQXVCLE9BQU8sR0FBRyxxQkFBcUIsa0JBQWtCO0VBQ25LLElBQUksd0JBQXdCLE9BQU8sbUJBQW1CLHNCQUFzQjtDQUM3RTtDQUNBLE9BQU8sb0JBQW9CO0FBQzVCOzs7Ozs7Ozs7Ozs7QUFZQSxTQUFTLHlCQUF5QixVQUFVO0NBQzNDLElBQUksQ0FBQyxTQUFTLElBQUksT0FBTztDQUN6QixzQkFBNkIsZ0JBQWdCLFFBQVEsSUFBSSx5QkFBeUIsVUFBVSxPQUFPO0NBQ25HLE9BQU8sU0FBUyxRQUFRLElBQUksY0FBYyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsV0FBVyx1QkFBdUIsTUFBTTtBQUNwRzs7Ozs7Ozs7QUFRQSxTQUFTLG9CQUFvQixRQUFRLGNBQWMsc0JBQXNCLE1BQU0scUJBQXFCLE1BQU0sU0FBUyxXQUFXLENBQUMsR0FBRztDQUNqSSxNQUFNLFdBQVcsZ0JBQWdCLGVBQWUsUUFBUSxtQkFBbUI7Q0FDM0UsTUFBTSxRQUFRLGlCQUFpQjtDQUMvQixNQUFNLGFBQWEsa0JBQWtCO0NBQ3JDLE1BQU0sTUFBTSxLQUFLLElBQUk7Q0FDckIsTUFBTSxXQUFXLE1BQU0sSUFBSSxRQUFRO0NBQ25DLE1BQU0scUJBQXFCLFNBQVMsc0JBQXNCO0NBQzFELElBQUksVUFBVSx5QkFBeUIsT0FBTyxZQUFZLFVBQVUsVUFBVSxLQUFLO0NBQ25GLE1BQU0sUUFBUTtFQUNiO0VBQ0EsMkJBQTJCLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQztFQUM3QztFQUNBLHNCQUFzQixTQUFTLHlCQUF5QjtFQUN4RCxTQUFTO0VBQ1QsY0FBYyxTQUFTLGlCQUFpQixTQUFTLHlCQUF5QixPQUFPLGtCQUFrQjtFQUNuRyxxQkFBcUIsU0FBUyx3QkFBd0I7RUFDdEQsV0FBVztDQUNaO0NBQ0EsSUFBSSxTQUFTLHFCQUFxQixtQkFBbUIsU0FBUyx3QkFBd0IsTUFBTTtFQUMzRixNQUFNLG1CQUFtQjtFQUN6QixNQUFNLGdCQUFnQixTQUFTLGlCQUFpQjtDQUNqRCxPQUFPLElBQUksU0FBUyxxQkFBcUIsaUJBQWlCLE1BQU0sbUJBQW1CO0NBQ25GLGdDQUFnQyxPQUFPLFNBQVMsWUFBWTtDQUM1RCxNQUFNLGVBQWU7Q0FDckIsTUFBTSxVQUFVLGFBQWEsS0FBSyxPQUFPLGFBQWE7RUFDckQsSUFBSSx5QkFBeUIsUUFBUSxHQUFHO0dBQ3ZDLE1BQU0sV0FBVyxNQUFNLG9CQUFvQixRQUFRO0dBQ25ELElBQUksTUFBTSxJQUFJLFFBQVEsTUFBTSxPQUFPO0dBQ25DLE1BQU0sZUFBZSwwQkFBMEIsS0FBSztHQUNwRCxNQUFNLFdBQVc7R0FDakIsTUFBTSxPQUFPLFNBQVMsT0FBTztHQUM3Qiw0QkFBNEIsT0FBTyxNQUFNLE9BQU8sWUFBWTtHQUM1RCxNQUFNLGdCQUFnQixTQUFTLGlCQUFpQjtHQUNoRCxNQUFNLG1CQUFtQixTQUFTLHdCQUF3QixPQUFPLFdBQVcsTUFBTSxvQkFBb0IsU0FBUyxxQkFBcUIsU0FBUyx5QkFBeUIsT0FBTyxXQUFXO0dBQ3hMLElBQUkscUJBQXFCLG1CQUFtQixtQkFBbUIsU0FBUyx1QkFBdUIsR0FBRztJQUNqRyxNQUFNLHFCQUFxQjtJQUMzQixNQUFNLFlBQVksTUFBTSxZQUFZLEtBQUssSUFBSSxlQUFlLDBCQUEwQjtHQUN2RixPQUFPLE1BQU0sWUFBWSxzQ0FBc0MsTUFBTSxXQUFXLE1BQU0sVUFBVSxlQUFlLHFCQUFxQixrQkFBa0IsYUFBYSxnQkFBZ0I7R0FDbkwsSUFBSSxTQUFTLG1CQUFtQixNQUFNLHNCQUFzQixTQUFTLG1CQUFtQixLQUFLLEdBQUcsSUFBSTtJQUNuRyxNQUFNLG1CQUFtQixNQUFNLFNBQVMsZ0JBQWdCLFFBQVE7SUFDaEUsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNLE9BQU87SUFDbkMsTUFBTSxtQkFBbUI7R0FDMUIsUUFBUSxDQUFDO0dBQ1Qsc0NBQXNDLE9BQU8sWUFBWSxVQUFVLEtBQUs7R0FDeEUsMkJBQTJCO0VBQzVCLE9BQU87R0FDTiw0QkFBNEIsUUFBUTtHQUNwQyxTQUFTLE1BQU0sT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7R0FDdEMseUJBQXlCLE9BQU8sWUFBWSxVQUFVLE9BQU8sS0FBSztFQUNuRTtDQUNELENBQUMsQ0FBQyxDQUFDLFlBQVk7RUFDZCx5QkFBeUIsT0FBTyxZQUFZLFVBQVUsT0FBTyxLQUFLO0NBQ25FLENBQUMsQ0FBQyxDQUFDLGNBQWM7RUFDaEIsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNLE9BQU87RUFDbkMsTUFBTSxVQUFVLEtBQUs7RUFDckIsTUFBTSxlQUFlLEtBQUs7RUFDMUIsSUFBSSxNQUFNLFVBQVU7R0FDbkIsTUFBTSxVQUFVO0dBQ2hCLDZCQUE2QixVQUFVLEtBQUs7RUFDN0M7Q0FDRCxDQUFDO0NBQ0QsTUFBTSxJQUFJLFVBQVUsS0FBSztDQUN6QiwyQkFBMkI7QUFDNUI7QUFDQSxTQUFTLHNDQUFzQyxPQUFPLFlBQVksaUJBQWlCLE9BQU87Q0FDekYsSUFBSSxNQUFNLHVCQUF1QixPQUFPO0NBQ3hDLE1BQU0sd0JBQXdCLE1BQU0sVUFBVTtDQUM5QyxJQUFJLENBQUMsdUJBQXVCO0NBQzVCLE1BQU0sU0FBUyxzQkFBc0IsZUFBZTtDQUNwRCxNQUFNLGdCQUFnQixnQkFBZ0IsZUFBZSx1QkFBdUIsT0FBTyxtQkFBbUI7Q0FDdEcsSUFBSSxrQkFBa0IsaUJBQWlCO0NBQ3ZDLE1BQU0sV0FBVyxNQUFNLElBQUksYUFBYTtDQUN4QyxJQUFJLFlBQVksYUFBYSxPQUFPLHlCQUF5QixPQUFPLFlBQVksZUFBZSxVQUFVLEtBQUs7Q0FDOUcsTUFBTSw4QkFBOEIsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDO0NBQzdELE1BQU0sVUFBVSxJQUFJLGFBQWE7Q0FDakMsTUFBTSxJQUFJLGVBQWUsS0FBSztDQUM5QixXQUFXLElBQUksYUFBYTtBQUM3QjtBQUNBLFNBQVMsa0NBQWtDLFFBQVEsc0JBQXNCLE1BQU0scUJBQXFCLE1BQU0sU0FBUztDQUNsSCxNQUFNLFFBQVEsb0NBQW9DLFFBQVEscUJBQXFCLG9CQUFvQixTQUFTLGlCQUFpQjtDQUM3SCxJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLE1BQU0sRUFBRSxVQUFVLFVBQVU7Q0FDNUIsSUFBSSxNQUFNLFdBQVcsTUFBTSxZQUFZLGdCQUFnQixPQUFPO0NBQzlELElBQUksTUFBTSx1QkFBdUIsU0FBUyxDQUFDLE1BQU0sVUFBVSxPQUFPO0NBQ2xFLElBQUksbUNBQW1DLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRztFQUM1RCx5QkFBeUIsaUJBQWlCLEdBQUcsa0JBQWtCLEdBQUcsVUFBVSxPQUFPLElBQUk7RUFDdkYsT0FBTztDQUNSO0NBQ0EsSUFBSSxNQUFNLGNBQWMsS0FBSyxLQUFLLE1BQU0sU0FBUyxjQUFjLEtBQUssR0FBRyxPQUFPO0VBQzdFLEdBQUcsTUFBTTtFQUNULFdBQVcsbUNBQW1DLEtBQUs7Q0FDcEQ7Q0FDQSxPQUFPLE1BQU07QUFDZDs7Ozs7O0FBTUEsU0FBUyx3QkFBd0IsUUFBUSxzQkFBc0IsTUFBTSxxQkFBcUIsTUFBTSxTQUFTO0NBQ3hHLE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsTUFBTSxnQkFBZ0IsZ0JBQWdCLGVBQWUsUUFBUSxtQkFBbUI7Q0FDaEYsTUFBTSxhQUFhLE1BQU0sSUFBSSxhQUFhO0NBQzFDLElBQUksY0FBYyxXQUFXLHVCQUF1QixTQUFTLENBQUMsK0NBQStDLFlBQVksa0JBQWtCLEdBQUcseUJBQXlCLE9BQU8sa0JBQWtCLEdBQUcsZUFBZSxZQUFZLEtBQUs7Q0FDbk8sTUFBTSxRQUFRLG9DQUFvQyxRQUFRLHFCQUFxQixvQkFBb0IsU0FBUyxpQkFBaUI7Q0FDN0gsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixNQUFNLEVBQUUsVUFBVSxVQUFVO0NBQzVCLE9BQU8sK0JBQStCLFVBQVUsT0FBTyxrQkFBa0I7QUFDMUU7QUFDQSxTQUFTLCtCQUErQixVQUFVLE9BQU8sb0JBQW9CLDhCQUE4QixPQUFPO0NBQ2pILE1BQU0sUUFBUSxpQkFBaUI7Q0FDL0IsSUFBSSxNQUFNLFdBQVcsTUFBTSxZQUFZLGdCQUFnQixPQUFPO0NBQzlELElBQUksTUFBTSx1QkFBdUIsT0FBTyxPQUFPO0NBQy9DLElBQUksTUFBTSxVQUFVO0VBQ25CLElBQUksQ0FBQywrQ0FBK0MsT0FBTyxrQkFBa0IsR0FBRyxPQUFPO0VBQ3ZGLElBQUksQ0FBQywrQkFBK0IsbUNBQW1DLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRztHQUM1Rix5QkFBeUIsT0FBTyxrQkFBa0IsR0FBRyxVQUFVLE9BQU8sSUFBSTtHQUMxRSxPQUFPO0VBQ1I7RUFDQSx1Q0FBdUMsS0FBSztFQUM1Qyx5QkFBeUIsT0FBTyxrQkFBa0IsR0FBRyxVQUFVLE9BQU8sS0FBSztFQUMzRSxNQUFNLFdBQVcsTUFBTTtFQUN2QixJQUFJLE1BQU0sY0FBYyxLQUFLLEtBQUssTUFBTSxTQUFTLGNBQWMsS0FBSyxHQUFHLE9BQU87R0FDN0UsR0FBRztHQUNILFdBQVcsbUNBQW1DLEtBQUs7R0FDbkQsR0FBRyxNQUFNLG1CQUFtQixFQUFFLGtCQUFrQixNQUFNLGlCQUFpQixJQUFJLENBQUM7RUFDN0U7RUFDQSxPQUFPLE1BQU0sbUJBQW1CO0dBQy9CLEdBQUc7R0FDSCxrQkFBa0IsTUFBTTtFQUN6QixJQUFJO0NBQ0w7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxlQUFlLHFDQUFxQyxRQUFRLHNCQUFzQixNQUFNLHFCQUFxQixNQUFNLFNBQVM7Q0FDM0gsTUFBTSxRQUFRLGlCQUFpQjtDQUMvQixNQUFNLFFBQVEsb0NBQW9DLFFBQVEscUJBQXFCLG9CQUFvQixTQUFTLGlCQUFpQjtDQUM3SCxJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLE1BQU0sRUFBRSxVQUFVLFVBQVU7Q0FDNUIsSUFBSSxTQUFTLGdCQUFnQixNQUFNLE9BQU8sT0FBTztDQUNqRCxNQUFNLDhCQUE4QixNQUFNLFlBQVksS0FBSztDQUMzRCxJQUFJLE1BQU0sWUFBWSxLQUFLLEdBQUc7RUFDN0IsTUFBTSxlQUFlLHdCQUF3QixNQUFNLGNBQWMsU0FBUyxhQUFhO0VBQ3ZGLElBQUk7R0FDSCxNQUFNLE1BQU0sUUFBUSxZQUFZLENBQUMsQ0FBQztFQUNuQyxVQUFVO0dBQ1QsYUFBYTtFQUNkO0VBQ0EsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNLE9BQU8sT0FBTztFQUMxQyxJQUFJLFNBQVMsZ0JBQWdCLE1BQU0sT0FBTyxPQUFPO0NBQ2xEO0NBQ0EsT0FBTywrQkFBK0IsVUFBVSxPQUFPLG9CQUFvQiwyQkFBMkI7QUFDdkc7QUFDQSxNQUFNLHdCQUF3QixPQUFPLElBQUksOEJBQThCO0FBQ3ZFLE1BQU0sNEJBQTRCLE9BQU8sSUFBSSwyQkFBMkI7QUFDeEUsU0FBUyxzQkFBc0IsUUFBUTtDQUN0QyxJQUFJLFVBQVU7Q0FDZCxNQUFNLGNBQWM7Q0FDcEIsWUFBWSw2QkFBNkI7QUFDMUM7QUFDQSxTQUFTLHdCQUF3QjtDQUNoQyxJQUFJLFVBQVUsT0FBTztDQUNyQixPQUFPLE9BQU8sOEJBQThCO0FBQzdDO0FBQ0EsU0FBUywyQkFBMkI7Q0FDbkMsSUFBSSxVQUFVLE9BQU87Q0FDckIsTUFBTSxjQUFjO0NBQ3BCLFlBQVksMkJBQTJCO0VBQ3RDLDJCQUEyQixJQUFJLElBQUk7RUFDbkMsY0FBYyxPQUFPLFNBQVM7RUFDOUIsNEJBQTRCLElBQUksd0JBQXdCLE9BQU8sU0FBUyxNQUFNO0VBQzlFLGdCQUFnQixjQUFjLE9BQU8sU0FBUyxVQUFVLFVBQVU7RUFDbEUsY0FBYyxDQUFDO0VBQ2Ysa0JBQWtCO0VBQ2xCLHFCQUFxQjtFQUNyQix5QkFBeUI7RUFDekIsaUJBQWlCO0VBQ2pCLHNCQUFzQjtFQUN0QixtQkFBbUIsT0FBTyxRQUFRLFVBQVUsS0FBSyxPQUFPLE9BQU87RUFDL0Qsc0JBQXNCLE9BQU8sUUFBUSxhQUFhLEtBQUssT0FBTyxPQUFPO0VBQ3JFLGdCQUFnQjtFQUNoQix5QkFBeUI7RUFDekIsb0JBQW9CO0VBQ3BCLDRCQUE0QjtFQUM1Qix3QkFBd0I7RUFDeEIsK0JBQStCO0NBQ2hDO0NBQ0EsT0FBTyxZQUFZO0FBQ3BCO0FBQ0EsU0FBUyw0QkFBNEI7Q0FDcEMsTUFBTSxRQUFRLHlCQUF5QjtDQUN2QyxJQUFJLENBQUMsT0FBTztDQUNaLEtBQUssTUFBTSxNQUFNLE1BQU0sV0FBVyxHQUFHO0FBQ3RDO0FBQ0EsSUFBSSxDQUFDLFVBQVUsV0FBVywrQkFBK0I7QUFDekQsSUFBSSxpQ0FBaUM7QUFDckMsTUFBTSxrREFBa0QsSUFBSSxRQUFRO0FBQ3BFLElBQUksc0NBQXNDO0FBQzFDLElBQUksbUNBQW1DO0FBQ3ZDLFNBQVMsNkJBQTZCLGNBQWM7Q0FDbkQsTUFBTSxTQUFTLGdDQUFnQyxJQUFJLFlBQVk7Q0FDL0QsSUFBSSxRQUFRLE9BQU87Q0FDbkIsTUFBTSxNQUFNLGFBQWEsU0FBUztDQUNsQyxJQUFJLHdDQUF3QyxPQUFPLGtDQUFrQztFQUNwRixnQ0FBZ0MsSUFBSSxjQUFjLGdDQUFnQztFQUNsRixPQUFPO0NBQ1I7Q0FDQSxNQUFNLFdBQVcsSUFBSSx3QkFBd0IsWUFBWTtDQUN6RCxnQ0FBZ0MsSUFBSSxjQUFjLFFBQVE7Q0FDMUQsc0NBQXNDO0NBQ3RDLG1DQUFtQztDQUNuQyxPQUFPO0FBQ1I7Ozs7Ozs7OztBQVNBLFNBQVMsc0JBQXNCO0NBQzlCLE1BQU0sV0FBVywwQkFBMEI7Q0FDM0MsSUFBSSxVQUFVLE9BQU8sU0FBUztDQUM5QixPQUFPLHlCQUF5QixDQUFDLEVBQUUsa0JBQWtCO0FBQ3REO0FBQ0EsSUFBSSxpQ0FBaUM7Ozs7Ozs7OztBQVNyQyxTQUFTLDBCQUEwQjtDQUNsQyxNQUFNLGdCQUFnQixxQkFBcUIsTUFBTTtDQUNqRCxNQUFNLFdBQVcsMEJBQTBCO0NBQzNDLElBQUksQ0FBQyxpQkFBaUIsVUFBVSxPQUFPLDZCQUE2QixTQUFTLFlBQVk7Q0FDekYsTUFBTSxRQUFRLHlCQUF5QjtDQUN2QyxJQUFJLE9BQU87RUFDVixJQUFJLGVBQWUsMkJBQTJCLEtBQUs7RUFDbkQsT0FBTyxNQUFNO0NBQ2Q7Q0FDQSxJQUFJLG1DQUFtQyxNQUFNLGlDQUFpQyxJQUFJLHdCQUF3QjtDQUMxRyxPQUFPO0FBQ1I7QUFDQSxJQUFJLGlDQUFpQzs7Ozs7OztBQU9yQyxTQUFTLDJCQUEyQixPQUFPO0NBQzFDLE1BQU0sV0FBVyw4QkFBOEI7Q0FDL0MsSUFBSSxhQUFhLE1BQU0sNEJBQTRCO0NBQ25ELElBQUksYUFBYSxnQ0FBZ0M7Q0FDakQsaUNBQWlDO0NBQ2pDLElBQUksU0FBUyxTQUFTLE1BQU0sTUFBTSwyQkFBMkIsU0FBUyxHQUFHLE1BQU0sNkJBQTZCO0FBQzdHO0FBQ0EsU0FBUyxvQ0FBb0M7Q0FDNUMsTUFBTSxRQUFRLHlCQUF5QjtDQUN2QyxJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLElBQUksVUFBVTtDQUNkLE1BQU0sV0FBVyxjQUFjLE9BQU8sU0FBUyxVQUFVLFVBQVU7Q0FDbkUsSUFBSSxhQUFhLE1BQU0sZ0JBQWdCO0VBQ3RDLE1BQU0saUJBQWlCO0VBQ3ZCLFVBQVU7Q0FDWDtDQUNBLE1BQU0sU0FBUyxPQUFPLFNBQVM7Q0FDL0IsSUFBSSxXQUFXLE1BQU0sY0FBYztFQUNsQyxNQUFNLGVBQWU7RUFDckIsTUFBTSw2QkFBNkIsSUFBSSx3QkFBd0IsTUFBTTtFQUNyRSxVQUFVO0NBQ1g7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGdDQUFnQztDQUN4QyxNQUFNLE1BQU0scUJBQXFCO0NBQ2pDLElBQUksQ0FBQyxLQUFLO0VBQ1QsTUFBTSxXQUFXLDBCQUEwQjtFQUMzQyxJQUFJLFVBQVUsT0FBTyw2QkFBNkIsU0FBUyxZQUFZO0VBQ3ZFLElBQUksbUNBQW1DLE1BQU0saUNBQWlDLElBQUksd0JBQXdCO0VBQzFHLE9BQU87Q0FDUjtDQUNBLE1BQU0sU0FBUyxJQUFJO0NBQ25CLE1BQU0sU0FBUyxJQUFJO0NBQ25CLE1BQU0sZUFBZSxJQUFJO0NBQ3pCLElBQUksVUFBVSxpQkFBaUIsUUFBUSxPQUFPO0NBQzlDLE1BQU0sWUFBWSxPQUFPLFNBQVM7Q0FDbEMsSUFBSSxVQUFVLElBQUksd0NBQXdDLFdBQVc7RUFDcEUsSUFBSSxrQ0FBa0M7RUFDdEMsT0FBTztDQUNSO0NBQ0EsTUFBTSxXQUFXLElBQUksd0JBQXdCLE1BQU07Q0FDbkQsSUFBSSwyQkFBMkI7Q0FDL0IsSUFBSSxrQ0FBa0M7Q0FDdEMsSUFBSSxzQ0FBc0M7Q0FDMUMsT0FBTztBQUNSOzs7Ozs7OztBQVFBLFNBQVMsNkJBQTZCO0NBQ3JDLE1BQU0sUUFBUSx5QkFBeUI7Q0FDdkMsSUFBSSxPQUFPLE1BQU07QUFDbEI7QUFDQSxNQUFNLGdCQUFnQixDQUFDO0FBQ3ZCLE1BQU0sNkJBQTZCLE9BQU8sSUFBSSxzQ0FBc0M7QUFDcEYsU0FBUyxtQ0FBbUM7Q0FDM0MsSUFBSSxPQUFPLFFBQVEsa0JBQWtCLFlBQVksT0FBTztDQUN4RCxNQUFNLGNBQWM7Q0FDcEIsSUFBSSxDQUFDLFlBQVksNkJBQTZCLFlBQVksOEJBQThCLFFBQVEsY0FBYyxJQUFJO0NBQ2xILE9BQU8sWUFBWSwrQkFBK0I7QUFDbkQ7O0FBRUEsU0FBUyxvQ0FBb0M7Q0FDNUMsTUFBTSxNQUFNLGlDQUFpQztDQUM3QyxJQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsZUFBZSxZQUFZLE9BQU87Q0FDN0QsSUFBSTtFQUNILE9BQU8sUUFBUSxXQUFXLEdBQUc7Q0FDOUIsUUFBUTtFQUNQLE9BQU87Q0FDUjtBQUNEOzs7OztBQUtBLFNBQVMscUNBQXFDLE1BQU0sUUFBUSx1QkFBdUI7Q0FDbEYsTUFBTSxTQUFTLE9BQU8sV0FBVyxjQUFjLE9BQU8sU0FBUyxTQUFTO0NBQ3hFLE1BQU0sTUFBTSxJQUFJLElBQUksTUFBTSxNQUFNO0NBQ2hDLE9BQU87RUFDTixVQUFVLGNBQWMsSUFBSSxVQUFVLFVBQVU7RUFDaEQsUUFBUSxJQUFJO0VBQ1osY0FBYyxJQUFJLHdCQUF3QixJQUFJLE1BQU07RUFDcEQ7RUFDQSxHQUFHLHlCQUF5QixPQUFPLEVBQUUsZ0JBQWdCLElBQUksSUFBSSx1QkFBdUIsTUFBTSxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUM7Q0FDekc7QUFDRDtBQUNBLFNBQVMsNEJBQTRCLFVBQVU7Q0FDOUMsT0FBTyxTQUFTLFdBQVcsU0FBUztBQUNyQztBQUNBLElBQUksd0JBQXdCO0FBQzVCLElBQUksNEJBQTRCO0FBQ2hDLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDaEMsTUFBTSxRQUFRLHlCQUF5QjtDQUN2QyxJQUFJLENBQUMsT0FBTztFQUNYLE1BQU0sT0FBTyxLQUFLLFVBQVUsTUFBTTtFQUNsQyxJQUFJLFNBQVMsMkJBQTJCO0dBQ3ZDLHdCQUF3QjtHQUN4Qiw0QkFBNEI7RUFDN0I7RUFDQTtDQUNEO0NBQ0EsTUFBTSxPQUFPLEtBQUssVUFBVSxNQUFNO0NBQ2xDLElBQUksU0FBUyxNQUFNLGtCQUFrQjtFQUNwQyxNQUFNLGVBQWU7RUFDckIsTUFBTSxtQkFBbUI7RUFDekIsTUFBTSxzQkFBc0I7RUFDNUIsTUFBTSwwQkFBMEI7RUFDaEMsMEJBQTBCO0NBQzNCO0FBQ0Q7QUFDQSxTQUFTLGlDQUFpQyxRQUFRO0NBQ2pELE1BQU0sUUFBUSx5QkFBeUI7Q0FDdkMsSUFBSSxDQUFDLE9BQU87Q0FDWixNQUFNLE9BQU8sS0FBSyxVQUFVLE1BQU07Q0FDbEMsSUFBSSxTQUFTLE1BQU0sb0JBQW9CLFNBQVMsTUFBTSx5QkFBeUI7RUFDOUUsTUFBTSxzQkFBc0I7RUFDNUIsTUFBTSwwQkFBMEI7RUFDaEMsTUFBTSw2QkFBNkI7Q0FDcEM7QUFDRDs7QUFFQSxTQUFTLGtCQUFrQjtDQUMxQixPQUFPLHlCQUF5QixDQUFDLEVBQUUsZ0JBQWdCO0FBQ3BEOzs7Ozs7QUFNQSxTQUFTLG1CQUFtQixVQUFVLE9BQU87Q0FDNUMsTUFBTSxRQUFRLHlCQUF5QjtDQUN2QyxJQUFJLENBQUMsT0FBTztDQUNaLE1BQU0sa0JBQWtCLGNBQWMsVUFBVSxVQUFVO0NBQzFELE1BQU0sdUJBQXVCO0FBQzlCOzs7Ozs7QUFNQSxTQUFTLHFCQUFxQixPQUFPO0NBQ3BDLE1BQU0sUUFBUSx5QkFBeUI7Q0FDdkMsSUFBSSxDQUFDLE9BQU87Q0FDWixJQUFJLE1BQU0seUJBQXlCLFFBQVEsTUFBTSx5QkFBeUIsT0FBTztFQUNoRixNQUFNLGtCQUFrQjtFQUN4QixNQUFNLHVCQUF1QjtDQUM5QjtBQUNEO0FBQ0EsU0FBUywwQkFBMEI7Q0FDbEMsTUFBTSxRQUFRLHlCQUF5QjtDQUN2QyxNQUFNLE1BQU0scUJBQXFCO0NBQ2pDLElBQUksS0FBSyxPQUFPLElBQUk7Q0FDcEIsTUFBTSxXQUFXLDBCQUEwQjtDQUMzQyxJQUFJLFVBQVUsT0FBTyxTQUFTO0NBQzlCLE9BQU8sT0FBTyxnQkFBZ0I7QUFDL0I7QUFDQSxTQUFTLDBCQUEwQjtDQUNsQyxNQUFNLE1BQU0scUJBQXFCO0NBQ2pDLElBQUksS0FBSyxPQUFPLElBQUk7Q0FDcEIsTUFBTSxXQUFXLDBCQUEwQjtDQUMzQyxJQUFJLFVBQVUsT0FBTyxTQUFTO0NBQzlCLE9BQU87QUFDUjtBQUNBLFNBQVMsc0JBQXNCLElBQUk7Q0FDbEMsTUFBTSxRQUFRLHlCQUF5QjtDQUN2QyxJQUFJLENBQUMsT0FBTyxhQUFhLENBQUM7Q0FDMUIsTUFBTSxVQUFVLElBQUksRUFBRTtDQUN0QixhQUFhO0VBQ1osTUFBTSxVQUFVLE9BQU8sRUFBRTtDQUMxQjtBQUNEOzs7OztBQUtBLFNBQVMsY0FBYztDQUN0QixJQUFJLFVBQVU7RUFDYixvQ0FBb0M7RUFDcEMsTUFBTSxNQUFNLHFCQUFxQjtFQUNqQyxJQUFJLEtBQUssT0FBTyxJQUFJO0VBQ3BCLE1BQU0sV0FBVywwQkFBMEI7RUFDM0MsT0FBTyxXQUFXLFNBQVMsV0FBVztDQUN2QztDQUNBLE1BQU0saUJBQWlCLGtDQUFrQztDQUN6RCxNQUFNLFdBQVcsUUFBUSxxQkFBcUIsdUJBQXVCLDJCQUEyQjtFQUMvRixNQUFNLE1BQU0scUJBQXFCO0VBQ2pDLElBQUksS0FBSyxPQUFPLElBQUk7RUFDcEIsTUFBTSxXQUFXLDBCQUEwQjtFQUMzQyxPQUFPLFdBQVcsU0FBUyxXQUFXO0NBQ3ZDLENBQUM7Q0FDRCxJQUFJLG1CQUFtQix5QkFBeUIsQ0FBQyxFQUFFLGlDQUFpQyxLQUFLLEdBQUcsT0FBTyxlQUFlO0NBQ2xILE9BQU87QUFDUjs7OztBQUlBLFNBQVMsa0JBQWtCO0NBQzFCLElBQUksVUFBVTtFQUNiLE1BQU0sTUFBTSxxQkFBcUI7RUFDakMsSUFBSSxLQUFLLHVCQUF1QixRQUFRLElBQUksa0JBQWtCLFFBQVEseUJBQXlCLE1BQU0sTUFBTSxNQUFNLElBQUksa0JBQWtCLG1CQUFtQjtFQUMxSixNQUFNLE9BQU8sS0FBSztFQUNsQixJQUFJLE1BQU07R0FDVCxRQUFRLElBQUksS0FBSyxPQUFPO0dBQ3hCLElBQUksS0FBSyxhQUFhLFdBQVcsTUFBTSxJQUFJLGtCQUFrQixtQkFBbUI7RUFDakY7RUFDQSxvQ0FBb0M7RUFDcEMsT0FBTyw4QkFBOEI7Q0FDdEM7Q0FDQSxNQUFNLGlCQUFpQixrQ0FBa0M7Q0FDekQsTUFBTSxlQUFlLFFBQVEscUJBQXFCLHVCQUF1Qix5QkFBeUIsNkJBQTZCO0NBQy9ILElBQUksbUJBQW1CLHlCQUF5QixDQUFDLEVBQUUsaUNBQWlDLEtBQUssR0FBRyxPQUFPLGVBQWU7Q0FDbEgsT0FBTztBQUNSOzs7O0FBSUEsU0FBUyxZQUFZO0NBQ3BCLElBQUksVUFBVTtFQUNiLG9DQUFvQztFQUNwQyxPQUFPLHdCQUF3QjtDQUNoQztDQUNBLE1BQU0saUJBQWlCLGtDQUFrQztDQUN6RCxNQUFNLFNBQVMsUUFBUSxxQkFBcUIsdUJBQXVCLHlCQUF5Qix1QkFBdUI7Q0FDbkgsSUFBSSxtQkFBbUIseUJBQXlCLENBQUMsRUFBRSxpQ0FBaUMsS0FBSyxHQUFHLE9BQU8sZUFBZTtDQUNsSCxPQUFPO0FBQ1I7QUFDQSxTQUFTLCtCQUErQixJQUFJO0NBQzNDLE1BQU0sUUFBUSx5QkFBeUI7Q0FDdkMsSUFBSSxDQUFDLE9BQU8sT0FBTyxHQUFHO0NBQ3RCLE1BQU0sMEJBQTBCO0NBQ2hDLElBQUk7RUFDSCxPQUFPLEdBQUc7Q0FDWCxVQUFVO0VBQ1QsTUFBTSwwQkFBMEI7Q0FDakM7QUFDRDs7Ozs7Ozs7O0FBU0EsU0FBUyw0QkFBNEIsT0FBTyxTQUFTO0NBQ3BELElBQUksVUFBVTtDQUNkLE1BQU0sUUFBUSx5QkFBeUI7Q0FDdkMsSUFBSSxDQUFDLE9BQU87Q0FDWixLQUFLLFNBQVMsbUJBQW1CLFVBQVUsS0FBSyxNQUFNLE1BQU0sZ0NBQWdDLEdBQUcsTUFBTSxpQ0FBaUM7Q0FDdEksTUFBTSxhQUFhLGtDQUFrQztDQUNyRCxJQUFJLGdCQUFnQjtDQUNwQixJQUFJLE1BQU0sd0JBQXdCLFFBQVEsTUFBTSw0QkFBNEIsTUFBTTtFQUNqRixNQUFNLGVBQWUsTUFBTTtFQUMzQixNQUFNLG1CQUFtQixNQUFNO0VBQy9CLE1BQU0sc0JBQXNCO0VBQzVCLE1BQU0sMEJBQTBCO0VBQ2hDLGdCQUFnQjtDQUNqQjtDQUNBLElBQUksTUFBTSx5QkFBeUIsUUFBUSxVQUFVLEtBQUssS0FBSyxNQUFNLHlCQUF5QixPQUFPO0VBQ3BHLE1BQU0sa0JBQWtCO0VBQ3hCLE1BQU0sdUJBQXVCO0NBQzlCO0NBQ0EsTUFBTSxlQUFlLGNBQWMsTUFBTTtDQUN6QyxNQUFNLDZCQUE2QjtDQUNuQyxJQUFJLGNBQWMsZUFBZSw0QkFBNEI7Q0FDN0QsSUFBSSxjQUFjLDBCQUEwQjtBQUM3Qzs7QUFFQSxTQUFTLHVCQUF1QixjQUFjLE1BQU07Q0FDbkQsSUFBSTtFQUNILE9BQU8sS0FBSyxVQUFVLFlBQVksTUFBTSxLQUFLLFVBQVUsSUFBSTtDQUM1RCxRQUFRO0VBQ1AsT0FBTztDQUNSO0FBQ0Q7O0FBRUEsU0FBUywwQkFBMEIsT0FBTyxRQUFRLE1BQU0sUUFBUSxLQUFLO0NBQ3BFLE1BQU0sUUFBUSxNQUFNO0NBQ3BCLElBQUksT0FBTyxXQUFXLFFBQVEsT0FBTztDQUNyQyxJQUFJLE1BQU0sT0FBTztFQUNoQixJQUFJLE9BQU8sUUFBUSxJQUFJLElBQUksS0FBSyxPQUFPLFNBQVMsSUFBSSxDQUFDLENBQUMsU0FBUyxNQUFNLE1BQU0sT0FBTztFQUNsRixJQUFJLE1BQU0sU0FBUyxRQUFRLEVBQUUsdUJBQXVCLElBQUksS0FBSywrQkFBK0IsSUFBSSxNQUFNLCtCQUErQixNQUFNLElBQUksSUFBSSxPQUFPO0NBQzNKLE9BQU8sSUFBSSxNQUFNLFNBQVMsUUFBUSxNQUFNLFFBQVEsS0FBSyxPQUFPO0NBQzVELElBQUksTUFBTSxRQUFRLE9BQU87Q0FDekIsTUFBTSxxQkFBcUI7Q0FDM0IsTUFBTSxVQUFVLE1BQU0sT0FBTyxJQUFJO0NBQ2pDLE1BQU0sV0FBVyxXQUFXLGNBQWMsTUFBTSxvQkFBb0IsTUFBTTtDQUMxRSxNQUFNLGNBQWMsVUFBVSxRQUFRLE9BQU87Q0FDN0MsTUFBTSwwQkFBMEIsT0FBTyxRQUFRO0NBQy9DLElBQUk7RUFDSCxTQUFTLEtBQUssT0FBTyxTQUFTLGFBQWEsUUFBUSxHQUFHO0NBQ3ZELFNBQVMsT0FBTztFQUNmLE1BQU0sU0FBUyxPQUFPLFFBQVEsVUFBVSwyQkFBMkIsT0FBTyxTQUFTLFNBQVMsTUFBTSxRQUFRLHVCQUF1QixPQUFPLFFBQVEsT0FBTyxXQUFXO0VBQ2xLLElBQUksUUFBUSxTQUFTLE9BQU87RUFDNUIsTUFBTSxxQkFBcUI7R0FDMUIsR0FBRztHQUNILE9BQU87R0FDUDtFQUNEO0VBQ0EsTUFBTTtDQUNQO0NBQ0EsU0FBUyxPQUFPO0NBQ2hCLElBQUksTUFBTSxPQUFPLE1BQU0scUJBQXFCO0VBQzNDLEdBQUc7RUFDSCxRQUFRO0NBQ1Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLHdCQUF3QixRQUFRLE1BQU0sUUFBUSxLQUFLLE1BQU07Q0FDakUscUNBQXFDO0VBQ3BDLE1BQU0sUUFBUSx5QkFBeUI7RUFDdkMsSUFBSSxDQUFDLE9BQU87RUFDWixJQUFJLE9BQU8sTUFBTTtHQUNoQixDQUFDLFdBQVcsY0FBYyxNQUFNLG9CQUFvQixNQUFNLHFCQUFvQixDQUFFLEtBQUssT0FBTyxTQUFTLE1BQU0sUUFBUSxHQUFHO0dBQ3RIO0VBQ0Q7RUFDQSxNQUFNLGdCQUFnQixNQUFNO0VBQzVCLE1BQU0sMkJBQTJCO0VBQ2pDLE1BQU0scUJBQXFCO0dBQzFCO0dBQ0E7R0FDQTtHQUNBLE1BQU0sSUFBSSxJQUFJLEtBQUssT0FBTyxTQUFTLElBQUksQ0FBQyxDQUFDO0dBQ3pDO0dBQ0EsT0FBTztHQUNQLFFBQVE7RUFDVDtFQUNBLElBQUk7R0FDSCxPQUFPLFFBQVEsT0FBTyxDQUFDLE1BQU0sUUFBUSxHQUFHO0VBQ3pDLFVBQVU7R0FDVCxNQUFNLDJCQUEyQjtHQUNqQyxNQUFNLHFCQUFxQjtFQUM1QjtDQUNELENBQUM7QUFDRjtBQUNBLFNBQVMsOEJBQThCLE1BQU0sUUFBUSxLQUFLLE1BQU07Q0FDL0Qsd0JBQXdCLGFBQWEsTUFBTSxRQUFRLEtBQUssSUFBSTtBQUM3RDtBQUNBLFNBQVMsaUNBQWlDLE1BQU0sUUFBUSxLQUFLLE1BQU07Q0FDbEUsd0JBQXdCLGdCQUFnQixNQUFNLFFBQVEsS0FBSyxJQUFJO0FBQ2hFOzs7Ozs7OztBQVFBLFNBQVMscUJBQXFCO0NBQzdCLGlDQUFpQztFQUNoQyxHQUFHLE9BQU8sUUFBUSxTQUFTLENBQUM7RUFDNUIsa0JBQWtCLE9BQU87RUFDekIsa0JBQWtCLE9BQU87Q0FDMUIsR0FBRyxFQUFFO0FBQ047QUFDQSxTQUFTLDJCQUEyQixNQUFNLE1BQU0sUUFBUTtDQUN2RCxNQUFNLGdDQUFnQyxxQkFBcUIsQ0FBQyxFQUFFLFVBQVU7Q0FDeEUsSUFBSSwrQkFBK0I7RUFDbEMsOEJBQThCLE1BQU0sTUFBTSxNQUFNO0VBQ2hEO0NBQ0Q7Q0FDQSxNQUFNLGVBQWUsdURBQXVELE9BQU8sUUFBUSxLQUFLO0NBQ2hHLElBQUksU0FBUyxXQUFXLGlDQUFpQyxjQUFjLElBQUksSUFBSTtNQUMxRSw4QkFBOEIsY0FBYyxJQUFJLElBQUk7QUFDMUQ7QUFDQSxTQUFTLDZCQUE2QixRQUFRO0NBQzdDLElBQUksT0FBTyxhQUFhLGVBQWUsT0FBTyxXQUFXLGFBQWE7Q0FDdEUsSUFBSSxPQUFPLFNBQVMsTUFBTTtFQUN6QixNQUFNLE9BQU8sT0FBTztFQUNwQiw0QkFBNEI7R0FDM0IsSUFBSSxDQUFDLDhCQUE4QixNQUFNLEdBQUc7R0FDNUMsK0NBQStDO0lBQzlDLG1CQUFtQixJQUFJO0dBQ3hCLENBQUM7RUFDRixDQUFDO0VBQ0Q7Q0FDRDtDQUNBLElBQUksT0FBTyxxQkFBcUI7Q0FDaEMsK0NBQStDO0VBQzlDLFNBQVMsZ0JBQWdCLFlBQVk7Q0FDdEMsQ0FBQztBQUNGO0FBQ0EsU0FBUyxnQ0FBZ0MsUUFBUTtDQUNoRCxxQkFBcUI7RUFDcEIsTUFBTSxnQkFBZ0IsZ0NBQWdDO0VBQ3RELElBQUksa0JBQWtCLFFBQVEsY0FBYyxPQUFPLE9BQU8sSUFBSTtFQUM5RCxNQUFNLGlCQUFpQiw2QkFBNkIsTUFBTTtFQUMxRCxJQUFJLGdCQUFnQiw2QkFBNkIsY0FBYztDQUNoRSxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsU0FBUyxzQkFBc0IsT0FBTztDQUNyQyxJQUFJLFNBQVMsT0FBTyxVQUFVLFlBQVksc0JBQXNCLE9BQU87RUFDdEUsTUFBTSxFQUFFLGtCQUFrQixHQUFHLGtCQUFrQixNQUFNO0VBQ3JELFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVztHQUM1QixNQUFNLFVBQVUsT0FBTywwQkFBMEI7R0FDakQsSUFBSSxTQUFTLFFBQVEsV0FBVyxjQUFjLEdBQUcsQ0FBQyxDQUFDO1FBQzlDLGNBQWMsR0FBRyxDQUFDO0VBQ3hCLENBQUM7Q0FDRjtBQUNEOzs7Ozs7QUFNQSxTQUFTLGVBQWUsVUFBVSxNQUFNO0NBQ3ZDLElBQUksU0FBUyxXQUFXLE9BQU8sU0FBUyxRQUFRLFFBQVE7TUFDbkQsT0FBTyxTQUFTLE9BQU8sUUFBUTtBQUNyQzs7Ozs7OztBQU9BLFNBQVMsdUJBQXVCO0NBQy9CLHFCQUFxQixDQUFDLEVBQUUsVUFBVSw0QkFBNEI7QUFDL0Q7Ozs7Ozs7QUFPQSxTQUFTLHlCQUF5QixNQUFNO0NBQ3ZDLE1BQU0sY0FBYyx5QkFBeUIsSUFBSTtDQUNqRCxJQUFJLGdCQUFnQixRQUFRLENBQUMsMkJBQTJCLE1BQU0sT0FBTyxTQUFTLE1BQU0sVUFBVSxHQUFHLDRCQUE0QixXQUFXO0NBQ3hJLHFCQUFxQjtBQUN0Qjs7Ozs7Ozs7O0FBU0EsU0FBUyxtQ0FBbUM7Q0FDM0MsTUFBTSxjQUFjLHlCQUF5QixPQUFPLFNBQVMsSUFBSTtDQUNqRSxJQUFJLGdCQUFnQixNQUFNLDRCQUE0QixXQUFXO0NBQ2pFLHFCQUFxQjtBQUN0Qjs7OztBQUlBLGVBQWUsbUJBQW1CLE1BQU0sTUFBTSxRQUFRLHlCQUF5QixPQUFPLG9CQUFvQixjQUFjO0NBQ3ZILHlCQUF5QixJQUFJO0NBQzdCLElBQUksaUJBQWlCO0NBQ3JCLElBQUksY0FBYyxJQUFJLEdBQUc7RUFDeEIsTUFBTSxZQUFZLG9CQUFvQixNQUFNLFVBQVU7RUFDdEQsSUFBSSxhQUFhLE1BQU07R0FDdEIsK0JBQStCLE1BQU0sSUFBSTtHQUN6QyxNQUFNLG1CQUFtQixxQkFBcUIsQ0FBQyxFQUFFLFVBQVU7R0FDM0QsSUFBSSxrQkFBa0I7SUFDckIsTUFBTSxpQkFBaUIsTUFBTSxJQUFJO0lBQ2pDO0dBQ0Q7R0FDQSxlQUFlLE1BQU0sSUFBSTtHQUN6QixNQUFNLElBQUksY0FBYyxDQUFDLENBQUM7R0FDMUI7RUFDRDtFQUNBLGlCQUFpQjtDQUNsQjtDQUNBLE1BQU0sY0FBYyw4QkFBOEIsY0FBYztDQUNoRSxJQUFJLGdCQUFnQixXQUFXLGdCQUFnQixZQUFZO0VBQzFELE1BQU0sV0FBVyxpQ0FBaUMsZ0JBQWdCLE9BQU8sU0FBUyxNQUFNLFlBQVksZUFBZTtFQUNuSCwrQkFBK0IsVUFBVSxJQUFJO0VBQzdDLElBQUksU0FBUyxRQUFRLG1CQUFtQjtFQUN4QyxNQUFNLGNBQWMscUJBQXFCLENBQUMsRUFBRSxVQUFVO0VBQ3RELElBQUksYUFBYTtHQUNoQixNQUFNLFlBQVksVUFBVSxJQUFJO0dBQ2hDO0VBQ0Q7RUFDQSxlQUFlLFVBQVUsSUFBSTtFQUM3QixNQUFNLElBQUksY0FBYyxDQUFDLENBQUM7RUFDMUI7Q0FDRDtDQUNBLE1BQU0sV0FBVyxpQ0FBaUMsZ0JBQWdCLE9BQU8sU0FBUyxNQUFNLFlBQVksZUFBZTtDQUNuSCxnQ0FBZ0MsUUFBUTtDQUN4QywrQkFBK0IsVUFBVSxJQUFJO0NBQzdDLElBQUksU0FBUyxRQUFRLG1CQUFtQjtDQUN4QyxNQUFNLGNBQWMsa0JBQWtCLDhCQUE4QjtFQUNuRSxVQUFVO0VBQ1YsaUJBQWlCO0VBQ2pCLGFBQWEsT0FBTyxTQUFTO0VBQzdCO0VBQ0E7RUFDQSxZQUFZO0NBQ2IsQ0FBQztDQUNELElBQUksWUFBWSxTQUFTLHNCQUFzQjtFQUM5QywyQkFBMkI7RUFDM0IsMkJBQTJCLFVBQVUsWUFBWSxNQUFNLFlBQVksTUFBTTtFQUN6RSxnQ0FBZ0MsUUFBUTtFQUN4Qyw0QkFBNEI7RUFDNUIsSUFBSSxZQUFZLFFBQVEsbUJBQW1CLFlBQVksSUFBSTtFQUMzRDtDQUNEO0NBQ0EsSUFBSSxnQ0FBZ0MsT0FBTyxhQUFhLGNBQWMsS0FBSyxJQUFJLFFBQVEsR0FBRztFQUN6RixNQUFNLGNBQWMscUJBQXFCLENBQUMsRUFBRSxVQUFVO0VBQ3RELElBQUksYUFBYTtHQUNoQixNQUFNLFlBQVksVUFBVSxJQUFJO0dBQ2hDO0VBQ0Q7RUFDQSxlQUFlLFVBQVUsSUFBSTtFQUM3QixNQUFNLElBQUksY0FBYyxDQUFDLENBQUM7RUFDMUI7Q0FDRDtDQUNBLE1BQU0sVUFBVSxTQUFTLFFBQVEsR0FBRztDQUNwQyxNQUFNLE9BQU8sWUFBWSxDQUFDLElBQUksU0FBUyxNQUFNLE9BQU8sSUFBSTtDQUN4RCxNQUFNLGVBQWUsU0FBUywyQkFBMkIsUUFBUSxJQUFJLElBQUk7Q0FDekUsSUFBSSxDQUFDLFFBQVEsMkJBQTJCO0NBQ3hDLE1BQU0sY0FBYyxxQkFBcUIsQ0FBQyxFQUFFLFVBQVU7Q0FDdEQsSUFBSTtFQUNILElBQUksYUFBYSxNQUFNLFlBQVksVUFBVSxHQUFHLFlBQVksTUFBTSxLQUFLLEdBQUcsd0JBQXdCLEtBQUssR0FBRyxjQUFjLG1CQUFtQixZQUFZLHFCQUFxQjtPQUN2SztHQUNKLElBQUksU0FBUyxXQUFXLGlDQUFpQyxNQUFNLElBQUksUUFBUTtRQUN0RSw4QkFBOEIsTUFBTSxJQUFJLFFBQVE7R0FDckQsNEJBQTRCO0VBQzdCO0NBQ0QsU0FBUyxPQUFPO0VBQ2YsSUFBSSxjQUFjLDZCQUE2QixZQUFZO0VBQzNELE1BQU07Q0FDUDtDQUNBLElBQUksY0FBYyxnQ0FBZ0MsWUFBWTtBQUMvRDtBQUNBLElBQUksb0NBQW9DO0FBQ3hDLFNBQVMsb0NBQW9DO0NBQzVDLHFDQUFxQztDQUNyQyxJQUFJLFdBQVc7Q0FDZixhQUFhO0VBQ1osSUFBSSxVQUFVO0VBQ2QsV0FBVztFQUNYLG9DQUFvQyxLQUFLLElBQUksR0FBRyxvQ0FBb0MsQ0FBQztDQUN0RjtBQUNEO0FBQ0EsU0FBUyxrQ0FBa0M7Q0FDMUMsT0FBTyxvQ0FBb0M7QUFDNUM7QUFDQSxTQUFTLG9EQUFvRCxTQUFTO0NBQ3JFLGVBQWUsT0FBTztBQUN2QjtBQUNBLElBQUksbUNBQW1DO0FBQ3ZDLElBQUksbUNBQW1DOzs7OztBQUt2QyxTQUFTLG1DQUFtQztDQUMzQyxvQ0FBb0M7Q0FDcEMsSUFBSSxXQUFXO0NBQ2YsYUFBYTtFQUNaLElBQUksVUFBVTtFQUNkLFdBQVc7RUFDWCxtQ0FBbUMsS0FBSyxJQUFJLEdBQUcsbUNBQW1DLENBQUM7RUFDbkYsSUFBSSxxQ0FBcUMsS0FBSyxrQ0FBa0M7R0FDL0UsbUNBQW1DO0dBQ25DLHFCQUFxQixDQUFDLEVBQUUsVUFBVSxtQkFBbUI7RUFDdEQ7Q0FDRDtBQUNEO0FBQ0EsU0FBUyx3Q0FBd0M7Q0FDaEQsSUFBSSxtQ0FBbUMsR0FBRztFQUN6QyxtQ0FBbUM7RUFDbkM7Q0FDRDtDQUNBLHFCQUFxQixDQUFDLEVBQUUsVUFBVSxtQkFBbUI7QUFDdEQ7Ozs7Ozs7Ozs7QUFVQSxNQUFNLGFBQWE7Q0FDbEIsV0FBVztDQUNYLEtBQUssTUFBTSxTQUFTO0VBQ25CLHdCQUF3QixJQUFJO0VBQzVCLElBQUksVUFBVTtFQUNkLHlCQUF5QixJQUFJO0VBQzdCLE1BQU0sb0JBQW9CLGtDQUFrQztFQUM1RCxJQUFJO0dBQ0gsUUFBUSxzQkFBc0I7SUFDN0IsbUJBQW1CLE1BQU0sUUFBUSxTQUFTLFdBQVcsT0FBTyxJQUFJO0dBQ2pFLENBQUM7RUFDRixTQUFTLE9BQU87R0FDZixrQkFBa0I7R0FDbEIsTUFBTTtFQUNQO0VBQ0Esb0RBQW9ELGlCQUFpQjtDQUN0RTtDQUNBLFFBQVEsTUFBTSxTQUFTO0VBQ3RCLHdCQUF3QixJQUFJO0VBQzVCLElBQUksVUFBVTtFQUNkLHlCQUF5QixJQUFJO0VBQzdCLE1BQU0sb0JBQW9CLGtDQUFrQztFQUM1RCxJQUFJO0dBQ0gsUUFBUSxzQkFBc0I7SUFDN0IsbUJBQW1CLE1BQU0sV0FBVyxTQUFTLFdBQVcsT0FBTyxJQUFJO0dBQ3BFLENBQUM7RUFDRixTQUFTLE9BQU87R0FDZixrQkFBa0I7R0FDbEIsTUFBTTtFQUNQO0VBQ0Esb0RBQW9ELGlCQUFpQjtDQUN0RTtDQUNBLE9BQU87RUFDTixJQUFJLFVBQVU7RUFDZCxPQUFPLFFBQVEsS0FBSztDQUNyQjtDQUNBLFVBQVU7RUFDVCxJQUFJLFVBQVU7RUFDZCxPQUFPLFFBQVEsUUFBUTtDQUN4QjtDQUNBLFVBQVU7RUFDVCxJQUFJLFVBQVU7RUFDZCxxQkFBcUIsQ0FBQyxFQUFFLFVBQVUsd0JBQXdCLEVBQUUsa0JBQWtCLE1BQU0sQ0FBQztFQUNyRixNQUFNLGNBQWMscUJBQXFCLENBQUMsRUFBRSxVQUFVO0VBQ3RELElBQUksZ0NBQWdDLEtBQUssQ0FBQyxhQUFhO0dBQ3RELHFCQUFxQixDQUFDLEVBQUUsVUFBVSxtQkFBbUI7R0FDckQ7RUFDRDtFQUNBLE1BQU0saUJBQWlCO0dBQ3RCLFlBQVksT0FBTyxTQUFTLE1BQU0sR0FBRyxXQUFXLEtBQUssR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUMsUUFBUSxxQ0FBcUM7RUFDcEg7RUFDQSxRQUFRLGdCQUFnQixRQUFRO0NBQ2pDO0NBQ0EsU0FBUyxNQUFNLFNBQVM7RUFDdkIsd0JBQXdCLElBQUk7RUFDNUIsSUFBSSxVQUFVO0VBQ2QsSUFBSSxlQUFlLE9BQU8sV0FBVyxhQUFhLEVBQUUsR0FBRztFQUN2RCxJQUFJO0dBQ0gsSUFBSSxJQUFJLGFBQWEsTUFBTSxVQUFVLEdBQUcsT0FBTyxTQUFTLElBQUk7RUFDN0QsUUFBUTtHQUNQLE1BQU0sSUFBSSxNQUFNLG9CQUFvQixLQUFLLDJDQUEyQztFQUNyRjtFQUNBLE1BQU0sZUFBZSxjQUFjLElBQUksSUFBSSxvQkFBb0IsTUFBTSxVQUFVLElBQUk7RUFDbkYsSUFBSSxnQkFBZ0IsTUFBTTtFQUMxQixNQUFNLFdBQVcseUJBQXlCLFlBQVk7RUFDdEQsSUFBSSxhQUFhLE1BQU07RUFDdkIsTUFBTSxrQkFBa0IsT0FBTyxTQUFTO0VBQ3hDLElBQUksc0JBQXNCLCtCQUErQixVQUFVLGVBQWU7RUFDbEYsTUFBTSxxQkFBcUIsc0JBQXNCO0VBQ2pELE1BQU0sVUFBVSxnQ0FBZ0M7R0FDL0MsZUFBZTtHQUNmO0dBQ0Esb0JBQW9CLHNCQUFzQjtFQUMzQyxDQUFDO0VBQ0QsTUFBTSxRQUFRLG1CQUFtQixRQUFRO0VBQ3pDLENBQUMsWUFBWTtHQUNaLE1BQU0sb0JBQW9CLG1DQUFtQztHQUM3RCxJQUFJLHNCQUFzQixNQUFNO0lBQy9CLElBQUksQ0FBQyxNQUFNLHFCQUFxQixNQUFNLFdBQVc7SUFDakQsc0JBQXNCLCtCQUErQixVQUFVLGVBQWU7SUFDOUUsSUFBSSx3QkFBd0IsTUFBTSxRQUFRLElBQUksb0NBQW9DLG1CQUFtQjtHQUN0RztHQUNBLElBQUkscUJBQXFCLE1BQU0sOEJBQThCO0dBQzdELE1BQU0sY0FBYyw4QkFBOEIsUUFBUTtHQUMxRCxJQUFJLGdCQUFnQixXQUFXLGdCQUFnQixZQUFZO0dBQzNELE1BQU0sd0JBQXdCLHNCQUFzQixxQ0FBcUMsVUFBVSxVQUFVLElBQUk7R0FDakgsTUFBTSxPQUFPLFNBQVMsU0FBUyxTQUFTLFNBQVM7R0FDakQsTUFBTSxDQUFDLEVBQUUsNkJBQTZCLCtCQUErQixFQUFFLGtDQUFrQyxNQUFNLFFBQVEsSUFBSSxDQUFDLE9BQU8sNENBQTRDLE9BQU8seUNBQXlDLENBQUM7R0FDaE8sSUFBSSxNQUFNLFdBQVc7R0FDckIsTUFBTSxTQUFTLFNBQVMsU0FBUyw0QkFBNEIsSUFBSSw0QkFBNEIseUJBQXlCLFVBQVUsbUJBQW1CO0dBQ25KLE1BQU0sV0FBVyxPQUFPLGtCQUFrQixPQUFPO0dBQ2pELE1BQU0sNEJBQTRCLE9BQU8sOEJBQThCO0dBQ3ZFLElBQUksWUFBWSxTQUFTLFFBQVEsUUFBUSxPQUFPLDJCQUEyQjtHQUMzRSxJQUFJLFlBQVksU0FBUyxRQUFRO0lBQ2hDLFFBQVEsSUFBSSw2QkFBNkIsR0FBRztJQUM1QyxRQUFRLElBQUkscUNBQXFDLHNCQUFzQiw0QkFBNEIsY0FBYyxHQUFHO0dBQ3JIO0dBQ0EsTUFBTSxrQkFBa0IsSUFBSSxJQUFJLFVBQVUsT0FBTyxTQUFTLElBQUksQ0FBQyxDQUFDLFdBQVc7R0FDM0UsSUFBSSxDQUFDLFlBQVksU0FBUyxRQUFRO0lBQ2pDLFFBQVEsSUFBSSw2QkFBNkIsR0FBRztJQUM1QyxRQUFRLElBQUkscUNBQXFDLEdBQUc7SUFDcEQsUUFBUSxJQUFJLCtCQUErQixtQkFBbUIsT0FBTyx1QkFBdUIsT0FBTyw2Q0FBNkMsMENBQTBDO0dBQzNMO0dBQ0EsTUFBTSxFQUFFLG1CQUFtQixXQUFXLE1BQU0sNkJBQTZCO0lBQ3hFO0lBQ0E7SUFDQTtHQUNELENBQUM7R0FDRCxJQUFJLE1BQU0sV0FBVztHQUNyQixNQUFNLFdBQVcsZ0JBQWdCLGVBQWUsUUFBUSxtQkFBbUI7R0FDM0UsTUFBTSxhQUFhLGtCQUFrQjtHQUNyQyxJQUFJLE9BQU8scUJBQXFCLG1CQUFtQix1Q0FBdUMsUUFBUSxtQkFBbUIsR0FBRztJQUN2SCxtQ0FBbUMsVUFBVSxTQUFTLFlBQVk7SUFDbEU7R0FDRDtHQUNBLElBQUksVUFBVTtJQUNiLHNDQUFzQyxRQUFRLHFCQUFxQixrQkFBa0I7SUFDckYsSUFBSSxtQ0FBbUMsUUFBUSxxQkFBcUIsb0JBQW9CO0tBQ3ZGO0tBQ0EsY0FBYyxTQUFTO0tBQ3ZCLFNBQVMsT0FBTyxxQkFBcUIsbUJBQW1CLE9BQU8sb0JBQW9CLHVDQUF1QyxpQkFBaUIsS0FBSyxJQUFJLEtBQUs7SUFDMUosQ0FBQyxHQUFHO0lBQ0osSUFBSSxPQUFPLHFCQUFxQixtQkFBbUIsb0NBQW9DLFFBQVEscUJBQXFCLG9CQUFvQixtQkFBbUIsU0FBUyxZQUFZLEdBQUc7R0FDcEw7R0FDQSxJQUFJLE9BQU8scUJBQXFCLG1CQUFtQixrQ0FBa0MsUUFBUSxxQkFBcUIsb0JBQW9CLG1CQUFtQixTQUFTLFlBQVksR0FBRztHQUNqTCxXQUFXLElBQUksUUFBUTtHQUN2QixNQUFNLDRCQUE0QiwwQkFBMEIsV0FBVyxNQUFNLFFBQVE7SUFDcEY7SUFDQSxhQUFhO0lBQ2IsVUFBVTtJQUNWO0dBQ0QsQ0FBQyxHQUFHLEtBQUs7R0FDVCxvQkFBb0IsUUFBUSxZQUFZLFNBQVMsVUFBVSw0QkFBNEIsNEJBQTRCO0lBQ2xIO0lBQ0EsaUJBQWlCLGlCQUFpQixxQkFBcUIsMEJBQTBCLFdBQVcsTUFBTSxpQkFBaUI7S0FDbEgsU0FBUztLQUNULGFBQWE7S0FDYixVQUFVO0tBQ1Y7SUFDRCxDQUFDLEdBQUcsS0FBSztJQUNUO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQyxJQUFJLG9CQUFvQixHQUFHLHFCQUFxQixvQkFBb0IsU0FBUyxXQUFXO0lBQ3hGLG9CQUFvQjtJQUNwQixlQUFlLE9BQU8sZ0JBQWdCLFlBQVksK0JBQStCO0lBQ2pGLGtCQUFrQixPQUFPO0lBQ3pCLHNCQUFzQjtJQUN0QixjQUFjO0lBQ2QsaUJBQWlCO0dBQ2xCLElBQUk7SUFDSCxvQkFBb0I7SUFDcEIsZUFBZSxPQUFPLGdCQUFnQixZQUFZLCtCQUErQjtJQUNqRixrQkFBa0IsT0FBTztJQUN6QixzQkFBc0I7SUFDdEIsY0FBYztHQUNmLENBQUM7RUFDRixFQUFDLENBQUUsQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUNyQixRQUFRLE1BQU0sc0NBQXNDLEtBQUs7RUFDMUQsQ0FBQyxDQUFDLENBQUMsY0FBYztHQUNoQixzQkFBc0IsT0FBTyxLQUFLO0VBQ25DLENBQUM7Q0FDRjtBQUNEO0FBQ0EsSUFBSSxRQUFRLElBQUksMkJBQTJCLFdBQVcsNEJBQTRCLE1BQU0sWUFBWTtDQUNuRyx3QkFBd0IsSUFBSTtDQUM1QixJQUFJLFVBQVU7Q0FDZCxJQUFJLENBQUMscUJBQXFCLENBQUMsRUFBRSxVQUFVLFVBQVU7Q0FDakQsSUFBSSxVQUFVO0NBQ2QsSUFBSSxjQUFjLElBQUksR0FBRztFQUN4QixNQUFNLFlBQVksb0JBQW9CLE1BQU0sVUFBVTtFQUN0RCxJQUFJLGNBQWMsTUFBTTtFQUN4QixVQUFVO0NBQ1g7Q0FDQSxNQUFNLG9CQUFvQixrQ0FBa0M7Q0FDNUQsbUJBQW1CLFNBQVMsUUFBUSxTQUFTLFdBQVcsT0FBTyxPQUFPLGFBQWE7Q0FDbkYsb0RBQW9ELGlCQUFpQjtBQUN0RTtBQUNBLFNBQVMsc0JBQXNCLE9BQU87Q0FDckMsSUFBSSxDQUFDLFNBQVMsVUFBVSxLQUFLLE9BQU87Q0FDcEMsT0FBTztBQUNSO0FBQ0EsU0FBUywyQkFBMkI7Q0FDbkMsTUFBTSxpQkFBaUIsMkJBQTJCO0NBQ2xELE1BQU0sZUFBZSx1QkFBdUI7Q0FDNUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixPQUFPLFFBQVEsZUFBZSxZQUFZLE9BQU8sc0JBQXNCLElBQUk7Q0FDbkgsSUFBSTtFQUNILE1BQU0sWUFBWSxRQUFRLFdBQVcsY0FBYztFQUNuRCxNQUFNLFFBQVEsUUFBUSxXQUFXLFlBQVk7RUFDN0MsT0FBTyxzQkFBc0IsY0FBYyxPQUFPLFFBQVEsYUFBYSxJQUFJO0NBQzVFLFNBQVMsT0FBTztFQUNmLHNCQUE2QixjQUFjLFFBQVEsS0FBSyw2Q0FBNkMsS0FBSztFQUMxRyxPQUFPLHNCQUFzQixJQUFJO0NBQ2xDO0FBQ0Q7Ozs7Ozs7O0FBUUEsTUFBTSxvQkFBb0I7Ozs7Ozs7O0FBUTFCLFNBQVMsWUFBWTtDQUNwQixJQUFJLENBQUMsb0JBQW9CLE9BQU8sUUFBUSxlQUFlLGNBQWMsT0FBTyxRQUFRLFlBQVksWUFBWSxNQUFNLElBQUksTUFBTSw2Q0FBNkM7Q0FDekssTUFBTSxTQUFTLFFBQVEsV0FBVyxnQkFBZ0I7Q0FDbEQsSUFBSSxXQUFXLE1BQU0sTUFBTSxJQUFJLE1BQU0sNkNBQTZDO0NBQ2xGLE1BQU0sWUFBWSx5QkFBeUI7Q0FDM0MsT0FBTyxRQUFRLGVBQWU7RUFDN0IsR0FBRztFQUNIO0NBQ0QsSUFBSSxDQUFDLFFBQVEsU0FBUyxDQUFDO0FBQ3hCOzs7Ozs7Ozs7O0FBVUEsU0FBUyx5QkFBeUIsbUJBQW1CO0NBQ3BELE1BQU0sV0FBVywwQkFBMEIsaUJBQWlCO0NBQzVELElBQUksU0FBUyxXQUFXLEdBQUcsT0FBTztDQUNsQyxPQUFPLHNCQUFzQixLQUFLLEtBQUssc0JBQXNCLGFBQWEsU0FBUyxLQUFLLFNBQVMsU0FBUyxTQUFTO0FBQ3BIOzs7Ozs7Ozs7O0FBVUEsU0FBUywwQkFBMEIsbUJBQW1CO0NBQ3JELElBQUksVUFBVSxvQ0FBb0M7Q0FDbEQsT0FBTyxpQkFBaUIsaUJBQWlCO0FBQzFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFTLHNCQUFzQixVQUFVO0NBQ3hDLElBQUksT0FBTyxhQUFhLGFBQWE7Q0FDckMsbUNBQW1DLFFBQVE7QUFDNUM7QUFDQSxJQUFJLENBQUMsVUFBVTtDQUNkLE1BQU0sUUFBUSx5QkFBeUI7Q0FDdkMsSUFBSSxTQUFTLENBQUMsTUFBTSxnQkFBZ0I7RUFDbkMsTUFBTSxpQkFBaUI7RUFDdkIsT0FBTyxpQkFBaUIsa0JBQWtCO0dBQ3pDLGlDQUFpQztFQUNsQyxDQUFDO0VBQ0QsT0FBTyxpQkFBaUIsYUFBYSxVQUFVO0dBQzlDLElBQUksQ0FBQyx3QkFBd0IsR0FBRztJQUMvQiw0QkFBNEI7SUFDNUIsc0JBQXNCLE1BQU0sS0FBSztHQUNsQztFQUNELENBQUM7RUFDRCxPQUFPLFFBQVEsWUFBWSxTQUFTLGlCQUFpQixNQUFNLFFBQVEsS0FBSztHQUN2RSxJQUFJLDBCQUEwQixPQUFPLGFBQWEsTUFBTSxRQUFRLEdBQUcsR0FBRztHQUN0RSxJQUFJLE1BQU0sNEJBQTRCLEdBQUcscUJBQXFCLENBQUMsRUFBRSxVQUFVLCtCQUErQjtHQUMxRyxJQUFJLHVCQUF1QixJQUFJLEdBQUc7SUFDakMsTUFBTSx1QkFBdUIsT0FBTyxRQUFRO0lBQzVDLE1BQU0sa0JBQWtCLEtBQUssT0FBTyxTQUFTLE1BQU0sUUFBUSxHQUFHO0lBQzlELHFCQUFxQixDQUFDLEVBQUUsVUFBVSxrQ0FBa0MsUUFBUSxvQkFBb0I7SUFDaEc7R0FDRDtHQUNBLE1BQU0sdUJBQXVCLE9BQU8sUUFBUTtHQUM1QyxNQUFNLGtCQUFrQixLQUFLLE9BQU8sU0FBUyw2Q0FBNkMsTUFBTSxPQUFPLFFBQVEsS0FBSyxHQUFHLFFBQVEsR0FBRztHQUNsSSxxQkFBcUIsQ0FBQyxFQUFFLFVBQVUsa0NBQWtDLFFBQVEsb0JBQW9CO0dBQ2hHLElBQUksTUFBTSwyQkFBMkIsR0FBRztJQUN2QyxxQkFBcUI7SUFDckIsSUFBSSxLQUFLLHFCQUFxQixDQUFDLEVBQUUsVUFBVSwyQkFBMkI7SUFDdEUsNEJBQTRCO0dBQzdCO0VBQ0Q7RUFDQSxPQUFPLFFBQVEsZUFBZSxTQUFTLG9CQUFvQixNQUFNLFFBQVEsS0FBSztHQUM3RSxJQUFJLDBCQUEwQixPQUFPLGdCQUFnQixNQUFNLFFBQVEsR0FBRyxHQUFHO0dBQ3pFLElBQUksTUFBTSw0QkFBNEIsR0FBRyxxQkFBcUIsQ0FBQyxFQUFFLFVBQVUsK0JBQStCO0dBQzFHLElBQUksdUJBQXVCLElBQUksR0FBRztJQUNqQyxNQUFNLHVCQUF1QixPQUFPLFFBQVE7SUFDNUMsTUFBTSxxQkFBcUIsS0FBSyxPQUFPLFNBQVMsTUFBTSxRQUFRLEdBQUc7SUFDakUscUJBQXFCLENBQUMsRUFBRSxVQUFVLGtDQUFrQyxXQUFXLG9CQUFvQjtJQUNuRztHQUNEO0dBQ0EsTUFBTSx1QkFBdUIsT0FBTyxRQUFRO0dBQzVDLE1BQU0scUJBQXFCLEtBQUssT0FBTyxTQUFTLDZDQUE2QyxNQUFNLE9BQU8sUUFBUSxLQUFLLEdBQUcsUUFBUSxHQUFHO0dBQ3JJLHFCQUFxQixDQUFDLEVBQUUsVUFBVSxrQ0FBa0MsV0FBVyxvQkFBb0I7R0FDbkcsSUFBSSxNQUFNLDJCQUEyQixHQUFHO0lBQ3ZDLHFCQUFxQjtJQUNyQixJQUFJLEtBQUsscUJBQXFCLENBQUMsRUFBRSxVQUFVLDJCQUEyQjtJQUN0RSw0QkFBNEI7R0FDN0I7RUFDRDtDQUNEO0FBQ0Q7O0FBRUEsU0FBUyxtQkFBbUIsOEJBQThCLG9CQUFvQixzQkFBc0IsZ0NBQWdDLHlCQUF5QixvQkFBb0IseUJBQXlCLGNBQWMsMkJBQTJCLHlCQUF5QixZQUFZLHlCQUF5Qiw0QkFBNEIsbUJBQW1CLDhCQUE4QixzQkFBc0IseUJBQXlCLDZCQUE2Qix5QkFBeUIsc0NBQXNDLGlDQUFpQyxpQ0FBaUMsc0NBQXNDLDZCQUE2QixxQkFBcUIsZ0NBQWdDLDZDQUE2Qyx1Q0FBdUMsNkJBQTZCLHlCQUF5QixXQUFXLDZCQUE2Qix3QkFBd0IsNEJBQTRCLGtDQUFrQywwQkFBMEIsaUJBQWlCLCtCQUErQixtQkFBbUIsNEJBQTRCLHlCQUF5Qix1QkFBdUIsc0JBQXNCLGtCQUFrQixnQ0FBZ0MsbUJBQW1CLHdDQUF3QyxtQ0FBbUMsb0NBQW9DLHdDQUF3QyxnQ0FBZ0MseUJBQXlCLHFDQUFxQyxxQkFBcUIsc0JBQXNCLDJCQUEyQixtQkFBbUIsaUJBQWlCLG9CQUFvQixVQUFVLGtDQUFrQyxtQ0FBbUMsbUJBQW1CLHFCQUFxQiwrQkFBK0IsbUNBQW1DLHdDQUF3QywrQkFBK0IsVUFBVSwwQkFBMEIsa0NBQWtDLGtDQUFrQyxtQ0FBbUMsK0JBQStCLHNDQUFzQyw2Q0FBNkMsb0JBQW9CLG9CQUFvQixxQ0FBcUMsOEJBQThCLGlCQUFpQix1QkFBdUIsc0JBQXNCLG9CQUFvQixxQkFBcUIsdUJBQXVCLGtDQUFrQyxjQUFjLG9DQUFvQyxrQkFBa0IsbUNBQW1DLFdBQVcsYUFBYSxXQUFXLGlCQUFpQiwwQkFBMEIsMkJBQTJCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm5hdmlnYXRpb24uanM/dj1iNDFiZWNkZCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpc0JvdFVzZXJBZ2VudCB9IGZyb20gXCIuLi91dGlscy9odG1sLWxpbWl0ZWQtYm90cy5qc1wiO1xuaW1wb3J0IHsgaXNFeHRlcm5hbFVybCB9IGZyb20gXCIuLi91dGlscy9leHRlcm5hbC11cmwuanNcIjtcbmltcG9ydCB7IHN0cmlwQmFzZVBhdGggfSBmcm9tIFwiLi4vdXRpbHMvYmFzZS1wYXRoLmpzXCI7XG5pbXBvcnQgeyBORVhUX1JPVVRFUl9QUkVGRVRDSF9IRUFERVIsIE5FWFRfUk9VVEVSX1NFR01FTlRfUFJFRkVUQ0hfSEVBREVSLCBWSU5FWFRfSU5URVJDRVBUSU9OX0NPTlRFWFRfSEVBREVSLCBWSU5FWFRfTU9VTlRFRF9TTE9UU19IRUFERVIsIFZJTkVYVF9SU0NfUkVOREVSX01PREVfSEVBREVSIH0gZnJvbSBcIi4uL3NlcnZlci9hcHAtcnNjLXZhcnkuanNcIjtcbmltcG9ydCB7IE5FWFRfUk9VVEVSX1NUQUxFX1RJTUVfSEVBREVSLCBWSU5FWFRfRFlOQU1JQ19TVEFMRV9USU1FX0hFQURFUiwgVklORVhUX1BBUkFNU19IRUFERVIsIFZJTkVYVF9SRU5ERVJFRF9QQVRIX0FORF9TRUFSQ0hfSEVBREVSLCBWSU5FWFRfUlNDX0NPTVBMRVRJT05fTUVUQURBVEFfSEVBREVSLCBWSU5FWFRfUlNDX1JFRElSRUNUX0hFQURFUiwgVklORVhUX1JTQ19SRURJUkVDVF9UWVBFX0hFQURFUiwgVklORVhUX1NUQUxFX1RJTUVfUEVORElOR19IRUFERVIgfSBmcm9tIFwiLi4vc2VydmVyL2hlYWRlcnMuanNcIjtcbmltcG9ydCB7IGFzc2VydFNhZmVOYXZpZ2F0aW9uVXJsIH0gZnJvbSBcIi4vdXJsLXNhZmV0eS5qc1wiO1xuaW1wb3J0IHsgQVBQX1JTQ19SRU5ERVJfTU9ERV9QUkVGRVRDSF9EWU5BTUlDX1NIRUxMLCBBUFBfUlNDX1JFTkRFUl9NT0RFX1BSRUZFVENIX0xPQURJTkdfU0hFTEwgfSBmcm9tIFwiLi4vc2VydmVyL2FwcC1yc2MtcmVuZGVyLW1vZGUuanNcIjtcbmltcG9ydCB7IGdldFBwckZhbGxiYWNrU2hlbGxTdGF0ZSwgbWFya1BwckZhbGxiYWNrU2hlbGxEeW5hbWljQm91bmRhcnkgfSBmcm9tIFwiLi9wcHItZmFsbGJhY2stc2hlbGwuanNcIjtcbmltcG9ydCB7IEFwcFJvdXRlckNvbnRleHQgfSBmcm9tIFwiLi9pbnRlcm5hbC9hcHAtcm91dGVyLWNvbnRleHQuanNcIjtcbmltcG9ydCB7IHJlc29sdmVEaXJlY3RIeWJyaWRDbGllbnRSb3V0ZU93bmVyIH0gZnJvbSBcIi4vaW50ZXJuYWwvaHlicmlkLWNsaWVudC1yb3V0ZS1vd25lci1kaXJlY3QuanNcIjtcbmltcG9ydCB7IGlzSGFzaE9ubHlCcm93c2VyVXJsQ2hhbmdlLCB0b0Nhbm9uaWNhbEJyb3dzZXJOYXZpZ2F0aW9uSHJlZiwgdG9TYW1lT3JpZ2luQXBwUGF0aCwgd2l0aEJhc2VQYXRoIH0gZnJvbSBcIi4vdXJsLXV0aWxzLmpzXCI7XG5pbXBvcnQgeyBkaXNhYmxlU21vb3RoU2Nyb2xsRHVyaW5nUm91dGVUcmFuc2l0aW9uIH0gZnJvbSBcIi4vZGlzYWJsZS1zbW9vdGgtc2Nyb2xsLmpzXCI7XG5pbXBvcnQgeyByZXRyeVNjcm9sbFRvLCBzY3JvbGxUb0hhc2hUYXJnZXQgfSBmcm9tIFwiLi9oYXNoLXNjcm9sbC5qc1wiO1xuaW1wb3J0IHsgVklORVhUX1JTQ19DT01QQVRJQklMSVRZX0lEX0hFQURFUiwgVklORVhUX1JTQ19DT05URU5UX1RZUEUsIGNyZWF0ZVJzY1JlcXVlc3RIZWFkZXJzLCBjcmVhdGVSc2NSZXF1ZXN0VXJsLCBmb3JtYXRSc2NSZXF1ZXN0UGF0aCwgcGFyc2VSc2NSZXF1ZXN0UGF0aCwgc3RyaXBSc2NDYWNoZUJ1c3RpbmdTZWFyY2hQYXJhbSB9IGZyb20gXCIuLi9zZXJ2ZXIvYXBwLXJzYy1jYWNoZS1idXN0aW5nLmpzXCI7XG5pbXBvcnQgeyBjbGVhckFwcE5hdmlnYXRpb25GYWlsdXJlVGFyZ2V0LCBzdGFnZUFwcE5hdmlnYXRpb25GYWlsdXJlVGFyZ2V0IH0gZnJvbSBcIi4uL2NsaWVudC9hcHAtbmF2LWZhaWx1cmUtaGFuZGxlci5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5QXBwUm91dGVyVHJhbnNpdGlvblN0YXJ0IH0gZnJvbSBcIi4uL2NsaWVudC9pbnN0cnVtZW50YXRpb24tY2xpZW50LXN0YXRlLmpzXCI7XG5pbXBvcnQgeyBnZXROYXZpZ2F0aW9uUnVudGltZSwgaGFzQXBwTmF2aWdhdGlvblJ1bnRpbWUsIGxvYWROYXZpZ2F0aW9uUnVudGltZVJvdXRlTWFuaWZlc3QgfSBmcm9tIFwiLi4vY2xpZW50L25hdmlnYXRpb24tcnVudGltZS5qc1wiO1xuaW1wb3J0IHsgVW5yZWNvZ25pemVkQWN0aW9uRXJyb3IsIHVuc3RhYmxlX2lzVW5yZWNvZ25pemVkQWN0aW9uRXJyb3IgfSBmcm9tIFwiLi91bnJlY29nbml6ZWQtYWN0aW9uLWVycm9yLmpzXCI7XG5pbXBvcnQgeyBBcHBFbGVtZW50c1dpcmUgfSBmcm9tIFwiLi4vc2VydmVyL2FwcC1lbGVtZW50cy13aXJlLmpzXCI7XG5pbXBvcnQgXCIuLi9zZXJ2ZXIvYXBwLWVsZW1lbnRzLmpzXCI7XG5pbXBvcnQgeyBQVUJMSUNfSU5JVElBTF9CRkNBQ0hFX0lEIH0gZnJvbSBcIi4uL3NlcnZlci9hcHAtYmZjYWNoZS1pZC5qc1wiO1xuaW1wb3J0IHsgcmVzb2x2ZU1hbmlmZXN0TmF2aWdhdGlvbkludGVyY2VwdGlvbkNvbnRleHQgfSBmcm9tIFwiLi4vc2VydmVyL2FwcC1icm93c2VyLWludGVyY2VwdGlvbi1jb250ZXh0LmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVFeHRlcm5hbEhpc3RvcnlTdGF0ZVByZXNlcnZpbmdNZXRhZGF0YSwgY3JlYXRlSGFzaE9ubHlIaXN0b3J5U3RhdGVQcmVzZXJ2aW5nTmF2aWdhdGlvbk1ldGFkYXRhLCBpc0FwcE93bmVkSGlzdG9yeVN0YXRlLCByZWFkSGlzdG9yeVN0YXRlVHJhdmVyc2FsSW5kZXggfSBmcm9tIFwiLi4vc2VydmVyL2FwcC1oaXN0b3J5LXN0YXRlLmpzXCI7XG5pbXBvcnQgeyBoYXNQZW5kaW5nQXBwUm91dGVyUGFnZVJlZGlyZWN0IH0gZnJvbSBcIi4uL3NlcnZlci9hcHAtYnJvd3Nlci1tcGEtbmF2aWdhdGlvbi5qc1wiO1xuaW1wb3J0IHsgZXh0cmFjdFJzY0NvbXBsZXRpb25NZXRhZGF0YSB9IGZyb20gXCIuLi9zZXJ2ZXIvcnNjLWNvbXBsZXRpb24tbWV0YWRhdGEuanNcIjtcbmltcG9ydCB7IG5hdmlnYXRpb25QbGFubmVyIH0gZnJvbSBcIi4uL3NlcnZlci9uYXZpZ2F0aW9uLXBsYW5uZXIuanNcIjtcbmltcG9ydCB7IFJlYWRvbmx5VVJMU2VhcmNoUGFyYW1zIH0gZnJvbSBcIi4vcmVhZG9ubHktdXJsLXNlYXJjaC1wYXJhbXMuanNcIjtcbmltcG9ydCB7IEJhaWxvdXRUb0NTUkVycm9yLCBEeW5hbWljU2VydmVyRXJyb3IsIEhUVFBfRVJST1JfRkFMTEJBQ0tfRVJST1JfQ09ERSwgUmVkaXJlY3RUeXBlLCBkZWNvZGVSZWRpcmVjdEVycm9yLCBmb3JiaWRkZW4sIGdldEFjY2Vzc0ZhbGxiYWNrSFRUUFN0YXR1cywgaXNCYWlsb3V0VG9DU1JFcnJvciwgaXNEeW5hbWljU2VydmVyRXJyb3IsIGlzSFRUUEFjY2Vzc0ZhbGxiYWNrRXJyb3IsIGlzTmV4dFJvdXRlckVycm9yLCBpc1JlZGlyZWN0RXJyb3IsIG5vdEZvdW5kLCBwZXJtYW5lbnRSZWRpcmVjdCwgcmVkaXJlY3QsIHVuYXV0aG9yaXplZCwgdW5zdGFibGVfcmV0aHJvdyB9IGZyb20gXCIuL25hdmlnYXRpb24tZXJyb3JzLmpzXCI7XG5pbXBvcnQgeyBnZXRQYWdlc05hdmlnYXRpb25Db250ZXh0IH0gZnJvbSBcIi4vaW50ZXJuYWwvcGFnZXMtcm91dGVyLWFjY2Vzc29yLmpzXCI7XG5pbXBvcnQgeyBiZWdpbkFwcFJvdXRlclNjcm9sbEludGVudCwgY2xlYXJBcHBSb3V0ZXJTY3JvbGxJbnRlbnQsIGNvbnN1bWVBcHBSb3V0ZXJTY3JvbGxJbnRlbnQsIGdldFBlbmRpbmdBcHBSb3V0ZXJTY3JvbGxJbnRlbnQsIGlzTGF0ZXN0QXBwUm91dGVyU2Nyb2xsSW50ZW50IH0gZnJvbSBcIi4vYXBwLXJvdXRlci1zY3JvbGwtc3RhdGUuanNcIjtcbmltcG9ydCB7IEdMT0JBTF9BQ0NFU1NPUlNfS0VZLCBTZXJ2ZXJJbnNlcnRlZEhUTUxDb250ZXh0LCBfcmVnaXN0ZXJTdGF0ZUFjY2Vzc29ycywgY2xlYXJDbGllbnRIeWRyYXRpb25Db250ZXh0LCBjbGVhclNlcnZlckluc2VydGVkSFRNTCwgZmx1c2hTZXJ2ZXJJbnNlcnRlZEhUTUwsIGdldEJmY2FjaGVJZE1hcENvbnRleHQsIGdldEJmY2FjaGVTZWdtZW50SWRDb250ZXh0LCBnZXRMYXlvdXRTZWdtZW50Q29udGV4dCwgZ2V0TmF2aWdhdGlvbkNvbnRleHQsIHJlZ2lzdGVyU2VydmVySW5zZXJ0ZWRIVE1MQ2FsbGJhY2ssIHJlbmRlclNlcnZlckluc2VydGVkSFRNTCwgc2V0TmF2aWdhdGlvbkNvbnRleHQgfSBmcm9tIFwiLi9uYXZpZ2F0aW9uLWNvbnRleHQtc3RhdGUuanNcIjtcbmltcG9ydCB7IGNhbmNlbEFwcFByZWZldGNoRmV0Y2gsIHByb21vdGVBcHBQcmVmZXRjaEZldGNoLCByZWxlYXNlQXBwUHJlZmV0Y2hGZXRjaFNsb3QsIHNjaGVkdWxlQXBwUHJlZmV0Y2hGZXRjaCB9IGZyb20gXCIuL2ludGVybmFsL2FwcC1wcmVmZXRjaC1mZXRjaC1xdWV1ZS5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbi8vI3JlZ2lvbiBzcmMvc2hpbXMvbmF2aWdhdGlvbi50c1xuLyoqXG4qIG5leHQvbmF2aWdhdGlvbiBzaGltXG4qXG4qIEFwcCBSb3V0ZXIgbmF2aWdhdGlvbiBob29rcy4gVGhlc2Ugd29yayBvbiBib3RoIHNlcnZlciAoUlNDKSBhbmQgY2xpZW50LlxuKiBTZXJ2ZXItc2lkZTogcmVhZHMgZnJvbSBhIHJlcXVlc3QgY29udGV4dCBzZXQgYnkgdGhlIFJTQyBoYW5kbGVyLlxuKiBDbGllbnQtc2lkZTogcmVhZHMgZnJvbSBicm93c2VyIExvY2F0aW9uIEFQSSBhbmQgcHJvdmlkZXMgbmF2aWdhdGlvbi5cbiovXG5jb25zdCBIQVNfUEFHRVNfUk9VVEVSID0gcHJvY2Vzcy5lbnYuX19WSU5FWFRfSEFTX1BBR0VTX1JPVVRFUiAhPT0gXCJmYWxzZVwiO1xuY29uc3QgSEFTX0NMSUVOVF9SRVdSSVRFUyA9IHByb2Nlc3MuZW52Ll9fVklORVhUX0hBU19DTElFTlRfUkVXUklURVMgIT09IFwiZmFsc2VcIjtcbmxldCBoeWJyaWRDbGllbnRSb3V0ZU93bmVyTW9kdWxlID0gbnVsbDtcbmxldCBoeWJyaWRDbGllbnRSb3V0ZU93bmVyTW9kdWxlUHJvbWlzZSA9IG51bGw7XG4vKiogTG9hZCByZXdyaXRlLWF3YXJlIGh5YnJpZCByb3V0ZSBvd25lcnNoaXAgYmVmb3JlIG5hdmlnYXRpb24gYmVjb21lcyBpbnRlcmFjdGl2ZS4gKi9cbmFzeW5jIGZ1bmN0aW9uIHByZWxvYWRIeWJyaWRDbGllbnRSb3V0ZU93bmVyKCkge1xuXHRpZiAoaHlicmlkQ2xpZW50Um91dGVPd25lck1vZHVsZSkgcmV0dXJuO1xuXHRoeWJyaWRDbGllbnRSb3V0ZU93bmVyTW9kdWxlUHJvbWlzZSA/Pz0gaW1wb3J0KFwiLi9pbnRlcm5hbC9oeWJyaWQtY2xpZW50LXJvdXRlLW93bmVyLmpzXCIpO1xuXHRoeWJyaWRDbGllbnRSb3V0ZU93bmVyTW9kdWxlID0gYXdhaXQgaHlicmlkQ2xpZW50Um91dGVPd25lck1vZHVsZVByb21pc2U7XG59XG5mdW5jdGlvbiByZXNvbHZlTG9hZGVkSHlicmlkQ2xpZW50UmV3cml0ZUhyZWYoaHJlZiwgYmFzZVBhdGgpIHtcblx0cmV0dXJuIGh5YnJpZENsaWVudFJvdXRlT3duZXJNb2R1bGU/LnJlc29sdmVIeWJyaWRDbGllbnRSZXdyaXRlSHJlZihocmVmLCBiYXNlUGF0aCkgPz8gbnVsbDtcbn1cbmZ1bmN0aW9uIHJlc29sdmVIeWJyaWRDbGllbnRSb3V0ZU93bmVyKGhyZWYpIHtcblx0aWYgKCFIQVNfUEFHRVNfUk9VVEVSKSByZXR1cm4gbnVsbDtcblx0cmV0dXJuIGh5YnJpZENsaWVudFJvdXRlT3duZXJNb2R1bGUgPyBoeWJyaWRDbGllbnRSb3V0ZU93bmVyTW9kdWxlLnJlc29sdmVIeWJyaWRDbGllbnRSb3V0ZU93bmVyKGhyZWYsIF9fYmFzZVBhdGgpIDogcmVzb2x2ZURpcmVjdEh5YnJpZENsaWVudFJvdXRlT3duZXIoaHJlZiwgX19iYXNlUGF0aCk7XG59XG4vKipcbiogUmVhZCB0aGUgY2hpbGQgc2VnbWVudHMgZm9yIGEgcGFyYWxsZWwgcm91dGUgYmVsb3cgdGhlIGN1cnJlbnQgbGF5b3V0LlxuKiBSZXR1cm5zIFtdIGlmIG5vIGNvbnRleHQgaXMgYXZhaWxhYmxlIChSU0MgZW52aXJvbm1lbnQsIG91dHNpZGUgUmVhY3QgdHJlZSlcbiogb3IgaWYgdGhlIHJlcXVlc3RlZCBrZXkgaXMgbm90IHByZXNlbnQgaW4gdGhlIHNlZ21lbnQgbWFwLlxuKi9cbmZ1bmN0aW9uIHVzZUNoaWxkU2VnbWVudHMocGFyYWxsZWxSb3V0ZXNLZXkgPSBcImNoaWxkcmVuXCIpIHtcblx0Y29uc3QgY3R4ID0gZ2V0TGF5b3V0U2VnbWVudENvbnRleHQoKTtcblx0aWYgKCFjdHgpIHJldHVybiBbXTtcblx0dHJ5IHtcblx0XHRyZXR1cm4gKFJlYWN0JDEudXNlQ29udGV4dChjdHgpW3BhcmFsbGVsUm91dGVzS2V5XSA/PyBbXSkuZmlsdGVyKChzZWdtZW50KSA9PiAhc2VnbWVudC5zdGFydHNXaXRoKFwiX19QQUdFX19cIikpO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm4gW107XG5cdH1cbn1cbmNvbnN0IF9SRUFET05MWV9TRUFSQ0hfUEFSQU1TID0gU3ltYm9sLmZvcihcInZpbmV4dC5uYXZpZ2F0aW9uLnJlYWRvbmx5U2VhcmNoUGFyYW1zXCIpO1xuY29uc3QgX1JFQURPTkxZX1NFQVJDSF9QQVJBTVNfU09VUkNFID0gU3ltYm9sLmZvcihcInZpbmV4dC5uYXZpZ2F0aW9uLnJlYWRvbmx5U2VhcmNoUGFyYW1zU291cmNlXCIpO1xuY29uc3QgX1JFQURPTkxZX1NFQVJDSF9QQVJBTVNfU09VUkNFX0tFWSA9IFN5bWJvbC5mb3IoXCJ2aW5leHQubmF2aWdhdGlvbi5yZWFkb25seVNlYXJjaFBhcmFtc1NvdXJjZUtleVwiKTtcbmNvbnN0IFBBR0VTX05BVklHQVRJT05fTk9USUZZX0tFWSA9IFN5bWJvbC5mb3IoXCJ2aW5leHQubmF2aWdhdGlvbi5wYWdlc05hdmlnYXRpb25Ob3RpZnlcIik7XG5jb25zdCBpc1NlcnZlciA9IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCI7XG4vKiogYmFzZVBhdGggZnJvbSBuZXh0LmNvbmZpZy5qcywgaW5qZWN0ZWQgYnkgdGhlIHBsdWdpbiBhdCBidWlsZCB0aW1lICovXG5jb25zdCBfX2Jhc2VQYXRoID0gcHJvY2Vzcy5lbnYuX19ORVhUX1JPVVRFUl9CQVNFUEFUSCA/PyBcIlwiO1xuLyoqIHRyYWlsaW5nU2xhc2ggZnJvbSBuZXh0LmNvbmZpZy5qcywgaW5qZWN0ZWQgYnkgdGhlIHBsdWdpbiBhdCBidWlsZCB0aW1lICovXG5jb25zdCBfX3RyYWlsaW5nU2xhc2ggPSBwcm9jZXNzLmVudi5fX1ZJTkVYVF9UUkFJTElOR19TTEFTSCA9PT0gXCJ0cnVlXCI7XG4vKiogcHJlZmV0Y2ggaW5saW5pbmcgKFNlZ21lbnQgQ2FjaGUgd2lyZSBtb2RlKSwgaW5qZWN0ZWQgYnkgdGhlIHBsdWdpbiBhdCBidWlsZCB0aW1lICovXG5jb25zdCBfX3ByZWZldGNoSW5saW5pbmcgPSBwcm9jZXNzLmVudi5fX1ZJTkVYVF9QUkVGRVRDSF9JTkxJTklORyA9PT0gXCJ0cnVlXCI7XG4vKiogTWF4aW11bSBidWZmZXJlZCBieXRlcyBpbiB0aGUgUlNDIHByZWZldGNoIGNhY2hlLiBNaXJyb3JzIE5leHQuanMnIDUwIE1CIExSVS4gKi9cbmNvbnN0IE1BWF9QUkVGRVRDSF9DQUNIRV9TSVpFID0gNTI0Mjg4MDA7XG5jb25zdCBQUkVGRVRDSF9DQUNIRV9FVklDVElPTl9UQVJHRVRfU0laRSA9IE1BWF9QUkVGRVRDSF9DQUNIRV9TSVpFICogLjk7XG4vKipcbiogVFRMIGZvciBwcmVmZXRjaCBjYWNoZSBlbnRyaWVzIGluIG1zLlxuKlxuKiBNaXJyb3JzIE5leHQuanMnIGBTVEFUSUNfU1RBTEVUSU1FX01TYCBkZXJpdmF0aW9uLiBUaGUgcGx1Z2luIGluamVjdHNcbiogYHByb2Nlc3MuZW52Ll9fTkVYVF9DTElFTlRfUk9VVEVSX1NUQVRJQ19TVEFMRVRJTUVgIGZyb21cbiogYGV4cGVyaW1lbnRhbC5zdGFsZVRpbWVzLnN0YXRpY2AgKGluIHNlY29uZHMpIGF0IGJ1aWxkIHRpbWU7IHdlIGNvbnZlcnRcbiogdG8gbXMgaGVyZS5cbipcbiogRmFsbHMgYmFjayB0byB2aW5leHQncyBoaXN0b3JpY2FsIGRlZmF1bHQgb2YgMzBzIHdoZW4gdGhlIGVudiB2YXIgaXNcbiogYWJzZW50IChlLmcuIHVuaXQgdGVzdHMgdGhhdCBpbXBvcnQgdGhpcyBtb2R1bGUgd2l0aG91dCBnb2luZyB0aHJvdWdoXG4qIHRoZSBwbHVnaW4ncyBgZGVmaW5lYCBwaXBlbGluZSkuIFdoZW4gdGhlIHBsdWdpbiBpcyBhY3RpdmUgYW5kIHRoZSB1c2VyXG4qIGhhcyBub3Qgc2V0IGBleHBlcmltZW50YWwuc3RhbGVUaW1lc2AsIE5leHQuanMnIDMwMHMgZGVmYXVsdCBhcHBsaWVzXG4qIChzZWUgYHJlc29sdmVTdGFsZVRpbWVzYCBpbiBgY29uZmlnL25leHQtY29uZmlnLnRzYCkuXG4qL1xuZnVuY3Rpb24gcmVzb2x2ZUNsaWVudFJvdXRlclN0YWxlVGltZShyYXcsIGZhbGxiYWNrTXMpIHtcblx0aWYgKHJhdyA9PT0gdm9pZCAwIHx8IHJhdyA9PT0gXCJcIikgcmV0dXJuIGZhbGxiYWNrTXM7XG5cdGNvbnN0IHNlY29uZHMgPSBOdW1iZXIocmF3KTtcblx0aWYgKCFOdW1iZXIuaXNGaW5pdGUoc2Vjb25kcykgfHwgc2Vjb25kcyA8IDApIHJldHVybiBmYWxsYmFja01zO1xuXHRyZXR1cm4gc2Vjb25kcyAqIDFlMztcbn1cbmNvbnN0IERZTkFNSUNfTkFWSUdBVElPTl9DQUNIRV9UVEwgPSByZXNvbHZlQ2xpZW50Um91dGVyU3RhbGVUaW1lKHByb2Nlc3MuZW52Ll9fTkVYVF9DTElFTlRfUk9VVEVSX0RZTkFNSUNfU1RBTEVUSU1FLCAzZTQpO1xuY29uc3QgUFJFRkVUQ0hfQ0FDSEVfVFRMID0gcmVzb2x2ZUNsaWVudFJvdXRlclN0YWxlVGltZShwcm9jZXNzLmVudi5fX05FWFRfQ0xJRU5UX1JPVVRFUl9TVEFUSUNfU1RBTEVUSU1FLCAzZTQpO1xuLyoqXG4qIEZsb29yIGZvciBhbnkgc2VydmVyLWRlY2xhcmVkIGBjYWNoZUxpZmVgIHN0YWxlIHRpbWUsIG1pcnJvcmluZyBOZXh0LmpzJ3NcbiogYGdldFN0YWxlVGltZU1zYCAoYE1hdGgubWF4KHN0YWxlVGltZVNlY29uZHMsIDMwKSAqIDEwMDBgKS4gT25lIHJ1bGUgZm9yXG4qIGJvdGggY2xpZW50IGNhY2hlcywgc28gYmVoYXZpb3IgZG9lcyBub3QgZGVwZW5kIG9uIHdoaWNoIGNhY2hlIGEgcm91dGUgaGl0LlxuKi9cbmNvbnN0IE1JTl9TRVJWRVJfU1RBTEVfVElNRV9TRUNPTkRTID0gMzA7XG5jb25zdCBNSU5fUFJFRkVUQ0hfU1RBTEVfVElNRV9NUyA9IE1JTl9TRVJWRVJfU1RBTEVfVElNRV9TRUNPTkRTICogMWUzO1xuZnVuY3Rpb24gZ2V0Q3VycmVudEludGVyY2VwdGlvbkNvbnRleHQoKSB7XG5cdGlmIChpc1NlcnZlcikgcmV0dXJuIG51bGw7XG5cdHJldHVybiBzdHJpcEJhc2VQYXRoKHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSwgX19iYXNlUGF0aCk7XG59XG5mdW5jdGlvbiBnZXRQcmVmZXRjaEludGVyY2VwdGlvbkNvbnRleHQodGFyZ2V0SHJlZiwgY3VycmVudFBhdGhuYW1lKSB7XG5cdGlmIChpc1NlcnZlcikgcmV0dXJuIG51bGw7XG5cdGxldCB0YXJnZXRVcmw7XG5cdHRyeSB7XG5cdFx0dGFyZ2V0VXJsID0gbmV3IFVSTCh0YXJnZXRIcmVmLCB3aW5kb3cubG9jYXRpb24uaHJlZik7XG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdHJldHVybiByZXNvbHZlTWFuaWZlc3ROYXZpZ2F0aW9uSW50ZXJjZXB0aW9uQ29udGV4dCh7XG5cdFx0YmFzZVBhdGg6IF9fYmFzZVBhdGgsXG5cdFx0Y3VycmVudFBhdGhuYW1lOiBjdXJyZW50UGF0aG5hbWUgPz8gd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLFxuXHRcdHJvdXRlTWFuaWZlc3Q6IGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmJvb3RzdHJhcC5yb3V0ZU1hbmlmZXN0ID8/IG51bGwsXG5cdFx0dGFyZ2V0UGF0aG5hbWU6IHRhcmdldFVybC5wYXRobmFtZVxuXHR9KTtcbn1cbmZ1bmN0aW9uIGdldEN1cnJlbnROZXh0VXJsKCkge1xuXHRpZiAoaXNTZXJ2ZXIpIHJldHVybiBcIi9cIjtcblx0cmV0dXJuIHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSArIHdpbmRvdy5sb2NhdGlvbi5zZWFyY2g7XG59XG5mdW5jdGlvbiBjcmVhdGVBcHBQcmVmZXRjaFJlcXVlc3RIZWFkZXJzKG9wdGlvbnMpIHtcblx0Y29uc3QgcHJlZmV0Y2hSb3V0ZXJTdGF0ZSA9IGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5nZXRQcmVmZXRjaFJvdXRlclN0YXRlPy4oKSA/PyBudWxsO1xuXHRyZXR1cm4gY3JlYXRlUnNjUmVxdWVzdEhlYWRlcnMoe1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0bmV4dFVybDogZ2V0Q3VycmVudE5leHRVcmwoKSxcblx0XHRpbmNsdWRlUHJlZmV0Y2hIZWFkZXI6IG9wdGlvbnMucHJlZmV0Y2hLaW5kICE9PSBcImZ1bGxcIixcblx0XHRwcmVmZXRjaFJvdXRlclN0YXRlXG5cdH0pO1xufVxuLyoqIEdldCBvciBjcmVhdGUgdGhlIHNoYXJlZCBpbi1tZW1vcnkgUlNDIHByZWZldGNoIGNhY2hlIG9uIHdpbmRvdy4gKi9cbmZ1bmN0aW9uIGdldFByZWZldGNoQ2FjaGUoKSB7XG5cdGlmIChpc1NlcnZlcikgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGlmICghd2luZG93Ll9fVklORVhUX1JTQ19QUkVGRVRDSF9DQUNIRV9fKSB3aW5kb3cuX19WSU5FWFRfUlNDX1BSRUZFVENIX0NBQ0hFX18gPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRyZXR1cm4gd2luZG93Ll9fVklORVhUX1JTQ19QUkVGRVRDSF9DQUNIRV9fO1xufVxuLyoqXG4qIFJlYWQgYW4gZXhhY3QgcHJlZmV0Y2ggZW50cnkgd2l0aG91dCBhbGxvd2luZyBhIHNldHRsZWQgc3RhbGUgdmFsdWUgdG9cbiogc3RlZXIgYSBsYXRlciByZXF1ZXN0LiBUaW1lcnMgYXJlIGFuIGV2aWN0aW9uIG9wdGltaXphdGlvbiwgbm90IGEgZnJlc2huZXNzXG4qIGd1YXJhbnRlZTogYmFja2dyb3VuZCB0aHJvdHRsaW5nIGNhbiBsZWF2ZSBhbiBleHBpcmVkIHJvdXRlLXRyZWUgZW50cnkgaW5cbiogdGhlIE1hcCB1bnRpbCB0aGUgbmV4dCBmb3JlZ3JvdW5kIHJlYWQuXG4qL1xuZnVuY3Rpb24gZ2V0RnJlc2hQcmVmZXRjaENhY2hlRW50cnkoY2FjaGVLZXkpIHtcblx0Y29uc3QgY2FjaGUgPSBnZXRQcmVmZXRjaENhY2hlKCk7XG5cdGNvbnN0IGVudHJ5ID0gY2FjaGUuZ2V0KGNhY2hlS2V5KTtcblx0aWYgKGVudHJ5ID09PSB2b2lkIDAgfHwgZW50cnkucGVuZGluZykgcmV0dXJuIGVudHJ5O1xuXHRpZiAocmVzb2x2ZVByZWZldGNoQ2FjaGVFbnRyeUV4cGlyZXNBdChlbnRyeSkgPiBEYXRlLm5vdygpKSByZXR1cm4gZW50cnk7XG5cdGRlbGV0ZVByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgZ2V0UHJlZmV0Y2hlZFVybHMoKSwgY2FjaGVLZXksIGVudHJ5LCB0cnVlKTtcbn1cbi8qKlxuKiBHZXQgb3IgY3JlYXRlIHRoZSBzaGFyZWQgc2V0IG9mIGFscmVhZHktcHJlZmV0Y2hlZCBSU0MgVVJMcyBvbiB3aW5kb3cuXG4qIEtleWVkIGJ5IGludGVyY2VwdGlvbi1hd2FyZSBjYWNoZSBrZXkgc28gZGlzdGluY3Qgc291cmNlIHJvdXRlcyBkbyBub3QgYWxpYXMuXG4qL1xuZnVuY3Rpb24gZ2V0UHJlZmV0Y2hlZFVybHMoKSB7XG5cdGlmIChpc1NlcnZlcikgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGlmICghd2luZG93Ll9fVklORVhUX1JTQ19QUkVGRVRDSEVEX1VSTFNfXykgd2luZG93Ll9fVklORVhUX1JTQ19QUkVGRVRDSEVEX1VSTFNfXyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdHJldHVybiB3aW5kb3cuX19WSU5FWFRfUlNDX1BSRUZFVENIRURfVVJMU19fO1xufVxuZnVuY3Rpb24gaXNTdGFsZVRpbWVTZWNvbmRzKHZhbHVlKSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgJiYgTnVtYmVyLmlzRmluaXRlKHZhbHVlKSAmJiBOdW1iZXIuaXNJbnRlZ2VyKHZhbHVlKSAmJiB2YWx1ZSA+PSAwO1xufVxuZnVuY3Rpb24gaXNDYWNoZUV4cGlyZXNBdCh2YWx1ZSkge1xuXHRyZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiICYmIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgJiYgdmFsdWUgPj0gMDtcbn1cbmZ1bmN0aW9uIHBhcnNlU3RhbGVUaW1lU2Vjb25kc0hlYWRlcih2YWx1ZSkge1xuXHRpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IFwiXCIpIHJldHVybiB2b2lkIDA7XG5cdGNvbnN0IHNlY29uZHMgPSBOdW1iZXIodmFsdWUpO1xuXHRyZXR1cm4gaXNTdGFsZVRpbWVTZWNvbmRzKHNlY29uZHMpID8gc2Vjb25kcyA6IHZvaWQgMDtcbn1cbi8qKlxuKiBUaGUgZmxvb3IgYSBgY2FjaGVMaWZlYCBjbGFpbSBsaWNlbnNlcy4gQSBwZW5kaW5nIGNsYWltIGNvbnRyaWJ1dGVzIGV4YWN0bHlcbiogdGhlIGZsb29yIOKAlCB0aGUgbGVhc3QgYW55IHJlc29sdXRpb24gb2YgaXQgY291bGQgaGF2ZSBncmFudGVkLlxuKi9cbmZ1bmN0aW9uIHNlcnZlclN0YWxlVGltZVNlY29uZHMoc2VydmVyKSB7XG5cdGlmIChzZXJ2ZXIgPT09IHZvaWQgMCkgcmV0dXJuIHZvaWQgMDtcblx0aWYgKHNlcnZlci5raW5kID09PSBcInBlbmRpbmdcIikgcmV0dXJuIE1JTl9TRVJWRVJfU1RBTEVfVElNRV9TRUNPTkRTO1xuXHRyZXR1cm4gTWF0aC5tYXgoc2VydmVyLnNlY29uZHMsIE1JTl9TRVJWRVJfU1RBTEVfVElNRV9TRUNPTkRTKTtcbn1cbi8qKlxuKiBNaW4tY29tYmluZSB0aGUgdHdvIGluZGVwZW5kZW50IHN0YWxlbmVzcyBsYXR0aWNlcyBhIHJlc3BvbnNlIGNhbiBjYXJyeTpcbiogYGR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzYCAoZnJvbSBgZXhwZXJpbWVudGFsLnN0YWxlVGltZXNgIGNvbmZpZykgYW5kXG4qIGBzZXJ2ZXJTdGFsZVRpbWVgIChmcm9tIHRoZSByZW5kZXIncyBgY2FjaGVMaWZlYCkg4oCUIG5laXRoZXIgbWF5IG92ZXJyaWRlXG4qIHRoZSBvdGhlci4gVGhlIGNhY2hlTGlmZSB2YWx1ZSBpcyBmbG9vcmVkICpiZWZvcmUqIHRoZSBtaW4gc28gdGhlIGZsb29yXG4qIG5ldmVyIHJhaXNlcyB0aGUgY29uZmlnIGJvdW5kLiBVbmRlZmluZWQgPSBubyBzaWduYWw7IHRoZSBjYWxsZXInc1xuKiBmYWxsYmFjayBUVEwgc3RheXMgaW4gZm9yY2UuXG4qL1xuZnVuY3Rpb24gcmVzb2x2ZVJzY1Jlc3BvbnNlU3RhbGVUaW1lU2Vjb25kcyhjYWNoZWQpIHtcblx0Y29uc3QgZHluYW1pYyA9IGNhY2hlZC5keW5hbWljU3RhbGVUaW1lU2Vjb25kcztcblx0Y29uc3Qgc2VydmVyID0gc2VydmVyU3RhbGVUaW1lU2Vjb25kcyhjYWNoZWQuc2VydmVyU3RhbGVUaW1lKTtcblx0aWYgKCFpc1N0YWxlVGltZVNlY29uZHMoZHluYW1pYykpIHJldHVybiBzZXJ2ZXI7XG5cdHJldHVybiBzZXJ2ZXIgPT09IHZvaWQgMCA/IGR5bmFtaWMgOiBNYXRoLm1pbihkeW5hbWljLCBzZXJ2ZXIpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUNhY2hlZFJzY1Jlc3BvbnNlVHRsTXMoY2FjaGVkLCBmYWxsYmFja1R0bE1zKSB7XG5cdGNvbnN0IHNlY29uZHMgPSByZXNvbHZlUnNjUmVzcG9uc2VTdGFsZVRpbWVTZWNvbmRzKGNhY2hlZCk7XG5cdGlmIChzZWNvbmRzID09PSB2b2lkIDApIHJldHVybiBmYWxsYmFja1R0bE1zO1xuXHRyZXR1cm4gc2Vjb25kcyAqIDFlMztcbn1cbmZ1bmN0aW9uIHJlc29sdmVDYWNoZWRSc2NSZXNwb25zZUV4cGlyZXNBdCh0aW1lc3RhbXAsIGNhY2hlZCwgZmFsbGJhY2tUdGxNcykge1xuXHRpZiAoaXNDYWNoZUV4cGlyZXNBdChjYWNoZWQuZXhwaXJlc0F0KSkgcmV0dXJuIGNhY2hlZC5leHBpcmVzQXQ7XG5cdHJldHVybiB0aW1lc3RhbXAgKyByZXNvbHZlQ2FjaGVkUnNjUmVzcG9uc2VUdGxNcyhjYWNoZWQsIGZhbGxiYWNrVHRsTXMpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVByZWZldGNoZWRSc2NSZXNwb25zZUV4cGlyZXNBdCh0aW1lc3RhbXAsIGNhY2hlZCwgZmFsbGJhY2tUdGxNcywgZHluYW1pY1N0YWxlVGltZSkge1xuXHRpZiAoaXNDYWNoZUV4cGlyZXNBdChjYWNoZWQuZXhwaXJlc0F0KSkgcmV0dXJuIGNhY2hlZC5leHBpcmVzQXQ7XG5cdGNvbnN0IHNlcnZlclNlY29uZHMgPSBjYWNoZWQuc2VydmVyU3RhbGVUaW1lPy5raW5kID09PSBcInBlbmRpbmdcIiAmJiBkeW5hbWljU3RhbGVUaW1lICE9PSBcInZlcmJhdGltXCIgPyB2b2lkIDAgOiBzZXJ2ZXJTdGFsZVRpbWVTZWNvbmRzKGNhY2hlZC5zZXJ2ZXJTdGFsZVRpbWUpO1xuXHRpZiAoc2VydmVyU2Vjb25kcyAhPT0gdm9pZCAwKSByZXR1cm4gdGltZXN0YW1wICsgc2VydmVyU2Vjb25kcyAqIDFlMztcblx0aWYgKGR5bmFtaWNTdGFsZVRpbWUgPT09IFwiaWdub3JlXCIpIHJldHVybiB0aW1lc3RhbXAgKyBNYXRoLm1heChmYWxsYmFja1R0bE1zLCBNSU5fUFJFRkVUQ0hfU1RBTEVfVElNRV9NUyk7XG5cdGNvbnN0IHNlY29uZHMgPSBpc1N0YWxlVGltZVNlY29uZHMoY2FjaGVkLmR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzKSA/IGNhY2hlZC5keW5hbWljU3RhbGVUaW1lU2Vjb25kcyA6IHZvaWQgMDtcblx0aWYgKHNlY29uZHMgPT09IHZvaWQgMCkgcmV0dXJuIHRpbWVzdGFtcCArIE1hdGgubWF4KGZhbGxiYWNrVHRsTXMsIE1JTl9QUkVGRVRDSF9TVEFMRV9USU1FX01TKTtcblx0cmV0dXJuIGR5bmFtaWNTdGFsZVRpbWUgPT09IFwidmVyYmF0aW1cIiA/IHRpbWVzdGFtcCArIHNlY29uZHMgKiAxZTMgOiB0aW1lc3RhbXAgKyAoc2Vjb25kcyA9PT0gMCA/IE1hdGgubWF4KGZhbGxiYWNrVHRsTXMsIE1JTl9QUkVGRVRDSF9TVEFMRV9USU1FX01TKSA6IE1hdGgubWF4KHNlY29uZHMgKiAxZTMsIE1JTl9QUkVGRVRDSF9TVEFMRV9USU1FX01TKSk7XG59XG5mdW5jdGlvbiByZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5RXhwaXJlc0F0KGVudHJ5KSB7XG5cdGlmIChlbnRyeS5leHBpcmVzQXQgIT09IHZvaWQgMCkgcmV0dXJuIGVudHJ5LmV4cGlyZXNBdDtcblx0aWYgKGVudHJ5LnNuYXBzaG90KSByZXR1cm4gcmVzb2x2ZUNhY2hlZFJzY1Jlc3BvbnNlRXhwaXJlc0F0KGVudHJ5LnRpbWVzdGFtcCwgZW50cnkuc25hcHNob3QsIFBSRUZFVENIX0NBQ0hFX1RUTCk7XG5cdHJldHVybiBlbnRyeS50aW1lc3RhbXAgKyBQUkVGRVRDSF9DQUNIRV9UVEw7XG59XG5mdW5jdGlvbiByZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5TW91bnRlZFNsb3RzSGVhZGVyKGVudHJ5KSB7XG5cdGlmIChlbnRyeS5tb3VudGVkU2xvdHNIZWFkZXIgIT09IHZvaWQgMCkgcmV0dXJuIGVudHJ5Lm1vdW50ZWRTbG90c0hlYWRlcjtcblx0cmV0dXJuIGVudHJ5LnNuYXBzaG90Py5tb3VudGVkU2xvdHNIZWFkZXIgPz8gbnVsbDtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJzY0NhY2hlTG9va3VwVXJsKHJzY1VybCkge1xuXHR0cnkge1xuXHRcdGNvbnN0IHVybCA9IHBhcnNlUnNjUmVxdWVzdFBhdGgocnNjVXJsKTtcblx0XHRzdHJpcFJzY0NhY2hlQnVzdGluZ1NlYXJjaFBhcmFtKHVybCk7XG5cdFx0cmV0dXJuIGAke3VybC5wYXRobmFtZX0ke3VybC5zZWFyY2h9YDtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJzY0NhY2hlTG9va3VwUGF0aG5hbWUocnNjVXJsKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHBhcnNlUnNjUmVxdWVzdFBhdGgocnNjVXJsKS5wYXRobmFtZTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cbn1cbmZ1bmN0aW9uIHBhcnNlUHJlZmV0Y2hDYWNoZUtleShjYWNoZUtleSkge1xuXHRjb25zdCBzZXBhcmF0b3JJbmRleCA9IGNhY2hlS2V5LmluZGV4T2YoXCJcXDBcIik7XG5cdGlmIChzZXBhcmF0b3JJbmRleCA9PT0gLTEpIHJldHVybiB7XG5cdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogbnVsbCxcblx0XHRyc2NVcmw6IGNhY2hlS2V5XG5cdH07XG5cdHJldHVybiB7XG5cdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogY2FjaGVLZXkuc2xpY2Uoc2VwYXJhdG9ySW5kZXggKyAxKSxcblx0XHRyc2NVcmw6IGNhY2hlS2V5LnNsaWNlKDAsIHNlcGFyYXRvckluZGV4KVxuXHR9O1xufVxuZnVuY3Rpb24gaXNQcmVmZXRjaENhY2hlRW50cnlDb21wYXRpYmxlV2l0aE1vdW50ZWRTbG90cyhlbnRyeSwgbW91bnRlZFNsb3RzSGVhZGVyKSB7XG5cdGlmIChyZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5TW91bnRlZFNsb3RzSGVhZGVyKGVudHJ5KSA9PT0gbW91bnRlZFNsb3RzSGVhZGVyKSByZXR1cm4gdHJ1ZTtcblx0cmV0dXJuIChlbnRyeS5zbmFwc2hvdD8ubW91bnRlZFNsb3RzSGVhZGVyID8/IG51bGwpID09PSBtb3VudGVkU2xvdHNIZWFkZXI7XG59XG5mdW5jdGlvbiBmaW5kUHJlZmV0Y2hDYWNoZUVudHJ5Rm9yTmF2aWdhdGlvbihyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQsIG1vdW50ZWRTbG90c0hlYWRlciwgYWRkaXRpb25hbFJzY1VybHMgPSBbXSkge1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0Y29uc3QgcnNjVXJscyA9IFtyc2NVcmwsIC4uLmFkZGl0aW9uYWxSc2NVcmxzXTtcblx0Zm9yIChjb25zdCBsb29rdXBSc2NVcmwgb2YgcnNjVXJscykge1xuXHRcdGNvbnN0IGV4YWN0Q2FjaGVLZXkgPSBBcHBFbGVtZW50c1dpcmUuZW5jb2RlQ2FjaGVLZXkobG9va3VwUnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0KTtcblx0XHRjb25zdCBleGFjdEVudHJ5ID0gY2FjaGUuZ2V0KGV4YWN0Q2FjaGVLZXkpO1xuXHRcdGlmIChleGFjdEVudHJ5ICYmIGV4YWN0RW50cnkuY2FjaGVGb3JOYXZpZ2F0aW9uICE9PSBmYWxzZSAmJiBpc1ByZWZldGNoQ2FjaGVFbnRyeUNvbXBhdGlibGVXaXRoTW91bnRlZFNsb3RzKGV4YWN0RW50cnksIG1vdW50ZWRTbG90c0hlYWRlcikpIHJldHVybiB7XG5cdFx0XHRjYWNoZUtleTogZXhhY3RDYWNoZUtleSxcblx0XHRcdGVudHJ5OiBleGFjdEVudHJ5XG5cdFx0fTtcblx0fVxuXHRjb25zdCBub3JtYWxpemVkVGFyZ2V0cyA9IG5ldyBTZXQocnNjVXJscy5tYXAoKGxvb2t1cFJzY1VybCkgPT4gbm9ybWFsaXplUnNjQ2FjaGVMb29rdXBVcmwobG9va3VwUnNjVXJsKSkuZmlsdGVyKChsb29rdXBSc2NVcmwpID0+IGxvb2t1cFJzY1VybCAhPT0gbnVsbCkpO1xuXHRpZiAobm9ybWFsaXplZFRhcmdldHMuc2l6ZSA9PT0gMCkgcmV0dXJuIG51bGw7XG5cdGZvciAoY29uc3QgW2NhY2hlS2V5LCBlbnRyeV0gb2YgY2FjaGUpIHtcblx0XHRpZiAoZW50cnkuY2FjaGVGb3JOYXZpZ2F0aW9uID09PSBmYWxzZSkgY29udGludWU7XG5cdFx0Y29uc3Qgc291cmNlID0gcGFyc2VQcmVmZXRjaENhY2hlS2V5KGNhY2hlS2V5KTtcblx0XHRpZiAoc291cmNlLmludGVyY2VwdGlvbkNvbnRleHQgIT09IGludGVyY2VwdGlvbkNvbnRleHQpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IG5vcm1hbGl6ZWRTb3VyY2UgPSBub3JtYWxpemVSc2NDYWNoZUxvb2t1cFVybChzb3VyY2UucnNjVXJsKTtcblx0XHRpZiAobm9ybWFsaXplZFNvdXJjZSA9PT0gbnVsbCB8fCAhbm9ybWFsaXplZFRhcmdldHMuaGFzKG5vcm1hbGl6ZWRTb3VyY2UpKSBjb250aW51ZTtcblx0XHRpZiAoIWlzUHJlZmV0Y2hDYWNoZUVudHJ5Q29tcGF0aWJsZVdpdGhNb3VudGVkU2xvdHMoZW50cnksIG1vdW50ZWRTbG90c0hlYWRlcikpIGNvbnRpbnVlO1xuXHRcdHJldHVybiB7XG5cdFx0XHRjYWNoZUtleSxcblx0XHRcdGVudHJ5XG5cdFx0fTtcblx0fVxuXHRyZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIGhhc1ByZWZldGNoQ2FjaGVFbnRyeUZvck5hdmlnYXRpb24ocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0ID0gbnVsbCwgbW91bnRlZFNsb3RzSGVhZGVyID0gbnVsbCwgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IG1hdGNoID0gZmluZFByZWZldGNoQ2FjaGVFbnRyeUZvck5hdmlnYXRpb24ocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIsIG9wdGlvbnMuYWRkaXRpb25hbFJzY1VybHMpO1xuXHRpZiAobWF0Y2ggPT09IG51bGwpIHJldHVybiBmYWxzZTtcblx0aWYgKG1hdGNoLmVudHJ5LnBlbmRpbmcgIT09IHZvaWQgMCAmJiBvcHRpb25zLnJldXNlUGVuZGluZyA9PT0gZmFsc2UpIHJldHVybiBmYWxzZTtcblx0aWYgKG1hdGNoLmVudHJ5LnBlbmRpbmcgIT09IHZvaWQgMCB8fCByZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5RXhwaXJlc0F0KG1hdGNoLmVudHJ5KSA+IERhdGUubm93KCkpIHtcblx0XHR0b3VjaFByZWZldGNoQ2FjaGVFbnRyeShnZXRQcmVmZXRjaENhY2hlKCksIG1hdGNoLmNhY2hlS2V5LCBtYXRjaC5lbnRyeSk7XG5cdFx0YXR0YWNoUHJlZmV0Y2hJbnZhbGlkYXRpb25Ub0VudHJ5KG1hdGNoLmNhY2hlS2V5LCBtYXRjaC5lbnRyeSwgb3B0aW9ucy5vbkludmFsaWRhdGUpO1xuXHRcdG9wdGlvbnMub25SZXVzZT8uKG1hdGNoLmVudHJ5LCBtYXRjaC5jYWNoZUtleSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cblx0ZGVsZXRlUHJlZmV0Y2hDYWNoZUVudHJ5KGdldFByZWZldGNoQ2FjaGUoKSwgZ2V0UHJlZmV0Y2hlZFVybHMoKSwgbWF0Y2guY2FjaGVLZXksIG1hdGNoLmVudHJ5LCBvcHRpb25zLm5vdGlmeUludmFsaWRhdGlvbiA/PyB0cnVlKTtcblx0cmV0dXJuIGZhbHNlO1xufVxuLyoqXG4qIFJldHVybiB3aGV0aGVyIHRoZSBleGFjdCBsZWFybmluZy1vbmx5IExpbmsgcHJlZmV0Y2ggaXMgc3RpbGwgdXNhYmxlLlxuKiBQZW5kaW5nIGVudHJpZXMgZGVkdXBlIGNvbmN1cnJlbnQgTGlua3M7IHNldHRsZWQgZW50cmllcyBvbmx5IHN1cHByZXNzIGFcbiogcmVtb3VudCB3aGlsZSB0aGVpciByZXNwb25zZS1kZXJpdmVkIGZyZXNobmVzcyB3aW5kb3cgcmVtYWlucyBhY3RpdmUuXG4qL1xuZnVuY3Rpb24gaGFzRnJlc2hMZWFybmluZ09ubHlQcmVmZXRjaENhY2hlRW50cnkocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0ID0gbnVsbCkge1xuXHRjb25zdCBjYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0Y29uc3QgZW50cnkgPSBjYWNoZS5nZXQoY2FjaGVLZXkpO1xuXHRpZiAoZW50cnk/LmNhY2hlRm9yTmF2aWdhdGlvbiAhPT0gZmFsc2UpIHJldHVybiBmYWxzZTtcblx0aWYgKGVudHJ5LnBlbmRpbmcgIT09IHZvaWQgMCB8fCByZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5RXhwaXJlc0F0KGVudHJ5KSA+IERhdGUubm93KCkpIHtcblx0XHR0b3VjaFByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgY2FjaGVLZXksIGVudHJ5KTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXHRkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIGdldFByZWZldGNoZWRVcmxzKCksIGNhY2hlS2V5LCBlbnRyeSwgdHJ1ZSk7XG5cdHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGhhc1NlYXJjaEFnbm9zdGljUHJlZmV0Y2hTaGVsbEZvclJvdXRlKHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCA9IG51bGwsIG1vdW50ZWRTbG90c0hlYWRlciA9IG51bGwpIHtcblx0Y29uc3Qgbm9ybWFsaXplZFRhcmdldFBhdGhuYW1lID0gbm9ybWFsaXplUnNjQ2FjaGVMb29rdXBQYXRobmFtZShyc2NVcmwpO1xuXHRpZiAobm9ybWFsaXplZFRhcmdldFBhdGhuYW1lID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdGNvbnN0IGNhY2hlID0gZ2V0UHJlZmV0Y2hDYWNoZSgpO1xuXHRmb3IgKGNvbnN0IFtjYWNoZUtleSwgZW50cnldIG9mIGNhY2hlKSB7XG5cdFx0aWYgKGVudHJ5LnNlYXJjaEFnbm9zdGljU2hlbGwgIT09IHRydWUpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IHNvdXJjZSA9IHBhcnNlUHJlZmV0Y2hDYWNoZUtleShjYWNoZUtleSk7XG5cdFx0aWYgKHNvdXJjZS5pbnRlcmNlcHRpb25Db250ZXh0ICE9PSBpbnRlcmNlcHRpb25Db250ZXh0KSBjb250aW51ZTtcblx0XHRpZiAobm9ybWFsaXplUnNjQ2FjaGVMb29rdXBQYXRobmFtZShzb3VyY2UucnNjVXJsKSAhPT0gbm9ybWFsaXplZFRhcmdldFBhdGhuYW1lKSBjb250aW51ZTtcblx0XHRpZiAoIWlzUHJlZmV0Y2hDYWNoZUVudHJ5Q29tcGF0aWJsZVdpdGhNb3VudGVkU2xvdHMoZW50cnksIG1vdW50ZWRTbG90c0hlYWRlcikpIGNvbnRpbnVlO1xuXHRcdGlmIChlbnRyeS5wZW5kaW5nICE9PSB2b2lkIDApIHJldHVybiB0cnVlO1xuXHRcdGlmIChyZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5RXhwaXJlc0F0KGVudHJ5KSA+IERhdGUubm93KCkpIHJldHVybiB0cnVlO1xuXHRcdGRlbGV0ZVByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgZ2V0UHJlZmV0Y2hlZFVybHMoKSwgY2FjaGVLZXksIGVudHJ5LCB0cnVlKTtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBnZXRQcmVmZXRjaENhY2hlRW50cnlTaXplKGVudHJ5KSB7XG5cdHJldHVybiBlbnRyeS5zbmFwc2hvdD8uYnVmZmVyLmJ5dGVMZW5ndGggPz8gZW50cnkuc2l6ZSA/PyAwO1xufVxubGV0IHRyYWNrZWRQcmVmZXRjaENhY2hlID0gbnVsbDtcbmxldCB0cmFja2VkUHJlZmV0Y2hDYWNoZUJ5dGVTaXplID0gMDtcbmZ1bmN0aW9uIGdldFByZWZldGNoQ2FjaGVCeXRlU2l6ZShjYWNoZSkge1xuXHRpZiAodHJhY2tlZFByZWZldGNoQ2FjaGUgPT09IGNhY2hlKSByZXR1cm4gdHJhY2tlZFByZWZldGNoQ2FjaGVCeXRlU2l6ZTtcblx0bGV0IHRvdGFsID0gMDtcblx0Y29uc3Qgc2VlbiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGZvciAoY29uc3QgZW50cnkgb2YgY2FjaGUudmFsdWVzKCkpIHtcblx0XHRpZiAoc2Vlbi5oYXMoZW50cnkpKSBjb250aW51ZTtcblx0XHRzZWVuLmFkZChlbnRyeSk7XG5cdFx0dG90YWwgKz0gZ2V0UHJlZmV0Y2hDYWNoZUVudHJ5U2l6ZShlbnRyeSk7XG5cdH1cblx0dHJhY2tlZFByZWZldGNoQ2FjaGUgPSBjYWNoZTtcblx0dHJhY2tlZFByZWZldGNoQ2FjaGVCeXRlU2l6ZSA9IHRvdGFsO1xuXHRyZXR1cm4gdG90YWw7XG59XG5mdW5jdGlvbiBhZGp1c3RQcmVmZXRjaENhY2hlQnl0ZVNpemUoY2FjaGUsIGRlbHRhKSB7XG5cdGlmICh0cmFja2VkUHJlZmV0Y2hDYWNoZSAhPT0gY2FjaGUpIHJldHVybjtcblx0dHJhY2tlZFByZWZldGNoQ2FjaGVCeXRlU2l6ZSA9IE1hdGgubWF4KDAsIHRyYWNrZWRQcmVmZXRjaENhY2hlQnl0ZVNpemUgKyBkZWx0YSk7XG59XG5mdW5jdGlvbiB0b3VjaFByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgY2FjaGVLZXksIGVudHJ5KSB7XG5cdGlmIChjYWNoZS5nZXQoY2FjaGVLZXkpICE9PSBlbnRyeSkgcmV0dXJuO1xuXHRjYWNoZS5kZWxldGUoY2FjaGVLZXkpO1xuXHRjYWNoZS5zZXQoY2FjaGVLZXksIGVudHJ5KTtcblx0Zm9yIChjb25zdCBrZXkgb2YgZW50cnkuY2FjaGVLZXlzID8/IFtdKSB7XG5cdFx0aWYgKGtleSA9PT0gY2FjaGVLZXkgfHwgY2FjaGUuZ2V0KGtleSkgIT09IGVudHJ5KSBjb250aW51ZTtcblx0XHRjYWNoZS5kZWxldGUoa2V5KTtcblx0XHRjYWNoZS5zZXQoa2V5LCBlbnRyeSk7XG5cdH1cbn1cbi8qKlxuKiBFdmljdCBwcmVmZXRjaCBjYWNoZSBlbnRyaWVzIGlmIGJ1ZmZlcmVkIHBheWxvYWRzIGV4Y2VlZCB0aGUgYnl0ZSBidWRnZXQuXG4qIFN3ZWVwcyBleHBpcmVkIGVudHJpZXMgb25seSBhZnRlciB0aGUgY2hlYXAgYnl0ZS1idWRnZXQgY2hlY2sgc2F5cyBjbGVhbnVwIGlzXG4qIG5lZWRlZCwgdGhlbiBldmljdHMgbGVhc3QtcmVjZW50bHktdXNlZCBlbnRyaWVzIGRvd24gdG8gdGhlIHRhcmdldCBzaXplLlxuKi9cbmZ1bmN0aW9uIGV2aWN0UHJlZmV0Y2hDYWNoZUlmTmVlZGVkKCkge1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0bGV0IHRvdGFsU2l6ZSA9IGdldFByZWZldGNoQ2FjaGVCeXRlU2l6ZShjYWNoZSk7XG5cdGlmICh0b3RhbFNpemUgPD0gNTI0Mjg4MDApIHJldHVybjtcblx0Y29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcblx0Y29uc3QgcHJlZmV0Y2hlZCA9IGdldFByZWZldGNoZWRVcmxzKCk7XG5cdGZvciAoY29uc3QgW2tleSwgZW50cnldIG9mIGNhY2hlKSBpZiAocmVzb2x2ZVByZWZldGNoQ2FjaGVFbnRyeUV4cGlyZXNBdChlbnRyeSkgPD0gbm93KSBkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIHByZWZldGNoZWQsIGtleSwgZW50cnksIHRydWUpO1xuXHR0b3RhbFNpemUgPSBnZXRQcmVmZXRjaENhY2hlQnl0ZVNpemUoY2FjaGUpO1xuXHRpZiAodG90YWxTaXplIDw9IDUyNDI4ODAwKSByZXR1cm47XG5cdGxldCBpbnNwZWN0ZWRFbnRyaWVzID0gMDtcblx0d2hpbGUgKHRvdGFsU2l6ZSA+IFBSRUZFVENIX0NBQ0hFX0VWSUNUSU9OX1RBUkdFVF9TSVpFICYmIGluc3BlY3RlZEVudHJpZXMgPCBjYWNoZS5zaXplKSB7XG5cdFx0Y29uc3Qgb2xkZXN0ID0gY2FjaGUua2V5cygpLm5leHQoKS52YWx1ZTtcblx0XHRpZiAob2xkZXN0ICE9PSB2b2lkIDApIHtcblx0XHRcdGNvbnN0IGVudHJ5ID0gY2FjaGUuZ2V0KG9sZGVzdCk7XG5cdFx0XHRpZiAoZW50cnkpIHtcblx0XHRcdFx0Y29uc3QgZW50cnlTaXplID0gZ2V0UHJlZmV0Y2hDYWNoZUVudHJ5U2l6ZShlbnRyeSk7XG5cdFx0XHRcdGlmIChlbnRyeS5wZW5kaW5nICE9PSB2b2lkIDAgJiYgZW50cnlTaXplID09PSAwKSB7XG5cdFx0XHRcdFx0dG91Y2hQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIG9sZGVzdCwgZW50cnkpO1xuXHRcdFx0XHRcdGluc3BlY3RlZEVudHJpZXMgKz0gMTtcblx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0fVxuXHRcdFx0XHR0b3RhbFNpemUgLT0gZW50cnlTaXplO1xuXHRcdFx0XHRkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIHByZWZldGNoZWQsIG9sZGVzdCwgZW50cnksIHRydWUpO1xuXHRcdFx0XHRpbnNwZWN0ZWRFbnRyaWVzID0gMDtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGNhY2hlLmRlbGV0ZShvbGRlc3QpO1xuXHRcdFx0XHRwcmVmZXRjaGVkLmRlbGV0ZShvbGRlc3QpO1xuXHRcdFx0XHRpbnNwZWN0ZWRFbnRyaWVzICs9IDE7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIGJyZWFrO1xuXHR9XG59XG5jb25zdCBwZW5kaW5nUHJlZmV0Y2hTZXR1cHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuZnVuY3Rpb24gYmVnaW5QcmVmZXRjaFNldHVwKGRlc3RpbmF0aW9uKSB7XG5cdGNvbnN0IHNldHVwID0ge1xuXHRcdGRlc3RpbmF0aW9uLFxuXHRcdGNhbmNlbGxlZDogZmFsc2Vcblx0fTtcblx0cGVuZGluZ1ByZWZldGNoU2V0dXBzLmFkZChzZXR1cCk7XG5cdHJldHVybiBzZXR1cDtcbn1cbi8qKiBQYXNzaW5nIGBudWxsYCBjYW5jZWxzIGV2ZXJ5IHBlbmRpbmcgc2V0dXAgcmVnYXJkbGVzcyBvZiBkZXN0aW5hdGlvbi4gKi9cbmZ1bmN0aW9uIGNhbmNlbFBlbmRpbmdQcmVmZXRjaFNldHVwcyhkZXN0aW5hdGlvbikge1xuXHRmb3IgKGNvbnN0IHNldHVwIG9mIHBlbmRpbmdQcmVmZXRjaFNldHVwcykgaWYgKGRlc3RpbmF0aW9uID09PSBudWxsIHx8IHNldHVwLmRlc3RpbmF0aW9uID09PSBkZXN0aW5hdGlvbikgc2V0dXAuY2FuY2VsbGVkID0gdHJ1ZTtcbn1cbi8qKlxuKiBOb3JtYWxpemUgYSBuYXZpZ2F0aW9uIG9yIHByZWZldGNoIHRhcmdldCB0byB0aGUgYnJvd3NlciBocmVmIGJvdGggc2lkZXNcbiogY29tcGFyZSBvbi4gUmV0dXJucyBudWxsIHdoZW4gdGhlIHRhcmdldCBpcyBub3Qgc2FtZS1vcmlnaW4g4oCUIG5vIHNhbWUtb3JpZ2luXG4qIHByZWZldGNoIGNhbiBiZSBhIGR1cGxpY2F0ZSBvZiBpdCDigJQgYW5kIG9uIHRoZSBzZXJ2ZXIsIHdoZXJlXG4qIGBuYXZpZ2F0ZUNsaWVudFNpZGVgIGNhbiBzdGlsbCBiZSByZWFjaGVkIGJ1dCB0aGVyZSBpcyBub3RoaW5nIHRvIGNhbmNlbC5cbiovXG5mdW5jdGlvbiB0b0FwcFByZWZldGNoRGVzdGluYXRpb24oaHJlZikge1xuXHRpZiAoaXNTZXJ2ZXIpIHJldHVybiBudWxsO1xuXHRsZXQgbG9jYWxIcmVmID0gaHJlZjtcblx0aWYgKGlzRXh0ZXJuYWxVcmwoaHJlZikpIHtcblx0XHRjb25zdCBsb2NhbFBhdGggPSB0b1NhbWVPcmlnaW5BcHBQYXRoKGhyZWYsIF9fYmFzZVBhdGgpO1xuXHRcdGlmIChsb2NhbFBhdGggPT0gbnVsbCkgcmV0dXJuIG51bGw7XG5cdFx0bG9jYWxIcmVmID0gbG9jYWxQYXRoO1xuXHR9XG5cdGNvbnN0IGJyb3dzZXJIcmVmID0gdG9DYW5vbmljYWxCcm93c2VyTmF2aWdhdGlvbkhyZWYobG9jYWxIcmVmLCB3aW5kb3cubG9jYXRpb24uaHJlZiwgX19iYXNlUGF0aCwgX190cmFpbGluZ1NsYXNoKTtcblx0dHJ5IHtcblx0XHRyZXR1cm4gZm9ybWF0UnNjUmVxdWVzdFBhdGgobmV3IFVSTChicm93c2VySHJlZiwgd2luZG93LmxvY2F0aW9uLmhyZWYpKTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIGJyb3dzZXJIcmVmLnNwbGl0KFwiI1wiLCAxKVswXTtcblx0fVxufVxuZnVuY3Rpb24gY2xlYXJQcmVmZXRjaEludmFsaWRhdGlvbihlbnRyeSkge1xuXHRpZiAoZW50cnkuaW52YWxpZGF0aW9uVGltZXIgIT09IHZvaWQgMCkge1xuXHRcdGNsZWFyVGltZW91dChlbnRyeS5pbnZhbGlkYXRpb25UaW1lcik7XG5cdFx0ZW50cnkuaW52YWxpZGF0aW9uVGltZXIgPSB2b2lkIDA7XG5cdH1cbn1cbmZ1bmN0aW9uIHJ1bkludmFsaWRhdGlvbkNhbGxiYWNrKG9uSW52YWxpZGF0ZSkge1xuXHR0cnkge1xuXHRcdG9uSW52YWxpZGF0ZSgpO1xuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdGlmICh0eXBlb2YgcmVwb3J0RXJyb3IgPT09IFwiZnVuY3Rpb25cIikgcmVwb3J0RXJyb3IoZXJyb3IpO1xuXHRcdGVsc2UgY29uc29sZS5lcnJvcihlcnJvcik7XG5cdH1cbn1cbmZ1bmN0aW9uIG5vdGlmeVByZWZldGNoSW52YWxpZGF0ZWQoZW50cnkpIHtcblx0Y2xlYXJQcmVmZXRjaEludmFsaWRhdGlvbihlbnRyeSk7XG5cdGNvbnN0IGNhbGxiYWNrcyA9IGVudHJ5Lm9uSW52YWxpZGF0ZUNhbGxiYWNrcztcblx0ZW50cnkub25JbnZhbGlkYXRlQ2FsbGJhY2tzID0gdm9pZCAwO1xuXHRpZiAoY2FsbGJhY2tzID09PSB2b2lkIDApIHJldHVybjtcblx0Zm9yIChjb25zdCBvbkludmFsaWRhdGUgb2YgY2FsbGJhY2tzKSBydW5JbnZhbGlkYXRpb25DYWxsYmFjayhvbkludmFsaWRhdGUpO1xufVxuY29uc3QgcmV0YWluZWRQcmVmZXRjaEludmFsaWRhdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuZnVuY3Rpb24gcmV0YWluUHJlZmV0Y2hJbnZhbGlkYXRpb25BZnRlckNvbnN1bWUoZW50cnkpIHtcblx0Y29uc3QgY2FsbGJhY2tzID0gZW50cnkub25JbnZhbGlkYXRlQ2FsbGJhY2tzO1xuXHRpZiAoY2FsbGJhY2tzID09PSB2b2lkIDAgfHwgY2FsbGJhY2tzLnNpemUgPT09IDApIHJldHVybjtcblx0cmV0YWluUHJlZmV0Y2hJbnZhbGlkYXRpb24oY2FsbGJhY2tzLCByZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5RXhwaXJlc0F0KGVudHJ5KSk7XG59XG5mdW5jdGlvbiByZXRhaW5QcmVmZXRjaEludmFsaWRhdGlvbihjYWxsYmFja3MsIGV4cGlyZXNBdCwgZm9yVmlzaXRlZFJlc3BvbnNlID0gZmFsc2UpIHtcblx0Y29uc3QgZGVsYXkgPSBNYXRoLm1heCgwLCBleHBpcmVzQXQgLSBEYXRlLm5vdygpKTtcblx0Y29uc3QgcmV0YWluZWQgPSB7XG5cdFx0Y2FsbGJhY2tzLFxuXHRcdC4uLmZvclZpc2l0ZWRSZXNwb25zZSA/IHsgZm9yVmlzaXRlZFJlc3BvbnNlOiB0cnVlIH0gOiB7fSxcblx0XHR0aW1lcjogc2V0VGltZW91dCgoKSA9PiBmaXJlUmV0YWluZWRQcmVmZXRjaEludmFsaWRhdGlvbihyZXRhaW5lZCksIGRlbGF5KVxuXHR9O1xuXHRyZXRhaW5lZFByZWZldGNoSW52YWxpZGF0aW9ucy5hZGQocmV0YWluZWQpO1xufVxuZnVuY3Rpb24gZmlyZVJldGFpbmVkUHJlZmV0Y2hJbnZhbGlkYXRpb24ocmV0YWluZWQpIHtcblx0aWYgKCFyZXRhaW5lZFByZWZldGNoSW52YWxpZGF0aW9ucy5kZWxldGUocmV0YWluZWQpKSByZXR1cm47XG5cdGNsZWFyVGltZW91dChyZXRhaW5lZC50aW1lcik7XG5cdGZvciAoY29uc3Qgb25JbnZhbGlkYXRlIG9mIHJldGFpbmVkLmNhbGxiYWNrcykgcnVuSW52YWxpZGF0aW9uQ2FsbGJhY2sob25JbnZhbGlkYXRlKTtcbn1cbmZ1bmN0aW9uIGRlbGV0ZVByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgcHJlZmV0Y2hlZCwgY2FjaGVLZXksIGVudHJ5LCBub3RpZnkpIHtcblx0Y29uc3QgY2FjaGVLZXlzID0gZW50cnkuY2FjaGVLZXlzID8/IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtjYWNoZUtleV0pO1xuXHRsZXQgcmVtb3ZlZE93bmVkS2V5ID0gZmFsc2U7XG5cdGZvciAoY29uc3Qga2V5IG9mIGNhY2hlS2V5cykgaWYgKGNhY2hlLmdldChrZXkpID09PSBlbnRyeSkge1xuXHRcdGNhY2hlLmRlbGV0ZShrZXkpO1xuXHRcdHByZWZldGNoZWQuZGVsZXRlKGtleSk7XG5cdFx0cmVtb3ZlZE93bmVkS2V5ID0gdHJ1ZTtcblx0fVxuXHRpZiAoIXJlbW92ZWRPd25lZEtleSkgcmV0dXJuO1xuXHRhZGp1c3RQcmVmZXRjaENhY2hlQnl0ZVNpemUoY2FjaGUsIC1nZXRQcmVmZXRjaENhY2hlRW50cnlTaXplKGVudHJ5KSk7XG5cdGVudHJ5LmNhY2hlS2V5cyA9IHZvaWQgMDtcblx0aWYgKG5vdGlmeSkgbm90aWZ5UHJlZmV0Y2hJbnZhbGlkYXRlZChlbnRyeSk7XG5cdGVsc2Uge1xuXHRcdGNsZWFyUHJlZmV0Y2hJbnZhbGlkYXRpb24oZW50cnkpO1xuXHRcdGVudHJ5Lm9uSW52YWxpZGF0ZUNhbGxiYWNrcyA9IHZvaWQgMDtcblx0fVxufVxuZnVuY3Rpb24gZGlzY2FyZExlYXJuaW5nT25seVByZWZldGNoQ2FjaGVFbnRyeShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQgPSBudWxsLCBtb3VudGVkU2xvdHNIZWFkZXIgPSBudWxsKSB7XG5cdGNvbnN0IGNhY2hlID0gZ2V0UHJlZmV0Y2hDYWNoZSgpO1xuXHRjb25zdCBwcmVmZXRjaGVkID0gZ2V0UHJlZmV0Y2hlZFVybHMoKTtcblx0Y29uc3Qgbm9ybWFsaXplZFRhcmdldCA9IG5vcm1hbGl6ZVJzY0NhY2hlTG9va3VwVXJsKHJzY1VybCk7XG5cdGlmIChub3JtYWxpemVkVGFyZ2V0ID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdGNvbnN0IHN1cGVyc2VkZWQgPSBbXTtcblx0Zm9yIChjb25zdCBbY2FjaGVLZXksIGVudHJ5XSBvZiBjYWNoZSkge1xuXHRcdGlmIChlbnRyeS5jYWNoZUZvck5hdmlnYXRpb24gIT09IGZhbHNlIHx8IGVudHJ5LnByZWZldGNoS2luZCAhPT0gXCJuYXZpZ2F0aW9uXCIpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IHNvdXJjZSA9IHBhcnNlUHJlZmV0Y2hDYWNoZUtleShjYWNoZUtleSk7XG5cdFx0aWYgKHNvdXJjZS5pbnRlcmNlcHRpb25Db250ZXh0ICE9PSBpbnRlcmNlcHRpb25Db250ZXh0KSBjb250aW51ZTtcblx0XHRpZiAobm9ybWFsaXplUnNjQ2FjaGVMb29rdXBVcmwoc291cmNlLnJzY1VybCkgIT09IG5vcm1hbGl6ZWRUYXJnZXQpIGNvbnRpbnVlO1xuXHRcdGlmICghaXNQcmVmZXRjaENhY2hlRW50cnlDb21wYXRpYmxlV2l0aE1vdW50ZWRTbG90cyhlbnRyeSwgbW91bnRlZFNsb3RzSGVhZGVyKSkgY29udGludWU7XG5cdFx0c3VwZXJzZWRlZC5wdXNoKFtjYWNoZUtleSwgZW50cnldKTtcblx0fVxuXHRmb3IgKGNvbnN0IFtjYWNoZUtleSwgZW50cnldIG9mIHN1cGVyc2VkZWQpIHtcblx0XHRjYW5jZWxBcHBQcmVmZXRjaEZldGNoKGVudHJ5LmZldGNoUHJvbWlzZSk7XG5cdFx0ZGVsZXRlUHJlZmV0Y2hDYWNoZUVudHJ5KGNhY2hlLCBwcmVmZXRjaGVkLCBjYWNoZUtleSwgZW50cnksIHRydWUpO1xuXHR9XG5cdHJldHVybiBzdXBlcnNlZGVkLmxlbmd0aCA+IDA7XG59XG4vKipcbiogTWFrZSBhIHByZWZldGNoIHJldXNhYmxlIGJ5IGEgbmF2aWdhdGlvbiwgYXMgYW4gYHVuc3RhYmxlX2R5bmFtaWNPbkhvdmVyYFxuKiBob3ZlciBkb2VzLiBBIHBlbmRpbmcgb25lIHRoYXQgd291bGQgYmUga2VwdCBhcyBsZWFybmluZy1vbmx5IGJlY29tZXMgYSBmdWxsXG4qIHByZWZldGNoIGFuZCB0YWtlcyB0aGUgZnVsbC1wcmVmZXRjaCBsaWZldGltZS4gT25lIGFscmVhZHkga2VwdCBhc1xuKiBsZWFybmluZy1vbmx5IGJlY2F1c2UgaXRzIHBhZ2UgcmVuZGVyZWQgZHluYW1pY2FsbHkgaXMgbGVmdCBmb3IgdGhlIGZ1bGxcbiogcHJlZmV0Y2ggdG8gcmVwbGFjZTogTmV4dC5qcyByZWZldGNoZXMgaXQgd2l0aCBgRmV0Y2hTdHJhdGVneS5GdWxsYCwgc28gdGhlXG4qIHBhZ2UgcmVmbGVjdHMgdGhlIGNvb2tpZXMgYW5kIGhlYWRlcnMgYXQgaG92ZXIgdGltZS5cbiovXG5mdW5jdGlvbiBwcm9tb3RlUHJlZmV0Y2hDYWNoZUVudHJ5Rm9yTmF2aWdhdGlvbihjYWNoZUtleSwgZW50cnkpIHtcblx0aWYgKGVudHJ5LmR5bmFtaWNTdGFsZVRpbWUgIT09IFwibGVhcm5pbmctb25seVwiKSB7XG5cdFx0ZW50cnkuY2FjaGVGb3JOYXZpZ2F0aW9uID0gdHJ1ZTtcblx0XHRyZXR1cm47XG5cdH1cblx0aWYgKGVudHJ5LmNhY2hlRm9yTmF2aWdhdGlvbiA9PT0gZmFsc2UpIHJldHVybjtcblx0ZW50cnkuZHluYW1pY1N0YWxlVGltZSA9IFwiZnVsbC1wcmVmZXRjaFwiO1xuXHRpZiAoZW50cnkuc25hcHNob3QgPT09IHZvaWQgMCkgcmV0dXJuO1xuXHRlbnRyeS5leHBpcmVzQXQgPSByZXNvbHZlUHJlZmV0Y2hlZFJzY1Jlc3BvbnNlRXhwaXJlc0F0KGVudHJ5LnRpbWVzdGFtcCwgZW50cnkuc25hcHNob3QsIGVudHJ5LmZhbGxiYWNrVHRsTXMgPz8gUFJFRkVUQ0hfQ0FDSEVfVFRMLCBcImZ1bGwtcHJlZmV0Y2hcIik7XG5cdHNjaGVkdWxlUHJlZmV0Y2hJbnZhbGlkYXRpb24oY2FjaGVLZXksIGVudHJ5KTtcbn1cbmZ1bmN0aW9uIGludmFsaWRhdGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGVLZXkpIHtcblx0Y29uc3QgY2FjaGUgPSBnZXRQcmVmZXRjaENhY2hlKCk7XG5cdGNvbnN0IGVudHJ5ID0gY2FjaGUuZ2V0KGNhY2hlS2V5KTtcblx0aWYgKCFlbnRyeSkgcmV0dXJuO1xuXHRkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIGdldFByZWZldGNoZWRVcmxzKCksIGNhY2hlS2V5LCBlbnRyeSwgdHJ1ZSk7XG59XG5mdW5jdGlvbiBzY2hlZHVsZVByZWZldGNoSW52YWxpZGF0aW9uKGNhY2hlS2V5LCBlbnRyeSkge1xuXHRpZiAoZW50cnkub25JbnZhbGlkYXRlQ2FsbGJhY2tzID09PSB2b2lkIDAgfHwgZW50cnkub25JbnZhbGlkYXRlQ2FsbGJhY2tzLnNpemUgPT09IDApIHJldHVybjtcblx0Y2xlYXJQcmVmZXRjaEludmFsaWRhdGlvbihlbnRyeSk7XG5cdGNvbnN0IGRlbGF5ID0gTWF0aC5tYXgoMCwgcmVzb2x2ZVByZWZldGNoQ2FjaGVFbnRyeUV4cGlyZXNBdChlbnRyeSkgLSBEYXRlLm5vdygpKTtcblx0ZW50cnkuaW52YWxpZGF0aW9uVGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRpbnZhbGlkYXRlUHJlZmV0Y2hDYWNoZUVudHJ5KGNhY2hlS2V5KTtcblx0fSwgZGVsYXkpO1xufVxuZnVuY3Rpb24gYWRkUHJlZmV0Y2hJbnZhbGlkYXRpb25DYWxsYmFjayhlbnRyeSwgb25JbnZhbGlkYXRlKSB7XG5cdGlmIChvbkludmFsaWRhdGUgPT09IHZvaWQgMCkgcmV0dXJuO1xuXHRpZiAoZW50cnkub25JbnZhbGlkYXRlQ2FsbGJhY2tzID09PSB2b2lkIDApIGVudHJ5Lm9uSW52YWxpZGF0ZUNhbGxiYWNrcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGVudHJ5Lm9uSW52YWxpZGF0ZUNhbGxiYWNrcy5hZGQob25JbnZhbGlkYXRlKTtcbn1cbi8qKlxuKiBBdHRhY2ggYG9uSW52YWxpZGF0ZWAgdG8gYW4gZW50cnkgdGhlIGNhbGxlciBhbHJlYWR5IGhvbGRzLiBBIHNldHRsZWQgZW50cnlcbiogbmVlZHMgaXRzIGludmFsaWRhdGlvbiB0aW1lciBzdGFydGVkIGhlcmUg4oCUIG5vdGhpbmcgZWxzZSB3aWxsIHNjaGVkdWxlIG9uZVxuKiBvbmNlIGBwcmVmZXRjaFJzY1Jlc3BvbnNlYCBoYXMgZmluaXNoZWQgd2l0aCBpdC5cbiovXG5mdW5jdGlvbiBhdHRhY2hQcmVmZXRjaEludmFsaWRhdGlvblRvRW50cnkoY2FjaGVLZXksIGVudHJ5LCBvbkludmFsaWRhdGUpIHtcblx0aWYgKG9uSW52YWxpZGF0ZSA9PT0gdm9pZCAwKSByZXR1cm47XG5cdGFkZFByZWZldGNoSW52YWxpZGF0aW9uQ2FsbGJhY2soZW50cnksIG9uSW52YWxpZGF0ZSk7XG5cdGlmIChlbnRyeS5vdXRjb21lID09PSBcImNhY2hlLXNlZWRlZFwiKSBzY2hlZHVsZVByZWZldGNoSW52YWxpZGF0aW9uKGNhY2hlS2V5LCBlbnRyeSk7XG59XG5mdW5jdGlvbiBhdHRhY2hQcmVmZXRjaEludmFsaWRhdGlvbkNhbGxiYWNrKGNhY2hlS2V5LCBvbkludmFsaWRhdGUpIHtcblx0aWYgKG9uSW52YWxpZGF0ZSA9PT0gdm9pZCAwKSByZXR1cm47XG5cdGNvbnN0IGVudHJ5ID0gZ2V0UHJlZmV0Y2hDYWNoZSgpLmdldChjYWNoZUtleSk7XG5cdGlmICghZW50cnkpIHJldHVybjtcblx0YXR0YWNoUHJlZmV0Y2hJbnZhbGlkYXRpb25Ub0VudHJ5KGNhY2hlS2V5LCBlbnRyeSwgb25JbnZhbGlkYXRlKTtcbn1cbmZ1bmN0aW9uIGludmFsaWRhdGVQcmVmZXRjaENhY2hlKG9wdGlvbnMgPSB7fSkge1xuXHRjYW5jZWxQZW5kaW5nUHJlZmV0Y2hTZXR1cHMobnVsbCk7XG5cdGNvbnN0IGNhY2hlID0gZ2V0UHJlZmV0Y2hDYWNoZSgpO1xuXHRjb25zdCBwcmVmZXRjaGVkID0gZ2V0UHJlZmV0Y2hlZFVybHMoKTtcblx0Zm9yIChjb25zdCBbY2FjaGVLZXksIGVudHJ5XSBvZiBjYWNoZSkgZGVsZXRlUHJlZmV0Y2hDYWNoZUVudHJ5KGNhY2hlLCBwcmVmZXRjaGVkLCBjYWNoZUtleSwgZW50cnksIHRydWUpO1xuXHRwcmVmZXRjaGVkLmNsZWFyKCk7XG5cdGZvciAoY29uc3QgcmV0YWluZWQgb2YgcmV0YWluZWRQcmVmZXRjaEludmFsaWRhdGlvbnMpIGZpcmVSZXRhaW5lZFByZWZldGNoSW52YWxpZGF0aW9uKHJldGFpbmVkKTtcblx0aWYgKCFpc1NlcnZlciAmJiBvcHRpb25zLnBpbmdWaXNpYmxlTGlua3MgIT09IGZhbHNlKSBnZXROYXZpZ2F0aW9uUnVudGltZSgpPy5mdW5jdGlvbnMucGluZ1Zpc2libGVMaW5rcz8uKCk7XG59XG4vKipcbiogRXZpY3QgdGhlIHByZWZldGNoIGVudHJpZXMgdGhhdCBtYXkgaG9sZCBkeW5hbWljIGRhdGEsIGZvciBhIFNlcnZlciBBY3Rpb25cbiogdGhhdCBjYWxsZWQgYHJlZnJlc2goKWAuIExpa2UgTmV4dC5qcydzIGR5bmFtaWMtb25seSByZXZhbGlkYXRpb24sIHdoaWNoXG4qIGV2aWN0cyBpdHMgQkZDYWNoZSBidXQga2VlcHMgaXRzIHByZWZldGNoIGNhY2hlLCB0aGlzIGtlZXBzIHJvdXRlIHRyZWVzLFxuKiBzdGF0aWMgcHJlZmV0Y2hlcyBhbmQgZnVsbCBwcmVmZXRjaGVzLiBJdCBkcm9wcyBuYXZpZ2F0aW9uIHJlc3BvbnNlcywgYW5kXG4qIGF1dG9tYXRpYyBwcmVmZXRjaGVzIHdob3NlIHBhZ2UgcmVuZGVyZWQgZHluYW1pY2FsbHkgb3IgaGFzbid0IGZpbmlzaGVkXG4qIHJlbmRlcmluZywgaW5jbHVkaW5nIHRob3NlIG9ubHkga2VwdCB0byBsZWFybiBhIHJvdXRlOiBOZXh0LmpzJ3MgYXV0b21hdGljXG4qIHByZWZldGNoZXMgbmV2ZXIgaG9sZCBkeW5hbWljIGRhdGEuXG4qL1xuZnVuY3Rpb24gaW52YWxpZGF0ZUR5bmFtaWNQcmVmZXRjaENhY2hlKCkge1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0Y29uc3QgcHJlZmV0Y2hlZCA9IGdldFByZWZldGNoZWRVcmxzKCk7XG5cdGNvbnN0IGV2aWN0ZWQgPSBbXTtcblx0Zm9yIChjb25zdCBbY2FjaGVLZXksIGVudHJ5XSBvZiBjYWNoZSkgaWYgKCEoZW50cnkucHJlZmV0Y2hLaW5kID09PSBcInJvdXRlLXRyZWVcIiB8fCBlbnRyeS5wcmVmZXRjaEtpbmQgIT09IHZvaWQgMCAmJiAoZW50cnkuZHluYW1pY1N0YWxlVGltZSA9PT0gXCJmdWxsLXByZWZldGNoXCIgfHwgZW50cnkuc25hcHNob3QgIT09IHZvaWQgMCAmJiAhaXNTdGFsZVRpbWVTZWNvbmRzKGVudHJ5LnNuYXBzaG90LmR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzKSkpKSBldmljdGVkLnB1c2goW2NhY2hlS2V5LCBlbnRyeV0pO1xuXHRmb3IgKGNvbnN0IFtjYWNoZUtleSwgZW50cnldIG9mIGV2aWN0ZWQpIGRlbGV0ZVByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgcHJlZmV0Y2hlZCwgY2FjaGVLZXksIGVudHJ5LCB0cnVlKTtcbn1cbi8qKlxuKiBOb3RpZnkgdGhlIHByZWZldGNoZXMgdGhhdCBzdG9vZCBpbiBmb3IgYSB2aXNpdGVkIHJlc3BvbnNlIChzZWVcbiogYGhhc05hdmlnYXRpb25GcmVzaFZpc2l0ZWRSZXNwb25zZWApLCBhcyB0aGUgdmlzaXRlZCByZXNwb25zZXMgYXJlIGNsZWFyZWQuXG4qL1xuZnVuY3Rpb24gaW52YWxpZGF0ZVZpc2l0ZWRSZXNwb25zZVByZWZldGNoZXMoKSB7XG5cdGZvciAoY29uc3QgcmV0YWluZWQgb2YgcmV0YWluZWRQcmVmZXRjaEludmFsaWRhdGlvbnMpIGlmIChyZXRhaW5lZC5mb3JWaXNpdGVkUmVzcG9uc2UgPT09IHRydWUpIGZpcmVSZXRhaW5lZFByZWZldGNoSW52YWxpZGF0aW9uKHJldGFpbmVkKTtcbn1cbi8qKlxuKiBQcmV2ZW50IGNvbXBsZXRlZCBuYXZpZ2F0aW9uIHJlc3BvbnNlcyBmcm9tIGJlY29taW5nIGF1dGhvcml0YXRpdmUgYWdhaW5cbiogYWZ0ZXIgcmVzdG9yaW5nIGEgaGlzdG9yeSBzbmFwc2hvdC4gRXhwbGljaXQgTGluay9yb3V0ZXIgcHJlZmV0Y2hlcyByZW1haW5cbiogY29uc3VtYWJsZS4gUmVzcG9uc2VzIHdpdGggYSBwb3NpdGl2ZSBjYWNoZSBsaWZldGltZSBhbmQgaW50ZXJjZXB0aW9uXG4qIHJlc3BvbnNlcyByZXRhaW4gdGhlIGNhY2hlIHJldXNlIGxpY2Vuc2VkIGJ5IE5leHQncyBzZWdtZW50IGNhY2hlLlxuKi9cbmZ1bmN0aW9uIGRpc2FibGVOYXZpZ2F0aW9uUmVzcG9uc2VQcmVmZXRjaENhY2hlUmV1c2UoKSB7XG5cdGxldCBkaWREZW1vdGUgPSBmYWxzZTtcblx0Zm9yIChjb25zdCBlbnRyeSBvZiBuZXcgU2V0KGdldFByZWZldGNoQ2FjaGUoKS52YWx1ZXMoKSkpIGlmIChlbnRyeS5wcmVmZXRjaEtpbmQgPT09IHZvaWQgMCAmJiBlbnRyeS5yZXVzZUFmdGVySGlzdG9yeVJlc3RvcmUgIT09IHRydWUpIHtcblx0XHRkaWREZW1vdGUgfHw9IGVudHJ5LmNhY2hlRm9yTmF2aWdhdGlvbiAhPT0gZmFsc2U7XG5cdFx0ZW50cnkuY2FjaGVGb3JOYXZpZ2F0aW9uID0gZmFsc2U7XG5cdH1cblx0aWYgKGRpZERlbW90ZSAmJiAhaXNTZXJ2ZXIpIGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5waW5nVmlzaWJsZUxpbmtzPy4oKTtcbn1cbmZ1bmN0aW9uIHNlZWRQcmVmZXRjaFJlc3BvbnNlU25hcHNob3QocnNjVXJsLCBzbmFwc2hvdCwgaW50ZXJjZXB0aW9uQ29udGV4dCA9IG51bGwsIG1vdW50ZWRTbG90c0hlYWRlciA9IG51bGwsIGZhbGxiYWNrVHRsTXMgPSBEWU5BTUlDX05BVklHQVRJT05fQ0FDSEVfVFRMLCByZXVzZUFmdGVySGlzdG9yeVJlc3RvcmUgPSBmYWxzZSwgZXhwaXJlc0F0ID0gcmVzb2x2ZUNhY2hlZFJzY1Jlc3BvbnNlRXhwaXJlc0F0KERhdGUubm93KCksIHNuYXBzaG90LCBmYWxsYmFja1R0bE1zKSkge1xuXHRjb25zdCBjYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0Y29uc3QgZXhpc3RpbmcgPSBjYWNoZS5nZXQoY2FjaGVLZXkpO1xuXHRpZiAoZXhpc3RpbmcpIGRlbGV0ZVByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgZ2V0UHJlZmV0Y2hlZFVybHMoKSwgY2FjaGVLZXksIGV4aXN0aW5nLCBmYWxzZSk7XG5cdGNvbnN0IHRpbWVzdGFtcCA9IERhdGUubm93KCk7XG5cdGNvbnN0IGVudHJ5ID0ge1xuXHRcdGNhY2hlRm9yTmF2aWdhdGlvbjogdHJ1ZSxcblx0XHRjYWNoZUtleXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtjYWNoZUtleV0pLFxuXHRcdGV4cGlyZXNBdCxcblx0XHRtb3VudGVkU2xvdHNIZWFkZXIsXG5cdFx0b3V0Y29tZTogXCJjYWNoZS1zZWVkZWRcIixcblx0XHRyZXVzZUFmdGVySGlzdG9yeVJlc3RvcmUsXG5cdFx0c2l6ZTogc25hcHNob3QuYnVmZmVyLmJ5dGVMZW5ndGgsXG5cdFx0c25hcHNob3QsXG5cdFx0dGltZXN0YW1wXG5cdH07XG5cdGNhY2hlLnNldChjYWNoZUtleSwgZW50cnkpO1xuXHRhZGp1c3RQcmVmZXRjaENhY2hlQnl0ZVNpemUoY2FjaGUsIHNuYXBzaG90LmJ1ZmZlci5ieXRlTGVuZ3RoKTtcblx0Z2V0UHJlZmV0Y2hlZFVybHMoKS5hZGQoY2FjaGVLZXkpO1xuXHRzY2hlZHVsZVByZWZldGNoSW52YWxpZGF0aW9uKGNhY2hlS2V5LCBlbnRyeSk7XG5cdGV2aWN0UHJlZmV0Y2hDYWNoZUlmTmVlZGVkKCk7XG59XG4vKipcbiogRnVsZmlsbCBhIGZ1bGwgcHJlZmV0Y2ggZnJvbSB0aGUgdmlzaXRlZCByZXNwb25zZSBvZiBhbiBlYXJsaWVyIG5hdmlnYXRpb24sXG4qIGFzIE5leHQuanMgZG9lcyBmcm9tIGl0cyBCRkNhY2hlLCBpbnN0ZWFkIG9mIGlzc3VpbmcgYSByZXF1ZXN0LiBUaGUgZGF0YSBpc1xuKiBmcmVzaCBmb3IgdGhlIHN0YXRpYyBzdGFsZSB0aW1lIGZyb20gdGhlIG5hdmlnYXRpb24sIG5vdCB0aGUgZHluYW1pYyBvbmVcbiogKGBhdHRlbXB0VG9GdWxmaWxsRHluYW1pY1NlZ21lbnRGcm9tQkZDYWNoZWApLlxuKi9cbmZ1bmN0aW9uIHNlZWRGdWxsUHJlZmV0Y2hGcm9tVmlzaXRlZFJlc3BvbnNlKHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyLCBhZGRpdGlvbmFsUnNjVXJscyA9IFtdLCBvbkludmFsaWRhdGUpIHtcblx0Y29uc3QgdmlzaXRlZCA9IGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5yZWFkVmlzaXRlZFJlc3BvbnNlRm9yRnVsbFByZWZldGNoPy4oW3JzY1VybCwgLi4uYWRkaXRpb25hbFJzY1VybHNdLCBpbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIpO1xuXHRpZiAoIXZpc2l0ZWQpIHJldHVybiBmYWxzZTtcblx0Y29uc3QgZXhwaXJlc0F0ID0gdmlzaXRlZC5uYXZpZ2F0ZWRBdCArIE1hdGgubWF4KFBSRUZFVENIX0NBQ0hFX1RUTCwgTUlOX1BSRUZFVENIX1NUQUxFX1RJTUVfTVMpO1xuXHRpZiAoZXhwaXJlc0F0IDw9IERhdGUubm93KCkpIHJldHVybiBmYWxzZTtcblx0c2VlZFByZWZldGNoUmVzcG9uc2VTbmFwc2hvdChyc2NVcmwsIHZpc2l0ZWQucmVzcG9uc2UsIGludGVyY2VwdGlvbkNvbnRleHQsIG1vdW50ZWRTbG90c0hlYWRlciwgdm9pZCAwLCB0cnVlLCBleHBpcmVzQXQpO1xuXHRjb25zdCBjYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRpZiAoZ2V0UHJlZmV0Y2hDYWNoZSgpLmdldChjYWNoZUtleSk/LnNuYXBzaG90ICE9PSB2aXNpdGVkLnJlc3BvbnNlKSByZXR1cm4gZmFsc2U7XG5cdGF0dGFjaFByZWZldGNoSW52YWxpZGF0aW9uQ2FsbGJhY2soY2FjaGVLZXksIG9uSW52YWxpZGF0ZSk7XG5cdHJldHVybiB0cnVlO1xufVxuLyoqXG4qIFdoZXRoZXIgYSBuYXZpZ2F0aW9uIHRvIHRoZSBVUkwgd291bGQgcmV1c2UgdGhlIHJlc3BvbnNlIG9mIGFuIGVhcmxpZXIgb25lLFxuKiBzbyBhIHByZWZldGNoIGhhcyBub3RoaW5nIHRvIGZldGNoLiBMaWtlIE5leHQuanMsIHdob3NlIG5hdmlnYXRpb24ga2VlcHMgdGhlXG4qIHJvdXRlIGFuZCBpdHMgc2VnbWVudHMgZm9yIGBzdGFsZVRpbWVzLmR5bmFtaWNgLiBgb25JbnZhbGlkYXRlYCBmaXJlcyB3aGVuXG4qIHRoYXQgcmV1c2UgZW5kcy5cbiovXG5mdW5jdGlvbiBoYXNOYXZpZ2F0aW9uRnJlc2hWaXNpdGVkUmVzcG9uc2UocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIsIGFkZGl0aW9uYWxSc2NVcmxzID0gW10sIG9uSW52YWxpZGF0ZSkge1xuXHRjb25zdCBmcmVzaFVudGlsID0gZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLnJlYWRWaXNpdGVkUmVzcG9uc2VGb3JGdWxsUHJlZmV0Y2g/LihbcnNjVXJsLCAuLi5hZGRpdGlvbmFsUnNjVXJsc10sIGludGVyY2VwdGlvbkNvbnRleHQsIG1vdW50ZWRTbG90c0hlYWRlcik/Lm5hdmlnYXRpb25GcmVzaFVudGlsO1xuXHRpZiAoZnJlc2hVbnRpbCA9PT0gdm9pZCAwIHx8IGZyZXNoVW50aWwgPT09IG51bGwpIHJldHVybiBmYWxzZTtcblx0aWYgKG9uSW52YWxpZGF0ZSAhPT0gdm9pZCAwKSByZXRhaW5QcmVmZXRjaEludmFsaWRhdGlvbigvKiBAX19QVVJFX18gKi8gbmV3IFNldChbb25JbnZhbGlkYXRlXSksIGZyZXNoVW50aWwsIHRydWUpO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGRlbGV0ZVByZWZldGNoUmVzcG9uc2VTbmFwc2hvdChyc2NVcmwsIHNuYXBzaG90LCBpbnRlcmNlcHRpb25Db250ZXh0ID0gbnVsbCkge1xuXHRjb25zdCBjYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0Y29uc3QgZW50cnkgPSBjYWNoZS5nZXQoY2FjaGVLZXkpO1xuXHRpZiAoZW50cnk/LnNuYXBzaG90ICE9PSBzbmFwc2hvdCkgcmV0dXJuO1xuXHRkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIGdldFByZWZldGNoZWRVcmxzKCksIGNhY2hlS2V5LCBlbnRyeSwgZmFsc2UpO1xufVxuLyoqXG4qIFN0b3JlIGEgcHJlZmV0Y2hlZCBSU0MgcmVzcG9uc2UgaW4gdGhlIGNhY2hlIGJ5IHNuYXBzaG90dGluZyBpdCB0byBhblxuKiBBcnJheUJ1ZmZlci4gIFRoZSBzbmFwc2hvdCBjb21wbGV0ZXMgYXN5bmNocm9ub3VzbHk7IGR1cmluZyB0aGF0IHdpbmRvd1xuKiB0aGUgZW50cnkgaXMgbWFya2VkIGBwZW5kaW5nYCBzbyBjb25zdW1lUHJlZmV0Y2hSZXNwb25zZSgpIHdpbGwgc2tpcCBpdFxuKiAodGhlIGNhbGxlciBmYWxscyBiYWNrIHRvIGEgZnJlc2ggZmV0Y2gsIHdoaWNoIGlzIGFjY2VwdGFibGUpLlxuKlxuKiBQcmVmZXIgcHJlZmV0Y2hSc2NSZXNwb25zZSgpIGZvciBuZXcgY2FsbC1zaXRlcyDigJQgaXQgaGFuZGxlcyB0aGUgZnVsbFxuKiBwcmVmZXRjaCBsaWZlY3ljbGUgaW5jbHVkaW5nIGRlZHVwIGFuZCBleHBsaWNpdCBzbG90IGNvbnRleHQuXG4qIHN0b3JlUHJlZmV0Y2hSZXNwb25zZSgpIGlzIGtlcHQgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHkgYW5kIHRlc3RcbiogaGVscGVycy4gSXQgaXMgc2xvdC11bmF3YXJlOiB0aGUgc25hcHNob3QncyBtb3VudGVkU2xvdHNIZWFkZXIgY29tZXNcbiogZnJvbSB0aGUgcmVzcG9uc2UgaGVhZGVycywgbm90IHRoZSBjYWxsZXIsIHNvIGNvbnN1bWVQcmVmZXRjaFJlc3BvbnNlXG4qIG1heSByZWplY3QgdGhlIGVudHJ5IGlmIHRoZSBjYWxsZXIncyBzbG90IGNvbnRleHQgZGlmZmVycy5cbipcbiogTkI6IENhbGxlciBpcyByZXNwb25zaWJsZSBmb3IgbWFuYWdpbmcgZ2V0UHJlZmV0Y2hlZFVybHMoKSDigJQgdGhpc1xuKiBmdW5jdGlvbiBvbmx5IHN0b3JlcyB0aGUgcmVzcG9uc2UgaW4gdGhlIHByZWZldGNoIGNhY2hlLlxuKi9cbmZ1bmN0aW9uIHN0b3JlUHJlZmV0Y2hSZXNwb25zZShyc2NVcmwsIHJlc3BvbnNlLCBpbnRlcmNlcHRpb25Db250ZXh0ID0gbnVsbCwgb3B0aW9ucykge1xuXHRjb25zdCBjYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0Y29uc3QgcHJlZmV0Y2hlZCA9IGdldFByZWZldGNoZWRVcmxzKCk7XG5cdGNvbnN0IGV4aXN0aW5nID0gY2FjaGUuZ2V0KGNhY2hlS2V5KTtcblx0aWYgKGV4aXN0aW5nKSBkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIHByZWZldGNoZWQsIGNhY2hlS2V5LCBleGlzdGluZywgZmFsc2UpO1xuXHRjb25zdCBlbnRyeSA9IHtcblx0XHRjYWNoZUtleXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtjYWNoZUtleV0pLFxuXHRcdG1vdW50ZWRTbG90c0hlYWRlcjogbnVsbCxcblx0XHRvdXRjb21lOiBcInBlbmRpbmdcIixcblx0XHR0aW1lc3RhbXA6IERhdGUubm93KClcblx0fTtcblx0YWRkUHJlZmV0Y2hJbnZhbGlkYXRpb25DYWxsYmFjayhlbnRyeSwgb3B0aW9ucz8ub25JbnZhbGlkYXRlKTtcblx0ZW50cnkucGVuZGluZyA9IHNuYXBzaG90UnNjUmVzcG9uc2UocmVzcG9uc2UpLnRoZW4oKHNuYXBzaG90KSA9PiB7XG5cdFx0aWYgKGNhY2hlLmdldChjYWNoZUtleSkgIT09IGVudHJ5KSByZXR1cm47XG5cdFx0Y29uc3QgcHJldmlvdXNTaXplID0gZ2V0UHJlZmV0Y2hDYWNoZUVudHJ5U2l6ZShlbnRyeSk7XG5cdFx0ZW50cnkubW91bnRlZFNsb3RzSGVhZGVyID0gc25hcHNob3QubW91bnRlZFNsb3RzSGVhZGVyID8/IG51bGw7XG5cdFx0ZW50cnkuc25hcHNob3QgPSBzbmFwc2hvdDtcblx0XHRlbnRyeS5zaXplID0gc25hcHNob3QuYnVmZmVyLmJ5dGVMZW5ndGg7XG5cdFx0YWRqdXN0UHJlZmV0Y2hDYWNoZUJ5dGVTaXplKGNhY2hlLCBlbnRyeS5zaXplIC0gcHJldmlvdXNTaXplKTtcblx0XHRlbnRyeS5leHBpcmVzQXQgPSByZXNvbHZlQ2FjaGVkUnNjUmVzcG9uc2VFeHBpcmVzQXQoZW50cnkudGltZXN0YW1wLCBzbmFwc2hvdCwgUFJFRkVUQ0hfQ0FDSEVfVFRMKTtcblx0XHRldmljdFByZWZldGNoQ2FjaGVJZk5lZWRlZCgpO1xuXHR9KS5jYXRjaCgoKSA9PiB7XG5cdFx0ZGVsZXRlUHJlZmV0Y2hDYWNoZUVudHJ5KGNhY2hlLCBwcmVmZXRjaGVkLCBjYWNoZUtleSwgZW50cnksIGZhbHNlKTtcblx0fSkuZmluYWxseSgoKSA9PiB7XG5cdFx0aWYgKGNhY2hlLmdldChjYWNoZUtleSkgIT09IGVudHJ5KSByZXR1cm47XG5cdFx0ZW50cnkucGVuZGluZyA9IHZvaWQgMDtcblx0XHRpZiAoZW50cnkuc25hcHNob3QpIHtcblx0XHRcdGVudHJ5Lm91dGNvbWUgPSBcImNhY2hlLXNlZWRlZFwiO1xuXHRcdFx0c2NoZWR1bGVQcmVmZXRjaEludmFsaWRhdGlvbihjYWNoZUtleSwgZW50cnkpO1xuXHRcdH1cblx0fSk7XG5cdGNhY2hlLnNldChjYWNoZUtleSwgZW50cnkpO1xufVxuZnVuY3Rpb24gY3JlYXRlQ2FjaGVkUnNjUmVzcG9uc2VTbmFwc2hvdChyZXNwb25zZSwgYnVmZmVyLCByZXNwb25zZVVybCA9IG51bGwpIHtcblx0Y29uc3QgaGVhZGVyRHluYW1pY1N0YWxlVGltZVNlY29uZHMgPSBwYXJzZVN0YWxlVGltZVNlY29uZHNIZWFkZXIocmVzcG9uc2UuaGVhZGVycy5nZXQoVklORVhUX0RZTkFNSUNfU1RBTEVfVElNRV9IRUFERVIpKTtcblx0Y29uc3QgY29tcGxldGlvbk1vZGUgPSByZXNwb25zZS5oZWFkZXJzLmdldChWSU5FWFRfUlNDX0NPTVBMRVRJT05fTUVUQURBVEFfSEVBREVSKTtcblx0Y29uc3QgZXh0cmFjdGVkID0gY29tcGxldGlvbk1vZGUgPT09IFwiMVwiID8gZXh0cmFjdFJzY0NvbXBsZXRpb25NZXRhZGF0YShidWZmZXIpIDogeyBidWZmZXIgfTtcblx0Y29uc3QgY29tcGxldGVkRHluYW1pY1N0YWxlVGltZVNlY29uZHMgPSBjb21wbGV0aW9uTW9kZSA9PT0gXCJyZXNvbHZlZFwiID8gaGVhZGVyRHluYW1pY1N0YWxlVGltZVNlY29uZHMgOiBleHRyYWN0ZWQubWV0YWRhdGE/LmR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzID8/IGhlYWRlckR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzO1xuXHRjb25zdCBkeW5hbWljU3RhbGVUaW1lU2Vjb25kcyA9IGNvbXBsZXRlZER5bmFtaWNTdGFsZVRpbWVTZWNvbmRzID8/IGhlYWRlckR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzO1xuXHRjb25zdCBwYXJzZWRTZXJ2ZXJTdGFsZVRpbWUgPSBwYXJzZVNlcnZlclN0YWxlVGltZUhlYWRlcnMocmVzcG9uc2UuaGVhZGVycyk7XG5cdGNvbnN0IHNlcnZlclN0YWxlVGltZSA9IGV4dHJhY3RlZC5tZXRhZGF0YSAhPT0gdm9pZCAwICYmIE9iamVjdC5oYXNPd24oZXh0cmFjdGVkLm1ldGFkYXRhLCBcInNlcnZlclN0YWxlVGltZVNlY29uZHNcIikgPyBleHRyYWN0ZWQubWV0YWRhdGE/LnNlcnZlclN0YWxlVGltZVNlY29uZHMgPT09IG51bGwgPyB2b2lkIDAgOiB7XG5cdFx0a2luZDogXCJyZXNvbHZlZFwiLFxuXHRcdHNlY29uZHM6IGV4dHJhY3RlZC5tZXRhZGF0YS5zZXJ2ZXJTdGFsZVRpbWVTZWNvbmRzXG5cdH0gOiBwYXJzZWRTZXJ2ZXJTdGFsZVRpbWU7XG5cdGNvbnN0IHJlZGlyZWN0SGVhZGVyID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoVklORVhUX1JTQ19SRURJUkVDVF9IRUFERVIpO1xuXHRjb25zdCByZWRpcmVjdFR5cGVIZWFkZXIgPSByZXNwb25zZS5oZWFkZXJzLmdldChWSU5FWFRfUlNDX1JFRElSRUNUX1RZUEVfSEVBREVSKTtcblx0cmV0dXJuIHtcblx0XHRjb21wYXRpYmlsaXR5SWRIZWFkZXI6IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFZJTkVYVF9SU0NfQ09NUEFUSUJJTElUWV9JRF9IRUFERVIpLFxuXHRcdGJ1ZmZlcjogZXh0cmFjdGVkLmJ1ZmZlcixcblx0XHQuLi5jb21wbGV0ZWREeW5hbWljU3RhbGVUaW1lU2Vjb25kcyAhPT0gdm9pZCAwID8geyBjb21wbGV0ZWREeW5hbWljU3RhbGVUaW1lU2Vjb25kcyB9IDoge30sXG5cdFx0Y29udGVudFR5cGU6IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiY29udGVudC10eXBlXCIpID8/IFwidGV4dC94LWNvbXBvbmVudFwiLFxuXHRcdC4uLmR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzICE9PSB2b2lkIDAgPyB7IGR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzIH0gOiB7fSxcblx0XHRtb3VudGVkU2xvdHNIZWFkZXI6IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFZJTkVYVF9NT1VOVEVEX1NMT1RTX0hFQURFUiksXG5cdFx0cGFyYW1zSGVhZGVyOiByZXNwb25zZS5oZWFkZXJzLmdldChWSU5FWFRfUEFSQU1TX0hFQURFUiksXG5cdFx0cmVjZWl2ZWRBdDogRGF0ZS5ub3coKSxcblx0XHQuLi5yZWRpcmVjdEhlYWRlciA9PT0gbnVsbCA/IHt9IDogeyByZWRpcmVjdEhlYWRlciB9LFxuXHRcdC4uLnJlZGlyZWN0VHlwZUhlYWRlciA9PT0gbnVsbCA/IHt9IDogeyByZWRpcmVjdFR5cGVIZWFkZXIgfSxcblx0XHRyZW5kZXJlZFBhdGhBbmRTZWFyY2g6IHBhcnNlUmVuZGVyZWRQYXRoQW5kU2VhcmNoSGVhZGVyKHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFZJTkVYVF9SRU5ERVJFRF9QQVRIX0FORF9TRUFSQ0hfSEVBREVSKSksXG5cdFx0Li4uc2VydmVyU3RhbGVUaW1lID09PSB2b2lkIDAgPyB7fSA6IHsgc2VydmVyU3RhbGVUaW1lIH0sXG5cdFx0dXJsOiByZXNwb25zZVVybCA/PyByZXNwb25zZS51cmxcblx0fTtcbn1cbi8qKlxuKiBDb2xsYXBzZSB0aGUgdHdvIG11dHVhbGx5LWV4Y2x1c2l2ZSB3aXJlIGhlYWRlcnMgaW50byBvbmUgc3RhdGUuIEEgcGVuZGluZ1xuKiBtYXJrZXIgd2luczogaXQgc2F5cyB0aGUgcmVuZGVyIGNvbW1pdHRlZCBoZWFkZXJzIGJlZm9yZSBgY2FjaGVMaWZlYCBzZXR0bGVkLFxuKiBzbyBhbnkgcmVzb2x2ZWQgdmFsdWUgYWxvbmdzaWRlIGl0IGNhbm5vdCBkZXNjcmliZSB0aGUgY29tcGxldGVkIHJlbmRlci5cbiovXG5mdW5jdGlvbiBwYXJzZVNlcnZlclN0YWxlVGltZUhlYWRlcnMoaGVhZGVycykge1xuXHRpZiAoaGVhZGVycy5nZXQoXCJYLVZpbmV4dC1TdGFsZS1UaW1lLVBlbmRpbmdcIikgPT09IFwiMVwiKSByZXR1cm4geyBraW5kOiBcInBlbmRpbmdcIiB9O1xuXHRjb25zdCBzZWNvbmRzID0gcGFyc2VTdGFsZVRpbWVTZWNvbmRzSGVhZGVyKGhlYWRlcnMuZ2V0KE5FWFRfUk9VVEVSX1NUQUxFX1RJTUVfSEVBREVSKSk7XG5cdHJldHVybiBzZWNvbmRzID09PSB2b2lkIDAgPyB2b2lkIDAgOiB7XG5cdFx0a2luZDogXCJyZXNvbHZlZFwiLFxuXHRcdHNlY29uZHNcblx0fTtcbn1cbi8qKiBEZWNvZGUgYW4gYFgtVmluZXh0LVJlbmRlcmVkLVBhdGgtQW5kLVNlYXJjaGAgaGVhZGVyIHZhbHVlLiAqL1xuZnVuY3Rpb24gcGFyc2VSZW5kZXJlZFBhdGhBbmRTZWFyY2hIZWFkZXIodmFsdWUpIHtcblx0aWYgKHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSBcIlwiKSByZXR1cm4gbnVsbDtcblx0dHJ5IHtcblx0XHRjb25zdCBkZWNvZGVkID0gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcblx0XHRyZXR1cm4gZGVjb2RlZC5zdGFydHNXaXRoKFwiL1wiKSA/IGRlY29kZWQgOiBudWxsO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxufVxuLyoqXG4qIFNuYXBzaG90IGFuIFJTQyByZXNwb25zZSB0byBhbiBBcnJheUJ1ZmZlciBmb3IgY2FjaGluZyBhbmQgcmVwbGF5LlxuKiBDb25zdW1lcyB0aGUgcmVzcG9uc2UgYm9keSBhbmQgc3RvcmVzIGl0IHdpdGggY29udGVudC10eXBlIGFuZCBVUkwgbWV0YWRhdGEuXG4qL1xuYXN5bmMgZnVuY3Rpb24gc25hcHNob3RSc2NSZXNwb25zZShyZXNwb25zZSkge1xuXHR0cnkge1xuXHRcdGNvbnN0IHNuYXBzaG90ID0gY3JlYXRlQ2FjaGVkUnNjUmVzcG9uc2VTbmFwc2hvdChyZXNwb25zZSwgYXdhaXQgcmVzcG9uc2UuYXJyYXlCdWZmZXIoKSk7XG5cdFx0Y29uc3QgZXhwaXJlc0F0ID0gcmVzdG9yZWRSc2NSZXNwb25zZUV4cGlyZXNBdC5nZXQocmVzcG9uc2UpO1xuXHRcdHJldHVybiBleHBpcmVzQXQgPT09IHZvaWQgMCA/IHNuYXBzaG90IDoge1xuXHRcdFx0Li4uc25hcHNob3QsXG5cdFx0XHRleHBpcmVzQXRcblx0XHR9O1xuXHR9IGZpbmFsbHkge1xuXHRcdHJlbGVhc2VBcHBQcmVmZXRjaEZldGNoU2xvdChyZXNwb25zZSk7XG5cdH1cbn1cbmNvbnN0IHJlc3RvcmVkUnNjUmVzcG9uc2VFeHBpcmVzQXQgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbi8qKlxuKiBSZWNvbnN0cnVjdCBhIFJlc3BvbnNlIGZyb20gYSBjYWNoZWQgUlNDIHNuYXBzaG90LlxuKiBDcmVhdGVzIGEgbmV3IFJlc3BvbnNlIHdpdGggdGhlIG9yaWdpbmFsIEFycmF5QnVmZmVyIHNvIGNyZWF0ZUZyb21GZXRjaFxuKiBjYW4gY29uc3VtZSB0aGUgc3RyZWFtIGZyb20gc2NyYXRjaC5cbipcbiogTk9URTogVGhlIHJlY29uc3RydWN0ZWQgUmVzcG9uc2UgYWx3YXlzIGhhcyBgdXJsID09PSBcIlwiYCDigJQgdGhlIFJlc3BvbnNlXG4qIGNvbnN0cnVjdG9yIGRvZXMgbm90IGFjY2VwdCBhIGB1cmxgIG9wdGlvbiwgYW5kIGByZXNwb25zZS51cmxgIGlzIHJlYWQtb25seVxuKiBzZXQgYnkgdGhlIGZldGNoIGluZnJhc3RydWN0dXJlLiBDYWxsZXJzIHRoYXQgbmVlZCB0aGUgb3JpZ2luYWwgVVJMIHNob3VsZFxuKiByZWFkIGl0IGZyb20gYGNhY2hlZC51cmxgIGRpcmVjdGx5IHJhdGhlciB0aGFuIGZyb20gdGhlIHJlc3RvcmVkIFJlc3BvbnNlLlxuKlxuKiBAcGFyYW0gY29weSAtIFdoZW4gdHJ1ZSAoZGVmYXVsdCksIGNvcGllcyB0aGUgQXJyYXlCdWZmZXIgc28gdGhlIGNhY2hlZFxuKiAgIHNuYXBzaG90IHJlbWFpbnMgcmVwbGF5YWJsZSAobmVlZGVkIGZvciB0aGUgdmlzaXRlZC1yZXNwb25zZSBjYWNoZSkuXG4qICAgUGFzcyBmYWxzZSBmb3Igc2luZ2xlLWNvbnN1bXB0aW9uIHBhdGhzIChlLmcuIHByZWZldGNoIGNhY2hlIGVudHJpZXNcbiogICB0aGF0IGFyZSBkZWxldGVkIGFmdGVyIGNvbnN1bXB0aW9uKSB0byBhdm9pZCB0aGUgZXh0cmEgYWxsb2NhdGlvbi5cbiovXG5mdW5jdGlvbiByZXN0b3JlUnNjUmVzcG9uc2UoY2FjaGVkLCBjb3B5ID0gdHJ1ZSkge1xuXHRjb25zdCBoZWFkZXJzID0gbmV3IEhlYWRlcnMoeyBcImNvbnRlbnQtdHlwZVwiOiBjYWNoZWQuY29udGVudFR5cGUgfSk7XG5cdGlmIChjYWNoZWQubW91bnRlZFNsb3RzSGVhZGVyICE9IG51bGwpIGhlYWRlcnMuc2V0KFZJTkVYVF9NT1VOVEVEX1NMT1RTX0hFQURFUiwgY2FjaGVkLm1vdW50ZWRTbG90c0hlYWRlcik7XG5cdGlmIChjYWNoZWQuY29tcGF0aWJpbGl0eUlkSGVhZGVyICE9IG51bGwpIGhlYWRlcnMuc2V0KFZJTkVYVF9SU0NfQ09NUEFUSUJJTElUWV9JRF9IRUFERVIsIGNhY2hlZC5jb21wYXRpYmlsaXR5SWRIZWFkZXIpO1xuXHRpZiAoaXNTdGFsZVRpbWVTZWNvbmRzKGNhY2hlZC5keW5hbWljU3RhbGVUaW1lU2Vjb25kcykpIGhlYWRlcnMuc2V0KFZJTkVYVF9EWU5BTUlDX1NUQUxFX1RJTUVfSEVBREVSLCBTdHJpbmcoY2FjaGVkLmR5bmFtaWNTdGFsZVRpbWVTZWNvbmRzKSk7XG5cdGlmIChpc1N0YWxlVGltZVNlY29uZHMoY2FjaGVkLmNvbXBsZXRlZER5bmFtaWNTdGFsZVRpbWVTZWNvbmRzKSkgaGVhZGVycy5zZXQoVklORVhUX1JTQ19DT01QTEVUSU9OX01FVEFEQVRBX0hFQURFUiwgXCJyZXNvbHZlZFwiKTtcblx0aWYgKGNhY2hlZC5zZXJ2ZXJTdGFsZVRpbWU/LmtpbmQgPT09IFwicGVuZGluZ1wiKSBoZWFkZXJzLnNldChWSU5FWFRfU1RBTEVfVElNRV9QRU5ESU5HX0hFQURFUiwgXCIxXCIpO1xuXHRlbHNlIGlmIChjYWNoZWQuc2VydmVyU3RhbGVUaW1lICE9PSB2b2lkIDApIGhlYWRlcnMuc2V0KE5FWFRfUk9VVEVSX1NUQUxFX1RJTUVfSEVBREVSLCBTdHJpbmcoY2FjaGVkLnNlcnZlclN0YWxlVGltZS5zZWNvbmRzKSk7XG5cdGlmIChjYWNoZWQucGFyYW1zSGVhZGVyICE9IG51bGwpIGhlYWRlcnMuc2V0KFZJTkVYVF9QQVJBTVNfSEVBREVSLCBjYWNoZWQucGFyYW1zSGVhZGVyKTtcblx0aWYgKGNhY2hlZC5yZWRpcmVjdEhlYWRlciAhPT0gdm9pZCAwKSBoZWFkZXJzLnNldChWSU5FWFRfUlNDX1JFRElSRUNUX0hFQURFUiwgY2FjaGVkLnJlZGlyZWN0SGVhZGVyKTtcblx0aWYgKGNhY2hlZC5yZWRpcmVjdFR5cGVIZWFkZXIgIT09IHZvaWQgMCkgaGVhZGVycy5zZXQoVklORVhUX1JTQ19SRURJUkVDVF9UWVBFX0hFQURFUiwgY2FjaGVkLnJlZGlyZWN0VHlwZUhlYWRlcik7XG5cdGlmIChjYWNoZWQucmVuZGVyZWRQYXRoQW5kU2VhcmNoICE9IG51bGwpIGhlYWRlcnMuc2V0KFZJTkVYVF9SRU5ERVJFRF9QQVRIX0FORF9TRUFSQ0hfSEVBREVSLCBlbmNvZGVVUklDb21wb25lbnQoY2FjaGVkLnJlbmRlcmVkUGF0aEFuZFNlYXJjaCkpO1xuXHRjb25zdCByZXNwb25zZSA9IG5ldyBSZXNwb25zZShjb3B5ID8gY2FjaGVkLmJ1ZmZlci5zbGljZSgwKSA6IGNhY2hlZC5idWZmZXIsIHtcblx0XHRzdGF0dXM6IDIwMCxcblx0XHRoZWFkZXJzXG5cdH0pO1xuXHRpZiAoaXNDYWNoZUV4cGlyZXNBdChjYWNoZWQuZXhwaXJlc0F0KSkgcmVzdG9yZWRSc2NSZXNwb25zZUV4cGlyZXNBdC5zZXQocmVzcG9uc2UsIGNhY2hlZC5leHBpcmVzQXQpO1xuXHRyZXR1cm4gcmVzcG9uc2U7XG59XG4vKipcbiogYHByZWZldGNoUnNjUmVzcG9uc2VgJ3MgYHByZXBhcmVTbmFwc2hvdGAgZm9yIG5hdmlnYXRpb24tcmV1c2FibGUgZW50cmllczpcbiogZGVjb2RlIHRoZSBjYWNoZWQgcGF5bG9hZCB0aHJvdWdoIHRoZSBBcHAgUm91dGVyIHJ1bnRpbWUgc28gYSBsYXRlclxuKiBuYXZpZ2F0aW9uIGNhbiBjb21taXQgaXQgd2l0aG91dCByZS1wYXJzaW5nLiBTaGFyZWQgYnkgYDxMaW5rPmAgYW5kXG4qIGByb3V0ZXIucHJlZmV0Y2goKWAuXG4qL1xuYXN5bmMgZnVuY3Rpb24gcHJlcGFyZU5hdmlnYXRpb25QcmVmZXRjaFNuYXBzaG90KHNuYXBzaG90KSB7XG5cdGNvbnN0IHByZXBhcmVQcmVmZXRjaFJlc3BvbnNlID0gZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLnByZXBhcmVQcmVmZXRjaFJlc3BvbnNlO1xuXHRpZiAoIXByZXBhcmVQcmVmZXRjaFJlc3BvbnNlKSB0aHJvdyBuZXcgRXJyb3IoXCJBcHAgUm91dGVyIHByZWZldGNoIHByZXBhcmF0aW9uIGlzIHVuYXZhaWxhYmxlXCIpO1xuXHRyZXR1cm4gYXdhaXQgcHJlcGFyZVByZWZldGNoUmVzcG9uc2UocmVzdG9yZVJzY1Jlc3BvbnNlKHNuYXBzaG90KSk7XG59XG4vKipcbiogR2F0ZSBhIG5hdmlnYXRpb24tcmV1c2FibGUgcHJlZmV0Y2ggYmVoaW5kIHRoZSByb3V0ZS10cmVlIHJlcXVlc3Qgc2hhcmVkIGJ5XG4qIGA8TGluaz5gIGFuZCBgcm91dGVyLnByZWZldGNoKClgLiBDYWxsZXJzIHJldGFpbiBjb250cm9sIG9mIGZldGNoIHNjaGVkdWxpbmdcbiogYW5kIHJlcXVlc3Qtb25seSBvcHRpb25zIHdoaWxlIGZyZXNobmVzcywgZGVkdXBsaWNhdGlvbiwgYW5kIGFsaWFzIHJldXNlIHN0YXlcbiogaWRlbnRpY2FsIGFjcm9zcyBib3RoIGVudHJ5IHBvaW50cy5cbiovXG5hc3luYyBmdW5jdGlvbiBmZXRjaFJvdXRlVHJlZUdhdGVkUHJlZmV0Y2gob3B0aW9ucykge1xuXHRjb25zdCB7IGZldGNoRnVsbFJzY1BheWxvYWQsIGZldGNoUm91dGVUcmVlLCBmdWxsSHJlZiwgaGVhZGVycywgaW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyIH0gPSBvcHRpb25zO1xuXHRjb25zdCByb3V0ZVRyZWVIZWFkZXJzID0gbmV3IEhlYWRlcnMoaGVhZGVycyk7XG5cdHJvdXRlVHJlZUhlYWRlcnMuc2V0KE5FWFRfUk9VVEVSX1BSRUZFVENIX0hFQURFUiwgXCIxXCIpO1xuXHRyb3V0ZVRyZWVIZWFkZXJzLnNldChORVhUX1JPVVRFUl9TRUdNRU5UX1BSRUZFVENIX0hFQURFUiwgXCIvX3RyZWVcIik7XG5cdGNvbnN0IHJvdXRlVHJlZVJzY1VybCA9IGF3YWl0IGNyZWF0ZVJzY1JlcXVlc3RVcmwoZnVsbEhyZWYsIHJvdXRlVHJlZUhlYWRlcnMpO1xuXHRjb25zdCByb3V0ZVRyZWVDYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyb3V0ZVRyZWVSc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRsZXQgcm91dGVUcmVlRW50cnkgPSBnZXRGcmVzaFByZWZldGNoQ2FjaGVFbnRyeShyb3V0ZVRyZWVDYWNoZUtleSk7XG5cdGlmIChyb3V0ZVRyZWVFbnRyeSA9PT0gdm9pZCAwKSB7XG5cdFx0Z2V0UHJlZmV0Y2hlZFVybHMoKS5hZGQocm91dGVUcmVlQ2FjaGVLZXkpO1xuXHRcdHByZWZldGNoUnNjUmVzcG9uc2Uocm91dGVUcmVlUnNjVXJsLCBmZXRjaFJvdXRlVHJlZShyb3V0ZVRyZWVSc2NVcmwsIHJvdXRlVHJlZUhlYWRlcnMpLCBpbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIsIHZvaWQgMCwge1xuXHRcdFx0Y2FjaGVGb3JOYXZpZ2F0aW9uOiBmYWxzZSxcblx0XHRcdG9wdGltaXN0aWNSb3V0ZVNoZWxsOiBmYWxzZSxcblx0XHRcdHByZWZldGNoS2luZDogXCJyb3V0ZS10cmVlXCJcblx0XHR9KTtcblx0XHRyb3V0ZVRyZWVFbnRyeSA9IGdldEZyZXNoUHJlZmV0Y2hDYWNoZUVudHJ5KHJvdXRlVHJlZUNhY2hlS2V5KTtcblx0fVxuXHRhd2FpdCByb3V0ZVRyZWVFbnRyeT8ucGVuZGluZz8uY2F0Y2goKCkgPT4ge30pO1xuXHRyb3V0ZVRyZWVFbnRyeSA9IGdldEZyZXNoUHJlZmV0Y2hDYWNoZUVudHJ5KHJvdXRlVHJlZUNhY2hlS2V5KTtcblx0Y29uc3QgcmVuZGVyZWRQYXRoQW5kU2VhcmNoID0gcm91dGVUcmVlRW50cnk/LnNuYXBzaG90Py5yZW5kZXJlZFBhdGhBbmRTZWFyY2g7XG5cdGlmIChyZW5kZXJlZFBhdGhBbmRTZWFyY2gpIHtcblx0XHRjb25zdCBjYWNoZWRSZW5kZXJlZFJlc3BvbnNlID0gcGVla1ByZWZldGNoUmVzcG9uc2VGb3JOYXZpZ2F0aW9uKGF3YWl0IGNyZWF0ZVJzY1JlcXVlc3RVcmwocmVuZGVyZWRQYXRoQW5kU2VhcmNoLCBoZWFkZXJzKSwgaW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyKTtcblx0XHRpZiAoY2FjaGVkUmVuZGVyZWRSZXNwb25zZSkgcmV0dXJuIHJlc3RvcmVSc2NSZXNwb25zZShjYWNoZWRSZW5kZXJlZFJlc3BvbnNlKTtcblx0fVxuXHRyZXR1cm4gZmV0Y2hGdWxsUnNjUGF5bG9hZCgpO1xufVxuLyoqXG4qIFdoZXRoZXIgYSBwcmVmZXRjaCByZXNwb25zZSBtYXkgYmUgZGVjb2RlZCBhcyBGbGlnaHQuIEEgc3VjY2Vzc2Z1bCByZXNwb25zZVxuKiB0aGF0IGlzIG5vdCBGbGlnaHQgKGUuZy4gYSBSb3V0ZSBIYW5kbGVyJ3MgdGV4dCBkb3dubG9hZCkgaXMgYSBtaXNzOiBkZWNvZGluZ1xuKiBpdHMgYnl0ZXMgd291bGQgbGV0IHRleHQgc2hhcGVkIGxpa2UgRmxpZ2h0IHJlc291cmNlIGhpbnRzIGluc2VydCBzY3JpcHRzLlxuKiBOYXZpZ2F0aW9uIHRoZW4gZmV0Y2hlcyBpdCBhbmQgZmFsbHMgYmFjayB0byBhIGRvY3VtZW50IG5hdmlnYXRpb24uXG4qXG4qIFBvcnRlZCBmcm9tIE5leHQuanM6IGZldGNoUHJlZmV0Y2hSZXNwb25zZSBpblxuKiBwYWNrYWdlcy9uZXh0L3NyYy9jbGllbnQvY29tcG9uZW50cy9zZWdtZW50LWNhY2hlL2NhY2hlLnRzLCB3aGljaCBza2lwcyB0aGVcbiogY2hlY2sgaW4gYG91dHB1dDogXCJleHBvcnRcImAgYmVjYXVzZSBhIHN0YXRpYyBob3N0LCBub3QgTmV4dC5qcywgY2hvb3NlcyB0aGVcbiogTUlNRSB0eXBlIG9mIHRoZSBleHBvcnRlZCBgLnR4dGAgcGF5bG9hZHMuXG4qL1xuZnVuY3Rpb24gaXNGbGlnaHRQcmVmZXRjaFJlc3BvbnNlKHJlc3BvbnNlKSB7XG5cdGlmICghcmVzcG9uc2Uub2spIHJldHVybiBmYWxzZTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiAmJiBwcm9jZXNzLmVudi5fX05FWFRfQ09ORklHX09VVFBVVCA9PT0gXCJleHBvcnRcIikgcmV0dXJuIHRydWU7XG5cdHJldHVybiByZXNwb25zZS5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKT8udG9Mb3dlckNhc2UoKS5zdGFydHNXaXRoKFZJTkVYVF9SU0NfQ09OVEVOVF9UWVBFKSA9PT0gdHJ1ZTtcbn1cbi8qKlxuKiBQcmVmZXRjaCBhbiBSU0MgcmVzcG9uc2UgYW5kIHNuYXBzaG90IGl0IGZvciBsYXRlciBjb25zdW1wdGlvbi5cbiogU3RvcmVzIHRoZSBpbi1mbGlnaHQgcHJvbWlzZSBzbyBpbW1lZGlhdGUgY2xpY2tzIGNhbiBhd2FpdCBpdCBpbnN0ZWFkXG4qIG9mIGZpcmluZyBhIGR1cGxpY2F0ZSBmZXRjaC5cbiogRW5mb3JjZXMgYSBtYXhpbXVtIGNhY2hlIHNpemUgdG8gcHJldmVudCB1bmJvdW5kZWQgbWVtb3J5IGdyb3d0aCBvblxuKiBsaW5rLWhlYXZ5IHBhZ2VzLlxuKi9cbmZ1bmN0aW9uIHByZWZldGNoUnNjUmVzcG9uc2UocnNjVXJsLCBmZXRjaFByb21pc2UsIGludGVyY2VwdGlvbkNvbnRleHQgPSBudWxsLCBtb3VudGVkU2xvdHNIZWFkZXIgPSBudWxsLCBvcHRpb25zLCBiZWhhdmlvciA9IHt9KSB7XG5cdGNvbnN0IGNhY2hlS2V5ID0gQXBwRWxlbWVudHNXaXJlLmVuY29kZUNhY2hlS2V5KHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCk7XG5cdGNvbnN0IGNhY2hlID0gZ2V0UHJlZmV0Y2hDYWNoZSgpO1xuXHRjb25zdCBwcmVmZXRjaGVkID0gZ2V0UHJlZmV0Y2hlZFVybHMoKTtcblx0Y29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcblx0Y29uc3QgZXhpc3RpbmcgPSBjYWNoZS5nZXQoY2FjaGVLZXkpO1xuXHRjb25zdCBjYWNoZUZvck5hdmlnYXRpb24gPSBiZWhhdmlvci5jYWNoZUZvck5hdmlnYXRpb24gPz8gdHJ1ZTtcblx0aWYgKGV4aXN0aW5nKSBkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIHByZWZldGNoZWQsIGNhY2hlS2V5LCBleGlzdGluZywgZmFsc2UpO1xuXHRjb25zdCBlbnRyeSA9IHtcblx0XHRjYWNoZUZvck5hdmlnYXRpb24sXG5cdFx0Y2FjaGVLZXlzOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbY2FjaGVLZXldKSxcblx0XHRtb3VudGVkU2xvdHNIZWFkZXIsXG5cdFx0b3B0aW1pc3RpY1JvdXRlU2hlbGw6IGJlaGF2aW9yLm9wdGltaXN0aWNSb3V0ZVNoZWxsID09PSB0cnVlLFxuXHRcdG91dGNvbWU6IFwicGVuZGluZ1wiLFxuXHRcdHByZWZldGNoS2luZDogYmVoYXZpb3IucHJlZmV0Y2hLaW5kID8/IChiZWhhdmlvci5vcHRpbWlzdGljUm91dGVTaGVsbCA9PT0gdHJ1ZSA/IFwibG9hZGluZy1zaGVsbFwiIDogXCJuYXZpZ2F0aW9uXCIpLFxuXHRcdHNlYXJjaEFnbm9zdGljU2hlbGw6IGJlaGF2aW9yLnNlYXJjaEFnbm9zdGljU2hlbGwgPT09IHRydWUsXG5cdFx0dGltZXN0YW1wOiBub3dcblx0fTtcblx0aWYgKGJlaGF2aW9yLmR5bmFtaWNTdGFsZVRpbWUgPT09IFwibGVhcm5pbmctb25seVwiICYmIGJlaGF2aW9yLnNlYXJjaEFnbm9zdGljU2hlbGwgIT09IHRydWUpIHtcblx0XHRlbnRyeS5keW5hbWljU3RhbGVUaW1lID0gXCJsZWFybmluZy1vbmx5XCI7XG5cdFx0ZW50cnkuZmFsbGJhY2tUdGxNcyA9IGJlaGF2aW9yLmZhbGxiYWNrVHRsTXMgPz8gUFJFRkVUQ0hfQ0FDSEVfVFRMO1xuXHR9IGVsc2UgaWYgKGJlaGF2aW9yLmR5bmFtaWNTdGFsZVRpbWUgPT09IFwiZnVsbC1wcmVmZXRjaFwiKSBlbnRyeS5keW5hbWljU3RhbGVUaW1lID0gXCJmdWxsLXByZWZldGNoXCI7XG5cdGFkZFByZWZldGNoSW52YWxpZGF0aW9uQ2FsbGJhY2soZW50cnksIG9wdGlvbnM/Lm9uSW52YWxpZGF0ZSk7XG5cdGVudHJ5LmZldGNoUHJvbWlzZSA9IGZldGNoUHJvbWlzZTtcblx0ZW50cnkucGVuZGluZyA9IGZldGNoUHJvbWlzZS50aGVuKGFzeW5jIChyZXNwb25zZSkgPT4ge1xuXHRcdGlmIChpc0ZsaWdodFByZWZldGNoUmVzcG9uc2UocmVzcG9uc2UpKSB7XG5cdFx0XHRjb25zdCBzbmFwc2hvdCA9IGF3YWl0IHNuYXBzaG90UnNjUmVzcG9uc2UocmVzcG9uc2UpO1xuXHRcdFx0aWYgKGNhY2hlLmdldChjYWNoZUtleSkgIT09IGVudHJ5KSByZXR1cm47XG5cdFx0XHRjb25zdCBwcmV2aW91c1NpemUgPSBnZXRQcmVmZXRjaENhY2hlRW50cnlTaXplKGVudHJ5KTtcblx0XHRcdGVudHJ5LnNuYXBzaG90ID0gc25hcHNob3Q7XG5cdFx0XHRlbnRyeS5zaXplID0gc25hcHNob3QuYnVmZmVyLmJ5dGVMZW5ndGg7XG5cdFx0XHRhZGp1c3RQcmVmZXRjaENhY2hlQnl0ZVNpemUoY2FjaGUsIGVudHJ5LnNpemUgLSBwcmV2aW91c1NpemUpO1xuXHRcdFx0Y29uc3QgZmFsbGJhY2tUdGxNcyA9IGJlaGF2aW9yLmZhbGxiYWNrVHRsTXMgPz8gUFJFRkVUQ0hfQ0FDSEVfVFRMO1xuXHRcdFx0Y29uc3QgZHluYW1pY1N0YWxlVGltZSA9IGJlaGF2aW9yLnNlYXJjaEFnbm9zdGljU2hlbGwgPT09IHRydWUgPyBcImlnbm9yZVwiIDogZW50cnkuZHluYW1pY1N0YWxlVGltZSA/PyBiZWhhdmlvci5keW5hbWljU3RhbGVUaW1lID8/IChiZWhhdmlvci5vcHRpbWlzdGljUm91dGVTaGVsbCA9PT0gdHJ1ZSA/IFwiaWdub3JlXCIgOiBcInZlcmJhdGltXCIpO1xuXHRcdFx0aWYgKGR5bmFtaWNTdGFsZVRpbWUgPT09IFwibGVhcm5pbmctb25seVwiICYmIGlzU3RhbGVUaW1lU2Vjb25kcyhzbmFwc2hvdC5keW5hbWljU3RhbGVUaW1lU2Vjb25kcykpIHtcblx0XHRcdFx0ZW50cnkuY2FjaGVGb3JOYXZpZ2F0aW9uID0gZmFsc2U7XG5cdFx0XHRcdGVudHJ5LmV4cGlyZXNBdCA9IGVudHJ5LnRpbWVzdGFtcCArIE1hdGgubWF4KGZhbGxiYWNrVHRsTXMsIE1JTl9QUkVGRVRDSF9TVEFMRV9USU1FX01TKTtcblx0XHRcdH0gZWxzZSBlbnRyeS5leHBpcmVzQXQgPSByZXNvbHZlUHJlZmV0Y2hlZFJzY1Jlc3BvbnNlRXhwaXJlc0F0KGVudHJ5LnRpbWVzdGFtcCwgZW50cnkuc25hcHNob3QsIGZhbGxiYWNrVHRsTXMsIGR5bmFtaWNTdGFsZVRpbWUgPT09IFwibGVhcm5pbmctb25seVwiID8gXCJ2ZXJiYXRpbVwiIDogZHluYW1pY1N0YWxlVGltZSk7XG5cdFx0XHRpZiAoYmVoYXZpb3IucHJlcGFyZVNuYXBzaG90ICYmIGVudHJ5LmNhY2hlRm9yTmF2aWdhdGlvbiAmJiBzbmFwc2hvdC5yZWRpcmVjdEhlYWRlciA9PT0gdm9pZCAwKSB0cnkge1xuXHRcdFx0XHRjb25zdCBwcmVwYXJlZEVsZW1lbnRzID0gYXdhaXQgYmVoYXZpb3IucHJlcGFyZVNuYXBzaG90KHNuYXBzaG90KTtcblx0XHRcdFx0aWYgKGNhY2hlLmdldChjYWNoZUtleSkgIT09IGVudHJ5KSByZXR1cm47XG5cdFx0XHRcdGVudHJ5LnByZXBhcmVkRWxlbWVudHMgPSBwcmVwYXJlZEVsZW1lbnRzO1xuXHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0YWRkUmVuZGVyZWRQYXRoQW5kU2VhcmNoUHJlZmV0Y2hBbGlhcyhjYWNoZSwgcHJlZmV0Y2hlZCwgY2FjaGVLZXksIGVudHJ5KTtcblx0XHRcdGV2aWN0UHJlZmV0Y2hDYWNoZUlmTmVlZGVkKCk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHJlbGVhc2VBcHBQcmVmZXRjaEZldGNoU2xvdChyZXNwb25zZSk7XG5cdFx0XHRyZXNwb25zZS5ib2R5Py5jYW5jZWwoKS5jYXRjaCgoKSA9PiB7fSk7XG5cdFx0XHRkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIHByZWZldGNoZWQsIGNhY2hlS2V5LCBlbnRyeSwgZmFsc2UpO1xuXHRcdH1cblx0fSkuY2F0Y2goKCkgPT4ge1xuXHRcdGRlbGV0ZVByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgcHJlZmV0Y2hlZCwgY2FjaGVLZXksIGVudHJ5LCBmYWxzZSk7XG5cdH0pLmZpbmFsbHkoKCkgPT4ge1xuXHRcdGlmIChjYWNoZS5nZXQoY2FjaGVLZXkpICE9PSBlbnRyeSkgcmV0dXJuO1xuXHRcdGVudHJ5LnBlbmRpbmcgPSB2b2lkIDA7XG5cdFx0ZW50cnkuZmV0Y2hQcm9taXNlID0gdm9pZCAwO1xuXHRcdGlmIChlbnRyeS5zbmFwc2hvdCkge1xuXHRcdFx0ZW50cnkub3V0Y29tZSA9IFwiY2FjaGUtc2VlZGVkXCI7XG5cdFx0XHRzY2hlZHVsZVByZWZldGNoSW52YWxpZGF0aW9uKGNhY2hlS2V5LCBlbnRyeSk7XG5cdFx0fVxuXHR9KTtcblx0Y2FjaGUuc2V0KGNhY2hlS2V5LCBlbnRyeSk7XG5cdGV2aWN0UHJlZmV0Y2hDYWNoZUlmTmVlZGVkKCk7XG59XG5mdW5jdGlvbiBhZGRSZW5kZXJlZFBhdGhBbmRTZWFyY2hQcmVmZXRjaEFsaWFzKGNhY2hlLCBwcmVmZXRjaGVkLCBwcmltYXJ5Q2FjaGVLZXksIGVudHJ5KSB7XG5cdGlmIChlbnRyeS5jYWNoZUZvck5hdmlnYXRpb24gPT09IGZhbHNlKSByZXR1cm47XG5cdGNvbnN0IHJlbmRlcmVkUGF0aEFuZFNlYXJjaCA9IGVudHJ5LnNuYXBzaG90Py5yZW5kZXJlZFBhdGhBbmRTZWFyY2g7XG5cdGlmICghcmVuZGVyZWRQYXRoQW5kU2VhcmNoKSByZXR1cm47XG5cdGNvbnN0IHNvdXJjZSA9IHBhcnNlUHJlZmV0Y2hDYWNoZUtleShwcmltYXJ5Q2FjaGVLZXkpO1xuXHRjb25zdCBhbGlhc0NhY2hlS2V5ID0gQXBwRWxlbWVudHNXaXJlLmVuY29kZUNhY2hlS2V5KHJlbmRlcmVkUGF0aEFuZFNlYXJjaCwgc291cmNlLmludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRpZiAoYWxpYXNDYWNoZUtleSA9PT0gcHJpbWFyeUNhY2hlS2V5KSByZXR1cm47XG5cdGNvbnN0IGV4aXN0aW5nID0gY2FjaGUuZ2V0KGFsaWFzQ2FjaGVLZXkpO1xuXHRpZiAoZXhpc3RpbmcgJiYgZXhpc3RpbmcgIT09IGVudHJ5KSBkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIHByZWZldGNoZWQsIGFsaWFzQ2FjaGVLZXksIGV4aXN0aW5nLCBmYWxzZSk7XG5cdGVudHJ5LmNhY2hlS2V5cyA/Pz0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW3ByaW1hcnlDYWNoZUtleV0pO1xuXHRlbnRyeS5jYWNoZUtleXMuYWRkKGFsaWFzQ2FjaGVLZXkpO1xuXHRjYWNoZS5zZXQoYWxpYXNDYWNoZUtleSwgZW50cnkpO1xuXHRwcmVmZXRjaGVkLmFkZChhbGlhc0NhY2hlS2V5KTtcbn1cbmZ1bmN0aW9uIHBlZWtQcmVmZXRjaFJlc3BvbnNlRm9yTmF2aWdhdGlvbihyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQgPSBudWxsLCBtb3VudGVkU2xvdHNIZWFkZXIgPSBudWxsLCBvcHRpb25zKSB7XG5cdGNvbnN0IG1hdGNoID0gZmluZFByZWZldGNoQ2FjaGVFbnRyeUZvck5hdmlnYXRpb24ocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIsIG9wdGlvbnM/LmFkZGl0aW9uYWxSc2NVcmxzKTtcblx0aWYgKCFtYXRjaCkgcmV0dXJuIG51bGw7XG5cdGNvbnN0IHsgY2FjaGVLZXksIGVudHJ5IH0gPSBtYXRjaDtcblx0aWYgKGVudHJ5LnBlbmRpbmcgfHwgZW50cnkub3V0Y29tZSAhPT0gXCJjYWNoZS1zZWVkZWRcIikgcmV0dXJuIG51bGw7XG5cdGlmIChlbnRyeS5jYWNoZUZvck5hdmlnYXRpb24gPT09IGZhbHNlIHx8ICFlbnRyeS5zbmFwc2hvdCkgcmV0dXJuIG51bGw7XG5cdGlmIChyZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5RXhwaXJlc0F0KGVudHJ5KSA8PSBEYXRlLm5vdygpKSB7XG5cdFx0ZGVsZXRlUHJlZmV0Y2hDYWNoZUVudHJ5KGdldFByZWZldGNoQ2FjaGUoKSwgZ2V0UHJlZmV0Y2hlZFVybHMoKSwgY2FjaGVLZXksIGVudHJ5LCB0cnVlKTtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxuXHRpZiAoZW50cnkuZXhwaXJlc0F0ICE9PSB2b2lkIDAgfHwgZW50cnkuc25hcHNob3QuZXhwaXJlc0F0ICE9PSB2b2lkIDApIHJldHVybiB7XG5cdFx0Li4uZW50cnkuc25hcHNob3QsXG5cdFx0ZXhwaXJlc0F0OiByZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5RXhwaXJlc0F0KGVudHJ5KVxuXHR9O1xuXHRyZXR1cm4gZW50cnkuc25hcHNob3Q7XG59XG4vKipcbiogQ29uc3VtZSBhIHByZWZldGNoZWQgcmVzcG9uc2UgZm9yIGEgZ2l2ZW4gcnNjVXJsLlxuKiBPbmx5IHJldHVybnMgc2V0dGxlZCAobm9uLXBlbmRpbmcpIHNuYXBzaG90cyBzeW5jaHJvbm91c2x5LlxuKiBSZXR1cm5zIG51bGwgaWYgdGhlIGVudHJ5IGlzIHN0aWxsIGluIGZsaWdodCBvciBkb2Vzbid0IGV4aXN0LlxuKi9cbmZ1bmN0aW9uIGNvbnN1bWVQcmVmZXRjaFJlc3BvbnNlKHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCA9IG51bGwsIG1vdW50ZWRTbG90c0hlYWRlciA9IG51bGwsIG9wdGlvbnMpIHtcblx0Y29uc3QgY2FjaGUgPSBnZXRQcmVmZXRjaENhY2hlKCk7XG5cdGNvbnN0IGV4YWN0Q2FjaGVLZXkgPSBBcHBFbGVtZW50c1dpcmUuZW5jb2RlQ2FjaGVLZXkocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0KTtcblx0Y29uc3QgZXhhY3RFbnRyeSA9IGNhY2hlLmdldChleGFjdENhY2hlS2V5KTtcblx0aWYgKGV4YWN0RW50cnkgJiYgZXhhY3RFbnRyeS5jYWNoZUZvck5hdmlnYXRpb24gIT09IGZhbHNlICYmICFpc1ByZWZldGNoQ2FjaGVFbnRyeUNvbXBhdGlibGVXaXRoTW91bnRlZFNsb3RzKGV4YWN0RW50cnksIG1vdW50ZWRTbG90c0hlYWRlcikpIGRlbGV0ZVByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgZ2V0UHJlZmV0Y2hlZFVybHMoKSwgZXhhY3RDYWNoZUtleSwgZXhhY3RFbnRyeSwgZmFsc2UpO1xuXHRjb25zdCBtYXRjaCA9IGZpbmRQcmVmZXRjaENhY2hlRW50cnlGb3JOYXZpZ2F0aW9uKHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyLCBvcHRpb25zPy5hZGRpdGlvbmFsUnNjVXJscyk7XG5cdGlmICghbWF0Y2gpIHJldHVybiBudWxsO1xuXHRjb25zdCB7IGNhY2hlS2V5LCBlbnRyeSB9ID0gbWF0Y2g7XG5cdHJldHVybiBjb25zdW1lTWF0Y2hlZFByZWZldGNoUmVzcG9uc2UoY2FjaGVLZXksIGVudHJ5LCBtb3VudGVkU2xvdHNIZWFkZXIpO1xufVxuZnVuY3Rpb24gY29uc3VtZU1hdGNoZWRQcmVmZXRjaFJlc3BvbnNlKGNhY2hlS2V5LCBlbnRyeSwgbW91bnRlZFNsb3RzSGVhZGVyLCBhbGxvd0V4cGlyZWRJbkZsaWdodEhhbmRvZmYgPSBmYWxzZSkge1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0aWYgKGVudHJ5LnBlbmRpbmcgfHwgZW50cnkub3V0Y29tZSAhPT0gXCJjYWNoZS1zZWVkZWRcIikgcmV0dXJuIG51bGw7XG5cdGlmIChlbnRyeS5jYWNoZUZvck5hdmlnYXRpb24gPT09IGZhbHNlKSByZXR1cm4gbnVsbDtcblx0aWYgKGVudHJ5LnNuYXBzaG90KSB7XG5cdFx0aWYgKCFpc1ByZWZldGNoQ2FjaGVFbnRyeUNvbXBhdGlibGVXaXRoTW91bnRlZFNsb3RzKGVudHJ5LCBtb3VudGVkU2xvdHNIZWFkZXIpKSByZXR1cm4gbnVsbDtcblx0XHRpZiAoIWFsbG93RXhwaXJlZEluRmxpZ2h0SGFuZG9mZiAmJiByZXNvbHZlUHJlZmV0Y2hDYWNoZUVudHJ5RXhwaXJlc0F0KGVudHJ5KSA8PSBEYXRlLm5vdygpKSB7XG5cdFx0XHRkZWxldGVQcmVmZXRjaENhY2hlRW50cnkoY2FjaGUsIGdldFByZWZldGNoZWRVcmxzKCksIGNhY2hlS2V5LCBlbnRyeSwgdHJ1ZSk7XG5cdFx0XHRyZXR1cm4gbnVsbDtcblx0XHR9XG5cdFx0cmV0YWluUHJlZmV0Y2hJbnZhbGlkYXRpb25BZnRlckNvbnN1bWUoZW50cnkpO1xuXHRcdGRlbGV0ZVByZWZldGNoQ2FjaGVFbnRyeShjYWNoZSwgZ2V0UHJlZmV0Y2hlZFVybHMoKSwgY2FjaGVLZXksIGVudHJ5LCBmYWxzZSk7XG5cdFx0Y29uc3Qgc25hcHNob3QgPSBlbnRyeS5zbmFwc2hvdDtcblx0XHRpZiAoZW50cnkuZXhwaXJlc0F0ICE9PSB2b2lkIDAgfHwgZW50cnkuc25hcHNob3QuZXhwaXJlc0F0ICE9PSB2b2lkIDApIHJldHVybiB7XG5cdFx0XHQuLi5zbmFwc2hvdCxcblx0XHRcdGV4cGlyZXNBdDogcmVzb2x2ZVByZWZldGNoQ2FjaGVFbnRyeUV4cGlyZXNBdChlbnRyeSksXG5cdFx0XHQuLi5lbnRyeS5wcmVwYXJlZEVsZW1lbnRzID8geyBwcmVwYXJlZEVsZW1lbnRzOiBlbnRyeS5wcmVwYXJlZEVsZW1lbnRzIH0gOiB7fVxuXHRcdH07XG5cdFx0cmV0dXJuIGVudHJ5LnByZXBhcmVkRWxlbWVudHMgPyB7XG5cdFx0XHQuLi5zbmFwc2hvdCxcblx0XHRcdHByZXBhcmVkRWxlbWVudHM6IGVudHJ5LnByZXBhcmVkRWxlbWVudHNcblx0XHR9IDogc25hcHNob3Q7XG5cdH1cblx0cmV0dXJuIG51bGw7XG59XG5hc3luYyBmdW5jdGlvbiBjb25zdW1lUHJlZmV0Y2hSZXNwb25zZUZvck5hdmlnYXRpb24ocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0ID0gbnVsbCwgbW91bnRlZFNsb3RzSGVhZGVyID0gbnVsbCwgb3B0aW9ucykge1xuXHRjb25zdCBjYWNoZSA9IGdldFByZWZldGNoQ2FjaGUoKTtcblx0Y29uc3QgbWF0Y2ggPSBmaW5kUHJlZmV0Y2hDYWNoZUVudHJ5Rm9yTmF2aWdhdGlvbihyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQsIG1vdW50ZWRTbG90c0hlYWRlciwgb3B0aW9ucz8uYWRkaXRpb25hbFJzY1VybHMpO1xuXHRpZiAoIW1hdGNoKSByZXR1cm4gbnVsbDtcblx0Y29uc3QgeyBjYWNoZUtleSwgZW50cnkgfSA9IG1hdGNoO1xuXHRpZiAob3B0aW9ucz8uc2hvdWxkQ29uc3VtZT8uKCkgPT09IGZhbHNlKSByZXR1cm4gbnVsbDtcblx0Y29uc3QgYWxsb3dFeHBpcmVkSW5GbGlnaHRIYW5kb2ZmID0gZW50cnkucGVuZGluZyAhPT0gdm9pZCAwO1xuXHRpZiAoZW50cnkucGVuZGluZyAhPT0gdm9pZCAwKSB7XG5cdFx0Y29uc3QgcmVsZWFzZUNsYWltID0gcHJvbW90ZUFwcFByZWZldGNoRmV0Y2goZW50cnkuZmV0Y2hQcm9taXNlLCBvcHRpb25zPy5zaG91bGRDb25zdW1lKTtcblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgZW50cnkucGVuZGluZy5jYXRjaCgoKSA9PiB7fSk7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdHJlbGVhc2VDbGFpbSgpO1xuXHRcdH1cblx0XHRpZiAoY2FjaGUuZ2V0KGNhY2hlS2V5KSAhPT0gZW50cnkpIHJldHVybiBudWxsO1xuXHRcdGlmIChvcHRpb25zPy5zaG91bGRDb25zdW1lPy4oKSA9PT0gZmFsc2UpIHJldHVybiBudWxsO1xuXHR9XG5cdHJldHVybiBjb25zdW1lTWF0Y2hlZFByZWZldGNoUmVzcG9uc2UoY2FjaGVLZXksIGVudHJ5LCBtb3VudGVkU2xvdHNIZWFkZXIsIGFsbG93RXhwaXJlZEluRmxpZ2h0SGFuZG9mZik7XG59XG5jb25zdCBfQ0xJRU5UX05BVl9TVEFURV9LRVkgPSBTeW1ib2wuZm9yKFwidmluZXh0LmNsaWVudE5hdmlnYXRpb25TdGF0ZVwiKTtcbmNvbnN0IF9NT1VOVEVEX1NMT1RTX0hFQURFUl9LRVkgPSBTeW1ib2wuZm9yKFwidmluZXh0Lm1vdW50ZWRTbG90c0hlYWRlclwiKTtcbmZ1bmN0aW9uIHNldE1vdW50ZWRTbG90c0hlYWRlcihoZWFkZXIpIHtcblx0aWYgKGlzU2VydmVyKSByZXR1cm47XG5cdGNvbnN0IGdsb2JhbFN0YXRlID0gd2luZG93O1xuXHRnbG9iYWxTdGF0ZVtfTU9VTlRFRF9TTE9UU19IRUFERVJfS0VZXSA9IGhlYWRlcjtcbn1cbmZ1bmN0aW9uIGdldE1vdW50ZWRTbG90c0hlYWRlcigpIHtcblx0aWYgKGlzU2VydmVyKSByZXR1cm4gbnVsbDtcblx0cmV0dXJuIHdpbmRvd1tfTU9VTlRFRF9TTE9UU19IRUFERVJfS0VZXSA/PyBudWxsO1xufVxuZnVuY3Rpb24gZ2V0Q2xpZW50TmF2aWdhdGlvblN0YXRlKCkge1xuXHRpZiAoaXNTZXJ2ZXIpIHJldHVybiBudWxsO1xuXHRjb25zdCBnbG9iYWxTdGF0ZSA9IHdpbmRvdztcblx0Z2xvYmFsU3RhdGVbX0NMSUVOVF9OQVZfU1RBVEVfS0VZXSA/Pz0ge1xuXHRcdGxpc3RlbmVyczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcblx0XHRjYWNoZWRTZWFyY2g6IHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gsXG5cdFx0Y2FjaGVkUmVhZG9ubHlTZWFyY2hQYXJhbXM6IG5ldyBSZWFkb25seVVSTFNlYXJjaFBhcmFtcyh3aW5kb3cubG9jYXRpb24uc2VhcmNoKSxcblx0XHRjYWNoZWRQYXRobmFtZTogc3RyaXBCYXNlUGF0aCh3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUsIF9fYmFzZVBhdGgpLFxuXHRcdGNsaWVudFBhcmFtczoge30sXG5cdFx0Y2xpZW50UGFyYW1zSnNvbjogXCJ7fVwiLFxuXHRcdHBlbmRpbmdDbGllbnRQYXJhbXM6IG51bGwsXG5cdFx0cGVuZGluZ0NsaWVudFBhcmFtc0pzb246IG51bGwsXG5cdFx0cGVuZGluZ1BhdGhuYW1lOiBudWxsLFxuXHRcdHBlbmRpbmdQYXRobmFtZU5hdklkOiBudWxsLFxuXHRcdG9yaWdpbmFsUHVzaFN0YXRlOiB3aW5kb3cuaGlzdG9yeS5wdXNoU3RhdGUuYmluZCh3aW5kb3cuaGlzdG9yeSksXG5cdFx0b3JpZ2luYWxSZXBsYWNlU3RhdGU6IHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZS5iaW5kKHdpbmRvdy5oaXN0b3J5KSxcblx0XHRwYXRjaEluc3RhbGxlZDogZmFsc2UsXG5cdFx0cm91dGVySGlzdG9yeVdyaXRlRGVwdGg6IDAsXG5cdFx0cm91dGVySGlzdG9yeVdyaXRlOiBudWxsLFxuXHRcdGhhc1BlbmRpbmdOYXZpZ2F0aW9uVXBkYXRlOiBmYWxzZSxcblx0XHRzdXBwcmVzc1VybE5vdGlmeUNvdW50OiAwLFxuXHRcdG5hdmlnYXRpb25TbmFwc2hvdEFjdGl2ZUNvdW50OiAwXG5cdH07XG5cdHJldHVybiBnbG9iYWxTdGF0ZVtfQ0xJRU5UX05BVl9TVEFURV9LRVldO1xufVxuZnVuY3Rpb24gbm90aWZ5TmF2aWdhdGlvbkxpc3RlbmVycygpIHtcblx0Y29uc3Qgc3RhdGUgPSBnZXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKTtcblx0aWYgKCFzdGF0ZSkgcmV0dXJuO1xuXHRmb3IgKGNvbnN0IGZuIG9mIHN0YXRlLmxpc3RlbmVycykgZm4oKTtcbn1cbmlmICghaXNTZXJ2ZXIpIGdsb2JhbFRoaXNbUEFHRVNfTkFWSUdBVElPTl9OT1RJRllfS0VZXSA9IG5vdGlmeU5hdmlnYXRpb25MaXN0ZW5lcnM7XG5sZXQgX2NhY2hlZEVtcHR5U2VydmVyU2VhcmNoUGFyYW1zID0gbnVsbDtcbmNvbnN0IF9yZWFkb25seVBhZ2VzU2VhcmNoUGFyYW1zQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmxldCBfY2FjaGVkUmVhZG9ubHlQYWdlc1NlYXJjaFBhcmFtc0tleSA9IG51bGw7XG5sZXQgX2NhY2hlZFJlYWRvbmx5UGFnZXNTZWFyY2hQYXJhbXMgPSBudWxsO1xuZnVuY3Rpb24gZ2V0UmVhZG9ubHlQYWdlc1NlYXJjaFBhcmFtcyhzZWFyY2hQYXJhbXMpIHtcblx0Y29uc3QgY2FjaGVkID0gX3JlYWRvbmx5UGFnZXNTZWFyY2hQYXJhbXNDYWNoZS5nZXQoc2VhcmNoUGFyYW1zKTtcblx0aWYgKGNhY2hlZCkgcmV0dXJuIGNhY2hlZDtcblx0Y29uc3Qga2V5ID0gc2VhcmNoUGFyYW1zLnRvU3RyaW5nKCk7XG5cdGlmIChfY2FjaGVkUmVhZG9ubHlQYWdlc1NlYXJjaFBhcmFtc0tleSA9PT0ga2V5ICYmIF9jYWNoZWRSZWFkb25seVBhZ2VzU2VhcmNoUGFyYW1zKSB7XG5cdFx0X3JlYWRvbmx5UGFnZXNTZWFyY2hQYXJhbXNDYWNoZS5zZXQoc2VhcmNoUGFyYW1zLCBfY2FjaGVkUmVhZG9ubHlQYWdlc1NlYXJjaFBhcmFtcyk7XG5cdFx0cmV0dXJuIF9jYWNoZWRSZWFkb25seVBhZ2VzU2VhcmNoUGFyYW1zO1xuXHR9XG5cdGNvbnN0IHJlYWRvbmx5ID0gbmV3IFJlYWRvbmx5VVJMU2VhcmNoUGFyYW1zKHNlYXJjaFBhcmFtcyk7XG5cdF9yZWFkb25seVBhZ2VzU2VhcmNoUGFyYW1zQ2FjaGUuc2V0KHNlYXJjaFBhcmFtcywgcmVhZG9ubHkpO1xuXHRfY2FjaGVkUmVhZG9ubHlQYWdlc1NlYXJjaFBhcmFtc0tleSA9IGtleTtcblx0X2NhY2hlZFJlYWRvbmx5UGFnZXNTZWFyY2hQYXJhbXMgPSByZWFkb25seTtcblx0cmV0dXJuIHJlYWRvbmx5O1xufVxuLyoqXG4qIEdldCBjYWNoZWQgcGF0aG5hbWUgc25hcHNob3QgZm9yIHVzZVN5bmNFeHRlcm5hbFN0b3JlLlxuKiBOb3RlOiBSZXR1cm5zIGNhY2hlZCB2YWx1ZSBmcm9tIENsaWVudE5hdmlnYXRpb25TdGF0ZSwgbm90IGxpdmUgd2luZG93LmxvY2F0aW9uLlxuKiBUaGUgY2FjaGUgaXMgdXBkYXRlZCBieSBzeW5jQ29tbWl0dGVkVXJsU3RhdGVGcm9tTG9jYXRpb24oKSBhZnRlciBuYXZpZ2F0aW9uIGNvbW1pdHMuXG4qIFRoaXMgZW5zdXJlcyByZWZlcmVudGlhbCBzdGFiaWxpdHkgYW5kIHByZXZlbnRzIGluZmluaXRlIHJlLXJlbmRlcnMuXG4qIEV4dGVybmFsIHB1c2hTdGF0ZS9yZXBsYWNlU3RhdGUgd2hpbGUgVVJMIG5vdGlmaWNhdGlvbnMgYXJlIHN1cHByZXNzZWQgd29uJ3RcbiogYmUgdmlzaWJsZSB1bnRpbCB0aGUgbmV4dCBjb21taXQuXG4qL1xuZnVuY3Rpb24gZ2V0UGF0aG5hbWVTbmFwc2hvdCgpIHtcblx0Y29uc3QgcGFnZXNDdHggPSBnZXRQYWdlc05hdmlnYXRpb25Db250ZXh0KCk7XG5cdGlmIChwYWdlc0N0eCkgcmV0dXJuIHBhZ2VzQ3R4LnBhdGhuYW1lO1xuXHRyZXR1cm4gZ2V0Q2xpZW50TmF2aWdhdGlvblN0YXRlKCk/LmNhY2hlZFBhdGhuYW1lID8/IFwiL1wiO1xufVxubGV0IF9jYWNoZWRFbXB0eUNsaWVudFNlYXJjaFBhcmFtcyA9IG51bGw7XG4vKipcbiogR2V0IGNhY2hlZCBzZWFyY2ggcGFyYW1zIHNuYXBzaG90IGZvciB1c2VTeW5jRXh0ZXJuYWxTdG9yZS5cbiogTm90ZTogUmV0dXJucyBjYWNoZWQgdmFsdWUgZnJvbSBDbGllbnROYXZpZ2F0aW9uU3RhdGUsIG5vdCBsaXZlIHdpbmRvdy5sb2NhdGlvbi5zZWFyY2guXG4qIFRoZSBjYWNoZSBpcyB1cGRhdGVkIGJ5IHN5bmNDb21taXR0ZWRVcmxTdGF0ZUZyb21Mb2NhdGlvbigpIGFmdGVyIG5hdmlnYXRpb24gY29tbWl0cy5cbiogVGhpcyBlbnN1cmVzIHJlZmVyZW50aWFsIHN0YWJpbGl0eSBhbmQgcHJldmVudHMgaW5maW5pdGUgcmUtcmVuZGVycy5cbiogRXh0ZXJuYWwgcHVzaFN0YXRlL3JlcGxhY2VTdGF0ZSB3aGlsZSBVUkwgbm90aWZpY2F0aW9ucyBhcmUgc3VwcHJlc3NlZCB3b24ndFxuKiBiZSB2aXNpYmxlIHVudGlsIHRoZSBuZXh0IGNvbW1pdC5cbiovXG5mdW5jdGlvbiBnZXRTZWFyY2hQYXJhbXNTbmFwc2hvdCgpIHtcblx0Y29uc3QgaGFzQXBwQ29udGV4dCA9IGdldE5hdmlnYXRpb25Db250ZXh0KCkgIT09IG51bGw7XG5cdGNvbnN0IHBhZ2VzQ3R4ID0gZ2V0UGFnZXNOYXZpZ2F0aW9uQ29udGV4dCgpO1xuXHRpZiAoIWhhc0FwcENvbnRleHQgJiYgcGFnZXNDdHgpIHJldHVybiBnZXRSZWFkb25seVBhZ2VzU2VhcmNoUGFyYW1zKHBhZ2VzQ3R4LnNlYXJjaFBhcmFtcyk7XG5cdGNvbnN0IHN0YXRlID0gZ2V0Q2xpZW50TmF2aWdhdGlvblN0YXRlKCk7XG5cdGlmIChzdGF0ZSkge1xuXHRcdGlmIChoYXNBcHBDb250ZXh0KSBhZG9wdEh5ZHJhdGlvblNlYXJjaFBhcmFtcyhzdGF0ZSk7XG5cdFx0cmV0dXJuIHN0YXRlLmNhY2hlZFJlYWRvbmx5U2VhcmNoUGFyYW1zO1xuXHR9XG5cdGlmIChfY2FjaGVkRW1wdHlDbGllbnRTZWFyY2hQYXJhbXMgPT09IG51bGwpIF9jYWNoZWRFbXB0eUNsaWVudFNlYXJjaFBhcmFtcyA9IG5ldyBSZWFkb25seVVSTFNlYXJjaFBhcmFtcygpO1xuXHRyZXR1cm4gX2NhY2hlZEVtcHR5Q2xpZW50U2VhcmNoUGFyYW1zO1xufVxubGV0IF9jb21wYXJlZEh5ZHJhdGlvblNlYXJjaFBhcmFtcyA9IG51bGw7XG4vKipcbiogS2VlcCB0aGUgaHlkcmF0ZWQgc2VhcmNoIHBhcmFtcyBvYmplY3Qgd2hlbiB0aGUgYnJvd3NlciBVUkwgaGFzIHRoZSBzYW1lXG4qIHF1ZXJ5LiBSZWFjdCBjb21wYXJlcyB0aGUgdHdvIHNuYXBzaG90cyBieSBpZGVudGl0eSBvbmNlIGh5ZHJhdGVkLCBzbyBhIG5ld1xuKiBvYmplY3Qgd291bGQgcmUtcmVuZGVyIGV2ZXJ5IHVzZVNlYXJjaFBhcmFtcygpIGNhbGxlciBhbmQgcmUtcnVuIGVmZmVjdHNcbioga2V5ZWQgb24gaXQsIHdoZXJlIE5leHQuanMga2VlcHMgb25lIG9iamVjdCBmcm9tIHRoZSBmaXJzdCByZW5kZXIuXG4qL1xuZnVuY3Rpb24gYWRvcHRIeWRyYXRpb25TZWFyY2hQYXJhbXMoc3RhdGUpIHtcblx0Y29uc3QgaHlkcmF0ZWQgPSBnZXRTZXJ2ZXJTZWFyY2hQYXJhbXNTbmFwc2hvdCgpO1xuXHRpZiAoaHlkcmF0ZWQgPT09IHN0YXRlLmNhY2hlZFJlYWRvbmx5U2VhcmNoUGFyYW1zKSByZXR1cm47XG5cdGlmIChoeWRyYXRlZCA9PT0gX2NvbXBhcmVkSHlkcmF0aW9uU2VhcmNoUGFyYW1zKSByZXR1cm47XG5cdF9jb21wYXJlZEh5ZHJhdGlvblNlYXJjaFBhcmFtcyA9IGh5ZHJhdGVkO1xuXHRpZiAoaHlkcmF0ZWQudG9TdHJpbmcoKSA9PT0gc3RhdGUuY2FjaGVkUmVhZG9ubHlTZWFyY2hQYXJhbXMudG9TdHJpbmcoKSkgc3RhdGUuY2FjaGVkUmVhZG9ubHlTZWFyY2hQYXJhbXMgPSBoeWRyYXRlZDtcbn1cbmZ1bmN0aW9uIHN5bmNDb21taXR0ZWRVcmxTdGF0ZUZyb21Mb2NhdGlvbigpIHtcblx0Y29uc3Qgc3RhdGUgPSBnZXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKTtcblx0aWYgKCFzdGF0ZSkgcmV0dXJuIGZhbHNlO1xuXHRsZXQgY2hhbmdlZCA9IGZhbHNlO1xuXHRjb25zdCBwYXRobmFtZSA9IHN0cmlwQmFzZVBhdGgod2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLCBfX2Jhc2VQYXRoKTtcblx0aWYgKHBhdGhuYW1lICE9PSBzdGF0ZS5jYWNoZWRQYXRobmFtZSkge1xuXHRcdHN0YXRlLmNhY2hlZFBhdGhuYW1lID0gcGF0aG5hbWU7XG5cdFx0Y2hhbmdlZCA9IHRydWU7XG5cdH1cblx0Y29uc3Qgc2VhcmNoID0gd2luZG93LmxvY2F0aW9uLnNlYXJjaDtcblx0aWYgKHNlYXJjaCAhPT0gc3RhdGUuY2FjaGVkU2VhcmNoKSB7XG5cdFx0c3RhdGUuY2FjaGVkU2VhcmNoID0gc2VhcmNoO1xuXHRcdHN0YXRlLmNhY2hlZFJlYWRvbmx5U2VhcmNoUGFyYW1zID0gbmV3IFJlYWRvbmx5VVJMU2VhcmNoUGFyYW1zKHNlYXJjaCk7XG5cdFx0Y2hhbmdlZCA9IHRydWU7XG5cdH1cblx0cmV0dXJuIGNoYW5nZWQ7XG59XG5mdW5jdGlvbiBnZXRTZXJ2ZXJTZWFyY2hQYXJhbXNTbmFwc2hvdCgpIHtcblx0Y29uc3QgY3R4ID0gZ2V0TmF2aWdhdGlvbkNvbnRleHQoKTtcblx0aWYgKCFjdHgpIHtcblx0XHRjb25zdCBwYWdlc0N0eCA9IGdldFBhZ2VzTmF2aWdhdGlvbkNvbnRleHQoKTtcblx0XHRpZiAocGFnZXNDdHgpIHJldHVybiBnZXRSZWFkb25seVBhZ2VzU2VhcmNoUGFyYW1zKHBhZ2VzQ3R4LnNlYXJjaFBhcmFtcyk7XG5cdFx0aWYgKF9jYWNoZWRFbXB0eVNlcnZlclNlYXJjaFBhcmFtcyA9PT0gbnVsbCkgX2NhY2hlZEVtcHR5U2VydmVyU2VhcmNoUGFyYW1zID0gbmV3IFJlYWRvbmx5VVJMU2VhcmNoUGFyYW1zKCk7XG5cdFx0cmV0dXJuIF9jYWNoZWRFbXB0eVNlcnZlclNlYXJjaFBhcmFtcztcblx0fVxuXHRjb25zdCBzb3VyY2UgPSBjdHguc2VhcmNoUGFyYW1zO1xuXHRjb25zdCBjYWNoZWQgPSBjdHhbX1JFQURPTkxZX1NFQVJDSF9QQVJBTVNdO1xuXHRjb25zdCBjYWNoZWRTb3VyY2UgPSBjdHhbX1JFQURPTkxZX1NFQVJDSF9QQVJBTVNfU09VUkNFXTtcblx0aWYgKGNhY2hlZCAmJiBjYWNoZWRTb3VyY2UgPT09IHNvdXJjZSkgcmV0dXJuIGNhY2hlZDtcblx0Y29uc3Qgc291cmNlS2V5ID0gc291cmNlLnRvU3RyaW5nKCk7XG5cdGlmIChjYWNoZWQgJiYgY3R4W19SRUFET05MWV9TRUFSQ0hfUEFSQU1TX1NPVVJDRV9LRVldID09PSBzb3VyY2VLZXkpIHtcblx0XHRjdHhbX1JFQURPTkxZX1NFQVJDSF9QQVJBTVNfU09VUkNFXSA9IHNvdXJjZTtcblx0XHRyZXR1cm4gY2FjaGVkO1xuXHR9XG5cdGNvbnN0IHJlYWRvbmx5ID0gbmV3IFJlYWRvbmx5VVJMU2VhcmNoUGFyYW1zKHNvdXJjZSk7XG5cdGN0eFtfUkVBRE9OTFlfU0VBUkNIX1BBUkFNU10gPSByZWFkb25seTtcblx0Y3R4W19SRUFET05MWV9TRUFSQ0hfUEFSQU1TX1NPVVJDRV0gPSBzb3VyY2U7XG5cdGN0eFtfUkVBRE9OTFlfU0VBUkNIX1BBUkFNU19TT1VSQ0VfS0VZXSA9IHNvdXJjZUtleTtcblx0cmV0dXJuIHJlYWRvbmx5O1xufVxuLyoqXG4qIE1hcmsgYSBuYXZpZ2F0aW9uIHNuYXBzaG90IGFzIGFjdGl2ZS4gQ2FsbGVkIGJlZm9yZSBzdGFydFRyYW5zaXRpb25cbiogaW4gcmVuZGVyTmF2aWdhdGlvblBheWxvYWQuIFdoaWxlIGFjdGl2ZSwgaG9va3MgcHJlZmVyIHRoZSBzbmFwc2hvdFxuKiBjb250ZXh0IHZhbHVlIG92ZXIgdXNlU3luY0V4dGVybmFsU3RvcmUuIFVzZXMgYSBjb3VudGVyIChub3QgYm9vbGVhbilcbiogdG8gaGFuZGxlIG92ZXJsYXBwaW5nIG5hdmlnYXRpb25zIOKAlCByYXBpZCBjbGlja3MgY2FuIGludGVybGVhdmVcbiogYWN0aXZhdGUvZGVhY3RpdmF0ZSBpZiBtdWx0aXBsZSB0cmFuc2l0aW9ucyBhcmUgaW4gZmxpZ2h0LlxuKi9cbmZ1bmN0aW9uIGFjdGl2YXRlTmF2aWdhdGlvblNuYXBzaG90KCkge1xuXHRjb25zdCBzdGF0ZSA9IGdldENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRpZiAoc3RhdGUpIHN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdEFjdGl2ZUNvdW50Kys7XG59XG5jb25zdCBfRU1QVFlfUEFSQU1TID0ge307XG5jb25zdCBfQ0xJRU5UX05BVl9SRU5ERVJfQ1RYX0tFWSA9IFN5bWJvbC5mb3IoXCJ2aW5leHQuY2xpZW50TmF2aWdhdGlvblJlbmRlckNvbnRleHRcIik7XG5mdW5jdGlvbiBnZXRDbGllbnROYXZpZ2F0aW9uUmVuZGVyQ29udGV4dCgpIHtcblx0aWYgKHR5cGVvZiBSZWFjdCQxLmNyZWF0ZUNvbnRleHQgIT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIG51bGw7XG5cdGNvbnN0IGdsb2JhbFN0YXRlID0gZ2xvYmFsVGhpcztcblx0aWYgKCFnbG9iYWxTdGF0ZVtfQ0xJRU5UX05BVl9SRU5ERVJfQ1RYX0tFWV0pIGdsb2JhbFN0YXRlW19DTElFTlRfTkFWX1JFTkRFUl9DVFhfS0VZXSA9IFJlYWN0JDEuY3JlYXRlQ29udGV4dChudWxsKTtcblx0cmV0dXJuIGdsb2JhbFN0YXRlW19DTElFTlRfTkFWX1JFTkRFUl9DVFhfS0VZXSA/PyBudWxsO1xufVxuLyoqIEBpbnRlcm5hbCAqL1xuZnVuY3Rpb24gdXNlQ2xpZW50TmF2aWdhdGlvblJlbmRlclNuYXBzaG90KCkge1xuXHRjb25zdCBjdHggPSBnZXRDbGllbnROYXZpZ2F0aW9uUmVuZGVyQ29udGV4dCgpO1xuXHRpZiAoIWN0eCB8fCB0eXBlb2YgUmVhY3QkMS51c2VDb250ZXh0ICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBudWxsO1xuXHR0cnkge1xuXHRcdHJldHVybiBSZWFjdCQxLnVzZUNvbnRleHQoY3R4KTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cbn1cbi8qKlxuKiBAcGFyYW0gcmVuZGVyZWRQYXRoQW5kU2VhcmNoIFRoZSBwYXRoIGFuZCBxdWVyeSB0aGUgc2VydmVyIHJlbmRlcmVkIGZvciB0aGlzXG4qIG5hdmlnYXRpb24gKGBYLVZpbmV4dC1SZW5kZXJlZC1QYXRoLUFuZC1TZWFyY2hgKSwgd2hlbiBrbm93bi5cbiovXG5mdW5jdGlvbiBjcmVhdGVDbGllbnROYXZpZ2F0aW9uUmVuZGVyU25hcHNob3QoaHJlZiwgcGFyYW1zLCByZW5kZXJlZFBhdGhBbmRTZWFyY2gpIHtcblx0Y29uc3Qgb3JpZ2luID0gdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gOiBcImh0dHA6Ly9sb2NhbGhvc3RcIjtcblx0Y29uc3QgdXJsID0gbmV3IFVSTChocmVmLCBvcmlnaW4pO1xuXHRyZXR1cm4ge1xuXHRcdHBhdGhuYW1lOiBzdHJpcEJhc2VQYXRoKHVybC5wYXRobmFtZSwgX19iYXNlUGF0aCksXG5cdFx0c2VhcmNoOiB1cmwuc2VhcmNoLFxuXHRcdHNlYXJjaFBhcmFtczogbmV3IFJlYWRvbmx5VVJMU2VhcmNoUGFyYW1zKHVybC5zZWFyY2gpLFxuXHRcdHBhcmFtcyxcblx0XHQuLi5yZW5kZXJlZFBhdGhBbmRTZWFyY2ggIT0gbnVsbCA/IHsgcmVuZGVyZWRTZWFyY2g6IG5ldyBVUkwocmVuZGVyZWRQYXRoQW5kU2VhcmNoLCBvcmlnaW4pLnNlYXJjaCB9IDoge31cblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNuYXBzaG90UGF0aEFuZFNlYXJjaChzbmFwc2hvdCkge1xuXHRyZXR1cm4gc25hcHNob3QucGF0aG5hbWUgKyBzbmFwc2hvdC5zZWFyY2g7XG59XG5sZXQgX2ZhbGxiYWNrQ2xpZW50UGFyYW1zID0gX0VNUFRZX1BBUkFNUztcbmxldCBfZmFsbGJhY2tDbGllbnRQYXJhbXNKc29uID0gXCJ7fVwiO1xuZnVuY3Rpb24gc2V0Q2xpZW50UGFyYW1zKHBhcmFtcykge1xuXHRjb25zdCBzdGF0ZSA9IGdldENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRpZiAoIXN0YXRlKSB7XG5cdFx0Y29uc3QganNvbiA9IEpTT04uc3RyaW5naWZ5KHBhcmFtcyk7XG5cdFx0aWYgKGpzb24gIT09IF9mYWxsYmFja0NsaWVudFBhcmFtc0pzb24pIHtcblx0XHRcdF9mYWxsYmFja0NsaWVudFBhcmFtcyA9IHBhcmFtcztcblx0XHRcdF9mYWxsYmFja0NsaWVudFBhcmFtc0pzb24gPSBqc29uO1xuXHRcdH1cblx0XHRyZXR1cm47XG5cdH1cblx0Y29uc3QganNvbiA9IEpTT04uc3RyaW5naWZ5KHBhcmFtcyk7XG5cdGlmIChqc29uICE9PSBzdGF0ZS5jbGllbnRQYXJhbXNKc29uKSB7XG5cdFx0c3RhdGUuY2xpZW50UGFyYW1zID0gcGFyYW1zO1xuXHRcdHN0YXRlLmNsaWVudFBhcmFtc0pzb24gPSBqc29uO1xuXHRcdHN0YXRlLnBlbmRpbmdDbGllbnRQYXJhbXMgPSBudWxsO1xuXHRcdHN0YXRlLnBlbmRpbmdDbGllbnRQYXJhbXNKc29uID0gbnVsbDtcblx0XHRub3RpZnlOYXZpZ2F0aW9uTGlzdGVuZXJzKCk7XG5cdH1cbn1cbmZ1bmN0aW9uIHJlcGxhY2VDbGllbnRQYXJhbXNXaXRob3V0Tm90aWZ5KHBhcmFtcykge1xuXHRjb25zdCBzdGF0ZSA9IGdldENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRpZiAoIXN0YXRlKSByZXR1cm47XG5cdGNvbnN0IGpzb24gPSBKU09OLnN0cmluZ2lmeShwYXJhbXMpO1xuXHRpZiAoanNvbiAhPT0gc3RhdGUuY2xpZW50UGFyYW1zSnNvbiAmJiBqc29uICE9PSBzdGF0ZS5wZW5kaW5nQ2xpZW50UGFyYW1zSnNvbikge1xuXHRcdHN0YXRlLnBlbmRpbmdDbGllbnRQYXJhbXMgPSBwYXJhbXM7XG5cdFx0c3RhdGUucGVuZGluZ0NsaWVudFBhcmFtc0pzb24gPSBqc29uO1xuXHRcdHN0YXRlLmhhc1BlbmRpbmdOYXZpZ2F0aW9uVXBkYXRlID0gdHJ1ZTtcblx0fVxufVxuLyoqIEdldCB0aGUgY3VycmVudCBjbGllbnQgcGFyYW1zIChmb3IgdGVzdGluZyByZWZlcmVudGlhbCBzdGFiaWxpdHkpLiAqL1xuZnVuY3Rpb24gZ2V0Q2xpZW50UGFyYW1zKCkge1xuXHRyZXR1cm4gZ2V0Q2xpZW50TmF2aWdhdGlvblN0YXRlKCk/LmNsaWVudFBhcmFtcyA/PyBfZmFsbGJhY2tDbGllbnRQYXJhbXM7XG59XG4vKipcbiogU2V0IHRoZSBwZW5kaW5nIHBhdGhuYW1lIGZvciBjbGllbnQtc2lkZSBuYXZpZ2F0aW9uLlxuKiBTdHJpcHMgdGhlIGJhc2UgcGF0aCBiZWZvcmUgc3RvcmluZy4gQXNzb2NpYXRlcyB0aGUgcGF0aG5hbWUgd2l0aCB0aGUgZ2l2ZW4gbmF2SWRcbiogc28gb25seSB0aGF0IG5hdmlnYXRpb24gKG9yIGEgbmV3ZXIgb25lKSBjYW4gY2xlYXIgaXQuXG4qL1xuZnVuY3Rpb24gc2V0UGVuZGluZ1BhdGhuYW1lKHBhdGhuYW1lLCBuYXZJZCkge1xuXHRjb25zdCBzdGF0ZSA9IGdldENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRpZiAoIXN0YXRlKSByZXR1cm47XG5cdHN0YXRlLnBlbmRpbmdQYXRobmFtZSA9IHN0cmlwQmFzZVBhdGgocGF0aG5hbWUsIF9fYmFzZVBhdGgpO1xuXHRzdGF0ZS5wZW5kaW5nUGF0aG5hbWVOYXZJZCA9IG5hdklkO1xufVxuLyoqXG4qIENsZWFyIHRoZSBwZW5kaW5nIHBhdGhuYW1lLCBidXQgb25seSBpZiB0aGUgZ2l2ZW4gbmF2SWQgbWF0Y2hlcyB0aGUgb25lXG4qIHRoYXQgc2V0IGl0LCBvciBpZiBwZW5kaW5nUGF0aG5hbWVOYXZJZCBpcyBudWxsIChubyBhY3RpdmUgb3duZXIpLlxuKiBUaGlzIHByZXZlbnRzIHN1cGVyc2VkZWQgbmF2aWdhdGlvbnMgZnJvbSBjbGVhcmluZyBzdGF0ZSBiZWxvbmdpbmcgdG8gbmV3ZXIgbmF2aWdhdGlvbnMuXG4qL1xuZnVuY3Rpb24gY2xlYXJQZW5kaW5nUGF0aG5hbWUobmF2SWQpIHtcblx0Y29uc3Qgc3RhdGUgPSBnZXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKTtcblx0aWYgKCFzdGF0ZSkgcmV0dXJuO1xuXHRpZiAoc3RhdGUucGVuZGluZ1BhdGhuYW1lTmF2SWQgPT09IG51bGwgfHwgc3RhdGUucGVuZGluZ1BhdGhuYW1lTmF2SWQgPT09IG5hdklkKSB7XG5cdFx0c3RhdGUucGVuZGluZ1BhdGhuYW1lID0gbnVsbDtcblx0XHRzdGF0ZS5wZW5kaW5nUGF0aG5hbWVOYXZJZCA9IG51bGw7XG5cdH1cbn1cbmZ1bmN0aW9uIGdldENsaWVudFBhcmFtc1NuYXBzaG90KCkge1xuXHRjb25zdCBzdGF0ZSA9IGdldENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRjb25zdCBjdHggPSBnZXROYXZpZ2F0aW9uQ29udGV4dCgpO1xuXHRpZiAoY3R4KSByZXR1cm4gY3R4LnBhcmFtcztcblx0Y29uc3QgcGFnZXNDdHggPSBnZXRQYWdlc05hdmlnYXRpb25Db250ZXh0KCk7XG5cdGlmIChwYWdlc0N0eCkgcmV0dXJuIHBhZ2VzQ3R4LnBhcmFtcztcblx0cmV0dXJuIHN0YXRlPy5jbGllbnRQYXJhbXMgPz8gX0VNUFRZX1BBUkFNUztcbn1cbmZ1bmN0aW9uIGdldFNlcnZlclBhcmFtc1NuYXBzaG90KCkge1xuXHRjb25zdCBjdHggPSBnZXROYXZpZ2F0aW9uQ29udGV4dCgpO1xuXHRpZiAoY3R4KSByZXR1cm4gY3R4LnBhcmFtcztcblx0Y29uc3QgcGFnZXNDdHggPSBnZXRQYWdlc05hdmlnYXRpb25Db250ZXh0KCk7XG5cdGlmIChwYWdlc0N0eCkgcmV0dXJuIHBhZ2VzQ3R4LnBhcmFtcztcblx0cmV0dXJuIF9FTVBUWV9QQVJBTVM7XG59XG5mdW5jdGlvbiBzdWJzY3JpYmVUb05hdmlnYXRpb24oY2IpIHtcblx0Y29uc3Qgc3RhdGUgPSBnZXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKTtcblx0aWYgKCFzdGF0ZSkgcmV0dXJuICgpID0+IHt9O1xuXHRzdGF0ZS5saXN0ZW5lcnMuYWRkKGNiKTtcblx0cmV0dXJuICgpID0+IHtcblx0XHRzdGF0ZS5saXN0ZW5lcnMuZGVsZXRlKGNiKTtcblx0fTtcbn1cbi8qKlxuKiBSZXR1cm5zIHRoZSBjdXJyZW50IHBhdGhuYW1lLlxuKiBTZXJ2ZXI6IGZyb20gcmVxdWVzdCBjb250ZXh0LiBDbGllbnQ6IGZyb20gd2luZG93LmxvY2F0aW9uLlxuKi9cbmZ1bmN0aW9uIHVzZVBhdGhuYW1lKCkge1xuXHRpZiAoaXNTZXJ2ZXIpIHtcblx0XHRtYXJrUHByRmFsbGJhY2tTaGVsbER5bmFtaWNCb3VuZGFyeSgpO1xuXHRcdGNvbnN0IGN0eCA9IGdldE5hdmlnYXRpb25Db250ZXh0KCk7XG5cdFx0aWYgKGN0eCkgcmV0dXJuIGN0eC5wYXRobmFtZTtcblx0XHRjb25zdCBwYWdlc0N0eCA9IGdldFBhZ2VzTmF2aWdhdGlvbkNvbnRleHQoKTtcblx0XHRyZXR1cm4gcGFnZXNDdHggPyBwYWdlc0N0eC5wYXRobmFtZSA6IFwiL1wiO1xuXHR9XG5cdGNvbnN0IHJlbmRlclNuYXBzaG90ID0gdXNlQ2xpZW50TmF2aWdhdGlvblJlbmRlclNuYXBzaG90KCk7XG5cdGNvbnN0IHBhdGhuYW1lID0gUmVhY3QkMS51c2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmVUb05hdmlnYXRpb24sIGdldFBhdGhuYW1lU25hcHNob3QsICgpID0+IHtcblx0XHRjb25zdCBjdHggPSBnZXROYXZpZ2F0aW9uQ29udGV4dCgpO1xuXHRcdGlmIChjdHgpIHJldHVybiBjdHgucGF0aG5hbWU7XG5cdFx0Y29uc3QgcGFnZXNDdHggPSBnZXRQYWdlc05hdmlnYXRpb25Db250ZXh0KCk7XG5cdFx0cmV0dXJuIHBhZ2VzQ3R4ID8gcGFnZXNDdHgucGF0aG5hbWUgOiBcIi9cIjtcblx0fSk7XG5cdGlmIChyZW5kZXJTbmFwc2hvdCAmJiAoZ2V0Q2xpZW50TmF2aWdhdGlvblN0YXRlKCk/Lm5hdmlnYXRpb25TbmFwc2hvdEFjdGl2ZUNvdW50ID8/IDApID4gMCkgcmV0dXJuIHJlbmRlclNuYXBzaG90LnBhdGhuYW1lO1xuXHRyZXR1cm4gcGF0aG5hbWU7XG59XG4vKipcbiogUmV0dXJucyB0aGUgY3VycmVudCBzZWFyY2ggcGFyYW1zIGFzIGEgcmVhZC1vbmx5IFVSTFNlYXJjaFBhcmFtcy5cbiovXG5mdW5jdGlvbiB1c2VTZWFyY2hQYXJhbXMoKSB7XG5cdGlmIChpc1NlcnZlcikge1xuXHRcdGNvbnN0IGN0eCA9IGdldE5hdmlnYXRpb25Db250ZXh0KCk7XG5cdFx0aWYgKGN0eD8uaXNTdGF0aWNHZW5lcmF0aW9uID09PSB0cnVlICYmIGN0eC5pc0ZvcmNlU3RhdGljICE9PSB0cnVlICYmIGdldFBwckZhbGxiYWNrU2hlbGxTdGF0ZSgpID09PSBudWxsKSB0aHJvdyBuZXcgQmFpbG91dFRvQ1NSRXJyb3IoXCJ1c2VTZWFyY2hQYXJhbXMoKVwiKTtcblx0XHRjb25zdCBnYXRlID0gY3R4Py5zZWFyY2hQYXJhbXNHYXRlO1xuXHRcdGlmIChnYXRlKSB7XG5cdFx0XHRSZWFjdCQxLnVzZShnYXRlLmRlY2lkZWQpO1xuXHRcdFx0aWYgKGdhdGUuZGVjaXNpb24gPT09IFwiYmFpbG91dFwiKSB0aHJvdyBuZXcgQmFpbG91dFRvQ1NSRXJyb3IoXCJ1c2VTZWFyY2hQYXJhbXMoKVwiKTtcblx0XHR9XG5cdFx0bWFya1BwckZhbGxiYWNrU2hlbGxEeW5hbWljQm91bmRhcnkoKTtcblx0XHRyZXR1cm4gZ2V0U2VydmVyU2VhcmNoUGFyYW1zU25hcHNob3QoKTtcblx0fVxuXHRjb25zdCByZW5kZXJTbmFwc2hvdCA9IHVzZUNsaWVudE5hdmlnYXRpb25SZW5kZXJTbmFwc2hvdCgpO1xuXHRjb25zdCBzZWFyY2hQYXJhbXMgPSBSZWFjdCQxLnVzZVN5bmNFeHRlcm5hbFN0b3JlKHN1YnNjcmliZVRvTmF2aWdhdGlvbiwgZ2V0U2VhcmNoUGFyYW1zU25hcHNob3QsIGdldFNlcnZlclNlYXJjaFBhcmFtc1NuYXBzaG90KTtcblx0aWYgKHJlbmRlclNuYXBzaG90ICYmIChnZXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKT8ubmF2aWdhdGlvblNuYXBzaG90QWN0aXZlQ291bnQgPz8gMCkgPiAwKSByZXR1cm4gcmVuZGVyU25hcHNob3Quc2VhcmNoUGFyYW1zO1xuXHRyZXR1cm4gc2VhcmNoUGFyYW1zO1xufVxuLyoqXG4qIFJldHVybnMgdGhlIGR5bmFtaWMgcGFyYW1zIGZvciB0aGUgY3VycmVudCByb3V0ZS5cbiovXG5mdW5jdGlvbiB1c2VQYXJhbXMoKSB7XG5cdGlmIChpc1NlcnZlcikge1xuXHRcdG1hcmtQcHJGYWxsYmFja1NoZWxsRHluYW1pY0JvdW5kYXJ5KCk7XG5cdFx0cmV0dXJuIGdldFNlcnZlclBhcmFtc1NuYXBzaG90KCk7XG5cdH1cblx0Y29uc3QgcmVuZGVyU25hcHNob3QgPSB1c2VDbGllbnROYXZpZ2F0aW9uUmVuZGVyU25hcHNob3QoKTtcblx0Y29uc3QgcGFyYW1zID0gUmVhY3QkMS51c2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmVUb05hdmlnYXRpb24sIGdldENsaWVudFBhcmFtc1NuYXBzaG90LCBnZXRTZXJ2ZXJQYXJhbXNTbmFwc2hvdCk7XG5cdGlmIChyZW5kZXJTbmFwc2hvdCAmJiAoZ2V0Q2xpZW50TmF2aWdhdGlvblN0YXRlKCk/Lm5hdmlnYXRpb25TbmFwc2hvdEFjdGl2ZUNvdW50ID8/IDApID4gMCkgcmV0dXJuIHJlbmRlclNuYXBzaG90LnBhcmFtcztcblx0cmV0dXJuIHBhcmFtcztcbn1cbmZ1bmN0aW9uIHdpdGhTdXBwcmVzc2VkVXJsTm90aWZpY2F0aW9ucyhmbikge1xuXHRjb25zdCBzdGF0ZSA9IGdldENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRpZiAoIXN0YXRlKSByZXR1cm4gZm4oKTtcblx0c3RhdGUuc3VwcHJlc3NVcmxOb3RpZnlDb3VudCArPSAxO1xuXHR0cnkge1xuXHRcdHJldHVybiBmbigpO1xuXHR9IGZpbmFsbHkge1xuXHRcdHN0YXRlLnN1cHByZXNzVXJsTm90aWZ5Q291bnQgLT0gMTtcblx0fVxufVxuLyoqXG4qIENvbW1pdCBwZW5kaW5nIGNsaWVudCBuYXZpZ2F0aW9uIHN0YXRlIHRvIGNvbW1pdHRlZCBzbmFwc2hvdHMuXG4qXG4qIG5hdklkIGlzIG9wdGlvbmFsOiBjYWxsZXJzIHRoYXQgZG9uJ3Qgb3duIHBlbmRpbmdQYXRobmFtZSAoZm9yIGV4YW1wbGUsXG4qIHN1cGVyc2VkZWQgcHJlLXBhaW50IGNsZWFudXApIG1heSBwYXNzIHVuZGVmaW5lZCB0byBmbHVzaCBVUkwvcGFyYW1zIHN0YXRlXG4qIHdpdGhvdXQgY2xlYXJpbmcgcGVuZGluZ1BhdGhuYW1lIG93bmVkIGJ5IHRoZSBhY3RpdmUgbmF2aWdhdGlvbi4gU3VjaCBjYWxsZXJzXG4qIG11c3Qgb3B0IGluIGV4cGxpY2l0bHkgaWYgdGhleSBhbHNvIG93biBhbiBhY3RpdmF0ZWQgcmVuZGVyIHNuYXBzaG90LlxuKi9cbmZ1bmN0aW9uIGNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZShuYXZJZCwgb3B0aW9ucykge1xuXHRpZiAoaXNTZXJ2ZXIpIHJldHVybjtcblx0Y29uc3Qgc3RhdGUgPSBnZXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKTtcblx0aWYgKCFzdGF0ZSkgcmV0dXJuO1xuXHRpZiAoKG9wdGlvbnM/LnJlbGVhc2VTbmFwc2hvdCA/PyBuYXZJZCAhPT0gdm9pZCAwKSAmJiBzdGF0ZS5uYXZpZ2F0aW9uU25hcHNob3RBY3RpdmVDb3VudCA+IDApIHN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdEFjdGl2ZUNvdW50IC09IDE7XG5cdGNvbnN0IHVybENoYW5nZWQgPSBzeW5jQ29tbWl0dGVkVXJsU3RhdGVGcm9tTG9jYXRpb24oKTtcblx0bGV0IHBhcmFtc0NoYW5nZWQgPSBmYWxzZTtcblx0aWYgKHN0YXRlLnBlbmRpbmdDbGllbnRQYXJhbXMgIT09IG51bGwgJiYgc3RhdGUucGVuZGluZ0NsaWVudFBhcmFtc0pzb24gIT09IG51bGwpIHtcblx0XHRzdGF0ZS5jbGllbnRQYXJhbXMgPSBzdGF0ZS5wZW5kaW5nQ2xpZW50UGFyYW1zO1xuXHRcdHN0YXRlLmNsaWVudFBhcmFtc0pzb24gPSBzdGF0ZS5wZW5kaW5nQ2xpZW50UGFyYW1zSnNvbjtcblx0XHRzdGF0ZS5wZW5kaW5nQ2xpZW50UGFyYW1zID0gbnVsbDtcblx0XHRzdGF0ZS5wZW5kaW5nQ2xpZW50UGFyYW1zSnNvbiA9IG51bGw7XG5cdFx0cGFyYW1zQ2hhbmdlZCA9IHRydWU7XG5cdH1cblx0aWYgKHN0YXRlLnBlbmRpbmdQYXRobmFtZU5hdklkID09PSBudWxsIHx8IG5hdklkICE9PSB2b2lkIDAgJiYgc3RhdGUucGVuZGluZ1BhdGhuYW1lTmF2SWQgPT09IG5hdklkKSB7XG5cdFx0c3RhdGUucGVuZGluZ1BhdGhuYW1lID0gbnVsbDtcblx0XHRzdGF0ZS5wZW5kaW5nUGF0aG5hbWVOYXZJZCA9IG51bGw7XG5cdH1cblx0Y29uc3Qgc2hvdWxkTm90aWZ5ID0gdXJsQ2hhbmdlZCB8fCBzdGF0ZS5oYXNQZW5kaW5nTmF2aWdhdGlvblVwZGF0ZTtcblx0c3RhdGUuaGFzUGVuZGluZ05hdmlnYXRpb25VcGRhdGUgPSBmYWxzZTtcblx0aWYgKHVybENoYW5nZWQgfHwgcGFyYW1zQ2hhbmdlZCkgY2xlYXJDbGllbnRIeWRyYXRpb25Db250ZXh0KCk7XG5cdGlmIChzaG91bGROb3RpZnkpIG5vdGlmeU5hdmlnYXRpb25MaXN0ZW5lcnMoKTtcbn1cbi8qKiBXaGV0aGVyIGEgaGlzdG9yeSBlbnRyeSdzIHN0YXRlIGlzIHRoZSBkYXRhIHdyaXR0ZW4gdG8gaXQsIGNsb25lZCBieSB0aGUgYnJvd3Nlci4gKi9cbmZ1bmN0aW9uIGlzU2FtZUhpc3RvcnlTdGF0ZURhdGEoaGlzdG9yeVN0YXRlLCBkYXRhKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIEpTT04uc3RyaW5naWZ5KGhpc3RvcnlTdGF0ZSkgPT09IEpTT04uc3RyaW5naWZ5KGRhdGEpO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn1cbi8qKiBXcml0ZXMgdGhlIGluLXByb2dyZXNzIHJvdXRlciB3cml0ZSBpZiB0aGlzIGNhbGwgaXMgaXQsIGNvbnN1bWluZyBpdHMgbWFya2VyLiAqL1xuZnVuY3Rpb24gZm9yd2FyZFJvdXRlckhpc3RvcnlXcml0ZShzdGF0ZSwgbWV0aG9kLCBkYXRhLCB1bnVzZWQsIHVybCkge1xuXHRjb25zdCB3cml0ZSA9IHN0YXRlLnJvdXRlckhpc3RvcnlXcml0ZTtcblx0aWYgKHdyaXRlPy5tZXRob2QgIT09IG1ldGhvZCkgcmV0dXJuIGZhbHNlO1xuXHRpZiAod3JpdGUudGhyZXcpIHtcblx0XHRpZiAodXJsID09IG51bGwgfHwgbmV3IFVSTCh1cmwsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKS5ocmVmICE9PSB3cml0ZS5ocmVmKSByZXR1cm4gZmFsc2U7XG5cdFx0aWYgKHdyaXRlLmRhdGEgIT09IGRhdGEgJiYgIShpc0FwcE93bmVkSGlzdG9yeVN0YXRlKGRhdGEpICYmIHJlYWRIaXN0b3J5U3RhdGVUcmF2ZXJzYWxJbmRleChkYXRhKSA9PT0gcmVhZEhpc3RvcnlTdGF0ZVRyYXZlcnNhbEluZGV4KHdyaXRlLmRhdGEpKSkgcmV0dXJuIGZhbHNlO1xuXHR9IGVsc2UgaWYgKHdyaXRlLmRhdGEgIT09IGRhdGEgfHwgd3JpdGUudXJsICE9PSB1cmwpIHJldHVybiBmYWxzZTtcblx0aWYgKHdyaXRlLmxhbmRlZCkgcmV0dXJuIHRydWU7XG5cdHN0YXRlLnJvdXRlckhpc3RvcnlXcml0ZSA9IG51bGw7XG5cdGNvbnN0IGxhbmRpbmcgPSB3cml0ZS5sYW5kPy4oZGF0YSk7XG5cdGNvbnN0IG9yaWdpbmFsID0gbWV0aG9kID09PSBcInB1c2hTdGF0ZVwiID8gc3RhdGUub3JpZ2luYWxQdXNoU3RhdGUgOiBzdGF0ZS5vcmlnaW5hbFJlcGxhY2VTdGF0ZTtcblx0Y29uc3Qgd3JpdHRlbkRhdGEgPSBsYW5kaW5nID8gbGFuZGluZy5kYXRhIDogZGF0YTtcblx0Y29uc3QgaGlzdG9yeVN0YXRlQmVmb3JlV3JpdGUgPSB3aW5kb3cuaGlzdG9yeS5zdGF0ZTtcblx0dHJ5IHtcblx0XHRvcmlnaW5hbC5jYWxsKHdpbmRvdy5oaXN0b3J5LCB3cml0dGVuRGF0YSwgdW51c2VkLCB1cmwpO1xuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdGNvbnN0IGxhbmRlZCA9IHdpbmRvdy5oaXN0b3J5LnN0YXRlICE9PSBoaXN0b3J5U3RhdGVCZWZvcmVXcml0ZSAmJiB3aW5kb3cubG9jYXRpb24uaHJlZiA9PT0gd3JpdGUuaHJlZiAmJiBpc1NhbWVIaXN0b3J5U3RhdGVEYXRhKHdpbmRvdy5oaXN0b3J5LnN0YXRlLCB3cml0dGVuRGF0YSk7XG5cdFx0aWYgKGxhbmRlZCkgbGFuZGluZz8uY29tbWl0KCk7XG5cdFx0c3RhdGUucm91dGVySGlzdG9yeVdyaXRlID0ge1xuXHRcdFx0Li4ud3JpdGUsXG5cdFx0XHR0aHJldzogdHJ1ZSxcblx0XHRcdGxhbmRlZFxuXHRcdH07XG5cdFx0dGhyb3cgZXJyb3I7XG5cdH1cblx0bGFuZGluZz8uY29tbWl0KCk7XG5cdGlmICh3cml0ZS50aHJldykgc3RhdGUucm91dGVySGlzdG9yeVdyaXRlID0ge1xuXHRcdC4uLndyaXRlLFxuXHRcdGxhbmRlZDogdHJ1ZVxuXHR9O1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIHdyaXRlUm91dGVySGlzdG9yeVN0YXRlKG1ldGhvZCwgZGF0YSwgdW51c2VkLCB1cmwsIGxhbmQpIHtcblx0d2l0aFN1cHByZXNzZWRVcmxOb3RpZmljYXRpb25zKCgpID0+IHtcblx0XHRjb25zdCBzdGF0ZSA9IGdldENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRcdGlmICghc3RhdGUpIHJldHVybjtcblx0XHRpZiAodXJsID09IG51bGwpIHtcblx0XHRcdChtZXRob2QgPT09IFwicHVzaFN0YXRlXCIgPyBzdGF0ZS5vcmlnaW5hbFB1c2hTdGF0ZSA6IHN0YXRlLm9yaWdpbmFsUmVwbGFjZVN0YXRlKS5jYWxsKHdpbmRvdy5oaXN0b3J5LCBkYXRhLCB1bnVzZWQsIHVybCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGNvbnN0IHByZXZpb3VzV3JpdGUgPSBzdGF0ZS5yb3V0ZXJIaXN0b3J5V3JpdGU7XG5cdFx0c3RhdGUucm91dGVySGlzdG9yeVdyaXRlRGVwdGggKz0gMTtcblx0XHRzdGF0ZS5yb3V0ZXJIaXN0b3J5V3JpdGUgPSB7XG5cdFx0XHRtZXRob2QsXG5cdFx0XHRkYXRhLFxuXHRcdFx0dXJsLFxuXHRcdFx0aHJlZjogbmV3IFVSTCh1cmwsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKS5ocmVmLFxuXHRcdFx0bGFuZCxcblx0XHRcdHRocmV3OiBmYWxzZSxcblx0XHRcdGxhbmRlZDogZmFsc2Vcblx0XHR9O1xuXHRcdHRyeSB7XG5cdFx0XHR3aW5kb3cuaGlzdG9yeVttZXRob2RdKGRhdGEsIHVudXNlZCwgdXJsKTtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0c3RhdGUucm91dGVySGlzdG9yeVdyaXRlRGVwdGggLT0gMTtcblx0XHRcdHN0YXRlLnJvdXRlckhpc3RvcnlXcml0ZSA9IHByZXZpb3VzV3JpdGU7XG5cdFx0fVxuXHR9KTtcbn1cbmZ1bmN0aW9uIHB1c2hIaXN0b3J5U3RhdGVXaXRob3V0Tm90aWZ5KGRhdGEsIHVudXNlZCwgdXJsLCBsYW5kKSB7XG5cdHdyaXRlUm91dGVySGlzdG9yeVN0YXRlKFwicHVzaFN0YXRlXCIsIGRhdGEsIHVudXNlZCwgdXJsLCBsYW5kKTtcbn1cbmZ1bmN0aW9uIHJlcGxhY2VIaXN0b3J5U3RhdGVXaXRob3V0Tm90aWZ5KGRhdGEsIHVudXNlZCwgdXJsLCBsYW5kKSB7XG5cdHdyaXRlUm91dGVySGlzdG9yeVN0YXRlKFwicmVwbGFjZVN0YXRlXCIsIGRhdGEsIHVudXNlZCwgdXJsLCBsYW5kKTtcbn1cbi8qKlxuKiBTYXZlIHRoZSBjdXJyZW50IHNjcm9sbCBwb3NpdGlvbiBpbnRvIHRoZSBjdXJyZW50IGhpc3Rvcnkgc3RhdGUuXG4qIENhbGxlZCBiZWZvcmUgZXZlcnkgbmF2aWdhdGlvbiB0byBlbmFibGUgc2Nyb2xsIHJlc3RvcmF0aW9uIG9uIGJhY2svZm9yd2FyZC5cbipcbiogVXNlcyByZXBsYWNlSGlzdG9yeVN0YXRlV2l0aG91dE5vdGlmeSB0byBhdm9pZCB0cmlnZ2VyaW5nIHRoZSBwYXRjaGVkXG4qIGhpc3RvcnkucmVwbGFjZVN0YXRlIGludGVyY2VwdGlvbiAod2hpY2ggd291bGQgY2F1c2Ugc3B1cmlvdXMgcmUtcmVuZGVycykuXG4qL1xuZnVuY3Rpb24gc2F2ZVNjcm9sbFBvc2l0aW9uKCkge1xuXHRyZXBsYWNlSGlzdG9yeVN0YXRlV2l0aG91dE5vdGlmeSh7XG5cdFx0Li4ud2luZG93Lmhpc3Rvcnkuc3RhdGUgPz8ge30sXG5cdFx0X192aW5leHRfc2Nyb2xsWDogd2luZG93LnNjcm9sbFgsXG5cdFx0X192aW5leHRfc2Nyb2xsWTogd2luZG93LnNjcm9sbFlcblx0fSwgXCJcIik7XG59XG5mdW5jdGlvbiBjb21taXRIYXNoT25seUhpc3RvcnlTdGF0ZShocmVmLCBtb2RlLCBzY3JvbGwpIHtcblx0Y29uc3QgY29tbWl0QXBwUm91dGVySGFzaE5hdmlnYXRpb24gPSBnZXROYXZpZ2F0aW9uUnVudGltZSgpPy5mdW5jdGlvbnMuY29tbWl0SGFzaE5hdmlnYXRpb247XG5cdGlmIChjb21taXRBcHBSb3V0ZXJIYXNoTmF2aWdhdGlvbikge1xuXHRcdGNvbW1pdEFwcFJvdXRlckhhc2hOYXZpZ2F0aW9uKGhyZWYsIG1vZGUsIHNjcm9sbCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IGhpc3RvcnlTdGF0ZSA9IGNyZWF0ZUhhc2hPbmx5SGlzdG9yeVN0YXRlUHJlc2VydmluZ05hdmlnYXRpb25NZXRhZGF0YSh3aW5kb3cuaGlzdG9yeS5zdGF0ZSk7XG5cdGlmIChtb2RlID09PSBcInJlcGxhY2VcIikgcmVwbGFjZUhpc3RvcnlTdGF0ZVdpdGhvdXROb3RpZnkoaGlzdG9yeVN0YXRlLCBcIlwiLCBocmVmKTtcblx0ZWxzZSBwdXNoSGlzdG9yeVN0YXRlV2l0aG91dE5vdGlmeShoaXN0b3J5U3RhdGUsIFwiXCIsIGhyZWYpO1xufVxuZnVuY3Rpb24gYXBwbHlBcHBSb3V0ZXJTY3JvbGxGYWxsYmFjayhpbnRlbnQpIHtcblx0aWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gXCJ1bmRlZmluZWRcIiB8fCB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG5cdGlmIChpbnRlbnQuaGFzaCAhPT0gbnVsbCkge1xuXHRcdGNvbnN0IGhhc2ggPSBpbnRlbnQuaGFzaDtcblx0XHRyZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4ge1xuXHRcdFx0aWYgKCFpc0xhdGVzdEFwcFJvdXRlclNjcm9sbEludGVudChpbnRlbnQpKSByZXR1cm47XG5cdFx0XHRkaXNhYmxlU21vb3RoU2Nyb2xsRHVyaW5nUm91dGVUcmFuc2l0aW9uKCgpID0+IHtcblx0XHRcdFx0c2Nyb2xsVG9IYXNoVGFyZ2V0KGhhc2gpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGlmIChpbnRlbnQudGFyZ2V0SG9pc3RlZEluSGVhZCkgcmV0dXJuO1xuXHRkaXNhYmxlU21vb3RoU2Nyb2xsRHVyaW5nUm91dGVUcmFuc2l0aW9uKCgpID0+IHtcblx0XHRkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsVG9wID0gMDtcblx0fSk7XG59XG5mdW5jdGlvbiBzY2hlZHVsZUFwcFJvdXRlclNjcm9sbEZhbGxiYWNrKGludGVudCkge1xuXHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0Y29uc3QgcGVuZGluZ0ludGVudCA9IGdldFBlbmRpbmdBcHBSb3V0ZXJTY3JvbGxJbnRlbnQoKTtcblx0XHRpZiAocGVuZGluZ0ludGVudCA9PT0gbnVsbCB8fCBwZW5kaW5nSW50ZW50LmlkICE9PSBpbnRlbnQuaWQpIHJldHVybjtcblx0XHRjb25zdCBmYWxsYmFja0ludGVudCA9IGNvbnN1bWVBcHBSb3V0ZXJTY3JvbGxJbnRlbnQoaW50ZW50KTtcblx0XHRpZiAoZmFsbGJhY2tJbnRlbnQpIGFwcGx5QXBwUm91dGVyU2Nyb2xsRmFsbGJhY2soZmFsbGJhY2tJbnRlbnQpO1xuXHR9KTtcbn1cbi8qKlxuKiBSZXN0b3JlIHNjcm9sbCBwb3NpdGlvbiBmcm9tIGEgaGlzdG9yeSBzdGF0ZSBvYmplY3QgKHVzZWQgb24gcG9wc3RhdGUpLlxuKlxuKiBXaGVuIGFuIFJTQyBuYXZpZ2F0aW9uIGlzIGluIGZsaWdodCAoYmFjay9mb3J3YXJkIHRyaWdnZXJzIGJvdGggdGhpc1xuKiBoYW5kbGVyIGFuZCB0aGUgYnJvd3NlciBlbnRyeSdzIHBvcHN0YXRlIGhhbmRsZXIgd2hpY2ggY2FsbHMgdGhlIHJlZ2lzdGVyZWRcbiogbmF2aWdhdGlvbiBydW50aW1lKSwgd2UgbXVzdCB3YWl0IGZvciB0aGUgbmV3IGNvbnRlbnQgdG8gcmVuZGVyXG4qIGJlZm9yZSBzY3JvbGxpbmcuIE90aGVyd2lzZSB0aGUgdXNlciBzZWVzIG9sZCBjb250ZW50IGZsYXNoIGF0IHRoZVxuKiByZXN0b3JlZCBzY3JvbGwgcG9zaXRpb24uXG4qXG4qIFRoaXMgaGFuZGxlciBmaXJlcyBiZWZvcmUgdGhlIGJyb3dzZXIgZW50cnkncyBwb3BzdGF0ZSBoYW5kbGVyIChiZWNhdXNlXG4qIG5hdmlnYXRpb24udHMgaXMgbG9hZGVkIGJlZm9yZSBoeWRyYXRpb24gY29tcGxldGVzKSwgc28gd2UgZGVmZXIgdmlhIGFcbiogbWljcm90YXNrIHRvIGdpdmUgdGhlIGJyb3dzZXIgZW50cnkgaGFuZGxlciBhIGNoYW5jZSB0byBzZXRcbiogX19WSU5FWFRfUlNDX1BFTkRJTkdfXy4gUHJvbWlzZS5yZXNvbHZlKCkgc2NoZWR1bGVzIGEgbWljcm90YXNrXG4qIHRoYXQgcnVucyBhZnRlciBhbGwgc3luY2hyb25vdXMgZXZlbnQgbGlzdGVuZXJzIGhhdmUgY29tcGxldGVkLlxuKi9cbmZ1bmN0aW9uIHJlc3RvcmVTY3JvbGxQb3NpdGlvbihzdGF0ZSkge1xuXHRpZiAoc3RhdGUgJiYgdHlwZW9mIHN0YXRlID09PSBcIm9iamVjdFwiICYmIFwiX192aW5leHRfc2Nyb2xsWVwiIGluIHN0YXRlKSB7XG5cdFx0Y29uc3QgeyBfX3ZpbmV4dF9zY3JvbGxYOiB4LCBfX3ZpbmV4dF9zY3JvbGxZOiB5IH0gPSBzdGF0ZTtcblx0XHRQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IHtcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSB3aW5kb3cuX19WSU5FWFRfUlNDX1BFTkRJTkdfXyA/PyBudWxsO1xuXHRcdFx0aWYgKHBlbmRpbmcpIHBlbmRpbmcudGhlbigoKSA9PiByZXRyeVNjcm9sbFRvKHgsIHkpKTtcblx0XHRcdGVsc2UgcmV0cnlTY3JvbGxUbyh4LCB5KTtcblx0XHR9KTtcblx0fVxufVxuLyoqXG4qIEhhcmQtbmF2aWdhdGUgdG8gYSBVUkwgdmlhIGB3aW5kb3cubG9jYXRpb25gLCBwcmVzZXJ2aW5nIHB1c2gvcmVwbGFjZVxuKiBzZW1hbnRpY3MuIFVzZWQgZm9yIFVSTHMgdGhlIEFwcCBSb3V0ZXIgY2Fubm90IHNlcnZlIChQYWdlcy1vd25lZFxuKiB0YXJnZXRzIGluIGEgaHlicmlkIGJ1aWxkKSBhbmQgZm9yIGNhdGNoLWFsbCBSU0MgZmFpbHVyZXMuXG4qL1xuZnVuY3Rpb24gaGFyZE5hdmlnYXRlVG8oZnVsbEhyZWYsIG1vZGUpIHtcblx0aWYgKG1vZGUgPT09IFwicmVwbGFjZVwiKSB3aW5kb3cubG9jYXRpb24ucmVwbGFjZShmdWxsSHJlZik7XG5cdGVsc2Ugd2luZG93LmxvY2F0aW9uLmFzc2lnbihmdWxsSHJlZik7XG59XG4vKipcbiogUmVzZXQgYW55IGxpbmsgc3RpbGwgc2hvd2luZyBhIGB1c2VMaW5rU3RhdHVzKClgIHBlbmRpbmcgc3RhdGUgdGhhdCBkaWQgbm90XG4qIGluaXRpYXRlIHRoZSBuYXZpZ2F0aW9uIG5vdyBzdGFydGluZyAoZS5nLiBhIHByb2dyYW1tYXRpYyByb3V0ZXIucHVzaCwgYSBmb3JtXG4qIHN1Ym1pdCwgb3IgYSByYXcgaGlzdG9yeSB1cGRhdGUpLiBBIDxMaW5rPiBjbGljayByZWdpc3RlcnMgaXRzZWxmIGZpcnN0LCBzb1xuKiB0aGUgaG9vayBrZWVwcyB0aGF0IGxpbmsgcGVuZGluZy5cbiovXG5mdW5jdGlvbiByZXNldFN0YWxlTGlua1N0YXR1cygpIHtcblx0Z2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLm5vdGlmeUxpbmtOYXZpZ2F0aW9uU3RhcnQ/LigpO1xufVxuLyoqXG4qIFNpZ25hbCB0aGF0IGEgbmF2aWdhdGlvbiB0byBgaHJlZmAgaXMgc3RhcnRpbmcsIGZvciB0aGUgY2FsbGVycyB0aGF0IHdpbGxcbiogZmV0Y2ggdGhlIGRlc3RpbmF0aW9uLiBTZXBhcmF0ZSBmcm9tIGByZXNldFN0YWxlTGlua1N0YXR1cygpYCBiZWNhdXNlIGEgcmF3XG4qIGBoaXN0b3J5LnB1c2hTdGF0ZWAgYWxzbyBzdXBlcnNlZGVzIGEgcGVuZGluZyBsaW5rIGJ1dCBpc3N1ZXMgbm8gcmVxdWVzdCDigJRcbiogY2FuY2VsbGluZyBhIHByZWZldGNoIHRoZXJlIHdvdWxkIGRyb3AgaXQgd2l0aCBub3RoaW5nIHRvIHRha2UgaXRzIHBsYWNlLlxuKi9cbmZ1bmN0aW9uIG5vdGlmeUFwcE5hdmlnYXRpb25TdGFydChocmVmKSB7XG5cdGNvbnN0IGRlc3RpbmF0aW9uID0gdG9BcHBQcmVmZXRjaERlc3RpbmF0aW9uKGhyZWYpO1xuXHRpZiAoZGVzdGluYXRpb24gIT09IG51bGwgJiYgIWlzSGFzaE9ubHlCcm93c2VyVXJsQ2hhbmdlKGhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmLCBfX2Jhc2VQYXRoKSkgY2FuY2VsUGVuZGluZ1ByZWZldGNoU2V0dXBzKGRlc3RpbmF0aW9uKTtcblx0cmVzZXRTdGFsZUxpbmtTdGF0dXMoKTtcbn1cbi8qKlxuKiBwb3BzdGF0ZSB2YXJpYW50LiBUaGUgYnJvd3NlciBoYXMgYWxyZWFkeSBhcHBsaWVkIHRoZSBoaXN0b3J5IGVudHJ5IGJ5IHRoZVxuKiB0aW1lIHRoaXMgcnVucywgc28gdGhlIHByZS1uYXZpZ2F0aW9uIFVSTCB0aGF0IGBpc0hhc2hPbmx5QnJvd3NlclVybENoYW5nZWBcbiogbmVlZHMgaXMgZ29uZS4gQmFjay9mb3J3YXJkIGFjcm9zcyBhIHJvdXRlIGJvdW5kYXJ5IGRvZXMgZHJpdmUgYW4gUlNDIGZldGNoXG4qIChgYXBwLWJyb3dzZXItZW50cnkudHNgJ3MgcG9wc3RhdGUgaGFuZGxlciksIHNvIGNhbmNlbGxpbmcgYnkgZGVzdGluYXRpb24gaXNcbiogcmlnaHQ7IGEgaGFzaC1vbmx5IGVudHJ5IG92ZXItY2FuY2Vscywgd2hpY2ggY29zdHMgb25lIHJlLXByZWZldGNoIGFuZCBjYW5cbiogbmV2ZXIgY2F1c2UgYSBkdXBsaWNhdGUgcmVxdWVzdC5cbiovXG5mdW5jdGlvbiBub3RpZnlBcHBQb3BzdGF0ZU5hdmlnYXRpb25TdGFydCgpIHtcblx0Y29uc3QgZGVzdGluYXRpb24gPSB0b0FwcFByZWZldGNoRGVzdGluYXRpb24od2luZG93LmxvY2F0aW9uLmhyZWYpO1xuXHRpZiAoZGVzdGluYXRpb24gIT09IG51bGwpIGNhbmNlbFBlbmRpbmdQcmVmZXRjaFNldHVwcyhkZXN0aW5hdGlvbik7XG5cdHJlc2V0U3RhbGVMaW5rU3RhdHVzKCk7XG59XG4vKipcbiogTmF2aWdhdGUgdG8gYSBVUkwsIGhhbmRsaW5nIGV4dGVybmFsIFVSTHMsIGhhc2gtb25seSBjaGFuZ2VzLCBhbmQgUlNDIG5hdmlnYXRpb24uXG4qL1xuYXN5bmMgZnVuY3Rpb24gbmF2aWdhdGVDbGllbnRTaWRlKGhyZWYsIG1vZGUsIHNjcm9sbCwgcHJvZ3JhbW1hdGljVHJhbnNpdGlvbiA9IGZhbHNlLCB2aXNpYmxlQ29tbWl0TW9kZSA9IFwidHJhbnNpdGlvblwiKSB7XG5cdG5vdGlmeUFwcE5hdmlnYXRpb25TdGFydChocmVmKTtcblx0bGV0IG5vcm1hbGl6ZWRIcmVmID0gaHJlZjtcblx0aWYgKGlzRXh0ZXJuYWxVcmwoaHJlZikpIHtcblx0XHRjb25zdCBsb2NhbFBhdGggPSB0b1NhbWVPcmlnaW5BcHBQYXRoKGhyZWYsIF9fYmFzZVBhdGgpO1xuXHRcdGlmIChsb2NhbFBhdGggPT0gbnVsbCkge1xuXHRcdFx0bm90aWZ5QXBwUm91dGVyVHJhbnNpdGlvblN0YXJ0KGhyZWYsIG1vZGUpO1xuXHRcdFx0Y29uc3QgZXh0ZXJuYWxOYXZpZ2F0ZSA9IGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5uYXZpZ2F0ZUV4dGVybmFsO1xuXHRcdFx0aWYgKGV4dGVybmFsTmF2aWdhdGUpIHtcblx0XHRcdFx0YXdhaXQgZXh0ZXJuYWxOYXZpZ2F0ZShocmVmLCBtb2RlKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0aGFyZE5hdmlnYXRlVG8oaHJlZiwgbW9kZSk7XG5cdFx0XHRhd2FpdCBuZXcgUHJvbWlzZSgoKSA9PiB7fSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdG5vcm1hbGl6ZWRIcmVmID0gbG9jYWxQYXRoO1xuXHR9XG5cdGNvbnN0IGh5YnJpZE93bmVyID0gcmVzb2x2ZUh5YnJpZENsaWVudFJvdXRlT3duZXIobm9ybWFsaXplZEhyZWYpO1xuXHRpZiAoaHlicmlkT3duZXIgPT09IFwicGFnZXNcIiB8fCBoeWJyaWRPd25lciA9PT0gXCJkb2N1bWVudFwiKSB7XG5cdFx0Y29uc3QgZnVsbEhyZWYgPSB0b0Nhbm9uaWNhbEJyb3dzZXJOYXZpZ2F0aW9uSHJlZihub3JtYWxpemVkSHJlZiwgd2luZG93LmxvY2F0aW9uLmhyZWYsIF9fYmFzZVBhdGgsIF9fdHJhaWxpbmdTbGFzaCk7XG5cdFx0bm90aWZ5QXBwUm91dGVyVHJhbnNpdGlvblN0YXJ0KGZ1bGxIcmVmLCBtb2RlKTtcblx0XHRpZiAobW9kZSA9PT0gXCJwdXNoXCIpIHNhdmVTY3JvbGxQb3NpdGlvbigpO1xuXHRcdGNvbnN0IG1wYU5hdmlnYXRlID0gZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLm5hdmlnYXRlRXh0ZXJuYWw7XG5cdFx0aWYgKG1wYU5hdmlnYXRlKSB7XG5cdFx0XHRhd2FpdCBtcGFOYXZpZ2F0ZShmdWxsSHJlZiwgbW9kZSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGhhcmROYXZpZ2F0ZVRvKGZ1bGxIcmVmLCBtb2RlKTtcblx0XHRhd2FpdCBuZXcgUHJvbWlzZSgoKSA9PiB7fSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IGZ1bGxIcmVmID0gdG9DYW5vbmljYWxCcm93c2VyTmF2aWdhdGlvbkhyZWYobm9ybWFsaXplZEhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmLCBfX2Jhc2VQYXRoLCBfX3RyYWlsaW5nU2xhc2gpO1xuXHRzdGFnZUFwcE5hdmlnYXRpb25GYWlsdXJlVGFyZ2V0KGZ1bGxIcmVmKTtcblx0bm90aWZ5QXBwUm91dGVyVHJhbnNpdGlvblN0YXJ0KGZ1bGxIcmVmLCBtb2RlKTtcblx0aWYgKG1vZGUgPT09IFwicHVzaFwiKSBzYXZlU2Nyb2xsUG9zaXRpb24oKTtcblx0Y29uc3QgZWFybHlJbnRlbnQgPSBuYXZpZ2F0aW9uUGxhbm5lci5jbGFzc2lmeUVhcmx5TmF2aWdhdGlvbkludGVudCh7XG5cdFx0YmFzZVBhdGg6IF9fYmFzZVBhdGgsXG5cdFx0Y3VycmVudFVybFNwYWNlOiBcImJyb3dzZXJcIixcblx0XHRjdXJyZW50SHJlZjogd2luZG93LmxvY2F0aW9uLmhyZWYsXG5cdFx0bW9kZSxcblx0XHRzY3JvbGwsXG5cdFx0dGFyZ2V0SHJlZjogZnVsbEhyZWZcblx0fSk7XG5cdGlmIChlYXJseUludGVudC5raW5kID09PSBcInNhbWVEb2N1bWVudFNjcm9sbFwiKSB7XG5cdFx0Y2xlYXJBcHBSb3V0ZXJTY3JvbGxJbnRlbnQoKTtcblx0XHRjb21taXRIYXNoT25seUhpc3RvcnlTdGF0ZShmdWxsSHJlZiwgZWFybHlJbnRlbnQubW9kZSwgZWFybHlJbnRlbnQuc2Nyb2xsKTtcblx0XHRjbGVhckFwcE5hdmlnYXRpb25GYWlsdXJlVGFyZ2V0KGZ1bGxIcmVmKTtcblx0XHRjb21taXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKTtcblx0XHRpZiAoZWFybHlJbnRlbnQuc2Nyb2xsKSBzY3JvbGxUb0hhc2hUYXJnZXQoZWFybHlJbnRlbnQuaGFzaCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGlmIChoYXNQZW5kaW5nQXBwUm91dGVyUGFnZVJlZGlyZWN0KHR5cGVvZiBkb2N1bWVudCA9PT0gXCJ1bmRlZmluZWRcIiA/IHZvaWQgMCA6IGRvY3VtZW50KSkge1xuXHRcdGNvbnN0IG1wYU5hdmlnYXRlID0gZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLm5hdmlnYXRlRXh0ZXJuYWw7XG5cdFx0aWYgKG1wYU5hdmlnYXRlKSB7XG5cdFx0XHRhd2FpdCBtcGFOYXZpZ2F0ZShmdWxsSHJlZiwgbW9kZSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGhhcmROYXZpZ2F0ZVRvKGZ1bGxIcmVmLCBtb2RlKTtcblx0XHRhd2FpdCBuZXcgUHJvbWlzZSgoKSA9PiB7fSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IGhhc2hJZHggPSBmdWxsSHJlZi5pbmRleE9mKFwiI1wiKTtcblx0Y29uc3QgaGFzaCA9IGhhc2hJZHggIT09IC0xID8gZnVsbEhyZWYuc2xpY2UoaGFzaElkeCkgOiBcIlwiO1xuXHRjb25zdCBzY3JvbGxJbnRlbnQgPSBzY3JvbGwgPyBiZWdpbkFwcFJvdXRlclNjcm9sbEludGVudChoYXNoIHx8IG51bGwpIDogbnVsbDtcblx0aWYgKCFzY3JvbGwpIGNsZWFyQXBwUm91dGVyU2Nyb2xsSW50ZW50KCk7XG5cdGNvbnN0IGFwcE5hdmlnYXRlID0gZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLm5hdmlnYXRlO1xuXHR0cnkge1xuXHRcdGlmIChhcHBOYXZpZ2F0ZSkgYXdhaXQgYXBwTmF2aWdhdGUoZnVsbEhyZWYsIDAsIFwibmF2aWdhdGVcIiwgbW9kZSwgdm9pZCAwLCBwcm9ncmFtbWF0aWNUcmFuc2l0aW9uLCB2b2lkIDAsIHNjcm9sbEludGVudCwgdmlzaWJsZUNvbW1pdE1vZGUsIGVhcmx5SW50ZW50LmJ5cGFzc05hdmlnYXRpb25DYWNoZSk7XG5cdFx0ZWxzZSB7XG5cdFx0XHRpZiAobW9kZSA9PT0gXCJyZXBsYWNlXCIpIHJlcGxhY2VIaXN0b3J5U3RhdGVXaXRob3V0Tm90aWZ5KG51bGwsIFwiXCIsIGZ1bGxIcmVmKTtcblx0XHRcdGVsc2UgcHVzaEhpc3RvcnlTdGF0ZVdpdGhvdXROb3RpZnkobnVsbCwgXCJcIiwgZnVsbEhyZWYpO1xuXHRcdFx0Y29tbWl0Q2xpZW50TmF2aWdhdGlvblN0YXRlKCk7XG5cdFx0fVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdGlmIChzY3JvbGxJbnRlbnQpIGNvbnN1bWVBcHBSb3V0ZXJTY3JvbGxJbnRlbnQoc2Nyb2xsSW50ZW50KTtcblx0XHR0aHJvdyBlcnJvcjtcblx0fVxuXHRpZiAoc2Nyb2xsSW50ZW50KSBzY2hlZHVsZUFwcFJvdXRlclNjcm9sbEZhbGxiYWNrKHNjcm9sbEludGVudCk7XG59XG5sZXQgc2NoZWR1bGVkQXBwUm91dGVyTmF2aWdhdGlvbkNvdW50ID0gMDtcbmZ1bmN0aW9uIHRyYWNrU2NoZWR1bGVkQXBwUm91dGVyTmF2aWdhdGlvbigpIHtcblx0c2NoZWR1bGVkQXBwUm91dGVyTmF2aWdhdGlvbkNvdW50ICs9IDE7XG5cdGxldCByZWxlYXNlZCA9IGZhbHNlO1xuXHRyZXR1cm4gKCkgPT4ge1xuXHRcdGlmIChyZWxlYXNlZCkgcmV0dXJuO1xuXHRcdHJlbGVhc2VkID0gdHJ1ZTtcblx0XHRzY2hlZHVsZWRBcHBSb3V0ZXJOYXZpZ2F0aW9uQ291bnQgPSBNYXRoLm1heCgwLCBzY2hlZHVsZWRBcHBSb3V0ZXJOYXZpZ2F0aW9uQ291bnQgLSAxKTtcblx0fTtcbn1cbmZ1bmN0aW9uIGhhc1NjaGVkdWxlZEFwcFJvdXRlck5hdmlnYXRpb24oKSB7XG5cdHJldHVybiBzY2hlZHVsZWRBcHBSb3V0ZXJOYXZpZ2F0aW9uQ291bnQgPiAwO1xufVxuZnVuY3Rpb24gcmVsZWFzZVNjaGVkdWxlZEFwcFJvdXRlck5hdmlnYXRpb25BZnRlckN1cnJlbnRUYXNrKHJlbGVhc2UpIHtcblx0cXVldWVNaWNyb3Rhc2socmVsZWFzZSk7XG59XG5sZXQgaW5GbGlnaHRBcHBSb3V0ZXJOYXZpZ2F0aW9uQ291bnQgPSAwO1xubGV0IHZpc2libGVMaW5rUGluZ0F3YWl0c05hdmlnYXRpb25zID0gZmFsc2U7XG4vKipcbiogQ2FsbGVkIGJ5IHRoZSBBcHAgUm91dGVyIGJyb3dzZXIgZW50cnkgZm9yIGVhY2ggUlNDIG5hdmlnYXRpb24gaXQgcnVucy5cbiogUmV0dXJucyBhIHJlbGVhc2UgY2FsbGJhY2sgZm9yIHRoZSBuYXZpZ2F0aW9uJ3Mgc2V0dGxlbWVudC5cbiovXG5mdW5jdGlvbiB0cmFja0FwcFJvdXRlck5hdmlnYXRpb25JbkZsaWdodCgpIHtcblx0aW5GbGlnaHRBcHBSb3V0ZXJOYXZpZ2F0aW9uQ291bnQgKz0gMTtcblx0bGV0IHJlbGVhc2VkID0gZmFsc2U7XG5cdHJldHVybiAoKSA9PiB7XG5cdFx0aWYgKHJlbGVhc2VkKSByZXR1cm47XG5cdFx0cmVsZWFzZWQgPSB0cnVlO1xuXHRcdGluRmxpZ2h0QXBwUm91dGVyTmF2aWdhdGlvbkNvdW50ID0gTWF0aC5tYXgoMCwgaW5GbGlnaHRBcHBSb3V0ZXJOYXZpZ2F0aW9uQ291bnQgLSAxKTtcblx0XHRpZiAoaW5GbGlnaHRBcHBSb3V0ZXJOYXZpZ2F0aW9uQ291bnQgPT09IDAgJiYgdmlzaWJsZUxpbmtQaW5nQXdhaXRzTmF2aWdhdGlvbnMpIHtcblx0XHRcdHZpc2libGVMaW5rUGluZ0F3YWl0c05hdmlnYXRpb25zID0gZmFsc2U7XG5cdFx0XHRnZXROYXZpZ2F0aW9uUnVudGltZSgpPy5mdW5jdGlvbnMucGluZ1Zpc2libGVMaW5rcz8uKCk7XG5cdFx0fVxuXHR9O1xufVxuZnVuY3Rpb24gcGluZ1Zpc2libGVMaW5rc09uY2VOYXZpZ2F0aW9uc1NldHRsZSgpIHtcblx0aWYgKGluRmxpZ2h0QXBwUm91dGVyTmF2aWdhdGlvbkNvdW50ID4gMCkge1xuXHRcdHZpc2libGVMaW5rUGluZ0F3YWl0c05hdmlnYXRpb25zID0gdHJ1ZTtcblx0XHRyZXR1cm47XG5cdH1cblx0Z2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLnBpbmdWaXNpYmxlTGlua3M/LigpO1xufVxuLyoqXG4qIEFwcCBSb3V0ZXIgcHVibGljIHJvdXRlciBpbnN0YW5jZS4gTWlycm9ycyBOZXh0LmpzJ3NcbiogYHB1YmxpY0FwcFJvdXRlckluc3RhbmNlYCBmcm9tXG4qIGBwYWNrYWdlcy9uZXh0L3NyYy9jbGllbnQvY29tcG9uZW50cy9hcHAtcm91dGVyLWluc3RhbmNlLnRzYC5cbipcbiogRXhwb3J0ZWQgc28gdGhlIEFwcCBSb3V0ZXIgYnJvd3NlciBlbnRyeSBjYW4gaW5zdGFsbCBpdCBvblxuKiBgd2luZG93Lm5leHQucm91dGVyYCBmb3IgTmV4dC5qcyBwYXJpdHkgKHNlZSBgY2xpZW50L3dpbmRvdy1uZXh0LnRzYCkuXG4qIEludGVybmFsIGNhbGxlcnMgaW4gdGhpcyBmaWxlIGNvbnRpbnVlIHRvIHVzZSBgX2FwcFJvdXRlcmAgZm9yIGJyZXZpdHkuXG4qL1xuY29uc3QgX2FwcFJvdXRlciA9IHtcblx0YmZjYWNoZUlkOiBcIjBcIixcblx0cHVzaChocmVmLCBvcHRpb25zKSB7XG5cdFx0YXNzZXJ0U2FmZU5hdmlnYXRpb25VcmwoaHJlZik7XG5cdFx0aWYgKGlzU2VydmVyKSByZXR1cm47XG5cdFx0bm90aWZ5QXBwTmF2aWdhdGlvblN0YXJ0KGhyZWYpO1xuXHRcdGNvbnN0IHJlbGVhc2VOYXZpZ2F0aW9uID0gdHJhY2tTY2hlZHVsZWRBcHBSb3V0ZXJOYXZpZ2F0aW9uKCk7XG5cdFx0dHJ5IHtcblx0XHRcdFJlYWN0JDEuc3RhcnRUcmFuc2l0aW9uKCgpID0+IHtcblx0XHRcdFx0bmF2aWdhdGVDbGllbnRTaWRlKGhyZWYsIFwicHVzaFwiLCBvcHRpb25zPy5zY3JvbGwgIT09IGZhbHNlLCB0cnVlKTtcblx0XHRcdH0pO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRyZWxlYXNlTmF2aWdhdGlvbigpO1xuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fVxuXHRcdHJlbGVhc2VTY2hlZHVsZWRBcHBSb3V0ZXJOYXZpZ2F0aW9uQWZ0ZXJDdXJyZW50VGFzayhyZWxlYXNlTmF2aWdhdGlvbik7XG5cdH0sXG5cdHJlcGxhY2UoaHJlZiwgb3B0aW9ucykge1xuXHRcdGFzc2VydFNhZmVOYXZpZ2F0aW9uVXJsKGhyZWYpO1xuXHRcdGlmIChpc1NlcnZlcikgcmV0dXJuO1xuXHRcdG5vdGlmeUFwcE5hdmlnYXRpb25TdGFydChocmVmKTtcblx0XHRjb25zdCByZWxlYXNlTmF2aWdhdGlvbiA9IHRyYWNrU2NoZWR1bGVkQXBwUm91dGVyTmF2aWdhdGlvbigpO1xuXHRcdHRyeSB7XG5cdFx0XHRSZWFjdCQxLnN0YXJ0VHJhbnNpdGlvbigoKSA9PiB7XG5cdFx0XHRcdG5hdmlnYXRlQ2xpZW50U2lkZShocmVmLCBcInJlcGxhY2VcIiwgb3B0aW9ucz8uc2Nyb2xsICE9PSBmYWxzZSwgdHJ1ZSk7XG5cdFx0XHR9KTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0cmVsZWFzZU5hdmlnYXRpb24oKTtcblx0XHRcdHRocm93IGVycm9yO1xuXHRcdH1cblx0XHRyZWxlYXNlU2NoZWR1bGVkQXBwUm91dGVyTmF2aWdhdGlvbkFmdGVyQ3VycmVudFRhc2socmVsZWFzZU5hdmlnYXRpb24pO1xuXHR9LFxuXHRiYWNrKCkge1xuXHRcdGlmIChpc1NlcnZlcikgcmV0dXJuO1xuXHRcdHdpbmRvdy5oaXN0b3J5LmJhY2soKTtcblx0fSxcblx0Zm9yd2FyZCgpIHtcblx0XHRpZiAoaXNTZXJ2ZXIpIHJldHVybjtcblx0XHR3aW5kb3cuaGlzdG9yeS5mb3J3YXJkKCk7XG5cdH0sXG5cdHJlZnJlc2goKSB7XG5cdFx0aWYgKGlzU2VydmVyKSByZXR1cm47XG5cdFx0Z2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLmNsZWFyTmF2aWdhdGlvbkNhY2hlcz8uKHsgcGluZ1Zpc2libGVMaW5rczogZmFsc2UgfSk7XG5cdFx0Y29uc3QgcnNjTmF2aWdhdGUgPSBnZXROYXZpZ2F0aW9uUnVudGltZSgpPy5mdW5jdGlvbnMubmF2aWdhdGU7XG5cdFx0aWYgKGhhc1NjaGVkdWxlZEFwcFJvdXRlck5hdmlnYXRpb24oKSB8fCAhcnNjTmF2aWdhdGUpIHtcblx0XHRcdGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5waW5nVmlzaWJsZUxpbmtzPy4oKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgbmF2aWdhdGUgPSAoKSA9PiB7XG5cdFx0XHRyc2NOYXZpZ2F0ZSh3aW5kb3cubG9jYXRpb24uaHJlZiwgMCwgXCJyZWZyZXNoXCIsIHZvaWQgMCwgdm9pZCAwLCB0cnVlKS5maW5hbGx5KHBpbmdWaXNpYmxlTGlua3NPbmNlTmF2aWdhdGlvbnNTZXR0bGUpO1xuXHRcdH07XG5cdFx0UmVhY3QkMS5zdGFydFRyYW5zaXRpb24obmF2aWdhdGUpO1xuXHR9LFxuXHRwcmVmZXRjaChocmVmLCBvcHRpb25zKSB7XG5cdFx0YXNzZXJ0U2FmZU5hdmlnYXRpb25VcmwoaHJlZik7XG5cdFx0aWYgKGlzU2VydmVyKSByZXR1cm47XG5cdFx0aWYgKGlzQm90VXNlckFnZW50KHdpbmRvdy5uYXZpZ2F0b3I/LnVzZXJBZ2VudCA/PyBcIlwiKSkgcmV0dXJuO1xuXHRcdHRyeSB7XG5cdFx0XHRuZXcgVVJMKHdpdGhCYXNlUGF0aChocmVmLCBfX2Jhc2VQYXRoKSwgd2luZG93LmxvY2F0aW9uLmhyZWYpO1xuXHRcdH0gY2F0Y2gge1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKGBDYW5ub3QgcHJlZmV0Y2ggJyR7aHJlZn0nIGJlY2F1c2UgaXQgY2Fubm90IGJlIGNvbnZlcnRlZCB0byBhIFVSTC5gKTtcblx0XHR9XG5cdFx0Y29uc3QgcHJlZmV0Y2hIcmVmID0gaXNFeHRlcm5hbFVybChocmVmKSA/IHRvU2FtZU9yaWdpbkFwcFBhdGgoaHJlZiwgX19iYXNlUGF0aCkgOiBocmVmO1xuXHRcdGlmIChwcmVmZXRjaEhyZWYgPT0gbnVsbCkgcmV0dXJuO1xuXHRcdGNvbnN0IGZ1bGxIcmVmID0gdG9BcHBQcmVmZXRjaERlc3RpbmF0aW9uKHByZWZldGNoSHJlZik7XG5cdFx0aWYgKGZ1bGxIcmVmID09PSBudWxsKSByZXR1cm47XG5cdFx0Y29uc3QgY3VycmVudFBhdGhuYW1lID0gd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lO1xuXHRcdGxldCBpbnRlcmNlcHRpb25Db250ZXh0ID0gZ2V0UHJlZmV0Y2hJbnRlcmNlcHRpb25Db250ZXh0KGZ1bGxIcmVmLCBjdXJyZW50UGF0aG5hbWUpO1xuXHRcdGNvbnN0IG1vdW50ZWRTbG90c0hlYWRlciA9IGdldE1vdW50ZWRTbG90c0hlYWRlcigpO1xuXHRcdGNvbnN0IGhlYWRlcnMgPSBjcmVhdGVBcHBQcmVmZXRjaFJlcXVlc3RIZWFkZXJzKHtcblx0XHRcdGZldGNoUHJpb3JpdHk6IFwibG93XCIsXG5cdFx0XHRpbnRlcmNlcHRpb25Db250ZXh0LFxuXHRcdFx0bW91bnRlZFNsb3RzSGVhZGVyOiBtb3VudGVkU2xvdHNIZWFkZXIgfHwgbnVsbFxuXHRcdH0pO1xuXHRcdGNvbnN0IHNldHVwID0gYmVnaW5QcmVmZXRjaFNldHVwKGZ1bGxIcmVmKTtcblx0XHQoYXN5bmMgKCkgPT4ge1xuXHRcdFx0Y29uc3Qgcm91dGVNYW5pZmVzdExvYWQgPSBsb2FkTmF2aWdhdGlvblJ1bnRpbWVSb3V0ZU1hbmlmZXN0KCk7XG5cdFx0XHRpZiAocm91dGVNYW5pZmVzdExvYWQgIT09IG51bGwpIHtcblx0XHRcdFx0aWYgKCFhd2FpdCByb3V0ZU1hbmlmZXN0TG9hZCB8fCBzZXR1cC5jYW5jZWxsZWQpIHJldHVybjtcblx0XHRcdFx0aW50ZXJjZXB0aW9uQ29udGV4dCA9IGdldFByZWZldGNoSW50ZXJjZXB0aW9uQ29udGV4dChmdWxsSHJlZiwgY3VycmVudFBhdGhuYW1lKTtcblx0XHRcdFx0aWYgKGludGVyY2VwdGlvbkNvbnRleHQgIT09IG51bGwpIGhlYWRlcnMuc2V0KFZJTkVYVF9JTlRFUkNFUFRJT05fQ09OVEVYVF9IRUFERVIsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRcdFx0fVxuXHRcdFx0aWYgKEhBU19DTElFTlRfUkVXUklURVMpIGF3YWl0IHByZWxvYWRIeWJyaWRDbGllbnRSb3V0ZU93bmVyKCk7XG5cdFx0XHRjb25zdCBoeWJyaWRPd25lciA9IHJlc29sdmVIeWJyaWRDbGllbnRSb3V0ZU93bmVyKGZ1bGxIcmVmKTtcblx0XHRcdGlmIChoeWJyaWRPd25lciA9PT0gXCJwYWdlc1wiIHx8IGh5YnJpZE93bmVyID09PSBcImRvY3VtZW50XCIpIHJldHVybjtcblx0XHRcdGNvbnN0IHJld3JpdHRlblByZWZldGNoSHJlZiA9IEhBU19DTElFTlRfUkVXUklURVMgPyByZXNvbHZlTG9hZGVkSHlicmlkQ2xpZW50UmV3cml0ZUhyZWYoZnVsbEhyZWYsIF9fYmFzZVBhdGgpIDogbnVsbDtcblx0XHRcdGNvbnN0IGtpbmQgPSBvcHRpb25zPy5raW5kID09PSBcImZ1bGxcIiA/IFwiZnVsbFwiIDogXCJhdXRvXCI7XG5cdFx0XHRjb25zdCBbeyByZXNvbHZlQXV0b0FwcFJvdXRlUHJlZmV0Y2gsIHJlc29sdmVGdWxsQXBwUm91dGVQcmVmZXRjaCB9LCB7IHJlc29sdmVBcHBQcmVmZXRjaFJzY1JlcXVlc3QgfV0gPSBhd2FpdCBQcm9taXNlLmFsbChbaW1wb3J0KFwiLi9pbnRlcm5hbC9hcHAtcm91dGUtcHJlZmV0Y2gtcG9saWN5LmpzXCIpLCBpbXBvcnQoXCIuL2ludGVybmFsL2FwcC1wcmVmZXRjaC1yc2MtcmVxdWVzdC5qc1wiKV0pO1xuXHRcdFx0aWYgKHNldHVwLmNhbmNlbGxlZCkgcmV0dXJuO1xuXHRcdFx0Y29uc3QgcG9saWN5ID0ga2luZCA9PT0gXCJmdWxsXCIgPyByZXNvbHZlRnVsbEFwcFJvdXRlUHJlZmV0Y2goKSA6IHJlc29sdmVBdXRvQXBwUm91dGVQcmVmZXRjaChyZXdyaXR0ZW5QcmVmZXRjaEhyZWYgPz8gZnVsbEhyZWYsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRcdFx0Y29uc3QgcmV1c2FibGUgPSBwb2xpY3kuc2hvdWxkUHJlZmV0Y2ggJiYgcG9saWN5LmNhY2hlRm9yTmF2aWdhdGlvbjtcblx0XHRcdGNvbnN0IHJlcXVpcmVzUm91dGVUcmVlUHJlZmV0Y2ggPSBwb2xpY3kucmVxdWlyZXNSb3V0ZVRyZWVQcmVmZXRjaCA9PT0gdHJ1ZTtcblx0XHRcdGlmIChyZXVzYWJsZSAmJiBraW5kID09PSBcImZ1bGxcIikgaGVhZGVycy5kZWxldGUoTkVYVF9ST1VURVJfUFJFRkVUQ0hfSEVBREVSKTtcblx0XHRcdGlmIChyZXVzYWJsZSAmJiBraW5kID09PSBcImF1dG9cIikge1xuXHRcdFx0XHRoZWFkZXJzLnNldChORVhUX1JPVVRFUl9QUkVGRVRDSF9IRUFERVIsIFwiMVwiKTtcblx0XHRcdFx0aGVhZGVycy5zZXQoTkVYVF9ST1VURVJfU0VHTUVOVF9QUkVGRVRDSF9IRUFERVIsIF9fcHJlZmV0Y2hJbmxpbmluZyB8fCByZXF1aXJlc1JvdXRlVHJlZVByZWZldGNoID8gXCIvX19QQUdFX19cIiA6IFwiMVwiKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGhhc1NlYXJjaFBhcmFtcyA9IG5ldyBVUkwoZnVsbEhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKS5zZWFyY2ggIT09IFwiXCI7XG5cdFx0XHRpZiAoIXJldXNhYmxlICYmIGtpbmQgPT09IFwiYXV0b1wiKSB7XG5cdFx0XHRcdGhlYWRlcnMuc2V0KE5FWFRfUk9VVEVSX1BSRUZFVENIX0hFQURFUiwgXCIxXCIpO1xuXHRcdFx0XHRoZWFkZXJzLnNldChORVhUX1JPVVRFUl9TRUdNRU5UX1BSRUZFVENIX0hFQURFUiwgXCIxXCIpO1xuXHRcdFx0XHRoZWFkZXJzLnNldChWSU5FWFRfUlNDX1JFTkRFUl9NT0RFX0hFQURFUiwgaGFzU2VhcmNoUGFyYW1zICYmIHBvbGljeS5yZW5kZXJzRHluYW1pY2FsbHkgIT09IHRydWUgPyBBUFBfUlNDX1JFTkRFUl9NT0RFX1BSRUZFVENIX0RZTkFNSUNfU0hFTEwgOiBBUFBfUlNDX1JFTkRFUl9NT0RFX1BSRUZFVENIX0xPQURJTkdfU0hFTEwpO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgeyBhZGRpdGlvbmFsUnNjVXJscywgcnNjVXJsIH0gPSBhd2FpdCByZXNvbHZlQXBwUHJlZmV0Y2hSc2NSZXF1ZXN0KHtcblx0XHRcdFx0ZnVsbEhyZWYsXG5cdFx0XHRcdGhlYWRlcnMsXG5cdFx0XHRcdHJld3JpdHRlblByZWZldGNoSHJlZlxuXHRcdFx0fSk7XG5cdFx0XHRpZiAoc2V0dXAuY2FuY2VsbGVkKSByZXR1cm47XG5cdFx0XHRjb25zdCBjYWNoZUtleSA9IEFwcEVsZW1lbnRzV2lyZS5lbmNvZGVDYWNoZUtleShyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQpO1xuXHRcdFx0Y29uc3QgcHJlZmV0Y2hlZCA9IGdldFByZWZldGNoZWRVcmxzKCk7XG5cdFx0XHRpZiAocG9saWN5LmR5bmFtaWNTdGFsZVRpbWUgIT09IFwiZnVsbC1wcmVmZXRjaFwiICYmIGhhc0ZyZXNoTGVhcm5pbmdPbmx5UHJlZmV0Y2hDYWNoZUVudHJ5KHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCkpIHtcblx0XHRcdFx0YXR0YWNoUHJlZmV0Y2hJbnZhbGlkYXRpb25DYWxsYmFjayhjYWNoZUtleSwgb3B0aW9ucz8ub25JbnZhbGlkYXRlKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHJldXNhYmxlKSB7XG5cdFx0XHRcdGRpc2NhcmRMZWFybmluZ09ubHlQcmVmZXRjaENhY2hlRW50cnkocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIpO1xuXHRcdFx0XHRpZiAoaGFzUHJlZmV0Y2hDYWNoZUVudHJ5Rm9yTmF2aWdhdGlvbihyc2NVcmwsIGludGVyY2VwdGlvbkNvbnRleHQsIG1vdW50ZWRTbG90c0hlYWRlciwge1xuXHRcdFx0XHRcdGFkZGl0aW9uYWxSc2NVcmxzLFxuXHRcdFx0XHRcdG9uSW52YWxpZGF0ZTogb3B0aW9ucz8ub25JbnZhbGlkYXRlLFxuXHRcdFx0XHRcdG9uUmV1c2U6IHBvbGljeS5keW5hbWljU3RhbGVUaW1lID09PSBcImZ1bGwtcHJlZmV0Y2hcIiA/IChlbnRyeSwgbWF0Y2hlZENhY2hlS2V5KSA9PiBwcm9tb3RlUHJlZmV0Y2hDYWNoZUVudHJ5Rm9yTmF2aWdhdGlvbihtYXRjaGVkQ2FjaGVLZXksIGVudHJ5KSA6IHZvaWQgMFxuXHRcdFx0XHR9KSkgcmV0dXJuO1xuXHRcdFx0XHRpZiAocG9saWN5LmR5bmFtaWNTdGFsZVRpbWUgPT09IFwiZnVsbC1wcmVmZXRjaFwiICYmIHNlZWRGdWxsUHJlZmV0Y2hGcm9tVmlzaXRlZFJlc3BvbnNlKHJzY1VybCwgaW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyLCBhZGRpdGlvbmFsUnNjVXJscywgb3B0aW9ucz8ub25JbnZhbGlkYXRlKSkgcmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHBvbGljeS5keW5hbWljU3RhbGVUaW1lICE9PSBcImZ1bGwtcHJlZmV0Y2hcIiAmJiBoYXNOYXZpZ2F0aW9uRnJlc2hWaXNpdGVkUmVzcG9uc2UocnNjVXJsLCBpbnRlcmNlcHRpb25Db250ZXh0LCBtb3VudGVkU2xvdHNIZWFkZXIsIGFkZGl0aW9uYWxSc2NVcmxzLCBvcHRpb25zPy5vbkludmFsaWRhdGUpKSByZXR1cm47XG5cdFx0XHRwcmVmZXRjaGVkLmFkZChjYWNoZUtleSk7XG5cdFx0XHRjb25zdCBmZXRjaEZ1bGxSc2NQYXlsb2FkID0gKCkgPT4gc2NoZWR1bGVBcHBQcmVmZXRjaEZldGNoKChzaWduYWwpID0+IGZldGNoKHJzY1VybCwge1xuXHRcdFx0XHRoZWFkZXJzLFxuXHRcdFx0XHRjcmVkZW50aWFsczogXCJpbmNsdWRlXCIsXG5cdFx0XHRcdHByaW9yaXR5OiBcImxvd1wiLFxuXHRcdFx0XHRzaWduYWxcblx0XHRcdH0pLCBcImxvd1wiKTtcblx0XHRcdHByZWZldGNoUnNjUmVzcG9uc2UocnNjVXJsLCByZXVzYWJsZSAmJiBraW5kID09PSBcImF1dG9cIiAmJiByZXF1aXJlc1JvdXRlVHJlZVByZWZldGNoID8gZmV0Y2hSb3V0ZVRyZWVHYXRlZFByZWZldGNoKHtcblx0XHRcdFx0ZmV0Y2hGdWxsUnNjUGF5bG9hZCxcblx0XHRcdFx0ZmV0Y2hSb3V0ZVRyZWU6IChyb3V0ZVRyZWVSc2NVcmwsIHJvdXRlVHJlZUhlYWRlcnMpID0+IHNjaGVkdWxlQXBwUHJlZmV0Y2hGZXRjaCgoc2lnbmFsKSA9PiBmZXRjaChyb3V0ZVRyZWVSc2NVcmwsIHtcblx0XHRcdFx0XHRoZWFkZXJzOiByb3V0ZVRyZWVIZWFkZXJzLFxuXHRcdFx0XHRcdGNyZWRlbnRpYWxzOiBcImluY2x1ZGVcIixcblx0XHRcdFx0XHRwcmlvcml0eTogXCJsb3dcIixcblx0XHRcdFx0XHRzaWduYWxcblx0XHRcdFx0fSksIFwibG93XCIpLFxuXHRcdFx0XHRmdWxsSHJlZixcblx0XHRcdFx0aGVhZGVycyxcblx0XHRcdFx0aW50ZXJjZXB0aW9uQ29udGV4dCxcblx0XHRcdFx0bW91bnRlZFNsb3RzSGVhZGVyXG5cdFx0XHR9KSA6IGZldGNoRnVsbFJzY1BheWxvYWQoKSwgaW50ZXJjZXB0aW9uQ29udGV4dCwgbW91bnRlZFNsb3RzSGVhZGVyLCBvcHRpb25zLCByZXVzYWJsZSA/IHtcblx0XHRcdFx0Y2FjaGVGb3JOYXZpZ2F0aW9uOiB0cnVlLFxuXHRcdFx0XHRmYWxsYmFja1R0bE1zOiBwb2xpY3kuZmFsbGJhY2tUdGwgPT09IFwiZHluYW1pY1wiID8gRFlOQU1JQ19OQVZJR0FUSU9OX0NBQ0hFX1RUTCA6IFBSRUZFVENIX0NBQ0hFX1RUTCxcblx0XHRcdFx0ZHluYW1pY1N0YWxlVGltZTogcG9saWN5LmR5bmFtaWNTdGFsZVRpbWUsXG5cdFx0XHRcdG9wdGltaXN0aWNSb3V0ZVNoZWxsOiBmYWxzZSxcblx0XHRcdFx0cHJlZmV0Y2hLaW5kOiBcIm5hdmlnYXRpb25cIixcblx0XHRcdFx0cHJlcGFyZVNuYXBzaG90OiBwcmVwYXJlTmF2aWdhdGlvblByZWZldGNoU25hcHNob3Rcblx0XHRcdH0gOiB7XG5cdFx0XHRcdGNhY2hlRm9yTmF2aWdhdGlvbjogZmFsc2UsXG5cdFx0XHRcdGZhbGxiYWNrVHRsTXM6IHBvbGljeS5mYWxsYmFja1R0bCA9PT0gXCJkeW5hbWljXCIgPyBEWU5BTUlDX05BVklHQVRJT05fQ0FDSEVfVFRMIDogUFJFRkVUQ0hfQ0FDSEVfVFRMLFxuXHRcdFx0XHRkeW5hbWljU3RhbGVUaW1lOiBwb2xpY3kuZHluYW1pY1N0YWxlVGltZSxcblx0XHRcdFx0b3B0aW1pc3RpY1JvdXRlU2hlbGw6IHRydWUsXG5cdFx0XHRcdHByZWZldGNoS2luZDogXCJuYXZpZ2F0aW9uXCJcblx0XHRcdH0pO1xuXHRcdH0pKCkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHRjb25zb2xlLmVycm9yKFwiW3ZpbmV4dF0gUlNDIHByZWZldGNoIHNldHVwIGVycm9yOlwiLCBlcnJvcik7XG5cdFx0fSkuZmluYWxseSgoKSA9PiB7XG5cdFx0XHRwZW5kaW5nUHJlZmV0Y2hTZXR1cHMuZGVsZXRlKHNldHVwKTtcblx0XHR9KTtcblx0fVxufTtcbmlmIChwcm9jZXNzLmVudi5fX05FWFRfR0VTVFVSRV9UUkFOU0lUSU9OKSBfYXBwUm91dGVyLmV4cGVyaW1lbnRhbF9nZXN0dXJlUHVzaCA9IChocmVmLCBvcHRpb25zKSA9PiB7XG5cdGFzc2VydFNhZmVOYXZpZ2F0aW9uVXJsKGhyZWYpO1xuXHRpZiAoaXNTZXJ2ZXIpIHJldHVybjtcblx0aWYgKCFnZXROYXZpZ2F0aW9uUnVudGltZSgpPy5mdW5jdGlvbnMubmF2aWdhdGUpIHJldHVybjtcblx0bGV0IGFwcEhyZWYgPSBocmVmO1xuXHRpZiAoaXNFeHRlcm5hbFVybChocmVmKSkge1xuXHRcdGNvbnN0IGxvY2FsUGF0aCA9IHRvU2FtZU9yaWdpbkFwcFBhdGgoaHJlZiwgX19iYXNlUGF0aCk7XG5cdFx0aWYgKGxvY2FsUGF0aCA9PT0gbnVsbCkgcmV0dXJuO1xuXHRcdGFwcEhyZWYgPSBsb2NhbFBhdGg7XG5cdH1cblx0Y29uc3QgcmVsZWFzZU5hdmlnYXRpb24gPSB0cmFja1NjaGVkdWxlZEFwcFJvdXRlck5hdmlnYXRpb24oKTtcblx0bmF2aWdhdGVDbGllbnRTaWRlKGFwcEhyZWYsIFwicHVzaFwiLCBvcHRpb25zPy5zY3JvbGwgIT09IGZhbHNlLCBmYWxzZSwgXCJzeW5jaHJvbm91c1wiKTtcblx0cmVsZWFzZVNjaGVkdWxlZEFwcFJvdXRlck5hdmlnYXRpb25BZnRlckN1cnJlbnRUYXNrKHJlbGVhc2VOYXZpZ2F0aW9uKTtcbn07XG5mdW5jdGlvbiBmb3JtYXRQdWJsaWNCZmNhY2hlSWQodmFsdWUpIHtcblx0aWYgKCF2YWx1ZSB8fCB2YWx1ZSA9PT0gXCIwXCIpIHJldHVybiBQVUJMSUNfSU5JVElBTF9CRkNBQ0hFX0lEO1xuXHRyZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiByZWFkQmZjYWNoZUlkRnJvbUNvbnRleHQoKSB7XG5cdGNvbnN0IHNlZ21lbnRDb250ZXh0ID0gZ2V0QmZjYWNoZVNlZ21lbnRJZENvbnRleHQoKTtcblx0Y29uc3QgaWRNYXBDb250ZXh0ID0gZ2V0QmZjYWNoZUlkTWFwQ29udGV4dCgpO1xuXHRpZiAoIXNlZ21lbnRDb250ZXh0IHx8ICFpZE1hcENvbnRleHQgfHwgdHlwZW9mIFJlYWN0JDEudXNlQ29udGV4dCAhPT0gXCJmdW5jdGlvblwiKSByZXR1cm4gZm9ybWF0UHVibGljQmZjYWNoZUlkKG51bGwpO1xuXHR0cnkge1xuXHRcdGNvbnN0IHNlZ21lbnRJZCA9IFJlYWN0JDEudXNlQ29udGV4dChzZWdtZW50Q29udGV4dCk7XG5cdFx0Y29uc3QgaWRNYXAgPSBSZWFjdCQxLnVzZUNvbnRleHQoaWRNYXBDb250ZXh0KTtcblx0XHRyZXR1cm4gZm9ybWF0UHVibGljQmZjYWNoZUlkKHNlZ21lbnRJZCAhPT0gbnVsbCA/IGlkTWFwPy5bc2VnbWVudElkXSA6IG51bGwpO1xuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihcIlt2aW5leHRdIHJlYWRCZmNhY2hlSWRGcm9tQ29udGV4dCBmYWlsZWQ6XCIsIGVycm9yKTtcblx0XHRyZXR1cm4gZm9ybWF0UHVibGljQmZjYWNoZUlkKG51bGwpO1xuXHR9XG59XG4vKipcbiogUHVibGljIEFwcCBSb3V0ZXIgaW5zdGFuY2UsIGV4cG9zZWQgZm9yIHRoZSBicm93c2VyIGVudHJ5IHNvIGl0IGNhbiB3aXJlXG4qIGB3aW5kb3cubmV4dC5yb3V0ZXJgIHRvIHRoZSBzYW1lIHNpbmdsZXRvbiByZXR1cm5lZCBmcm9tIGB1c2VSb3V0ZXIoKWAuXG4qXG4qIE1pcnJvcnMgYHB1YmxpY0FwcFJvdXRlckluc3RhbmNlYCBmcm9tIE5leHQuanMnc1xuKiBgcGFja2FnZXMvbmV4dC9zcmMvY2xpZW50L2NvbXBvbmVudHMvYXBwLXJvdXRlci1pbnN0YW5jZS50c2AgKGxpbmUgMzkyKS5cbiovXG5jb25zdCBhcHBSb3V0ZXJJbnN0YW5jZSA9IF9hcHBSb3V0ZXI7XG4vKipcbiogQXBwIFJvdXRlcidzIHVzZVJvdXRlciDigJQgcmV0dXJucyBwdXNoL3JlcGxhY2UvYmFjay9mb3J3YXJkL3JlZnJlc2guXG4qIERpZmZlcmVudCBmcm9tIFBhZ2VzIFJvdXRlcidzIHVzZVJvdXRlciAobmV4dC9yb3V0ZXIpLlxuKlxuKiBQcmVzZXJ2ZXMgdGhlIG1vdW50ZWQgQXBwUm91dGVyQ29udGV4dCByb3V0ZXIgYXMgdGhlIGF1dGhvcml0eSBmb3IgbWV0aG9kc1xuKiBhbmQgbGF5ZXJzIHRoZSBuZWFyZXN0IHNlZ21lbnQncyBjb250ZXh0dWFsIGBiZmNhY2hlSWRgIG9uIHRvcC5cbiovXG5mdW5jdGlvbiB1c2VSb3V0ZXIoKSB7XG5cdGlmICghQXBwUm91dGVyQ29udGV4dCB8fCB0eXBlb2YgUmVhY3QkMS51c2VDb250ZXh0ICE9PSBcImZ1bmN0aW9uXCIgfHwgdHlwZW9mIFJlYWN0JDEudXNlTWVtbyAhPT0gXCJmdW5jdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IoXCJpbnZhcmlhbnQgZXhwZWN0ZWQgYXBwIHJvdXRlciB0byBiZSBtb3VudGVkXCIpO1xuXHRjb25zdCByb3V0ZXIgPSBSZWFjdCQxLnVzZUNvbnRleHQoQXBwUm91dGVyQ29udGV4dCk7XG5cdGlmIChyb3V0ZXIgPT09IG51bGwpIHRocm93IG5ldyBFcnJvcihcImludmFyaWFudCBleHBlY3RlZCBhcHAgcm91dGVyIHRvIGJlIG1vdW50ZWRcIik7XG5cdGNvbnN0IGJmY2FjaGVJZCA9IHJlYWRCZmNhY2hlSWRGcm9tQ29udGV4dCgpO1xuXHRyZXR1cm4gUmVhY3QkMS51c2VNZW1vKCgpID0+ICh7XG5cdFx0Li4ucm91dGVyLFxuXHRcdGJmY2FjaGVJZFxuXHR9KSwgW3JvdXRlciwgYmZjYWNoZUlkXSk7XG59XG4vKipcbiogUmV0dXJucyB0aGUgYWN0aXZlIGNoaWxkIHNlZ21lbnQgb25lIGxldmVsIGJlbG93IHRoZSBsYXlvdXQgd2hlcmUgaXQncyBjYWxsZWQuXG4qXG4qIFJldHVybnMgdGhlIGZpcnN0IHNlZ21lbnQgZnJvbSB0aGUgcm91dGUgdHJlZSBiZWxvdyB0aGlzIGxheW91dCwgaW5jbHVkaW5nXG4qIHJvdXRlIGdyb3VwcyAoZS5nLiwgXCIobWFya2V0aW5nKVwiKSBhbmQgcmVzb2x2ZWQgZHluYW1pYyBwYXJhbXMuIFJldHVybnMgbnVsbFxuKiBpZiBhdCB0aGUgbGVhZiAobm8gY2hpbGQgc2VnbWVudHMpLlxuKlxuKiBAcGFyYW0gcGFyYWxsZWxSb3V0ZXNLZXkgLSBXaGljaCBwYXJhbGxlbCByb3V0ZSB0byByZWFkIChkZWZhdWx0OiBcImNoaWxkcmVuXCIpXG4qL1xuZnVuY3Rpb24gdXNlU2VsZWN0ZWRMYXlvdXRTZWdtZW50KHBhcmFsbGVsUm91dGVzS2V5KSB7XG5cdGNvbnN0IHNlZ21lbnRzID0gdXNlU2VsZWN0ZWRMYXlvdXRTZWdtZW50cyhwYXJhbGxlbFJvdXRlc0tleSk7XG5cdGlmIChzZWdtZW50cy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuXHRyZXR1cm4gcGFyYWxsZWxSb3V0ZXNLZXkgPT09IHZvaWQgMCB8fCBwYXJhbGxlbFJvdXRlc0tleSA9PT0gXCJjaGlsZHJlblwiID8gc2VnbWVudHNbMF0gOiBzZWdtZW50c1tzZWdtZW50cy5sZW5ndGggLSAxXTtcbn1cbi8qKlxuKiBSZXR1cm5zIGFsbCBhY3RpdmUgc2VnbWVudHMgYmVsb3cgdGhlIGxheW91dCB3aGVyZSBpdCdzIGNhbGxlZC5cbipcbiogRWFjaCBsYXlvdXQgaW4gdGhlIEFwcCBSb3V0ZXIgdHJlZSB3cmFwcyBpdHMgY2hpbGRyZW4gd2l0aCBhXG4qIExheW91dFNlZ21lbnRQcm92aWRlciB3aG9zZSB2YWx1ZSBpcyBhIG1hcCBvZiBwYXJhbGxlbCByb3V0ZSBrZXkgdG9cbiogc2VnbWVudCBhcnJheXMuIFRoZSBcImNoaWxkcmVuXCIga2V5IGlzIHRoZSBkZWZhdWx0IHBhcmFsbGVsIHJvdXRlLlxuKlxuKiBAcGFyYW0gcGFyYWxsZWxSb3V0ZXNLZXkgLSBXaGljaCBwYXJhbGxlbCByb3V0ZSB0byByZWFkIChkZWZhdWx0OiBcImNoaWxkcmVuXCIpXG4qL1xuZnVuY3Rpb24gdXNlU2VsZWN0ZWRMYXlvdXRTZWdtZW50cyhwYXJhbGxlbFJvdXRlc0tleSkge1xuXHRpZiAoaXNTZXJ2ZXIpIG1hcmtQcHJGYWxsYmFja1NoZWxsRHluYW1pY0JvdW5kYXJ5KCk7XG5cdHJldHVybiB1c2VDaGlsZFNlZ21lbnRzKHBhcmFsbGVsUm91dGVzS2V5KTtcbn1cbi8qKlxuKiB1c2VTZXJ2ZXJJbnNlcnRlZEhUTUwg4oCUIGluamVjdCBIVE1MIGR1cmluZyBTU1IgZnJvbSBjbGllbnQgY29tcG9uZW50cy5cbipcbiogVXNlZCBieSBDU1MtaW4tSlMgbGlicmFyaWVzIChzdHlsZWQtY29tcG9uZW50cywgZW1vdGlvbiwgU3R5bGVYKSB0byBpbmplY3RcbiogPHN0eWxlPiB0YWdzIGR1cmluZyBTU1Igc28gc3R5bGVzIGFwcGVhciBpbiB0aGUgaW5pdGlhbCBIVE1MIChubyBGT1VDKS5cbipcbiogVGhlIGNhbGxiYWNrIGlzIGNhbGxlZCBvbmNlIGFmdGVyIGVhY2ggU1NSIHJlbmRlciBwYXNzLiBUaGUgcmV0dXJuZWQgSlNYL0hUTUxcbiogaXMgc2VyaWFsaXplZCBhbmQgaW5qZWN0ZWQgaW50byB0aGUgSFRNTCBzdHJlYW0uXG4qXG4qIFVzYWdlIChpbiBhIFwidXNlIGNsaWVudFwiIGNvbXBvbmVudCB3cmFwcGluZyBjaGlsZHJlbik6XG4qICAgdXNlU2VydmVySW5zZXJ0ZWRIVE1MKCgpID0+IHtcbiogICAgIGNvbnN0IHN0eWxlcyA9IHNoZWV0LmdldFN0eWxlRWxlbWVudCgpO1xuKiAgICAgc2hlZXQuaW5zdGFuY2UuY2xlYXJUYWcoKTtcbiogICAgIHJldHVybiA8PntzdHlsZXN9PC8+O1xuKiAgIH0pO1xuKi9cbmZ1bmN0aW9uIHVzZVNlcnZlckluc2VydGVkSFRNTChjYWxsYmFjaykge1xuXHRpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG5cdHJlZ2lzdGVyU2VydmVySW5zZXJ0ZWRIVE1MQ2FsbGJhY2soY2FsbGJhY2spO1xufVxuaWYgKCFpc1NlcnZlcikge1xuXHRjb25zdCBzdGF0ZSA9IGdldENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRpZiAoc3RhdGUgJiYgIXN0YXRlLnBhdGNoSW5zdGFsbGVkKSB7XG5cdFx0c3RhdGUucGF0Y2hJbnN0YWxsZWQgPSB0cnVlO1xuXHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicG9wc3RhdGVcIiwgKCkgPT4ge1xuXHRcdFx0bm90aWZ5QXBwUG9wc3RhdGVOYXZpZ2F0aW9uU3RhcnQoKTtcblx0XHR9KTtcblx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBvcHN0YXRlXCIsIChldmVudCkgPT4ge1xuXHRcdFx0aWYgKCFoYXNBcHBOYXZpZ2F0aW9uUnVudGltZSgpKSB7XG5cdFx0XHRcdGNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZSgpO1xuXHRcdFx0XHRyZXN0b3JlU2Nyb2xsUG9zaXRpb24oZXZlbnQuc3RhdGUpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHdpbmRvdy5oaXN0b3J5LnB1c2hTdGF0ZSA9IGZ1bmN0aW9uIHBhdGNoZWRQdXNoU3RhdGUoZGF0YSwgdW51c2VkLCB1cmwpIHtcblx0XHRcdGlmIChmb3J3YXJkUm91dGVySGlzdG9yeVdyaXRlKHN0YXRlLCBcInB1c2hTdGF0ZVwiLCBkYXRhLCB1bnVzZWQsIHVybCkpIHJldHVybjtcblx0XHRcdGlmIChzdGF0ZS5yb3V0ZXJIaXN0b3J5V3JpdGVEZXB0aCA9PT0gMCkgZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLmZsdXNoQ29tbWl0dGluZ05hdmlnYXRpb25Vcmw/LigpO1xuXHRcdFx0aWYgKGlzQXBwT3duZWRIaXN0b3J5U3RhdGUoZGF0YSkpIHtcblx0XHRcdFx0Y29uc3QgcHJldmlvdXNIaXN0b3J5U3RhdGUgPSB3aW5kb3cuaGlzdG9yeS5zdGF0ZTtcblx0XHRcdFx0c3RhdGUub3JpZ2luYWxQdXNoU3RhdGUuY2FsbCh3aW5kb3cuaGlzdG9yeSwgZGF0YSwgdW51c2VkLCB1cmwpO1xuXHRcdFx0XHRnZXROYXZpZ2F0aW9uUnVudGltZSgpPy5mdW5jdGlvbnMuY29tbWl0QXBwT3duZWRIaXN0b3J5U3RhdGVXcml0ZT8uKFwicHVzaFwiLCBwcmV2aW91c0hpc3RvcnlTdGF0ZSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHByZXZpb3VzSGlzdG9yeVN0YXRlID0gd2luZG93Lmhpc3Rvcnkuc3RhdGU7XG5cdFx0XHRzdGF0ZS5vcmlnaW5hbFB1c2hTdGF0ZS5jYWxsKHdpbmRvdy5oaXN0b3J5LCBjcmVhdGVFeHRlcm5hbEhpc3RvcnlTdGF0ZVByZXNlcnZpbmdNZXRhZGF0YShkYXRhLCB3aW5kb3cuaGlzdG9yeS5zdGF0ZSksIHVudXNlZCwgdXJsKTtcblx0XHRcdGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5jbGFpbUN1cnJlbnRIaXN0b3J5VHJlZVNuYXBzaG90Py4oXCJwdXNoXCIsIHByZXZpb3VzSGlzdG9yeVN0YXRlKTtcblx0XHRcdGlmIChzdGF0ZS5zdXBwcmVzc1VybE5vdGlmeUNvdW50ID09PSAwKSB7XG5cdFx0XHRcdHJlc2V0U3RhbGVMaW5rU3RhdHVzKCk7XG5cdFx0XHRcdGlmICh1cmwpIGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5kaXNjYXJkUGVuZGluZ05hdmlnYXRpb24/LigpO1xuXHRcdFx0XHRjb21taXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZSA9IGZ1bmN0aW9uIHBhdGNoZWRSZXBsYWNlU3RhdGUoZGF0YSwgdW51c2VkLCB1cmwpIHtcblx0XHRcdGlmIChmb3J3YXJkUm91dGVySGlzdG9yeVdyaXRlKHN0YXRlLCBcInJlcGxhY2VTdGF0ZVwiLCBkYXRhLCB1bnVzZWQsIHVybCkpIHJldHVybjtcblx0XHRcdGlmIChzdGF0ZS5yb3V0ZXJIaXN0b3J5V3JpdGVEZXB0aCA9PT0gMCkgZ2V0TmF2aWdhdGlvblJ1bnRpbWUoKT8uZnVuY3Rpb25zLmZsdXNoQ29tbWl0dGluZ05hdmlnYXRpb25Vcmw/LigpO1xuXHRcdFx0aWYgKGlzQXBwT3duZWRIaXN0b3J5U3RhdGUoZGF0YSkpIHtcblx0XHRcdFx0Y29uc3QgcHJldmlvdXNIaXN0b3J5U3RhdGUgPSB3aW5kb3cuaGlzdG9yeS5zdGF0ZTtcblx0XHRcdFx0c3RhdGUub3JpZ2luYWxSZXBsYWNlU3RhdGUuY2FsbCh3aW5kb3cuaGlzdG9yeSwgZGF0YSwgdW51c2VkLCB1cmwpO1xuXHRcdFx0XHRnZXROYXZpZ2F0aW9uUnVudGltZSgpPy5mdW5jdGlvbnMuY29tbWl0QXBwT3duZWRIaXN0b3J5U3RhdGVXcml0ZT8uKFwicmVwbGFjZVwiLCBwcmV2aW91c0hpc3RvcnlTdGF0ZSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHByZXZpb3VzSGlzdG9yeVN0YXRlID0gd2luZG93Lmhpc3Rvcnkuc3RhdGU7XG5cdFx0XHRzdGF0ZS5vcmlnaW5hbFJlcGxhY2VTdGF0ZS5jYWxsKHdpbmRvdy5oaXN0b3J5LCBjcmVhdGVFeHRlcm5hbEhpc3RvcnlTdGF0ZVByZXNlcnZpbmdNZXRhZGF0YShkYXRhLCB3aW5kb3cuaGlzdG9yeS5zdGF0ZSksIHVudXNlZCwgdXJsKTtcblx0XHRcdGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5jbGFpbUN1cnJlbnRIaXN0b3J5VHJlZVNuYXBzaG90Py4oXCJyZXBsYWNlXCIsIHByZXZpb3VzSGlzdG9yeVN0YXRlKTtcblx0XHRcdGlmIChzdGF0ZS5zdXBwcmVzc1VybE5vdGlmeUNvdW50ID09PSAwKSB7XG5cdFx0XHRcdHJlc2V0U3RhbGVMaW5rU3RhdHVzKCk7XG5cdFx0XHRcdGlmICh1cmwpIGdldE5hdmlnYXRpb25SdW50aW1lKCk/LmZ1bmN0aW9ucy5kaXNjYXJkUGVuZGluZ05hdmlnYXRpb24/LigpO1xuXHRcdFx0XHRjb21taXRDbGllbnROYXZpZ2F0aW9uU3RhdGUoKTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEJhaWxvdXRUb0NTUkVycm9yLCBEWU5BTUlDX05BVklHQVRJT05fQ0FDSEVfVFRMLCBEeW5hbWljU2VydmVyRXJyb3IsIEdMT0JBTF9BQ0NFU1NPUlNfS0VZLCBIVFRQX0VSUk9SX0ZBTExCQUNLX0VSUk9SX0NPREUsIE1BWF9QUkVGRVRDSF9DQUNIRV9TSVpFLCBQUkVGRVRDSF9DQUNIRV9UVEwsIFJlYWRvbmx5VVJMU2VhcmNoUGFyYW1zLCBSZWRpcmVjdFR5cGUsIFNlcnZlckluc2VydGVkSFRNTENvbnRleHQsIFVucmVjb2duaXplZEFjdGlvbkVycm9yLCBfX2Jhc2VQYXRoLCBfcmVnaXN0ZXJTdGF0ZUFjY2Vzc29ycywgYWN0aXZhdGVOYXZpZ2F0aW9uU25hcHNob3QsIGFwcFJvdXRlckluc3RhbmNlLCBhcHBseUFwcFJvdXRlclNjcm9sbEZhbGxiYWNrLCBjbGVhclBlbmRpbmdQYXRobmFtZSwgY2xlYXJTZXJ2ZXJJbnNlcnRlZEhUTUwsIGNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZSwgY29uc3VtZVByZWZldGNoUmVzcG9uc2UsIGNvbnN1bWVQcmVmZXRjaFJlc3BvbnNlRm9yTmF2aWdhdGlvbiwgY3JlYXRlQXBwUHJlZmV0Y2hSZXF1ZXN0SGVhZGVycywgY3JlYXRlQ2FjaGVkUnNjUmVzcG9uc2VTbmFwc2hvdCwgY3JlYXRlQ2xpZW50TmF2aWdhdGlvblJlbmRlclNuYXBzaG90LCBjcmVhdGVTbmFwc2hvdFBhdGhBbmRTZWFyY2gsIGRlY29kZVJlZGlyZWN0RXJyb3IsIGRlbGV0ZVByZWZldGNoUmVzcG9uc2VTbmFwc2hvdCwgZGlzYWJsZU5hdmlnYXRpb25SZXNwb25zZVByZWZldGNoQ2FjaGVSZXVzZSwgZGlzY2FyZExlYXJuaW5nT25seVByZWZldGNoQ2FjaGVFbnRyeSwgZmV0Y2hSb3V0ZVRyZWVHYXRlZFByZWZldGNoLCBmbHVzaFNlcnZlckluc2VydGVkSFRNTCwgZm9yYmlkZGVuLCBnZXRBY2Nlc3NGYWxsYmFja0hUVFBTdGF0dXMsIGdldEJmY2FjaGVJZE1hcENvbnRleHQsIGdldEJmY2FjaGVTZWdtZW50SWRDb250ZXh0LCBnZXRDbGllbnROYXZpZ2F0aW9uUmVuZGVyQ29udGV4dCwgZ2V0Q2xpZW50TmF2aWdhdGlvblN0YXRlLCBnZXRDbGllbnRQYXJhbXMsIGdldEN1cnJlbnRJbnRlcmNlcHRpb25Db250ZXh0LCBnZXRDdXJyZW50TmV4dFVybCwgZ2V0RnJlc2hQcmVmZXRjaENhY2hlRW50cnksIGdldExheW91dFNlZ21lbnRDb250ZXh0LCBnZXRNb3VudGVkU2xvdHNIZWFkZXIsIGdldE5hdmlnYXRpb25Db250ZXh0LCBnZXRQcmVmZXRjaENhY2hlLCBnZXRQcmVmZXRjaEludGVyY2VwdGlvbkNvbnRleHQsIGdldFByZWZldGNoZWRVcmxzLCBoYXNGcmVzaExlYXJuaW5nT25seVByZWZldGNoQ2FjaGVFbnRyeSwgaGFzTmF2aWdhdGlvbkZyZXNoVmlzaXRlZFJlc3BvbnNlLCBoYXNQcmVmZXRjaENhY2hlRW50cnlGb3JOYXZpZ2F0aW9uLCBoYXNTZWFyY2hBZ25vc3RpY1ByZWZldGNoU2hlbGxGb3JSb3V0ZSwgaW52YWxpZGF0ZUR5bmFtaWNQcmVmZXRjaENhY2hlLCBpbnZhbGlkYXRlUHJlZmV0Y2hDYWNoZSwgaW52YWxpZGF0ZVZpc2l0ZWRSZXNwb25zZVByZWZldGNoZXMsIGlzQmFpbG91dFRvQ1NSRXJyb3IsIGlzRHluYW1pY1NlcnZlckVycm9yLCBpc0hUVFBBY2Nlc3NGYWxsYmFja0Vycm9yLCBpc05leHRSb3V0ZXJFcnJvciwgaXNSZWRpcmVjdEVycm9yLCBuYXZpZ2F0ZUNsaWVudFNpZGUsIG5vdEZvdW5kLCBwYXJzZVJlbmRlcmVkUGF0aEFuZFNlYXJjaEhlYWRlciwgcGVla1ByZWZldGNoUmVzcG9uc2VGb3JOYXZpZ2F0aW9uLCBwZXJtYW5lbnRSZWRpcmVjdCwgcHJlZmV0Y2hSc2NSZXNwb25zZSwgcHJlbG9hZEh5YnJpZENsaWVudFJvdXRlT3duZXIsIHByZXBhcmVOYXZpZ2F0aW9uUHJlZmV0Y2hTbmFwc2hvdCwgcHJvbW90ZVByZWZldGNoQ2FjaGVFbnRyeUZvck5hdmlnYXRpb24sIHB1c2hIaXN0b3J5U3RhdGVXaXRob3V0Tm90aWZ5LCByZWRpcmVjdCwgcmVuZGVyU2VydmVySW5zZXJ0ZWRIVE1MLCByZXBsYWNlQ2xpZW50UGFyYW1zV2l0aG91dE5vdGlmeSwgcmVwbGFjZUhpc3RvcnlTdGF0ZVdpdGhvdXROb3RpZnksIHJlc29sdmVDYWNoZWRSc2NSZXNwb25zZUV4cGlyZXNBdCwgcmVzb2x2ZUNhY2hlZFJzY1Jlc3BvbnNlVHRsTXMsIHJlc29sdmVMb2FkZWRIeWJyaWRDbGllbnRSZXdyaXRlSHJlZiwgcmVzb2x2ZVByZWZldGNoQ2FjaGVFbnRyeU1vdW50ZWRTbG90c0hlYWRlciwgcmVzdG9yZVJzY1Jlc3BvbnNlLCBzYXZlU2Nyb2xsUG9zaXRpb24sIHNlZWRGdWxsUHJlZmV0Y2hGcm9tVmlzaXRlZFJlc3BvbnNlLCBzZWVkUHJlZmV0Y2hSZXNwb25zZVNuYXBzaG90LCBzZXRDbGllbnRQYXJhbXMsIHNldE1vdW50ZWRTbG90c0hlYWRlciwgc2V0TmF2aWdhdGlvbkNvbnRleHQsIHNldFBlbmRpbmdQYXRobmFtZSwgc25hcHNob3RSc2NSZXNwb25zZSwgc3RvcmVQcmVmZXRjaFJlc3BvbnNlLCB0cmFja0FwcFJvdXRlck5hdmlnYXRpb25JbkZsaWdodCwgdW5hdXRob3JpemVkLCB1bnN0YWJsZV9pc1VucmVjb2duaXplZEFjdGlvbkVycm9yLCB1bnN0YWJsZV9yZXRocm93LCB1c2VDbGllbnROYXZpZ2F0aW9uUmVuZGVyU25hcHNob3QsIHVzZVBhcmFtcywgdXNlUGF0aG5hbWUsIHVzZVJvdXRlciwgdXNlU2VhcmNoUGFyYW1zLCB1c2VTZWxlY3RlZExheW91dFNlZ21lbnQsIHVzZVNlbGVjdGVkTGF5b3V0U2VnbWVudHMsIHVzZVNlcnZlckluc2VydGVkSFRNTCB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=