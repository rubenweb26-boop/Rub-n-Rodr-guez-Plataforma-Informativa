import { stripBasePath } from "/node_modules/vinext/dist/utils/base-path.js?v=b41becdd";
import { splitPathnameForRouteMatch } from "/node_modules/vinext/dist/routing/utils.js?v=b41becdd";
import { matchRoutePattern, matchRoutePatternPrefix, matchRoutePatternWithOptionalDynamicSegments } from "/node_modules/vinext/dist/routing/route-pattern.js?v=b41becdd";
import { resolveHardNavigationTargetFromRscResponse, resolveRscCompatibilityNavigationDecision } from "/node_modules/vinext/dist/server/app-rsc-cache-busting.js?v=b41becdd";
import { AppElementsWire, compareAppElementsSlotIds } from "/node_modules/vinext/dist/server/app-elements-wire.js?v=b41becdd";
import "/node_modules/vinext/dist/server/app-elements.js?v=b41becdd";
import { resolveRscRedirectLifecycleHop, resolveStreamedRscRedirectLifecycleHop } from "/node_modules/vinext/dist/server/app-browser-rsc-redirect.js?v=b41becdd";
import { NavigationTraceReasonCodes, createNavigationLifecycleTraceFields, createNavigationTrace } from "/node_modules/vinext/dist/server/navigation-trace.js?v=b41becdd";
import { verifyOperationTokenForCacheReuse } from "/node_modules/vinext/dist/server/operation-token.js?v=b41becdd";
//#region src/server/navigation-planner.ts
function mergeRscRedirectHistoryMode(navigationMode, redirectType) {
	return navigationMode === "push" || redirectType === "push" ? "push" : "replace";
}
const ROUTE_INTERCEPTION_CONTEXT_SEPARATOR = "\0";
const CACHE_ENTRY_PROOF_MISSING_CODE = "CP_CACHE_ENTRY_PROOF_MISSING";
function createRequestWorkDecision(options) {
	const traverseFields = options.work.kind === "traverseFlight" ? { traverseDirection: options.work.direction } : {};
	return {
		kind: "requestWork",
		token: options.state.nextOperationToken,
		work: options.work,
		trace: createNavigationTrace(NavigationTraceReasonCodes.requestWork, {
			eventKind: options.eventKind,
			targetHref: getRequestedWorkTargetHref(options.work),
			...traverseFields
		})
	};
}
function getRequestedWorkTargetHref(work) {
	switch (work.kind) {
		case "flight":
		case "prefetch": return work.href;
		case "traverseFlight": return null;
		default: throw new Error("[vinext] Unknown requested navigation work: " + String(work));
	}
}
function createRscFetchResultTraceFields(facts, fields = {}) {
	return {
		fetchResultSource: facts.source,
		...fields
	};
}
function createRscFetchResultHardNavigationDecision(options) {
	return {
		discardBody: options.discardBody,
		kind: "hardNavigate",
		...options.hardNavigationMode !== void 0 ? { hardNavigationMode: options.hardNavigationMode } : {},
		reason: options.reason,
		trace: createNavigationTrace(options.reasonCode, createRscFetchResultTraceFields(options.facts, {
			...options.redirectSignal !== void 0 ? { redirectSignal: options.redirectSignal } : {},
			redirectDepth: options.facts.redirectDepth,
			targetHref: options.url
		})),
		url: options.url
	};
}
function createRscFetchResultFollowRedirectDecision(options) {
	return {
		discardBody: options.discardBody,
		kind: "followRedirect",
		redirect: options.redirect,
		trace: createNavigationTrace(NavigationTraceReasonCodes.redirectFollow, createRscFetchResultTraceFields(options.facts, {
			redirectDepth: options.redirect.redirectDepth,
			redirectSignal: options.redirectSignal,
			targetHref: options.redirect.href
		}))
	};
}
function mapRscRedirectTerminalReason(reason) {
	switch (reason) {
		case "externalRedirect": return {
			hardNavigationReason: "externalRedirectTarget",
			traceReasonCode: NavigationTraceReasonCodes.redirectTerminalExternal
		};
		case "maxRedirectsExceeded": return {
			hardNavigationReason: "redirectDepthExhausted",
			traceReasonCode: NavigationTraceReasonCodes.redirectTerminalDepth
		};
		default: throw new Error("[vinext] Unknown RSC redirect terminal reason: " + String(reason));
	}
}
function classifyRscFetchResult(facts) {
	if (!facts.responseOk || !facts.isRscContentType || !facts.hasBody) {
		const url = resolveHardNavigationTargetFromRscResponse(facts.responseUrl, facts.currentHref, facts.origin);
		return createRscFetchResultHardNavigationDecision({
			discardBody: false,
			facts,
			reason: "invalidRscPayload",
			reasonCode: NavigationTraceReasonCodes.invalidRscPayload,
			url
		});
	}
	const compatibilityDecision = resolveRscCompatibilityNavigationDecision({
		clientCompatibilityId: facts.clientCompatibilityId,
		currentHref: facts.currentHref,
		origin: facts.origin,
		responseCompatibilityId: facts.compatibilityIdHeader,
		responseUrl: facts.responseUrl
	});
	if (compatibilityDecision.kind === "hard-navigate") return createRscFetchResultHardNavigationDecision({
		discardBody: false,
		facts,
		reason: "rscCompatibilityMismatch",
		reasonCode: NavigationTraceReasonCodes.rscCompatibilityMismatch,
		url: compatibilityDecision.hardNavigationTarget
	});
	if (facts.responseUrl !== null) {
		const redirectDecision = resolveRscRedirectLifecycleHop({
			currentHref: facts.currentHref,
			historyUpdateMode: facts.effectiveHistoryUpdateMode,
			origin: facts.origin,
			redirectDepth: facts.redirectDepth,
			requestPreviousNextUrl: facts.requestPreviousNextUrl,
			responseUrl: facts.responseUrl
		});
		if (redirectDecision.kind === "terminal-hard-navigation") {
			const terminalReason = mapRscRedirectTerminalReason(redirectDecision.reason);
			return createRscFetchResultHardNavigationDecision({
				discardBody: false,
				facts,
				reason: terminalReason.hardNavigationReason,
				reasonCode: terminalReason.traceReasonCode,
				redirectSignal: "response-url",
				url: redirectDecision.href
			});
		}
		if (redirectDecision.kind === "follow") return createRscFetchResultFollowRedirectDecision({
			discardBody: false,
			facts,
			redirect: {
				href: redirectDecision.href,
				historyUpdateMode: facts.effectiveHistoryUpdateMode,
				previousNextUrl: redirectDecision.previousNextUrl,
				redirectDepth: redirectDecision.redirectDepth
			},
			redirectSignal: "response-url"
		});
	}
	if (facts.streamedRedirectTarget !== null) {
		const streamedHistoryMode = mergeRscRedirectHistoryMode(facts.effectiveHistoryUpdateMode, facts.streamedRedirectType);
		const redirectDecision = resolveStreamedRscRedirectLifecycleHop({
			currentHref: facts.currentHref,
			historyUpdateMode: streamedHistoryMode,
			origin: facts.origin,
			redirectDepth: facts.redirectDepth,
			requestPreviousNextUrl: facts.requestPreviousNextUrl,
			streamedRedirectTarget: facts.streamedRedirectTarget
		});
		if (redirectDecision.kind === "terminal-hard-navigation") {
			const terminalReason = mapRscRedirectTerminalReason(redirectDecision.reason);
			return createRscFetchResultHardNavigationDecision({
				discardBody: true,
				facts,
				reason: terminalReason.hardNavigationReason,
				reasonCode: terminalReason.traceReasonCode,
				redirectSignal: "streamed-header",
				hardNavigationMode: streamedHistoryMode === "push" ? "assign" : "replace",
				url: redirectDecision.href
			});
		}
		if (redirectDecision.kind === "follow") return createRscFetchResultFollowRedirectDecision({
			discardBody: true,
			facts,
			redirect: {
				href: redirectDecision.href,
				historyUpdateMode: streamedHistoryMode,
				previousNextUrl: redirectDecision.previousNextUrl,
				redirectDepth: redirectDecision.redirectDepth
			},
			redirectSignal: "streamed-header"
		});
		return createRscFetchResultHardNavigationDecision({
			discardBody: true,
			facts,
			reason: "streamedRedirectLoop",
			reasonCode: NavigationTraceReasonCodes.streamedRedirectLoop,
			redirectSignal: "streamed-header",
			url: redirectDecision.href
		});
	}
	return {
		discardBody: false,
		kind: "proceedToCommit",
		trace: createNavigationTrace(NavigationTraceReasonCodes.proceedToCommit, createRscFetchResultTraceFields(facts))
	};
}
function createEarlyNavigationIntentTrace(reasonCode, facts) {
	return createNavigationTrace(reasonCode, { targetHref: facts.targetHref });
}
function appRelativeNavigationPathname(pathname, basePath, urlSpace) {
	return urlSpace === "browser" ? stripBasePath(pathname, basePath) : pathname;
}
function classifyEarlyNavigationIntent(facts) {
	let current;
	let next;
	try {
		current = new URL(facts.currentHref);
		next = new URL(facts.targetHref, facts.currentHref);
	} catch {
		return {
			bypassNavigationCache: false,
			kind: "flightNavigation",
			trace: createEarlyNavigationIntentTrace(NavigationTraceReasonCodes.crossDocumentFlight, facts)
		};
	}
	const currentAppPathname = appRelativeNavigationPathname(current.pathname, facts.basePath, facts.currentUrlSpace);
	const targetAppPathname = appRelativeNavigationPathname(next.pathname, facts.basePath, "browser");
	const samePathname = current.origin === next.origin && currentAppPathname === targetAppPathname;
	const sameSearch = current.searchParams.toString() === next.searchParams.toString();
	if (samePathname && current.search === next.search && current.hash === next.hash) return {
		bypassNavigationCache: true,
		kind: "flightNavigation",
		trace: createEarlyNavigationIntentTrace(NavigationTraceReasonCodes.samePageRefresh, facts)
	};
	if (samePathname && sameSearch && current.hash !== next.hash) return {
		hash: next.hash,
		kind: "sameDocumentScroll",
		mode: facts.mode,
		scroll: facts.scroll,
		trace: createEarlyNavigationIntentTrace(NavigationTraceReasonCodes.sameDocumentScroll, facts)
	};
	if (samePathname && !sameSearch) return {
		bypassNavigationCache: true,
		kind: "flightNavigation",
		trace: createEarlyNavigationIntentTrace(NavigationTraceReasonCodes.samePageSearch, facts)
	};
	return {
		bypassNavigationCache: false,
		kind: "flightNavigation",
		trace: createEarlyNavigationIntentTrace(NavigationTraceReasonCodes.crossDocumentFlight, facts)
	};
}
function classifyVisitedResponseCacheCandidate(facts) {
	if (facts.candidate === "missing") return { kind: "miss" };
	if (!facts.mountedSlotsMatch) return {
		kind: "evict",
		reason: "mountedSlotsMismatch"
	};
	if (facts.navigationKind === "refresh") return {
		kind: "evict",
		reason: "refresh"
	};
	if (!facts.fresh) return {
		kind: "evict",
		reason: "stale"
	};
	return { kind: "reuse" };
}
function createNavigationReuseTrace(code, facts, fields = {}) {
	return createNavigationTrace(code, {
		eventKind: facts.navigationKind,
		targetHref: facts.targetHref,
		...fields
	});
}
function createFreshFetchDecision(facts, reason) {
	return {
		kind: "fetchFresh",
		reason,
		trace: createNavigationReuseTrace(NavigationTraceReasonCodes.fetchFresh, facts, { freshFetchReason: reason })
	};
}
function classifyNavigationReuse(facts) {
	if (facts.navigationKind === "refresh") return createFreshFetchDecision(facts, "refresh");
	if (!facts.bypassNavigationCache && facts.visitedResponse.status === "available") return {
		kind: "reuseVisitedResponse",
		trace: createNavigationReuseTrace(NavigationTraceReasonCodes.visitedResponseReuse, facts)
	};
	if (!facts.bypassNavigationCache && facts.prefetch.status === "available") return {
		kind: "consumePrefetch",
		trace: createNavigationReuseTrace(NavigationTraceReasonCodes.prefetchResponseReuse, facts)
	};
	if (facts.navigationKind === "navigate") {
		if (facts.optimisticRouteShell.status === "available") return {
			kind: "attemptOptimisticRouteShell",
			trace: createNavigationReuseTrace(NavigationTraceReasonCodes.optimisticRouteShell, facts)
		};
		return createFreshFetchDecision(facts, facts.bypassNavigationCache ? "cacheBypassed" : facts.optimisticRouteShell.reason);
	}
	if (facts.bypassNavigationCache) return createFreshFetchDecision(facts, "cacheBypassed");
	return createFreshFetchDecision(facts, "cacheMiss");
}
function classifyNavigationPrefetchProbe(facts) {
	if (facts.visitedResponse.status === "available") return {
		kind: "skip",
		reason: "visitedResponseAvailable"
	};
	if (facts.navigationKind === "refresh") return {
		kind: "skip",
		reason: "refresh"
	};
	if (facts.bypassNavigationCache) return {
		kind: "skip",
		reason: "cacheBypassed"
	};
	return { kind: "probe" };
}
function createSnapshotRouteTopology(snapshot) {
	return {
		layoutIds: snapshot.layoutIds,
		rootBoundaryId: snapshot.rootBoundaryId,
		rootLayoutTreePath: snapshot.rootBoundaryId,
		slotBindings: snapshot.slotBindings
	};
}
function stripInterceptionContextFromRouteId(routeId) {
	const separatorIndex = routeId.indexOf(ROUTE_INTERCEPTION_CONTEXT_SEPARATOR);
	return separatorIndex === -1 ? routeId : routeId.slice(0, separatorIndex);
}
function matchedUrlFromConcreteRouteId(routeId) {
	const normalizedRouteId = stripInterceptionContextFromRouteId(routeId);
	if (!normalizedRouteId.startsWith("route:/")) return null;
	return normalizedRouteId.slice(6);
}
function getMatchedUrlPathname(matchedUrl) {
	try {
		return new URL(matchedUrl, "https://vinext.local").pathname;
	} catch {
		const [withoutHash = ""] = matchedUrl.split("#");
		const [pathname = ""] = withoutHash.split("?");
		return pathname === "" ? "/" : pathname;
	}
}
function splitMatchedUrlIntoRouteParts(matchedUrl) {
	return splitPathnameForRouteMatch(getMatchedUrlPathname(matchedUrl));
}
function findRouteManifestRouteByMatchedUrl(routeManifest, matchedUrl) {
	const urlParts = splitMatchedUrlIntoRouteParts(matchedUrl);
	for (const route of routeManifest.segmentGraph.routes.values()) if (matchRoutePattern(urlParts, route.patternParts) !== null) return route;
	return null;
}
function routeManifestRouteMatchesUrl(route, matchedUrl) {
	return matchRoutePattern(splitMatchedUrlIntoRouteParts(matchedUrl), route.patternParts) !== null;
}
function findRouteManifestRouteByIdOrMatchedUrl(options) {
	const routeId = stripInterceptionContextFromRouteId(options.routeId);
	const route = options.routeManifest.segmentGraph.routes.get(routeId);
	if (route && routeManifestRouteMatchesUrl(route, options.matchedUrl)) return route;
	const concreteRouteMatchedUrl = route === void 0 ? matchedUrlFromConcreteRouteId(options.routeId) : null;
	if (concreteRouteMatchedUrl !== null) {
		const concreteRoute = findRouteManifestRouteByMatchedUrl(options.routeManifest, concreteRouteMatchedUrl);
		if (concreteRoute !== null) return concreteRoute;
	}
	return findRouteManifestRouteByMatchedUrl(options.routeManifest, options.matchedUrl);
}
function findRouteManifestRouteForSnapshot(routeManifest, snapshot) {
	if (snapshot.interception !== null) return findRouteManifestRouteByIdOrMatchedUrl({
		matchedUrl: snapshot.interception.sourceMatchedUrl,
		routeId: snapshot.interception.sourceRouteId,
		routeManifest
	});
	return findRouteManifestRouteByIdOrMatchedUrl({
		matchedUrl: snapshot.matchedUrl,
		routeId: snapshot.routeId,
		routeManifest
	});
}
function resolveRouteManifestSlotBindings(routeManifest, route) {
	const bindings = [];
	for (const slotId of route.slotIds) {
		const binding = routeManifest.segmentGraph.slotBindings.get(`${route.id}::${slotId}`);
		if (!binding) continue;
		bindings.push({
			ownerLayoutId: binding.ownerLayoutId,
			slotId: binding.slotId,
			state: binding.state
		});
	}
	return bindings.sort((left, right) => compareAppElementsSlotIds(left.slotId, right.slotId));
}
function resolveRouteManifestRootLayoutTreePath(routeManifest, route) {
	if (route.rootBoundaryId === null) return null;
	return routeManifest.segmentGraph.rootBoundaries.get(route.rootBoundaryId)?.treePath ?? null;
}
function resolveRouteTopologySnapshot(options) {
	const route = options.routeManifest === null ? null : findRouteManifestRouteForSnapshot(options.routeManifest, options.snapshot);
	if (route === null || options.routeManifest === null) return { kind: "unknown" };
	const shouldUseManifestSlotBindings = options.slotBindingSource === "manifestTarget" && options.snapshot.interception === null;
	return {
		kind: "known",
		topology: {
			layoutIds: route.layoutIds,
			rootBoundaryId: route.rootBoundaryId,
			rootLayoutTreePath: resolveRouteManifestRootLayoutTreePath(options.routeManifest, route),
			slotBindings: shouldUseManifestSlotBindings ? resolveRouteManifestSlotBindings(options.routeManifest, route) : options.snapshot.slotBindings
		}
	};
}
function findRouteManifestInterceptionForProof(routeManifest, proof) {
	const sourceParts = splitMatchedUrlIntoRouteParts(proof.sourceMatchedUrl);
	const targetParts = splitMatchedUrlIntoRouteParts(proof.targetMatchedUrl);
	const targetRoute = findRouteManifestRouteByIdOrMatchedUrl({
		matchedUrl: proof.targetMatchedUrl,
		routeId: proof.targetRouteId,
		routeManifest
	});
	const candidateInterceptions = routeManifest.segmentGraph.interceptionsBySlotId.get(proof.slotId) ?? [];
	for (const interception of candidateInterceptions) {
		if (!matchRoutePatternPrefix(sourceParts, interception.sourcePatternParts)) continue;
		const exactTargetParams = matchRoutePattern(targetParts, interception.targetPatternParts);
		const allowsMiddlewareRewriteTarget = exactTargetParams === null && matchRoutePatternWithOptionalDynamicSegments(targetParts, interception.targetPatternParts);
		if (exactTargetParams === null && !allowsMiddlewareRewriteTarget) continue;
		if (!allowsMiddlewareRewriteTarget && interception.targetRouteId !== null && targetRoute?.id !== interception.targetRouteId) continue;
		return interception;
	}
	return null;
}
function createRootBoundaryTraceFields(options) {
	if (options.state.traceFields) return {
		...options.state.traceFields,
		currentRootLayoutTreePath: options.currentRootLayoutTreePath,
		nextRootLayoutTreePath: options.nextRootLayoutTreePath
	};
	return createNavigationLifecycleTraceFields({
		currentRootLayoutTreePath: options.currentRootLayoutTreePath,
		currentVisibleCommitVersion: options.state.visibleCommitVersion,
		nextRootLayoutTreePath: options.nextRootLayoutTreePath,
		startedVisibleCommitVersion: options.event.token.baseVisibleCommitVersion
	});
}
function classifyRootBoundaryTransition(currentRootBoundaryId, nextRootBoundaryId) {
	if (currentRootBoundaryId === null || nextRootBoundaryId === null) return "rootBoundaryUnknown";
	return currentRootBoundaryId === nextRootBoundaryId ? "currentRootBoundary" : "rootBoundaryChanged";
}
function resolveSameLayoutAncestorPersistence(currentSnapshot, targetSnapshot) {
	return resolveSameLayoutAncestorPersistenceForTopologies(createSnapshotRouteTopology(currentSnapshot), createSnapshotRouteTopology(targetSnapshot));
}
function resolveSameLayoutAncestorPersistenceForTopologies(currentTopology, targetTopology) {
	if (classifyRootBoundaryTransition(currentTopology.rootBoundaryId, targetTopology.rootBoundaryId) !== "currentRootBoundary") return [];
	const commonLayoutIds = [];
	const maxLength = Math.min(currentTopology.layoutIds.length, targetTopology.layoutIds.length);
	for (let index = 0; index < maxLength; index++) {
		const layoutId = currentTopology.layoutIds[index];
		if (layoutId !== targetTopology.layoutIds[index]) break;
		commonLayoutIds.push(layoutId);
	}
	return commonLayoutIds;
}
function resolveMountedParallelSlotPersistence(currentSnapshot, targetSnapshot) {
	return resolveMountedParallelSlotPersistenceForLayouts(currentSnapshot, resolveSameLayoutAncestorPersistence(currentSnapshot, targetSnapshot));
}
function resolveMountedParallelSlotPersistenceForLayouts(currentSnapshot, preservedLayoutIds) {
	if (preservedLayoutIds.length === 0) return [];
	const preservedLayoutIdSet = new Set(preservedLayoutIds);
	const preservedSlotIds = [];
	const seenSlotIds = /* @__PURE__ */ new Set();
	for (const slot of currentSnapshot.mountedParallelSlots) {
		if (slot.ownerLayoutId === null) continue;
		if (!preservedLayoutIdSet.has(slot.ownerLayoutId)) continue;
		if (seenSlotIds.has(slot.slotId)) continue;
		preservedSlotIds.push(slot.slotId);
		seenSlotIds.add(slot.slotId);
	}
	return preservedSlotIds;
}
function resolveCurrentRootBoundaryElementPersistence(currentSnapshot, targetSnapshot) {
	const preservedLayoutIds = resolveSameLayoutAncestorPersistence(currentSnapshot, targetSnapshot);
	return [...preservedLayoutIds, ...resolveMountedParallelSlotPersistenceForLayouts(currentSnapshot, preservedLayoutIds)];
}
function resolveCurrentRootBoundaryCommitElementPersistence(options) {
	return resolveSameLayoutAncestorPersistenceForTopologies(options.currentTopology, options.targetTopology);
}
function resolveCurrentRootBoundaryCommitSlotPersistence(options) {
	if (options.lane === "traverse") return [];
	const preservedLayoutIds = resolveSameLayoutAncestorPersistenceForTopologies(options.currentTopology, options.targetTopology);
	if (preservedLayoutIds.length === 0) return [];
	const defaultOrUnmatchedSlotIds = resolveDefaultOrUnmatchedSlotPersistenceForLayouts({
		currentSlotBindings: options.currentTopology.slotBindings,
		preservedLayoutIds,
		targetSlotBindings: options.targetTopology.slotBindings
	});
	const absentActiveSlotIds = resolveAbsentActiveSlotPersistenceForLayouts({
		currentSlotBindings: options.currentTopology.slotBindings,
		preservedLayoutIds,
		targetSlotBindings: options.targetTopology.slotBindings
	});
	return [.../* @__PURE__ */ new Set([...defaultOrUnmatchedSlotIds, ...absentActiveSlotIds])].sort(compareAppElementsSlotIds);
}
function resolveAbsentActiveSlotPersistenceForLayouts(options) {
	const preservedLayoutIdSet = new Set(options.preservedLayoutIds);
	const targetSlotIds = new Set(options.targetSlotBindings.map((binding) => binding.slotId));
	return options.currentSlotBindings.filter((binding) => {
		const parsedSlot = AppElementsWire.parseElementKey(binding.slotId);
		return binding.state === "active" && binding.ownerLayoutId !== null && preservedLayoutIdSet.has(binding.ownerLayoutId) && parsedSlot?.kind === "slot" && parsedSlot.name === "children" && !targetSlotIds.has(binding.slotId);
	}).map((binding) => binding.slotId).sort(compareAppElementsSlotIds);
}
/**
* Default/unmatched slot preservation law:
*
* A target default/unmatched slot may reuse previous content only when:
* - the slot's owner layout is part of the preserved layout ancestor set;
* - the current visible snapshot proves the same slot had renderable content;
* - the navigation is not a traversal.
*
* Wire absence and UNMATCHED_SLOT markers are not semantic proof.
*/
function resolveDefaultOrUnmatchedSlotPersistenceForLayouts(options) {
	const preservedLayoutIdSet = new Set(options.preservedLayoutIds);
	const slotIdsWithContent = /* @__PURE__ */ new Set();
	for (const binding of options.currentSlotBindings) {
		if (binding.state === "unmatched") continue;
		slotIdsWithContent.add(binding.slotId);
	}
	const preservedSlotIds = [];
	const seenSlotIds = /* @__PURE__ */ new Set();
	for (const binding of options.targetSlotBindings) {
		if (binding.ownerLayoutId === null) continue;
		if (!preservedLayoutIdSet.has(binding.ownerLayoutId)) continue;
		if (binding.state === "active") continue;
		if (!slotIdsWithContent.has(binding.slotId)) continue;
		if (seenSlotIds.has(binding.slotId)) continue;
		preservedSlotIds.push(binding.slotId);
		seenSlotIds.add(binding.slotId);
	}
	return preservedSlotIds.sort(compareAppElementsSlotIds);
}
function resolveInterceptedSourceSlotPersistenceForLayouts(options) {
	const currentBindings = new Map(options.currentSlotBindings.map((binding) => [binding.slotId, binding]));
	const preservedLayoutIdSet = new Set(options.preservedLayoutIds);
	const preservedSlotIds = [];
	for (const targetBinding of options.targetSlotBindings) {
		if (targetBinding.slotId === options.targetInterceptionSlotId) continue;
		if (targetBinding.state !== "active" || targetBinding.ownerLayoutId === null) continue;
		if (!preservedLayoutIdSet.has(targetBinding.ownerLayoutId)) continue;
		const currentBinding = currentBindings.get(targetBinding.slotId);
		if (currentBinding?.state !== "active") continue;
		if (currentBinding.ownerLayoutId !== targetBinding.ownerLayoutId) continue;
		if (currentBinding.activeRouteId && targetBinding.activeRouteId && currentBinding.activeRouteId !== targetBinding.activeRouteId) continue;
		preservedSlotIds.push(targetBinding.slotId);
	}
	return preservedSlotIds.sort(compareAppElementsSlotIds);
}
function getVisibleInterceptionSourceIdentity(snapshot) {
	if (snapshot.interception) return {
		matchedUrl: snapshot.interception.sourceMatchedUrl,
		routeId: snapshot.interception.sourceRouteId
	};
	return {
		matchedUrl: matchedUrlFromConcreteRouteId(snapshot.routeId) ?? snapshot.matchedUrl,
		routeId: snapshot.routeId
	};
}
function createInterceptionProofRejectedDecision(options) {
	return {
		kind: "hardNavigate",
		reason: "interceptionProofRejected",
		token: options.event.token,
		trace: createNavigationTrace(options.reasonCode, options.traceFields),
		url: options.event.result.href
	};
}
function evaluateCacheEntryReuseProof(proof) {
	if (proof === void 0) return {
		kind: "accepted",
		decision: null
	};
	if (proof.decision === null) return {
		kind: "rejected",
		decision: null
	};
	if (proof.decision.canReuse) return {
		kind: "accepted",
		decision: proof.decision
	};
	return {
		kind: "rejected",
		decision: proof.decision
	};
}
function createCacheProofRejectedTraceFields(traceFields, decision) {
	if (decision === null) return {
		...traceFields,
		cacheProofCode: CACHE_ENTRY_PROOF_MISSING_CODE
	};
	return {
		...traceFields,
		cacheProofCode: decision.code,
		cacheProofMode: decision.mode,
		cacheProofScope: decision.scope
	};
}
function createCacheProofRejectedDecision(options) {
	return {
		kind: "hardNavigate",
		reason: "cacheProofRejected",
		token: options.event.token,
		trace: createNavigationTrace(NavigationTraceReasonCodes.cacheProofRejected, createCacheProofRejectedTraceFields(options.traceFields, options.rejection.decision)),
		url: options.event.result.href
	};
}
function createCacheReuseTokenRejectedDecision(options) {
	return {
		kind: "hardNavigate",
		reason: "cacheReuseTokenRejected",
		token: options.event.token,
		trace: createNavigationTrace(NavigationTraceReasonCodes.cacheReuseTokenRejected, {
			...options.traceFields,
			cacheReuseTokenReason: options.reason
		}),
		url: options.event.result.href
	};
}
function createAcceptedCacheProofTraceFields(traceFields, decision) {
	if (decision === null) return traceFields;
	return {
		...traceFields,
		cacheProofCode: decision.code,
		cacheProofReuseClass: decision.reuseClass
	};
}
function createCacheEntryProposalFields(decision) {
	if (decision === null) return {};
	return { cacheEntryReuseDecision: decision };
}
function validateInterceptedPreservation(options) {
	const proof = options.targetSnapshot.interception;
	if (!proof) return {
		kind: "rejected",
		reasonCode: NavigationTraceReasonCodes.interceptedRejectedMissingProof
	};
	if (proof.targetMatchedUrl !== options.targetSnapshot.matchedUrl) return {
		kind: "rejected",
		reasonCode: NavigationTraceReasonCodes.interceptedRejectedTargetMismatch
	};
	const sourceIdentity = getVisibleInterceptionSourceIdentity(options.currentSnapshot);
	if (!options.restoredHistorySnapshot && (proof.sourceMatchedUrl !== sourceIdentity.matchedUrl || proof.sourceRouteId !== sourceIdentity.routeId)) return {
		kind: "rejected",
		reasonCode: NavigationTraceReasonCodes.interceptedRejectedUnknownSource
	};
	const declaredInterception = options.routeManifest === null ? null : findRouteManifestInterceptionForProof(options.routeManifest, proof);
	if (options.routeManifest !== null && declaredInterception === null) return {
		kind: "rejected",
		reasonCode: NavigationTraceReasonCodes.interceptedRejectedUndeclaredTopology
	};
	const preservedLayoutIds = resolveSameLayoutAncestorPersistenceForTopologies(options.currentTopology, options.targetTopology);
	if (preservedLayoutIds.length === 0) return {
		kind: "rejected",
		reasonCode: NavigationTraceReasonCodes.interceptedRejectedIncompatibleRoot
	};
	const preservedLayoutIdSet = new Set(preservedLayoutIds);
	const targetSlotBinding = options.targetTopology.slotBindings.find((binding) => binding.slotId === proof.slotId);
	if (!targetSlotBinding || targetSlotBinding.state !== "active" || targetSlotBinding.ownerLayoutId === null || !preservedLayoutIdSet.has(targetSlotBinding.ownerLayoutId)) return {
		kind: "rejected",
		reasonCode: NavigationTraceReasonCodes.interceptedRejectedMissingSlotProof
	};
	if (declaredInterception !== null && targetSlotBinding.ownerLayoutId !== declaredInterception.ownerLayoutId) return {
		kind: "rejected",
		reasonCode: NavigationTraceReasonCodes.interceptedRejectedUndeclaredTopology
	};
	const preserveDefaultOrUnmatchedSlotIds = resolveDefaultOrUnmatchedSlotPersistenceForLayouts({
		currentSlotBindings: options.currentTopology.slotBindings,
		preservedLayoutIds,
		targetSlotBindings: options.targetTopology.slotBindings
	}).filter((slotId) => slotId !== proof.slotId);
	const preserveSourceSlotIds = options.lane === "navigation" ? resolveInterceptedSourceSlotPersistenceForLayouts({
		currentSlotBindings: options.currentTopology.slotBindings,
		preservedLayoutIds,
		targetInterceptionSlotId: proof.slotId,
		targetSlotBindings: options.targetTopology.slotBindings
	}) : [];
	return {
		kind: "approved",
		preserveElementIds: preservedLayoutIds,
		preservePreviousSlotIds: [.../* @__PURE__ */ new Set([...preserveDefaultOrUnmatchedSlotIds, ...preserveSourceSlotIds])].sort(compareAppElementsSlotIds)
	};
}
function planFlightResponseArrived(options) {
	const targetSnapshot = options.event.result.targetSnapshot;
	const currentTopology = resolveRouteTopologySnapshot({
		routeManifest: options.routeManifest,
		slotBindingSource: "snapshot",
		snapshot: options.state.visibleSnapshot
	});
	const targetTopology = resolveRouteTopologySnapshot({
		routeManifest: options.routeManifest,
		slotBindingSource: "manifestTarget",
		snapshot: targetSnapshot
	});
	const traceFields = createRootBoundaryTraceFields({
		currentRootLayoutTreePath: currentTopology.kind === "known" ? currentTopology.topology.rootLayoutTreePath : null,
		event: options.event,
		nextRootLayoutTreePath: targetTopology.kind === "known" ? targetTopology.topology.rootLayoutTreePath : null,
		state: options.state
	});
	if (options.event.token.lane === "prefetch") return {
		kind: "noCommit",
		reason: "prefetchOnly",
		token: options.event.token,
		trace: createNavigationTrace(NavigationTraceReasonCodes.prefetchOnly, traceFields)
	};
	const cacheEntryProofEvaluation = evaluateCacheEntryReuseProof(options.event.result.cacheEntryReuseProof);
	if (cacheEntryProofEvaluation.kind === "rejected") return createCacheProofRejectedDecision({
		event: options.event,
		rejection: cacheEntryProofEvaluation,
		traceFields
	});
	const acceptedCacheEntryDecision = cacheEntryProofEvaluation.decision;
	if (acceptedCacheEntryDecision !== null) {
		const reuseVerdict = verifyOperationTokenForCacheReuse(options.event.token, {
			graphVersion: options.routeManifest?.graphVersion ?? null,
			installedCacheVariantFingerprint: null
		});
		if (!reuseVerdict.authorized) return createCacheReuseTokenRejectedDecision({
			event: options.event,
			reason: reuseVerdict.reason,
			traceFields
		});
	}
	const commitTraceFields = createAcceptedCacheProofTraceFields(traceFields, acceptedCacheEntryDecision);
	const cacheEntryProposalFields = createCacheEntryProposalFields(acceptedCacheEntryDecision);
	if (targetSnapshot.interception !== null) {
		if (currentTopology.kind === "unknown" || targetTopology.kind === "unknown") return createInterceptionProofRejectedDecision({
			event: options.event,
			reasonCode: NavigationTraceReasonCodes.interceptedRejectedUndeclaredTopology,
			traceFields: commitTraceFields
		});
		const validation = validateInterceptedPreservation({
			currentSnapshot: options.state.visibleSnapshot,
			currentTopology: currentTopology.topology,
			lane: options.event.token.lane,
			restoredHistorySnapshot: options.event.result.restoredHistorySnapshot === true,
			routeManifest: options.routeManifest,
			targetSnapshot,
			targetTopology: targetTopology.topology
		});
		if (validation.kind === "rejected") return createInterceptionProofRejectedDecision({
			event: options.event,
			reasonCode: validation.reasonCode,
			traceFields: commitTraceFields
		});
		return {
			kind: "proposeCommit",
			proposal: {
				...cacheEntryProposalFields,
				preserveAbsentSlots: false,
				preserveElementIds: validation.preserveElementIds,
				preservePreviousSlotIds: validation.preservePreviousSlotIds,
				reason: "interceptedCurrentRootBoundary",
				targetSnapshot
			},
			token: options.event.token,
			trace: createNavigationTrace(NavigationTraceReasonCodes.interceptedCommitCurrent, commitTraceFields)
		};
	}
	const transition = currentTopology.kind === "unknown" || targetTopology.kind === "unknown" ? "rootBoundaryUnknown" : classifyRootBoundaryTransition(currentTopology.topology.rootBoundaryId, targetTopology.topology.rootBoundaryId);
	if (transition === "rootBoundaryChanged") return {
		kind: "hardNavigate",
		reason: "rootBoundaryChanged",
		token: options.event.token,
		trace: createNavigationTrace(NavigationTraceReasonCodes.rootBoundaryChanged, commitTraceFields),
		url: options.event.result.href
	};
	if (transition === "rootBoundaryUnknown") return {
		kind: "proposeCommit",
		proposal: {
			...cacheEntryProposalFields,
			preserveAbsentSlots: false,
			preserveElementIds: [],
			preservePreviousSlotIds: [],
			reason: "unprovenTopologyFallback",
			targetSnapshot
		},
		token: options.event.token,
		trace: createNavigationTrace(NavigationTraceReasonCodes.rootBoundaryUnknown, commitTraceFields)
	};
	if (currentTopology.kind !== "known" || targetTopology.kind !== "known") throw new Error("[vinext] Current-root navigation planning requires manifest topology");
	return {
		kind: "proposeCommit",
		proposal: {
			...cacheEntryProposalFields,
			preserveAbsentSlots: false,
			preserveElementIds: resolveCurrentRootBoundaryCommitElementPersistence({
				currentTopology: currentTopology.topology,
				lane: options.event.token.lane,
				targetTopology: targetTopology.topology
			}),
			preservePreviousSlotIds: resolveCurrentRootBoundaryCommitSlotPersistence({
				currentTopology: currentTopology.topology,
				lane: options.event.token.lane,
				targetTopology: targetTopology.topology
			}),
			reason: "currentRootBoundary",
			targetSnapshot
		},
		token: options.event.token,
		trace: createNavigationTrace(NavigationTraceReasonCodes.commitCurrent, commitTraceFields)
	};
}
function planNavigation(input) {
	switch (input.event.kind) {
		case "navigate": return createRequestWorkDecision({
			eventKind: input.event.kind,
			state: input.state,
			work: {
				href: input.event.href,
				kind: "flight",
				mode: input.event.mode
			}
		});
		case "refresh": return createRequestWorkDecision({
			eventKind: input.event.kind,
			state: input.state,
			work: {
				href: input.state.visibleSnapshot.displayUrl,
				kind: "flight",
				mode: "refresh"
			}
		});
		case "traverse": return createRequestWorkDecision({
			eventKind: input.event.kind,
			state: input.state,
			work: {
				direction: input.event.direction,
				historyState: input.event.historyState,
				kind: "traverseFlight"
			}
		});
		case "prefetch": return createRequestWorkDecision({
			eventKind: input.event.kind,
			state: input.state,
			work: {
				href: input.event.href,
				kind: "prefetch"
			}
		});
		case "flightResponseArrived": return planFlightResponseArrived({
			event: input.event,
			routeManifest: input.routeManifest,
			state: input.state
		});
		default: {
			const _exhaustive = input.event;
			throw new Error("[vinext] Unknown navigation event: " + String(_exhaustive));
		}
	}
}
function classifyServerActionResult(facts) {
	if (facts.clientCompatibilityId === null) return {
		kind: "proceed",
		trace: createNavigationTrace(NavigationTraceReasonCodes.proceedToCommit, {})
	};
	if (!facts.isRscContentType) return {
		kind: "proceed",
		trace: createNavigationTrace(NavigationTraceReasonCodes.proceedToCommit, {})
	};
	if (resolveRscCompatibilityNavigationDecision({
		clientCompatibilityId: facts.clientCompatibilityId,
		currentHref: facts.currentHref,
		origin: facts.origin,
		responseCompatibilityId: facts.compatibilityIdHeader,
		responseUrl: facts.responseUrl
	}).kind === "compatible") return {
		kind: "proceed",
		trace: createNavigationTrace(NavigationTraceReasonCodes.proceedToCommit, {})
	};
	if (facts.actionRedirectHref !== null) return {
		kind: "hardNavigate",
		url: facts.actionRedirectHref,
		historyMode: facts.actionRedirectType === "push" ? "assign" : "replace",
		clearClientNavigationCaches: true,
		reason: "serverActionRedirectCompatibilityMismatch",
		trace: createNavigationTrace(NavigationTraceReasonCodes.serverActionRedirectCompatibilityMismatch, { targetHref: facts.actionRedirectHref })
	};
	const targetUrl = facts.currentHref;
	return {
		kind: "hardNavigate",
		url: targetUrl,
		clearClientNavigationCaches: false,
		reason: "serverActionRscCompatibilityMismatch",
		trace: createNavigationTrace(NavigationTraceReasonCodes.serverActionRscCompatibilityMismatch, { targetHref: targetUrl })
	};
}
function classifyRscNavigationError(facts) {
	return {
		kind: "hardNavigate",
		url: facts.currentHref,
		reason: "rscNavigationError",
		trace: createNavigationTrace(NavigationTraceReasonCodes.rscNavigationError, { targetHref: facts.currentHref })
	};
}
const navigationPlanner = {
	classifyEarlyNavigationIntent,
	classifyNavigationPrefetchProbe,
	classifyNavigationReuse,
	classifyRscFetchResult,
	classifyRscNavigationError,
	classifyRootBoundaryTransition,
	classifyServerActionResult,
	classifyVisitedResponseCacheCandidate,
	plan: planNavigation,
	resolveCurrentRootBoundaryElementPersistence,
	resolveMountedParallelSlotPersistence,
	resolveSameLayoutAncestorPersistence
};
//#endregion
export { navigationPlanner, resolveDefaultOrUnmatchedSlotPersistenceForLayouts };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5hdmlnYXRpb24tcGxhbm5lci5qcz92PWI0MWJlY2RkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHN0cmlwQmFzZVBhdGggfSBmcm9tIFwiL25vZGVfbW9kdWxlcy92aW5leHQvZGlzdC91dGlscy9iYXNlLXBhdGguanM/dj1iNDFiZWNkZFwiO1xuaW1wb3J0IHsgc3BsaXRQYXRobmFtZUZvclJvdXRlTWF0Y2ggfSBmcm9tIFwiL25vZGVfbW9kdWxlcy92aW5leHQvZGlzdC9yb3V0aW5nL3V0aWxzLmpzP3Y9YjQxYmVjZGRcIjtcbmltcG9ydCB7IG1hdGNoUm91dGVQYXR0ZXJuLCBtYXRjaFJvdXRlUGF0dGVyblByZWZpeCwgbWF0Y2hSb3V0ZVBhdHRlcm5XaXRoT3B0aW9uYWxEeW5hbWljU2VnbWVudHMgfSBmcm9tIFwiL25vZGVfbW9kdWxlcy92aW5leHQvZGlzdC9yb3V0aW5nL3JvdXRlLXBhdHRlcm4uanM/dj1iNDFiZWNkZFwiO1xuaW1wb3J0IHsgcmVzb2x2ZUhhcmROYXZpZ2F0aW9uVGFyZ2V0RnJvbVJzY1Jlc3BvbnNlLCByZXNvbHZlUnNjQ29tcGF0aWJpbGl0eU5hdmlnYXRpb25EZWNpc2lvbiB9IGZyb20gXCIvbm9kZV9tb2R1bGVzL3ZpbmV4dC9kaXN0L3NlcnZlci9hcHAtcnNjLWNhY2hlLWJ1c3RpbmcuanM/dj1iNDFiZWNkZFwiO1xuaW1wb3J0IHsgQXBwRWxlbWVudHNXaXJlLCBjb21wYXJlQXBwRWxlbWVudHNTbG90SWRzIH0gZnJvbSBcIi9ub2RlX21vZHVsZXMvdmluZXh0L2Rpc3Qvc2VydmVyL2FwcC1lbGVtZW50cy13aXJlLmpzP3Y9YjQxYmVjZGRcIjtcbmltcG9ydCBcIi9ub2RlX21vZHVsZXMvdmluZXh0L2Rpc3Qvc2VydmVyL2FwcC1lbGVtZW50cy5qcz92PWI0MWJlY2RkXCI7XG5pbXBvcnQgeyByZXNvbHZlUnNjUmVkaXJlY3RMaWZlY3ljbGVIb3AsIHJlc29sdmVTdHJlYW1lZFJzY1JlZGlyZWN0TGlmZWN5Y2xlSG9wIH0gZnJvbSBcIi9ub2RlX21vZHVsZXMvdmluZXh0L2Rpc3Qvc2VydmVyL2FwcC1icm93c2VyLXJzYy1yZWRpcmVjdC5qcz92PWI0MWJlY2RkXCI7XG5pbXBvcnQgeyBOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2RlcywgY3JlYXRlTmF2aWdhdGlvbkxpZmVjeWNsZVRyYWNlRmllbGRzLCBjcmVhdGVOYXZpZ2F0aW9uVHJhY2UgfSBmcm9tIFwiL25vZGVfbW9kdWxlcy92aW5leHQvZGlzdC9zZXJ2ZXIvbmF2aWdhdGlvbi10cmFjZS5qcz92PWI0MWJlY2RkXCI7XG5pbXBvcnQgeyB2ZXJpZnlPcGVyYXRpb25Ub2tlbkZvckNhY2hlUmV1c2UgfSBmcm9tIFwiL25vZGVfbW9kdWxlcy92aW5leHQvZGlzdC9zZXJ2ZXIvb3BlcmF0aW9uLXRva2VuLmpzP3Y9YjQxYmVjZGRcIjtcbi8vI3JlZ2lvbiBzcmMvc2VydmVyL25hdmlnYXRpb24tcGxhbm5lci50c1xuZnVuY3Rpb24gbWVyZ2VSc2NSZWRpcmVjdEhpc3RvcnlNb2RlKG5hdmlnYXRpb25Nb2RlLCByZWRpcmVjdFR5cGUpIHtcblx0cmV0dXJuIG5hdmlnYXRpb25Nb2RlID09PSBcInB1c2hcIiB8fCByZWRpcmVjdFR5cGUgPT09IFwicHVzaFwiID8gXCJwdXNoXCIgOiBcInJlcGxhY2VcIjtcbn1cbmNvbnN0IFJPVVRFX0lOVEVSQ0VQVElPTl9DT05URVhUX1NFUEFSQVRPUiA9IFwiXFwwXCI7XG5jb25zdCBDQUNIRV9FTlRSWV9QUk9PRl9NSVNTSU5HX0NPREUgPSBcIkNQX0NBQ0hFX0VOVFJZX1BST09GX01JU1NJTkdcIjtcbmZ1bmN0aW9uIGNyZWF0ZVJlcXVlc3RXb3JrRGVjaXNpb24ob3B0aW9ucykge1xuXHRjb25zdCB0cmF2ZXJzZUZpZWxkcyA9IG9wdGlvbnMud29yay5raW5kID09PSBcInRyYXZlcnNlRmxpZ2h0XCIgPyB7IHRyYXZlcnNlRGlyZWN0aW9uOiBvcHRpb25zLndvcmsuZGlyZWN0aW9uIH0gOiB7fTtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcInJlcXVlc3RXb3JrXCIsXG5cdFx0dG9rZW46IG9wdGlvbnMuc3RhdGUubmV4dE9wZXJhdGlvblRva2VuLFxuXHRcdHdvcms6IG9wdGlvbnMud29yayxcblx0XHR0cmFjZTogY3JlYXRlTmF2aWdhdGlvblRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnJlcXVlc3RXb3JrLCB7XG5cdFx0XHRldmVudEtpbmQ6IG9wdGlvbnMuZXZlbnRLaW5kLFxuXHRcdFx0dGFyZ2V0SHJlZjogZ2V0UmVxdWVzdGVkV29ya1RhcmdldEhyZWYob3B0aW9ucy53b3JrKSxcblx0XHRcdC4uLnRyYXZlcnNlRmllbGRzXG5cdFx0fSlcblx0fTtcbn1cbmZ1bmN0aW9uIGdldFJlcXVlc3RlZFdvcmtUYXJnZXRIcmVmKHdvcmspIHtcblx0c3dpdGNoICh3b3JrLmtpbmQpIHtcblx0XHRjYXNlIFwiZmxpZ2h0XCI6XG5cdFx0Y2FzZSBcInByZWZldGNoXCI6IHJldHVybiB3b3JrLmhyZWY7XG5cdFx0Y2FzZSBcInRyYXZlcnNlRmxpZ2h0XCI6IHJldHVybiBudWxsO1xuXHRcdGRlZmF1bHQ6IHRocm93IG5ldyBFcnJvcihcIlt2aW5leHRdIFVua25vd24gcmVxdWVzdGVkIG5hdmlnYXRpb24gd29yazogXCIgKyBTdHJpbmcod29yaykpO1xuXHR9XG59XG5mdW5jdGlvbiBjcmVhdGVSc2NGZXRjaFJlc3VsdFRyYWNlRmllbGRzKGZhY3RzLCBmaWVsZHMgPSB7fSkge1xuXHRyZXR1cm4ge1xuXHRcdGZldGNoUmVzdWx0U291cmNlOiBmYWN0cy5zb3VyY2UsXG5cdFx0Li4uZmllbGRzXG5cdH07XG59XG5mdW5jdGlvbiBjcmVhdGVSc2NGZXRjaFJlc3VsdEhhcmROYXZpZ2F0aW9uRGVjaXNpb24ob3B0aW9ucykge1xuXHRyZXR1cm4ge1xuXHRcdGRpc2NhcmRCb2R5OiBvcHRpb25zLmRpc2NhcmRCb2R5LFxuXHRcdGtpbmQ6IFwiaGFyZE5hdmlnYXRlXCIsXG5cdFx0Li4ub3B0aW9ucy5oYXJkTmF2aWdhdGlvbk1vZGUgIT09IHZvaWQgMCA/IHsgaGFyZE5hdmlnYXRpb25Nb2RlOiBvcHRpb25zLmhhcmROYXZpZ2F0aW9uTW9kZSB9IDoge30sXG5cdFx0cmVhc29uOiBvcHRpb25zLnJlYXNvbixcblx0XHR0cmFjZTogY3JlYXRlTmF2aWdhdGlvblRyYWNlKG9wdGlvbnMucmVhc29uQ29kZSwgY3JlYXRlUnNjRmV0Y2hSZXN1bHRUcmFjZUZpZWxkcyhvcHRpb25zLmZhY3RzLCB7XG5cdFx0XHQuLi5vcHRpb25zLnJlZGlyZWN0U2lnbmFsICE9PSB2b2lkIDAgPyB7IHJlZGlyZWN0U2lnbmFsOiBvcHRpb25zLnJlZGlyZWN0U2lnbmFsIH0gOiB7fSxcblx0XHRcdHJlZGlyZWN0RGVwdGg6IG9wdGlvbnMuZmFjdHMucmVkaXJlY3REZXB0aCxcblx0XHRcdHRhcmdldEhyZWY6IG9wdGlvbnMudXJsXG5cdFx0fSkpLFxuXHRcdHVybDogb3B0aW9ucy51cmxcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJzY0ZldGNoUmVzdWx0Rm9sbG93UmVkaXJlY3REZWNpc2lvbihvcHRpb25zKSB7XG5cdHJldHVybiB7XG5cdFx0ZGlzY2FyZEJvZHk6IG9wdGlvbnMuZGlzY2FyZEJvZHksXG5cdFx0a2luZDogXCJmb2xsb3dSZWRpcmVjdFwiLFxuXHRcdHJlZGlyZWN0OiBvcHRpb25zLnJlZGlyZWN0LFxuXHRcdHRyYWNlOiBjcmVhdGVOYXZpZ2F0aW9uVHJhY2UoTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMucmVkaXJlY3RGb2xsb3csIGNyZWF0ZVJzY0ZldGNoUmVzdWx0VHJhY2VGaWVsZHMob3B0aW9ucy5mYWN0cywge1xuXHRcdFx0cmVkaXJlY3REZXB0aDogb3B0aW9ucy5yZWRpcmVjdC5yZWRpcmVjdERlcHRoLFxuXHRcdFx0cmVkaXJlY3RTaWduYWw6IG9wdGlvbnMucmVkaXJlY3RTaWduYWwsXG5cdFx0XHR0YXJnZXRIcmVmOiBvcHRpb25zLnJlZGlyZWN0LmhyZWZcblx0XHR9KSlcblx0fTtcbn1cbmZ1bmN0aW9uIG1hcFJzY1JlZGlyZWN0VGVybWluYWxSZWFzb24ocmVhc29uKSB7XG5cdHN3aXRjaCAocmVhc29uKSB7XG5cdFx0Y2FzZSBcImV4dGVybmFsUmVkaXJlY3RcIjogcmV0dXJuIHtcblx0XHRcdGhhcmROYXZpZ2F0aW9uUmVhc29uOiBcImV4dGVybmFsUmVkaXJlY3RUYXJnZXRcIixcblx0XHRcdHRyYWNlUmVhc29uQ29kZTogTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMucmVkaXJlY3RUZXJtaW5hbEV4dGVybmFsXG5cdFx0fTtcblx0XHRjYXNlIFwibWF4UmVkaXJlY3RzRXhjZWVkZWRcIjogcmV0dXJuIHtcblx0XHRcdGhhcmROYXZpZ2F0aW9uUmVhc29uOiBcInJlZGlyZWN0RGVwdGhFeGhhdXN0ZWRcIixcblx0XHRcdHRyYWNlUmVhc29uQ29kZTogTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMucmVkaXJlY3RUZXJtaW5hbERlcHRoXG5cdFx0fTtcblx0XHRkZWZhdWx0OiB0aHJvdyBuZXcgRXJyb3IoXCJbdmluZXh0XSBVbmtub3duIFJTQyByZWRpcmVjdCB0ZXJtaW5hbCByZWFzb246IFwiICsgU3RyaW5nKHJlYXNvbikpO1xuXHR9XG59XG5mdW5jdGlvbiBjbGFzc2lmeVJzY0ZldGNoUmVzdWx0KGZhY3RzKSB7XG5cdGlmICghZmFjdHMucmVzcG9uc2VPayB8fCAhZmFjdHMuaXNSc2NDb250ZW50VHlwZSB8fCAhZmFjdHMuaGFzQm9keSkge1xuXHRcdGNvbnN0IHVybCA9IHJlc29sdmVIYXJkTmF2aWdhdGlvblRhcmdldEZyb21Sc2NSZXNwb25zZShmYWN0cy5yZXNwb25zZVVybCwgZmFjdHMuY3VycmVudEhyZWYsIGZhY3RzLm9yaWdpbik7XG5cdFx0cmV0dXJuIGNyZWF0ZVJzY0ZldGNoUmVzdWx0SGFyZE5hdmlnYXRpb25EZWNpc2lvbih7XG5cdFx0XHRkaXNjYXJkQm9keTogZmFsc2UsXG5cdFx0XHRmYWN0cyxcblx0XHRcdHJlYXNvbjogXCJpbnZhbGlkUnNjUGF5bG9hZFwiLFxuXHRcdFx0cmVhc29uQ29kZTogTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMuaW52YWxpZFJzY1BheWxvYWQsXG5cdFx0XHR1cmxcblx0XHR9KTtcblx0fVxuXHRjb25zdCBjb21wYXRpYmlsaXR5RGVjaXNpb24gPSByZXNvbHZlUnNjQ29tcGF0aWJpbGl0eU5hdmlnYXRpb25EZWNpc2lvbih7XG5cdFx0Y2xpZW50Q29tcGF0aWJpbGl0eUlkOiBmYWN0cy5jbGllbnRDb21wYXRpYmlsaXR5SWQsXG5cdFx0Y3VycmVudEhyZWY6IGZhY3RzLmN1cnJlbnRIcmVmLFxuXHRcdG9yaWdpbjogZmFjdHMub3JpZ2luLFxuXHRcdHJlc3BvbnNlQ29tcGF0aWJpbGl0eUlkOiBmYWN0cy5jb21wYXRpYmlsaXR5SWRIZWFkZXIsXG5cdFx0cmVzcG9uc2VVcmw6IGZhY3RzLnJlc3BvbnNlVXJsXG5cdH0pO1xuXHRpZiAoY29tcGF0aWJpbGl0eURlY2lzaW9uLmtpbmQgPT09IFwiaGFyZC1uYXZpZ2F0ZVwiKSByZXR1cm4gY3JlYXRlUnNjRmV0Y2hSZXN1bHRIYXJkTmF2aWdhdGlvbkRlY2lzaW9uKHtcblx0XHRkaXNjYXJkQm9keTogZmFsc2UsXG5cdFx0ZmFjdHMsXG5cdFx0cmVhc29uOiBcInJzY0NvbXBhdGliaWxpdHlNaXNtYXRjaFwiLFxuXHRcdHJlYXNvbkNvZGU6IE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnJzY0NvbXBhdGliaWxpdHlNaXNtYXRjaCxcblx0XHR1cmw6IGNvbXBhdGliaWxpdHlEZWNpc2lvbi5oYXJkTmF2aWdhdGlvblRhcmdldFxuXHR9KTtcblx0aWYgKGZhY3RzLnJlc3BvbnNlVXJsICE9PSBudWxsKSB7XG5cdFx0Y29uc3QgcmVkaXJlY3REZWNpc2lvbiA9IHJlc29sdmVSc2NSZWRpcmVjdExpZmVjeWNsZUhvcCh7XG5cdFx0XHRjdXJyZW50SHJlZjogZmFjdHMuY3VycmVudEhyZWYsXG5cdFx0XHRoaXN0b3J5VXBkYXRlTW9kZTogZmFjdHMuZWZmZWN0aXZlSGlzdG9yeVVwZGF0ZU1vZGUsXG5cdFx0XHRvcmlnaW46IGZhY3RzLm9yaWdpbixcblx0XHRcdHJlZGlyZWN0RGVwdGg6IGZhY3RzLnJlZGlyZWN0RGVwdGgsXG5cdFx0XHRyZXF1ZXN0UHJldmlvdXNOZXh0VXJsOiBmYWN0cy5yZXF1ZXN0UHJldmlvdXNOZXh0VXJsLFxuXHRcdFx0cmVzcG9uc2VVcmw6IGZhY3RzLnJlc3BvbnNlVXJsXG5cdFx0fSk7XG5cdFx0aWYgKHJlZGlyZWN0RGVjaXNpb24ua2luZCA9PT0gXCJ0ZXJtaW5hbC1oYXJkLW5hdmlnYXRpb25cIikge1xuXHRcdFx0Y29uc3QgdGVybWluYWxSZWFzb24gPSBtYXBSc2NSZWRpcmVjdFRlcm1pbmFsUmVhc29uKHJlZGlyZWN0RGVjaXNpb24ucmVhc29uKTtcblx0XHRcdHJldHVybiBjcmVhdGVSc2NGZXRjaFJlc3VsdEhhcmROYXZpZ2F0aW9uRGVjaXNpb24oe1xuXHRcdFx0XHRkaXNjYXJkQm9keTogZmFsc2UsXG5cdFx0XHRcdGZhY3RzLFxuXHRcdFx0XHRyZWFzb246IHRlcm1pbmFsUmVhc29uLmhhcmROYXZpZ2F0aW9uUmVhc29uLFxuXHRcdFx0XHRyZWFzb25Db2RlOiB0ZXJtaW5hbFJlYXNvbi50cmFjZVJlYXNvbkNvZGUsXG5cdFx0XHRcdHJlZGlyZWN0U2lnbmFsOiBcInJlc3BvbnNlLXVybFwiLFxuXHRcdFx0XHR1cmw6IHJlZGlyZWN0RGVjaXNpb24uaHJlZlxuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGlmIChyZWRpcmVjdERlY2lzaW9uLmtpbmQgPT09IFwiZm9sbG93XCIpIHJldHVybiBjcmVhdGVSc2NGZXRjaFJlc3VsdEZvbGxvd1JlZGlyZWN0RGVjaXNpb24oe1xuXHRcdFx0ZGlzY2FyZEJvZHk6IGZhbHNlLFxuXHRcdFx0ZmFjdHMsXG5cdFx0XHRyZWRpcmVjdDoge1xuXHRcdFx0XHRocmVmOiByZWRpcmVjdERlY2lzaW9uLmhyZWYsXG5cdFx0XHRcdGhpc3RvcnlVcGRhdGVNb2RlOiBmYWN0cy5lZmZlY3RpdmVIaXN0b3J5VXBkYXRlTW9kZSxcblx0XHRcdFx0cHJldmlvdXNOZXh0VXJsOiByZWRpcmVjdERlY2lzaW9uLnByZXZpb3VzTmV4dFVybCxcblx0XHRcdFx0cmVkaXJlY3REZXB0aDogcmVkaXJlY3REZWNpc2lvbi5yZWRpcmVjdERlcHRoXG5cdFx0XHR9LFxuXHRcdFx0cmVkaXJlY3RTaWduYWw6IFwicmVzcG9uc2UtdXJsXCJcblx0XHR9KTtcblx0fVxuXHRpZiAoZmFjdHMuc3RyZWFtZWRSZWRpcmVjdFRhcmdldCAhPT0gbnVsbCkge1xuXHRcdGNvbnN0IHN0cmVhbWVkSGlzdG9yeU1vZGUgPSBtZXJnZVJzY1JlZGlyZWN0SGlzdG9yeU1vZGUoZmFjdHMuZWZmZWN0aXZlSGlzdG9yeVVwZGF0ZU1vZGUsIGZhY3RzLnN0cmVhbWVkUmVkaXJlY3RUeXBlKTtcblx0XHRjb25zdCByZWRpcmVjdERlY2lzaW9uID0gcmVzb2x2ZVN0cmVhbWVkUnNjUmVkaXJlY3RMaWZlY3ljbGVIb3Aoe1xuXHRcdFx0Y3VycmVudEhyZWY6IGZhY3RzLmN1cnJlbnRIcmVmLFxuXHRcdFx0aGlzdG9yeVVwZGF0ZU1vZGU6IHN0cmVhbWVkSGlzdG9yeU1vZGUsXG5cdFx0XHRvcmlnaW46IGZhY3RzLm9yaWdpbixcblx0XHRcdHJlZGlyZWN0RGVwdGg6IGZhY3RzLnJlZGlyZWN0RGVwdGgsXG5cdFx0XHRyZXF1ZXN0UHJldmlvdXNOZXh0VXJsOiBmYWN0cy5yZXF1ZXN0UHJldmlvdXNOZXh0VXJsLFxuXHRcdFx0c3RyZWFtZWRSZWRpcmVjdFRhcmdldDogZmFjdHMuc3RyZWFtZWRSZWRpcmVjdFRhcmdldFxuXHRcdH0pO1xuXHRcdGlmIChyZWRpcmVjdERlY2lzaW9uLmtpbmQgPT09IFwidGVybWluYWwtaGFyZC1uYXZpZ2F0aW9uXCIpIHtcblx0XHRcdGNvbnN0IHRlcm1pbmFsUmVhc29uID0gbWFwUnNjUmVkaXJlY3RUZXJtaW5hbFJlYXNvbihyZWRpcmVjdERlY2lzaW9uLnJlYXNvbik7XG5cdFx0XHRyZXR1cm4gY3JlYXRlUnNjRmV0Y2hSZXN1bHRIYXJkTmF2aWdhdGlvbkRlY2lzaW9uKHtcblx0XHRcdFx0ZGlzY2FyZEJvZHk6IHRydWUsXG5cdFx0XHRcdGZhY3RzLFxuXHRcdFx0XHRyZWFzb246IHRlcm1pbmFsUmVhc29uLmhhcmROYXZpZ2F0aW9uUmVhc29uLFxuXHRcdFx0XHRyZWFzb25Db2RlOiB0ZXJtaW5hbFJlYXNvbi50cmFjZVJlYXNvbkNvZGUsXG5cdFx0XHRcdHJlZGlyZWN0U2lnbmFsOiBcInN0cmVhbWVkLWhlYWRlclwiLFxuXHRcdFx0XHRoYXJkTmF2aWdhdGlvbk1vZGU6IHN0cmVhbWVkSGlzdG9yeU1vZGUgPT09IFwicHVzaFwiID8gXCJhc3NpZ25cIiA6IFwicmVwbGFjZVwiLFxuXHRcdFx0XHR1cmw6IHJlZGlyZWN0RGVjaXNpb24uaHJlZlxuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGlmIChyZWRpcmVjdERlY2lzaW9uLmtpbmQgPT09IFwiZm9sbG93XCIpIHJldHVybiBjcmVhdGVSc2NGZXRjaFJlc3VsdEZvbGxvd1JlZGlyZWN0RGVjaXNpb24oe1xuXHRcdFx0ZGlzY2FyZEJvZHk6IHRydWUsXG5cdFx0XHRmYWN0cyxcblx0XHRcdHJlZGlyZWN0OiB7XG5cdFx0XHRcdGhyZWY6IHJlZGlyZWN0RGVjaXNpb24uaHJlZixcblx0XHRcdFx0aGlzdG9yeVVwZGF0ZU1vZGU6IHN0cmVhbWVkSGlzdG9yeU1vZGUsXG5cdFx0XHRcdHByZXZpb3VzTmV4dFVybDogcmVkaXJlY3REZWNpc2lvbi5wcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdHJlZGlyZWN0RGVwdGg6IHJlZGlyZWN0RGVjaXNpb24ucmVkaXJlY3REZXB0aFxuXHRcdFx0fSxcblx0XHRcdHJlZGlyZWN0U2lnbmFsOiBcInN0cmVhbWVkLWhlYWRlclwiXG5cdFx0fSk7XG5cdFx0cmV0dXJuIGNyZWF0ZVJzY0ZldGNoUmVzdWx0SGFyZE5hdmlnYXRpb25EZWNpc2lvbih7XG5cdFx0XHRkaXNjYXJkQm9keTogdHJ1ZSxcblx0XHRcdGZhY3RzLFxuXHRcdFx0cmVhc29uOiBcInN0cmVhbWVkUmVkaXJlY3RMb29wXCIsXG5cdFx0XHRyZWFzb25Db2RlOiBOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5zdHJlYW1lZFJlZGlyZWN0TG9vcCxcblx0XHRcdHJlZGlyZWN0U2lnbmFsOiBcInN0cmVhbWVkLWhlYWRlclwiLFxuXHRcdFx0dXJsOiByZWRpcmVjdERlY2lzaW9uLmhyZWZcblx0XHR9KTtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdGRpc2NhcmRCb2R5OiBmYWxzZSxcblx0XHRraW5kOiBcInByb2NlZWRUb0NvbW1pdFwiLFxuXHRcdHRyYWNlOiBjcmVhdGVOYXZpZ2F0aW9uVHJhY2UoTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMucHJvY2VlZFRvQ29tbWl0LCBjcmVhdGVSc2NGZXRjaFJlc3VsdFRyYWNlRmllbGRzKGZhY3RzKSlcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUVhcmx5TmF2aWdhdGlvbkludGVudFRyYWNlKHJlYXNvbkNvZGUsIGZhY3RzKSB7XG5cdHJldHVybiBjcmVhdGVOYXZpZ2F0aW9uVHJhY2UocmVhc29uQ29kZSwgeyB0YXJnZXRIcmVmOiBmYWN0cy50YXJnZXRIcmVmIH0pO1xufVxuZnVuY3Rpb24gYXBwUmVsYXRpdmVOYXZpZ2F0aW9uUGF0aG5hbWUocGF0aG5hbWUsIGJhc2VQYXRoLCB1cmxTcGFjZSkge1xuXHRyZXR1cm4gdXJsU3BhY2UgPT09IFwiYnJvd3NlclwiID8gc3RyaXBCYXNlUGF0aChwYXRobmFtZSwgYmFzZVBhdGgpIDogcGF0aG5hbWU7XG59XG5mdW5jdGlvbiBjbGFzc2lmeUVhcmx5TmF2aWdhdGlvbkludGVudChmYWN0cykge1xuXHRsZXQgY3VycmVudDtcblx0bGV0IG5leHQ7XG5cdHRyeSB7XG5cdFx0Y3VycmVudCA9IG5ldyBVUkwoZmFjdHMuY3VycmVudEhyZWYpO1xuXHRcdG5leHQgPSBuZXcgVVJMKGZhY3RzLnRhcmdldEhyZWYsIGZhY3RzLmN1cnJlbnRIcmVmKTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGJ5cGFzc05hdmlnYXRpb25DYWNoZTogZmFsc2UsXG5cdFx0XHRraW5kOiBcImZsaWdodE5hdmlnYXRpb25cIixcblx0XHRcdHRyYWNlOiBjcmVhdGVFYXJseU5hdmlnYXRpb25JbnRlbnRUcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5jcm9zc0RvY3VtZW50RmxpZ2h0LCBmYWN0cylcblx0XHR9O1xuXHR9XG5cdGNvbnN0IGN1cnJlbnRBcHBQYXRobmFtZSA9IGFwcFJlbGF0aXZlTmF2aWdhdGlvblBhdGhuYW1lKGN1cnJlbnQucGF0aG5hbWUsIGZhY3RzLmJhc2VQYXRoLCBmYWN0cy5jdXJyZW50VXJsU3BhY2UpO1xuXHRjb25zdCB0YXJnZXRBcHBQYXRobmFtZSA9IGFwcFJlbGF0aXZlTmF2aWdhdGlvblBhdGhuYW1lKG5leHQucGF0aG5hbWUsIGZhY3RzLmJhc2VQYXRoLCBcImJyb3dzZXJcIik7XG5cdGNvbnN0IHNhbWVQYXRobmFtZSA9IGN1cnJlbnQub3JpZ2luID09PSBuZXh0Lm9yaWdpbiAmJiBjdXJyZW50QXBwUGF0aG5hbWUgPT09IHRhcmdldEFwcFBhdGhuYW1lO1xuXHRjb25zdCBzYW1lU2VhcmNoID0gY3VycmVudC5zZWFyY2hQYXJhbXMudG9TdHJpbmcoKSA9PT0gbmV4dC5zZWFyY2hQYXJhbXMudG9TdHJpbmcoKTtcblx0aWYgKHNhbWVQYXRobmFtZSAmJiBjdXJyZW50LnNlYXJjaCA9PT0gbmV4dC5zZWFyY2ggJiYgY3VycmVudC5oYXNoID09PSBuZXh0Lmhhc2gpIHJldHVybiB7XG5cdFx0YnlwYXNzTmF2aWdhdGlvbkNhY2hlOiB0cnVlLFxuXHRcdGtpbmQ6IFwiZmxpZ2h0TmF2aWdhdGlvblwiLFxuXHRcdHRyYWNlOiBjcmVhdGVFYXJseU5hdmlnYXRpb25JbnRlbnRUcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5zYW1lUGFnZVJlZnJlc2gsIGZhY3RzKVxuXHR9O1xuXHRpZiAoc2FtZVBhdGhuYW1lICYmIHNhbWVTZWFyY2ggJiYgY3VycmVudC5oYXNoICE9PSBuZXh0Lmhhc2gpIHJldHVybiB7XG5cdFx0aGFzaDogbmV4dC5oYXNoLFxuXHRcdGtpbmQ6IFwic2FtZURvY3VtZW50U2Nyb2xsXCIsXG5cdFx0bW9kZTogZmFjdHMubW9kZSxcblx0XHRzY3JvbGw6IGZhY3RzLnNjcm9sbCxcblx0XHR0cmFjZTogY3JlYXRlRWFybHlOYXZpZ2F0aW9uSW50ZW50VHJhY2UoTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMuc2FtZURvY3VtZW50U2Nyb2xsLCBmYWN0cylcblx0fTtcblx0aWYgKHNhbWVQYXRobmFtZSAmJiAhc2FtZVNlYXJjaCkgcmV0dXJuIHtcblx0XHRieXBhc3NOYXZpZ2F0aW9uQ2FjaGU6IHRydWUsXG5cdFx0a2luZDogXCJmbGlnaHROYXZpZ2F0aW9uXCIsXG5cdFx0dHJhY2U6IGNyZWF0ZUVhcmx5TmF2aWdhdGlvbkludGVudFRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnNhbWVQYWdlU2VhcmNoLCBmYWN0cylcblx0fTtcblx0cmV0dXJuIHtcblx0XHRieXBhc3NOYXZpZ2F0aW9uQ2FjaGU6IGZhbHNlLFxuXHRcdGtpbmQ6IFwiZmxpZ2h0TmF2aWdhdGlvblwiLFxuXHRcdHRyYWNlOiBjcmVhdGVFYXJseU5hdmlnYXRpb25JbnRlbnRUcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5jcm9zc0RvY3VtZW50RmxpZ2h0LCBmYWN0cylcblx0fTtcbn1cbmZ1bmN0aW9uIGNsYXNzaWZ5VmlzaXRlZFJlc3BvbnNlQ2FjaGVDYW5kaWRhdGUoZmFjdHMpIHtcblx0aWYgKGZhY3RzLmNhbmRpZGF0ZSA9PT0gXCJtaXNzaW5nXCIpIHJldHVybiB7IGtpbmQ6IFwibWlzc1wiIH07XG5cdGlmICghZmFjdHMubW91bnRlZFNsb3RzTWF0Y2gpIHJldHVybiB7XG5cdFx0a2luZDogXCJldmljdFwiLFxuXHRcdHJlYXNvbjogXCJtb3VudGVkU2xvdHNNaXNtYXRjaFwiXG5cdH07XG5cdGlmIChmYWN0cy5uYXZpZ2F0aW9uS2luZCA9PT0gXCJyZWZyZXNoXCIpIHJldHVybiB7XG5cdFx0a2luZDogXCJldmljdFwiLFxuXHRcdHJlYXNvbjogXCJyZWZyZXNoXCJcblx0fTtcblx0aWYgKCFmYWN0cy5mcmVzaCkgcmV0dXJuIHtcblx0XHRraW5kOiBcImV2aWN0XCIsXG5cdFx0cmVhc29uOiBcInN0YWxlXCJcblx0fTtcblx0cmV0dXJuIHsga2luZDogXCJyZXVzZVwiIH07XG59XG5mdW5jdGlvbiBjcmVhdGVOYXZpZ2F0aW9uUmV1c2VUcmFjZShjb2RlLCBmYWN0cywgZmllbGRzID0ge30pIHtcblx0cmV0dXJuIGNyZWF0ZU5hdmlnYXRpb25UcmFjZShjb2RlLCB7XG5cdFx0ZXZlbnRLaW5kOiBmYWN0cy5uYXZpZ2F0aW9uS2luZCxcblx0XHR0YXJnZXRIcmVmOiBmYWN0cy50YXJnZXRIcmVmLFxuXHRcdC4uLmZpZWxkc1xuXHR9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUZyZXNoRmV0Y2hEZWNpc2lvbihmYWN0cywgcmVhc29uKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJmZXRjaEZyZXNoXCIsXG5cdFx0cmVhc29uLFxuXHRcdHRyYWNlOiBjcmVhdGVOYXZpZ2F0aW9uUmV1c2VUcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5mZXRjaEZyZXNoLCBmYWN0cywgeyBmcmVzaEZldGNoUmVhc29uOiByZWFzb24gfSlcblx0fTtcbn1cbmZ1bmN0aW9uIGNsYXNzaWZ5TmF2aWdhdGlvblJldXNlKGZhY3RzKSB7XG5cdGlmIChmYWN0cy5uYXZpZ2F0aW9uS2luZCA9PT0gXCJyZWZyZXNoXCIpIHJldHVybiBjcmVhdGVGcmVzaEZldGNoRGVjaXNpb24oZmFjdHMsIFwicmVmcmVzaFwiKTtcblx0aWYgKCFmYWN0cy5ieXBhc3NOYXZpZ2F0aW9uQ2FjaGUgJiYgZmFjdHMudmlzaXRlZFJlc3BvbnNlLnN0YXR1cyA9PT0gXCJhdmFpbGFibGVcIikgcmV0dXJuIHtcblx0XHRraW5kOiBcInJldXNlVmlzaXRlZFJlc3BvbnNlXCIsXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25SZXVzZVRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnZpc2l0ZWRSZXNwb25zZVJldXNlLCBmYWN0cylcblx0fTtcblx0aWYgKCFmYWN0cy5ieXBhc3NOYXZpZ2F0aW9uQ2FjaGUgJiYgZmFjdHMucHJlZmV0Y2guc3RhdHVzID09PSBcImF2YWlsYWJsZVwiKSByZXR1cm4ge1xuXHRcdGtpbmQ6IFwiY29uc3VtZVByZWZldGNoXCIsXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25SZXVzZVRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnByZWZldGNoUmVzcG9uc2VSZXVzZSwgZmFjdHMpXG5cdH07XG5cdGlmIChmYWN0cy5uYXZpZ2F0aW9uS2luZCA9PT0gXCJuYXZpZ2F0ZVwiKSB7XG5cdFx0aWYgKGZhY3RzLm9wdGltaXN0aWNSb3V0ZVNoZWxsLnN0YXR1cyA9PT0gXCJhdmFpbGFibGVcIikgcmV0dXJuIHtcblx0XHRcdGtpbmQ6IFwiYXR0ZW1wdE9wdGltaXN0aWNSb3V0ZVNoZWxsXCIsXG5cdFx0XHR0cmFjZTogY3JlYXRlTmF2aWdhdGlvblJldXNlVHJhY2UoTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMub3B0aW1pc3RpY1JvdXRlU2hlbGwsIGZhY3RzKVxuXHRcdH07XG5cdFx0cmV0dXJuIGNyZWF0ZUZyZXNoRmV0Y2hEZWNpc2lvbihmYWN0cywgZmFjdHMuYnlwYXNzTmF2aWdhdGlvbkNhY2hlID8gXCJjYWNoZUJ5cGFzc2VkXCIgOiBmYWN0cy5vcHRpbWlzdGljUm91dGVTaGVsbC5yZWFzb24pO1xuXHR9XG5cdGlmIChmYWN0cy5ieXBhc3NOYXZpZ2F0aW9uQ2FjaGUpIHJldHVybiBjcmVhdGVGcmVzaEZldGNoRGVjaXNpb24oZmFjdHMsIFwiY2FjaGVCeXBhc3NlZFwiKTtcblx0cmV0dXJuIGNyZWF0ZUZyZXNoRmV0Y2hEZWNpc2lvbihmYWN0cywgXCJjYWNoZU1pc3NcIik7XG59XG5mdW5jdGlvbiBjbGFzc2lmeU5hdmlnYXRpb25QcmVmZXRjaFByb2JlKGZhY3RzKSB7XG5cdGlmIChmYWN0cy52aXNpdGVkUmVzcG9uc2Uuc3RhdHVzID09PSBcImF2YWlsYWJsZVwiKSByZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2tpcFwiLFxuXHRcdHJlYXNvbjogXCJ2aXNpdGVkUmVzcG9uc2VBdmFpbGFibGVcIlxuXHR9O1xuXHRpZiAoZmFjdHMubmF2aWdhdGlvbktpbmQgPT09IFwicmVmcmVzaFwiKSByZXR1cm4ge1xuXHRcdGtpbmQ6IFwic2tpcFwiLFxuXHRcdHJlYXNvbjogXCJyZWZyZXNoXCJcblx0fTtcblx0aWYgKGZhY3RzLmJ5cGFzc05hdmlnYXRpb25DYWNoZSkgcmV0dXJuIHtcblx0XHRraW5kOiBcInNraXBcIixcblx0XHRyZWFzb246IFwiY2FjaGVCeXBhc3NlZFwiXG5cdH07XG5cdHJldHVybiB7IGtpbmQ6IFwicHJvYmVcIiB9O1xufVxuZnVuY3Rpb24gY3JlYXRlU25hcHNob3RSb3V0ZVRvcG9sb2d5KHNuYXBzaG90KSB7XG5cdHJldHVybiB7XG5cdFx0bGF5b3V0SWRzOiBzbmFwc2hvdC5sYXlvdXRJZHMsXG5cdFx0cm9vdEJvdW5kYXJ5SWQ6IHNuYXBzaG90LnJvb3RCb3VuZGFyeUlkLFxuXHRcdHJvb3RMYXlvdXRUcmVlUGF0aDogc25hcHNob3Qucm9vdEJvdW5kYXJ5SWQsXG5cdFx0c2xvdEJpbmRpbmdzOiBzbmFwc2hvdC5zbG90QmluZGluZ3Ncblx0fTtcbn1cbmZ1bmN0aW9uIHN0cmlwSW50ZXJjZXB0aW9uQ29udGV4dEZyb21Sb3V0ZUlkKHJvdXRlSWQpIHtcblx0Y29uc3Qgc2VwYXJhdG9ySW5kZXggPSByb3V0ZUlkLmluZGV4T2YoUk9VVEVfSU5URVJDRVBUSU9OX0NPTlRFWFRfU0VQQVJBVE9SKTtcblx0cmV0dXJuIHNlcGFyYXRvckluZGV4ID09PSAtMSA/IHJvdXRlSWQgOiByb3V0ZUlkLnNsaWNlKDAsIHNlcGFyYXRvckluZGV4KTtcbn1cbmZ1bmN0aW9uIG1hdGNoZWRVcmxGcm9tQ29uY3JldGVSb3V0ZUlkKHJvdXRlSWQpIHtcblx0Y29uc3Qgbm9ybWFsaXplZFJvdXRlSWQgPSBzdHJpcEludGVyY2VwdGlvbkNvbnRleHRGcm9tUm91dGVJZChyb3V0ZUlkKTtcblx0aWYgKCFub3JtYWxpemVkUm91dGVJZC5zdGFydHNXaXRoKFwicm91dGU6L1wiKSkgcmV0dXJuIG51bGw7XG5cdHJldHVybiBub3JtYWxpemVkUm91dGVJZC5zbGljZSg2KTtcbn1cbmZ1bmN0aW9uIGdldE1hdGNoZWRVcmxQYXRobmFtZShtYXRjaGVkVXJsKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIG5ldyBVUkwobWF0Y2hlZFVybCwgXCJodHRwczovL3ZpbmV4dC5sb2NhbFwiKS5wYXRobmFtZTtcblx0fSBjYXRjaCB7XG5cdFx0Y29uc3QgW3dpdGhvdXRIYXNoID0gXCJcIl0gPSBtYXRjaGVkVXJsLnNwbGl0KFwiI1wiKTtcblx0XHRjb25zdCBbcGF0aG5hbWUgPSBcIlwiXSA9IHdpdGhvdXRIYXNoLnNwbGl0KFwiP1wiKTtcblx0XHRyZXR1cm4gcGF0aG5hbWUgPT09IFwiXCIgPyBcIi9cIiA6IHBhdGhuYW1lO1xuXHR9XG59XG5mdW5jdGlvbiBzcGxpdE1hdGNoZWRVcmxJbnRvUm91dGVQYXJ0cyhtYXRjaGVkVXJsKSB7XG5cdHJldHVybiBzcGxpdFBhdGhuYW1lRm9yUm91dGVNYXRjaChnZXRNYXRjaGVkVXJsUGF0aG5hbWUobWF0Y2hlZFVybCkpO1xufVxuZnVuY3Rpb24gZmluZFJvdXRlTWFuaWZlc3RSb3V0ZUJ5TWF0Y2hlZFVybChyb3V0ZU1hbmlmZXN0LCBtYXRjaGVkVXJsKSB7XG5cdGNvbnN0IHVybFBhcnRzID0gc3BsaXRNYXRjaGVkVXJsSW50b1JvdXRlUGFydHMobWF0Y2hlZFVybCk7XG5cdGZvciAoY29uc3Qgcm91dGUgb2Ygcm91dGVNYW5pZmVzdC5zZWdtZW50R3JhcGgucm91dGVzLnZhbHVlcygpKSBpZiAobWF0Y2hSb3V0ZVBhdHRlcm4odXJsUGFydHMsIHJvdXRlLnBhdHRlcm5QYXJ0cykgIT09IG51bGwpIHJldHVybiByb3V0ZTtcblx0cmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiByb3V0ZU1hbmlmZXN0Um91dGVNYXRjaGVzVXJsKHJvdXRlLCBtYXRjaGVkVXJsKSB7XG5cdHJldHVybiBtYXRjaFJvdXRlUGF0dGVybihzcGxpdE1hdGNoZWRVcmxJbnRvUm91dGVQYXJ0cyhtYXRjaGVkVXJsKSwgcm91dGUucGF0dGVyblBhcnRzKSAhPT0gbnVsbDtcbn1cbmZ1bmN0aW9uIGZpbmRSb3V0ZU1hbmlmZXN0Um91dGVCeUlkT3JNYXRjaGVkVXJsKG9wdGlvbnMpIHtcblx0Y29uc3Qgcm91dGVJZCA9IHN0cmlwSW50ZXJjZXB0aW9uQ29udGV4dEZyb21Sb3V0ZUlkKG9wdGlvbnMucm91dGVJZCk7XG5cdGNvbnN0IHJvdXRlID0gb3B0aW9ucy5yb3V0ZU1hbmlmZXN0LnNlZ21lbnRHcmFwaC5yb3V0ZXMuZ2V0KHJvdXRlSWQpO1xuXHRpZiAocm91dGUgJiYgcm91dGVNYW5pZmVzdFJvdXRlTWF0Y2hlc1VybChyb3V0ZSwgb3B0aW9ucy5tYXRjaGVkVXJsKSkgcmV0dXJuIHJvdXRlO1xuXHRjb25zdCBjb25jcmV0ZVJvdXRlTWF0Y2hlZFVybCA9IHJvdXRlID09PSB2b2lkIDAgPyBtYXRjaGVkVXJsRnJvbUNvbmNyZXRlUm91dGVJZChvcHRpb25zLnJvdXRlSWQpIDogbnVsbDtcblx0aWYgKGNvbmNyZXRlUm91dGVNYXRjaGVkVXJsICE9PSBudWxsKSB7XG5cdFx0Y29uc3QgY29uY3JldGVSb3V0ZSA9IGZpbmRSb3V0ZU1hbmlmZXN0Um91dGVCeU1hdGNoZWRVcmwob3B0aW9ucy5yb3V0ZU1hbmlmZXN0LCBjb25jcmV0ZVJvdXRlTWF0Y2hlZFVybCk7XG5cdFx0aWYgKGNvbmNyZXRlUm91dGUgIT09IG51bGwpIHJldHVybiBjb25jcmV0ZVJvdXRlO1xuXHR9XG5cdHJldHVybiBmaW5kUm91dGVNYW5pZmVzdFJvdXRlQnlNYXRjaGVkVXJsKG9wdGlvbnMucm91dGVNYW5pZmVzdCwgb3B0aW9ucy5tYXRjaGVkVXJsKTtcbn1cbmZ1bmN0aW9uIGZpbmRSb3V0ZU1hbmlmZXN0Um91dGVGb3JTbmFwc2hvdChyb3V0ZU1hbmlmZXN0LCBzbmFwc2hvdCkge1xuXHRpZiAoc25hcHNob3QuaW50ZXJjZXB0aW9uICE9PSBudWxsKSByZXR1cm4gZmluZFJvdXRlTWFuaWZlc3RSb3V0ZUJ5SWRPck1hdGNoZWRVcmwoe1xuXHRcdG1hdGNoZWRVcmw6IHNuYXBzaG90LmludGVyY2VwdGlvbi5zb3VyY2VNYXRjaGVkVXJsLFxuXHRcdHJvdXRlSWQ6IHNuYXBzaG90LmludGVyY2VwdGlvbi5zb3VyY2VSb3V0ZUlkLFxuXHRcdHJvdXRlTWFuaWZlc3Rcblx0fSk7XG5cdHJldHVybiBmaW5kUm91dGVNYW5pZmVzdFJvdXRlQnlJZE9yTWF0Y2hlZFVybCh7XG5cdFx0bWF0Y2hlZFVybDogc25hcHNob3QubWF0Y2hlZFVybCxcblx0XHRyb3V0ZUlkOiBzbmFwc2hvdC5yb3V0ZUlkLFxuXHRcdHJvdXRlTWFuaWZlc3Rcblx0fSk7XG59XG5mdW5jdGlvbiByZXNvbHZlUm91dGVNYW5pZmVzdFNsb3RCaW5kaW5ncyhyb3V0ZU1hbmlmZXN0LCByb3V0ZSkge1xuXHRjb25zdCBiaW5kaW5ncyA9IFtdO1xuXHRmb3IgKGNvbnN0IHNsb3RJZCBvZiByb3V0ZS5zbG90SWRzKSB7XG5cdFx0Y29uc3QgYmluZGluZyA9IHJvdXRlTWFuaWZlc3Quc2VnbWVudEdyYXBoLnNsb3RCaW5kaW5ncy5nZXQoYCR7cm91dGUuaWR9Ojoke3Nsb3RJZH1gKTtcblx0XHRpZiAoIWJpbmRpbmcpIGNvbnRpbnVlO1xuXHRcdGJpbmRpbmdzLnB1c2goe1xuXHRcdFx0b3duZXJMYXlvdXRJZDogYmluZGluZy5vd25lckxheW91dElkLFxuXHRcdFx0c2xvdElkOiBiaW5kaW5nLnNsb3RJZCxcblx0XHRcdHN0YXRlOiBiaW5kaW5nLnN0YXRlXG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIGJpbmRpbmdzLnNvcnQoKGxlZnQsIHJpZ2h0KSA9PiBjb21wYXJlQXBwRWxlbWVudHNTbG90SWRzKGxlZnQuc2xvdElkLCByaWdodC5zbG90SWQpKTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVSb3V0ZU1hbmlmZXN0Um9vdExheW91dFRyZWVQYXRoKHJvdXRlTWFuaWZlc3QsIHJvdXRlKSB7XG5cdGlmIChyb3V0ZS5yb290Qm91bmRhcnlJZCA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG5cdHJldHVybiByb3V0ZU1hbmlmZXN0LnNlZ21lbnRHcmFwaC5yb290Qm91bmRhcmllcy5nZXQocm91dGUucm9vdEJvdW5kYXJ5SWQpPy50cmVlUGF0aCA/PyBudWxsO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVJvdXRlVG9wb2xvZ3lTbmFwc2hvdChvcHRpb25zKSB7XG5cdGNvbnN0IHJvdXRlID0gb3B0aW9ucy5yb3V0ZU1hbmlmZXN0ID09PSBudWxsID8gbnVsbCA6IGZpbmRSb3V0ZU1hbmlmZXN0Um91dGVGb3JTbmFwc2hvdChvcHRpb25zLnJvdXRlTWFuaWZlc3QsIG9wdGlvbnMuc25hcHNob3QpO1xuXHRpZiAocm91dGUgPT09IG51bGwgfHwgb3B0aW9ucy5yb3V0ZU1hbmlmZXN0ID09PSBudWxsKSByZXR1cm4geyBraW5kOiBcInVua25vd25cIiB9O1xuXHRjb25zdCBzaG91bGRVc2VNYW5pZmVzdFNsb3RCaW5kaW5ncyA9IG9wdGlvbnMuc2xvdEJpbmRpbmdTb3VyY2UgPT09IFwibWFuaWZlc3RUYXJnZXRcIiAmJiBvcHRpb25zLnNuYXBzaG90LmludGVyY2VwdGlvbiA9PT0gbnVsbDtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcImtub3duXCIsXG5cdFx0dG9wb2xvZ3k6IHtcblx0XHRcdGxheW91dElkczogcm91dGUubGF5b3V0SWRzLFxuXHRcdFx0cm9vdEJvdW5kYXJ5SWQ6IHJvdXRlLnJvb3RCb3VuZGFyeUlkLFxuXHRcdFx0cm9vdExheW91dFRyZWVQYXRoOiByZXNvbHZlUm91dGVNYW5pZmVzdFJvb3RMYXlvdXRUcmVlUGF0aChvcHRpb25zLnJvdXRlTWFuaWZlc3QsIHJvdXRlKSxcblx0XHRcdHNsb3RCaW5kaW5nczogc2hvdWxkVXNlTWFuaWZlc3RTbG90QmluZGluZ3MgPyByZXNvbHZlUm91dGVNYW5pZmVzdFNsb3RCaW5kaW5ncyhvcHRpb25zLnJvdXRlTWFuaWZlc3QsIHJvdXRlKSA6IG9wdGlvbnMuc25hcHNob3Quc2xvdEJpbmRpbmdzXG5cdFx0fVxuXHR9O1xufVxuZnVuY3Rpb24gZmluZFJvdXRlTWFuaWZlc3RJbnRlcmNlcHRpb25Gb3JQcm9vZihyb3V0ZU1hbmlmZXN0LCBwcm9vZikge1xuXHRjb25zdCBzb3VyY2VQYXJ0cyA9IHNwbGl0TWF0Y2hlZFVybEludG9Sb3V0ZVBhcnRzKHByb29mLnNvdXJjZU1hdGNoZWRVcmwpO1xuXHRjb25zdCB0YXJnZXRQYXJ0cyA9IHNwbGl0TWF0Y2hlZFVybEludG9Sb3V0ZVBhcnRzKHByb29mLnRhcmdldE1hdGNoZWRVcmwpO1xuXHRjb25zdCB0YXJnZXRSb3V0ZSA9IGZpbmRSb3V0ZU1hbmlmZXN0Um91dGVCeUlkT3JNYXRjaGVkVXJsKHtcblx0XHRtYXRjaGVkVXJsOiBwcm9vZi50YXJnZXRNYXRjaGVkVXJsLFxuXHRcdHJvdXRlSWQ6IHByb29mLnRhcmdldFJvdXRlSWQsXG5cdFx0cm91dGVNYW5pZmVzdFxuXHR9KTtcblx0Y29uc3QgY2FuZGlkYXRlSW50ZXJjZXB0aW9ucyA9IHJvdXRlTWFuaWZlc3Quc2VnbWVudEdyYXBoLmludGVyY2VwdGlvbnNCeVNsb3RJZC5nZXQocHJvb2Yuc2xvdElkKSA/PyBbXTtcblx0Zm9yIChjb25zdCBpbnRlcmNlcHRpb24gb2YgY2FuZGlkYXRlSW50ZXJjZXB0aW9ucykge1xuXHRcdGlmICghbWF0Y2hSb3V0ZVBhdHRlcm5QcmVmaXgoc291cmNlUGFydHMsIGludGVyY2VwdGlvbi5zb3VyY2VQYXR0ZXJuUGFydHMpKSBjb250aW51ZTtcblx0XHRjb25zdCBleGFjdFRhcmdldFBhcmFtcyA9IG1hdGNoUm91dGVQYXR0ZXJuKHRhcmdldFBhcnRzLCBpbnRlcmNlcHRpb24udGFyZ2V0UGF0dGVyblBhcnRzKTtcblx0XHRjb25zdCBhbGxvd3NNaWRkbGV3YXJlUmV3cml0ZVRhcmdldCA9IGV4YWN0VGFyZ2V0UGFyYW1zID09PSBudWxsICYmIG1hdGNoUm91dGVQYXR0ZXJuV2l0aE9wdGlvbmFsRHluYW1pY1NlZ21lbnRzKHRhcmdldFBhcnRzLCBpbnRlcmNlcHRpb24udGFyZ2V0UGF0dGVyblBhcnRzKTtcblx0XHRpZiAoZXhhY3RUYXJnZXRQYXJhbXMgPT09IG51bGwgJiYgIWFsbG93c01pZGRsZXdhcmVSZXdyaXRlVGFyZ2V0KSBjb250aW51ZTtcblx0XHRpZiAoIWFsbG93c01pZGRsZXdhcmVSZXdyaXRlVGFyZ2V0ICYmIGludGVyY2VwdGlvbi50YXJnZXRSb3V0ZUlkICE9PSBudWxsICYmIHRhcmdldFJvdXRlPy5pZCAhPT0gaW50ZXJjZXB0aW9uLnRhcmdldFJvdXRlSWQpIGNvbnRpbnVlO1xuXHRcdHJldHVybiBpbnRlcmNlcHRpb247XG5cdH1cblx0cmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBjcmVhdGVSb290Qm91bmRhcnlUcmFjZUZpZWxkcyhvcHRpb25zKSB7XG5cdGlmIChvcHRpb25zLnN0YXRlLnRyYWNlRmllbGRzKSByZXR1cm4ge1xuXHRcdC4uLm9wdGlvbnMuc3RhdGUudHJhY2VGaWVsZHMsXG5cdFx0Y3VycmVudFJvb3RMYXlvdXRUcmVlUGF0aDogb3B0aW9ucy5jdXJyZW50Um9vdExheW91dFRyZWVQYXRoLFxuXHRcdG5leHRSb290TGF5b3V0VHJlZVBhdGg6IG9wdGlvbnMubmV4dFJvb3RMYXlvdXRUcmVlUGF0aFxuXHR9O1xuXHRyZXR1cm4gY3JlYXRlTmF2aWdhdGlvbkxpZmVjeWNsZVRyYWNlRmllbGRzKHtcblx0XHRjdXJyZW50Um9vdExheW91dFRyZWVQYXRoOiBvcHRpb25zLmN1cnJlbnRSb290TGF5b3V0VHJlZVBhdGgsXG5cdFx0Y3VycmVudFZpc2libGVDb21taXRWZXJzaW9uOiBvcHRpb25zLnN0YXRlLnZpc2libGVDb21taXRWZXJzaW9uLFxuXHRcdG5leHRSb290TGF5b3V0VHJlZVBhdGg6IG9wdGlvbnMubmV4dFJvb3RMYXlvdXRUcmVlUGF0aCxcblx0XHRzdGFydGVkVmlzaWJsZUNvbW1pdFZlcnNpb246IG9wdGlvbnMuZXZlbnQudG9rZW4uYmFzZVZpc2libGVDb21taXRWZXJzaW9uXG5cdH0pO1xufVxuZnVuY3Rpb24gY2xhc3NpZnlSb290Qm91bmRhcnlUcmFuc2l0aW9uKGN1cnJlbnRSb290Qm91bmRhcnlJZCwgbmV4dFJvb3RCb3VuZGFyeUlkKSB7XG5cdGlmIChjdXJyZW50Um9vdEJvdW5kYXJ5SWQgPT09IG51bGwgfHwgbmV4dFJvb3RCb3VuZGFyeUlkID09PSBudWxsKSByZXR1cm4gXCJyb290Qm91bmRhcnlVbmtub3duXCI7XG5cdHJldHVybiBjdXJyZW50Um9vdEJvdW5kYXJ5SWQgPT09IG5leHRSb290Qm91bmRhcnlJZCA/IFwiY3VycmVudFJvb3RCb3VuZGFyeVwiIDogXCJyb290Qm91bmRhcnlDaGFuZ2VkXCI7XG59XG5mdW5jdGlvbiByZXNvbHZlU2FtZUxheW91dEFuY2VzdG9yUGVyc2lzdGVuY2UoY3VycmVudFNuYXBzaG90LCB0YXJnZXRTbmFwc2hvdCkge1xuXHRyZXR1cm4gcmVzb2x2ZVNhbWVMYXlvdXRBbmNlc3RvclBlcnNpc3RlbmNlRm9yVG9wb2xvZ2llcyhjcmVhdGVTbmFwc2hvdFJvdXRlVG9wb2xvZ3koY3VycmVudFNuYXBzaG90KSwgY3JlYXRlU25hcHNob3RSb3V0ZVRvcG9sb2d5KHRhcmdldFNuYXBzaG90KSk7XG59XG5mdW5jdGlvbiByZXNvbHZlU2FtZUxheW91dEFuY2VzdG9yUGVyc2lzdGVuY2VGb3JUb3BvbG9naWVzKGN1cnJlbnRUb3BvbG9neSwgdGFyZ2V0VG9wb2xvZ3kpIHtcblx0aWYgKGNsYXNzaWZ5Um9vdEJvdW5kYXJ5VHJhbnNpdGlvbihjdXJyZW50VG9wb2xvZ3kucm9vdEJvdW5kYXJ5SWQsIHRhcmdldFRvcG9sb2d5LnJvb3RCb3VuZGFyeUlkKSAhPT0gXCJjdXJyZW50Um9vdEJvdW5kYXJ5XCIpIHJldHVybiBbXTtcblx0Y29uc3QgY29tbW9uTGF5b3V0SWRzID0gW107XG5cdGNvbnN0IG1heExlbmd0aCA9IE1hdGgubWluKGN1cnJlbnRUb3BvbG9neS5sYXlvdXRJZHMubGVuZ3RoLCB0YXJnZXRUb3BvbG9neS5sYXlvdXRJZHMubGVuZ3RoKTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1heExlbmd0aDsgaW5kZXgrKykge1xuXHRcdGNvbnN0IGxheW91dElkID0gY3VycmVudFRvcG9sb2d5LmxheW91dElkc1tpbmRleF07XG5cdFx0aWYgKGxheW91dElkICE9PSB0YXJnZXRUb3BvbG9neS5sYXlvdXRJZHNbaW5kZXhdKSBicmVhaztcblx0XHRjb21tb25MYXlvdXRJZHMucHVzaChsYXlvdXRJZCk7XG5cdH1cblx0cmV0dXJuIGNvbW1vbkxheW91dElkcztcbn1cbmZ1bmN0aW9uIHJlc29sdmVNb3VudGVkUGFyYWxsZWxTbG90UGVyc2lzdGVuY2UoY3VycmVudFNuYXBzaG90LCB0YXJnZXRTbmFwc2hvdCkge1xuXHRyZXR1cm4gcmVzb2x2ZU1vdW50ZWRQYXJhbGxlbFNsb3RQZXJzaXN0ZW5jZUZvckxheW91dHMoY3VycmVudFNuYXBzaG90LCByZXNvbHZlU2FtZUxheW91dEFuY2VzdG9yUGVyc2lzdGVuY2UoY3VycmVudFNuYXBzaG90LCB0YXJnZXRTbmFwc2hvdCkpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZU1vdW50ZWRQYXJhbGxlbFNsb3RQZXJzaXN0ZW5jZUZvckxheW91dHMoY3VycmVudFNuYXBzaG90LCBwcmVzZXJ2ZWRMYXlvdXRJZHMpIHtcblx0aWYgKHByZXNlcnZlZExheW91dElkcy5sZW5ndGggPT09IDApIHJldHVybiBbXTtcblx0Y29uc3QgcHJlc2VydmVkTGF5b3V0SWRTZXQgPSBuZXcgU2V0KHByZXNlcnZlZExheW91dElkcyk7XG5cdGNvbnN0IHByZXNlcnZlZFNsb3RJZHMgPSBbXTtcblx0Y29uc3Qgc2VlblNsb3RJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRmb3IgKGNvbnN0IHNsb3Qgb2YgY3VycmVudFNuYXBzaG90Lm1vdW50ZWRQYXJhbGxlbFNsb3RzKSB7XG5cdFx0aWYgKHNsb3Qub3duZXJMYXlvdXRJZCA9PT0gbnVsbCkgY29udGludWU7XG5cdFx0aWYgKCFwcmVzZXJ2ZWRMYXlvdXRJZFNldC5oYXMoc2xvdC5vd25lckxheW91dElkKSkgY29udGludWU7XG5cdFx0aWYgKHNlZW5TbG90SWRzLmhhcyhzbG90LnNsb3RJZCkpIGNvbnRpbnVlO1xuXHRcdHByZXNlcnZlZFNsb3RJZHMucHVzaChzbG90LnNsb3RJZCk7XG5cdFx0c2VlblNsb3RJZHMuYWRkKHNsb3Quc2xvdElkKTtcblx0fVxuXHRyZXR1cm4gcHJlc2VydmVkU2xvdElkcztcbn1cbmZ1bmN0aW9uIHJlc29sdmVDdXJyZW50Um9vdEJvdW5kYXJ5RWxlbWVudFBlcnNpc3RlbmNlKGN1cnJlbnRTbmFwc2hvdCwgdGFyZ2V0U25hcHNob3QpIHtcblx0Y29uc3QgcHJlc2VydmVkTGF5b3V0SWRzID0gcmVzb2x2ZVNhbWVMYXlvdXRBbmNlc3RvclBlcnNpc3RlbmNlKGN1cnJlbnRTbmFwc2hvdCwgdGFyZ2V0U25hcHNob3QpO1xuXHRyZXR1cm4gWy4uLnByZXNlcnZlZExheW91dElkcywgLi4ucmVzb2x2ZU1vdW50ZWRQYXJhbGxlbFNsb3RQZXJzaXN0ZW5jZUZvckxheW91dHMoY3VycmVudFNuYXBzaG90LCBwcmVzZXJ2ZWRMYXlvdXRJZHMpXTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVDdXJyZW50Um9vdEJvdW5kYXJ5Q29tbWl0RWxlbWVudFBlcnNpc3RlbmNlKG9wdGlvbnMpIHtcblx0cmV0dXJuIHJlc29sdmVTYW1lTGF5b3V0QW5jZXN0b3JQZXJzaXN0ZW5jZUZvclRvcG9sb2dpZXMob3B0aW9ucy5jdXJyZW50VG9wb2xvZ3ksIG9wdGlvbnMudGFyZ2V0VG9wb2xvZ3kpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUN1cnJlbnRSb290Qm91bmRhcnlDb21taXRTbG90UGVyc2lzdGVuY2Uob3B0aW9ucykge1xuXHRpZiAob3B0aW9ucy5sYW5lID09PSBcInRyYXZlcnNlXCIpIHJldHVybiBbXTtcblx0Y29uc3QgcHJlc2VydmVkTGF5b3V0SWRzID0gcmVzb2x2ZVNhbWVMYXlvdXRBbmNlc3RvclBlcnNpc3RlbmNlRm9yVG9wb2xvZ2llcyhvcHRpb25zLmN1cnJlbnRUb3BvbG9neSwgb3B0aW9ucy50YXJnZXRUb3BvbG9neSk7XG5cdGlmIChwcmVzZXJ2ZWRMYXlvdXRJZHMubGVuZ3RoID09PSAwKSByZXR1cm4gW107XG5cdGNvbnN0IGRlZmF1bHRPclVubWF0Y2hlZFNsb3RJZHMgPSByZXNvbHZlRGVmYXVsdE9yVW5tYXRjaGVkU2xvdFBlcnNpc3RlbmNlRm9yTGF5b3V0cyh7XG5cdFx0Y3VycmVudFNsb3RCaW5kaW5nczogb3B0aW9ucy5jdXJyZW50VG9wb2xvZ3kuc2xvdEJpbmRpbmdzLFxuXHRcdHByZXNlcnZlZExheW91dElkcyxcblx0XHR0YXJnZXRTbG90QmluZGluZ3M6IG9wdGlvbnMudGFyZ2V0VG9wb2xvZ3kuc2xvdEJpbmRpbmdzXG5cdH0pO1xuXHRjb25zdCBhYnNlbnRBY3RpdmVTbG90SWRzID0gcmVzb2x2ZUFic2VudEFjdGl2ZVNsb3RQZXJzaXN0ZW5jZUZvckxheW91dHMoe1xuXHRcdGN1cnJlbnRTbG90QmluZGluZ3M6IG9wdGlvbnMuY3VycmVudFRvcG9sb2d5LnNsb3RCaW5kaW5ncyxcblx0XHRwcmVzZXJ2ZWRMYXlvdXRJZHMsXG5cdFx0dGFyZ2V0U2xvdEJpbmRpbmdzOiBvcHRpb25zLnRhcmdldFRvcG9sb2d5LnNsb3RCaW5kaW5nc1xuXHR9KTtcblx0cmV0dXJuIFsuLi4vKiBAX19QVVJFX18gKi8gbmV3IFNldChbLi4uZGVmYXVsdE9yVW5tYXRjaGVkU2xvdElkcywgLi4uYWJzZW50QWN0aXZlU2xvdElkc10pXS5zb3J0KGNvbXBhcmVBcHBFbGVtZW50c1Nsb3RJZHMpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUFic2VudEFjdGl2ZVNsb3RQZXJzaXN0ZW5jZUZvckxheW91dHMob3B0aW9ucykge1xuXHRjb25zdCBwcmVzZXJ2ZWRMYXlvdXRJZFNldCA9IG5ldyBTZXQob3B0aW9ucy5wcmVzZXJ2ZWRMYXlvdXRJZHMpO1xuXHRjb25zdCB0YXJnZXRTbG90SWRzID0gbmV3IFNldChvcHRpb25zLnRhcmdldFNsb3RCaW5kaW5ncy5tYXAoKGJpbmRpbmcpID0+IGJpbmRpbmcuc2xvdElkKSk7XG5cdHJldHVybiBvcHRpb25zLmN1cnJlbnRTbG90QmluZGluZ3MuZmlsdGVyKChiaW5kaW5nKSA9PiB7XG5cdFx0Y29uc3QgcGFyc2VkU2xvdCA9IEFwcEVsZW1lbnRzV2lyZS5wYXJzZUVsZW1lbnRLZXkoYmluZGluZy5zbG90SWQpO1xuXHRcdHJldHVybiBiaW5kaW5nLnN0YXRlID09PSBcImFjdGl2ZVwiICYmIGJpbmRpbmcub3duZXJMYXlvdXRJZCAhPT0gbnVsbCAmJiBwcmVzZXJ2ZWRMYXlvdXRJZFNldC5oYXMoYmluZGluZy5vd25lckxheW91dElkKSAmJiBwYXJzZWRTbG90Py5raW5kID09PSBcInNsb3RcIiAmJiBwYXJzZWRTbG90Lm5hbWUgPT09IFwiY2hpbGRyZW5cIiAmJiAhdGFyZ2V0U2xvdElkcy5oYXMoYmluZGluZy5zbG90SWQpO1xuXHR9KS5tYXAoKGJpbmRpbmcpID0+IGJpbmRpbmcuc2xvdElkKS5zb3J0KGNvbXBhcmVBcHBFbGVtZW50c1Nsb3RJZHMpO1xufVxuLyoqXG4qIERlZmF1bHQvdW5tYXRjaGVkIHNsb3QgcHJlc2VydmF0aW9uIGxhdzpcbipcbiogQSB0YXJnZXQgZGVmYXVsdC91bm1hdGNoZWQgc2xvdCBtYXkgcmV1c2UgcHJldmlvdXMgY29udGVudCBvbmx5IHdoZW46XG4qIC0gdGhlIHNsb3QncyBvd25lciBsYXlvdXQgaXMgcGFydCBvZiB0aGUgcHJlc2VydmVkIGxheW91dCBhbmNlc3RvciBzZXQ7XG4qIC0gdGhlIGN1cnJlbnQgdmlzaWJsZSBzbmFwc2hvdCBwcm92ZXMgdGhlIHNhbWUgc2xvdCBoYWQgcmVuZGVyYWJsZSBjb250ZW50O1xuKiAtIHRoZSBuYXZpZ2F0aW9uIGlzIG5vdCBhIHRyYXZlcnNhbC5cbipcbiogV2lyZSBhYnNlbmNlIGFuZCBVTk1BVENIRURfU0xPVCBtYXJrZXJzIGFyZSBub3Qgc2VtYW50aWMgcHJvb2YuXG4qL1xuZnVuY3Rpb24gcmVzb2x2ZURlZmF1bHRPclVubWF0Y2hlZFNsb3RQZXJzaXN0ZW5jZUZvckxheW91dHMob3B0aW9ucykge1xuXHRjb25zdCBwcmVzZXJ2ZWRMYXlvdXRJZFNldCA9IG5ldyBTZXQob3B0aW9ucy5wcmVzZXJ2ZWRMYXlvdXRJZHMpO1xuXHRjb25zdCBzbG90SWRzV2l0aENvbnRlbnQgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRmb3IgKGNvbnN0IGJpbmRpbmcgb2Ygb3B0aW9ucy5jdXJyZW50U2xvdEJpbmRpbmdzKSB7XG5cdFx0aWYgKGJpbmRpbmcuc3RhdGUgPT09IFwidW5tYXRjaGVkXCIpIGNvbnRpbnVlO1xuXHRcdHNsb3RJZHNXaXRoQ29udGVudC5hZGQoYmluZGluZy5zbG90SWQpO1xuXHR9XG5cdGNvbnN0IHByZXNlcnZlZFNsb3RJZHMgPSBbXTtcblx0Y29uc3Qgc2VlblNsb3RJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRmb3IgKGNvbnN0IGJpbmRpbmcgb2Ygb3B0aW9ucy50YXJnZXRTbG90QmluZGluZ3MpIHtcblx0XHRpZiAoYmluZGluZy5vd25lckxheW91dElkID09PSBudWxsKSBjb250aW51ZTtcblx0XHRpZiAoIXByZXNlcnZlZExheW91dElkU2V0LmhhcyhiaW5kaW5nLm93bmVyTGF5b3V0SWQpKSBjb250aW51ZTtcblx0XHRpZiAoYmluZGluZy5zdGF0ZSA9PT0gXCJhY3RpdmVcIikgY29udGludWU7XG5cdFx0aWYgKCFzbG90SWRzV2l0aENvbnRlbnQuaGFzKGJpbmRpbmcuc2xvdElkKSkgY29udGludWU7XG5cdFx0aWYgKHNlZW5TbG90SWRzLmhhcyhiaW5kaW5nLnNsb3RJZCkpIGNvbnRpbnVlO1xuXHRcdHByZXNlcnZlZFNsb3RJZHMucHVzaChiaW5kaW5nLnNsb3RJZCk7XG5cdFx0c2VlblNsb3RJZHMuYWRkKGJpbmRpbmcuc2xvdElkKTtcblx0fVxuXHRyZXR1cm4gcHJlc2VydmVkU2xvdElkcy5zb3J0KGNvbXBhcmVBcHBFbGVtZW50c1Nsb3RJZHMpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUludGVyY2VwdGVkU291cmNlU2xvdFBlcnNpc3RlbmNlRm9yTGF5b3V0cyhvcHRpb25zKSB7XG5cdGNvbnN0IGN1cnJlbnRCaW5kaW5ncyA9IG5ldyBNYXAob3B0aW9ucy5jdXJyZW50U2xvdEJpbmRpbmdzLm1hcCgoYmluZGluZykgPT4gW2JpbmRpbmcuc2xvdElkLCBiaW5kaW5nXSkpO1xuXHRjb25zdCBwcmVzZXJ2ZWRMYXlvdXRJZFNldCA9IG5ldyBTZXQob3B0aW9ucy5wcmVzZXJ2ZWRMYXlvdXRJZHMpO1xuXHRjb25zdCBwcmVzZXJ2ZWRTbG90SWRzID0gW107XG5cdGZvciAoY29uc3QgdGFyZ2V0QmluZGluZyBvZiBvcHRpb25zLnRhcmdldFNsb3RCaW5kaW5ncykge1xuXHRcdGlmICh0YXJnZXRCaW5kaW5nLnNsb3RJZCA9PT0gb3B0aW9ucy50YXJnZXRJbnRlcmNlcHRpb25TbG90SWQpIGNvbnRpbnVlO1xuXHRcdGlmICh0YXJnZXRCaW5kaW5nLnN0YXRlICE9PSBcImFjdGl2ZVwiIHx8IHRhcmdldEJpbmRpbmcub3duZXJMYXlvdXRJZCA9PT0gbnVsbCkgY29udGludWU7XG5cdFx0aWYgKCFwcmVzZXJ2ZWRMYXlvdXRJZFNldC5oYXModGFyZ2V0QmluZGluZy5vd25lckxheW91dElkKSkgY29udGludWU7XG5cdFx0Y29uc3QgY3VycmVudEJpbmRpbmcgPSBjdXJyZW50QmluZGluZ3MuZ2V0KHRhcmdldEJpbmRpbmcuc2xvdElkKTtcblx0XHRpZiAoY3VycmVudEJpbmRpbmc/LnN0YXRlICE9PSBcImFjdGl2ZVwiKSBjb250aW51ZTtcblx0XHRpZiAoY3VycmVudEJpbmRpbmcub3duZXJMYXlvdXRJZCAhPT0gdGFyZ2V0QmluZGluZy5vd25lckxheW91dElkKSBjb250aW51ZTtcblx0XHRpZiAoY3VycmVudEJpbmRpbmcuYWN0aXZlUm91dGVJZCAmJiB0YXJnZXRCaW5kaW5nLmFjdGl2ZVJvdXRlSWQgJiYgY3VycmVudEJpbmRpbmcuYWN0aXZlUm91dGVJZCAhPT0gdGFyZ2V0QmluZGluZy5hY3RpdmVSb3V0ZUlkKSBjb250aW51ZTtcblx0XHRwcmVzZXJ2ZWRTbG90SWRzLnB1c2godGFyZ2V0QmluZGluZy5zbG90SWQpO1xuXHR9XG5cdHJldHVybiBwcmVzZXJ2ZWRTbG90SWRzLnNvcnQoY29tcGFyZUFwcEVsZW1lbnRzU2xvdElkcyk7XG59XG5mdW5jdGlvbiBnZXRWaXNpYmxlSW50ZXJjZXB0aW9uU291cmNlSWRlbnRpdHkoc25hcHNob3QpIHtcblx0aWYgKHNuYXBzaG90LmludGVyY2VwdGlvbikgcmV0dXJuIHtcblx0XHRtYXRjaGVkVXJsOiBzbmFwc2hvdC5pbnRlcmNlcHRpb24uc291cmNlTWF0Y2hlZFVybCxcblx0XHRyb3V0ZUlkOiBzbmFwc2hvdC5pbnRlcmNlcHRpb24uc291cmNlUm91dGVJZFxuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdG1hdGNoZWRVcmw6IG1hdGNoZWRVcmxGcm9tQ29uY3JldGVSb3V0ZUlkKHNuYXBzaG90LnJvdXRlSWQpID8/IHNuYXBzaG90Lm1hdGNoZWRVcmwsXG5cdFx0cm91dGVJZDogc25hcHNob3Qucm91dGVJZFxuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlSW50ZXJjZXB0aW9uUHJvb2ZSZWplY3RlZERlY2lzaW9uKG9wdGlvbnMpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcImhhcmROYXZpZ2F0ZVwiLFxuXHRcdHJlYXNvbjogXCJpbnRlcmNlcHRpb25Qcm9vZlJlamVjdGVkXCIsXG5cdFx0dG9rZW46IG9wdGlvbnMuZXZlbnQudG9rZW4sXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25UcmFjZShvcHRpb25zLnJlYXNvbkNvZGUsIG9wdGlvbnMudHJhY2VGaWVsZHMpLFxuXHRcdHVybDogb3B0aW9ucy5ldmVudC5yZXN1bHQuaHJlZlxuXHR9O1xufVxuZnVuY3Rpb24gZXZhbHVhdGVDYWNoZUVudHJ5UmV1c2VQcm9vZihwcm9vZikge1xuXHRpZiAocHJvb2YgPT09IHZvaWQgMCkgcmV0dXJuIHtcblx0XHRraW5kOiBcImFjY2VwdGVkXCIsXG5cdFx0ZGVjaXNpb246IG51bGxcblx0fTtcblx0aWYgKHByb29mLmRlY2lzaW9uID09PSBudWxsKSByZXR1cm4ge1xuXHRcdGtpbmQ6IFwicmVqZWN0ZWRcIixcblx0XHRkZWNpc2lvbjogbnVsbFxuXHR9O1xuXHRpZiAocHJvb2YuZGVjaXNpb24uY2FuUmV1c2UpIHJldHVybiB7XG5cdFx0a2luZDogXCJhY2NlcHRlZFwiLFxuXHRcdGRlY2lzaW9uOiBwcm9vZi5kZWNpc2lvblxuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwicmVqZWN0ZWRcIixcblx0XHRkZWNpc2lvbjogcHJvb2YuZGVjaXNpb25cblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUNhY2hlUHJvb2ZSZWplY3RlZFRyYWNlRmllbGRzKHRyYWNlRmllbGRzLCBkZWNpc2lvbikge1xuXHRpZiAoZGVjaXNpb24gPT09IG51bGwpIHJldHVybiB7XG5cdFx0Li4udHJhY2VGaWVsZHMsXG5cdFx0Y2FjaGVQcm9vZkNvZGU6IENBQ0hFX0VOVFJZX1BST09GX01JU1NJTkdfQ09ERVxuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdC4uLnRyYWNlRmllbGRzLFxuXHRcdGNhY2hlUHJvb2ZDb2RlOiBkZWNpc2lvbi5jb2RlLFxuXHRcdGNhY2hlUHJvb2ZNb2RlOiBkZWNpc2lvbi5tb2RlLFxuXHRcdGNhY2hlUHJvb2ZTY29wZTogZGVjaXNpb24uc2NvcGVcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUNhY2hlUHJvb2ZSZWplY3RlZERlY2lzaW9uKG9wdGlvbnMpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kOiBcImhhcmROYXZpZ2F0ZVwiLFxuXHRcdHJlYXNvbjogXCJjYWNoZVByb29mUmVqZWN0ZWRcIixcblx0XHR0b2tlbjogb3B0aW9ucy5ldmVudC50b2tlbixcblx0XHR0cmFjZTogY3JlYXRlTmF2aWdhdGlvblRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLmNhY2hlUHJvb2ZSZWplY3RlZCwgY3JlYXRlQ2FjaGVQcm9vZlJlamVjdGVkVHJhY2VGaWVsZHMob3B0aW9ucy50cmFjZUZpZWxkcywgb3B0aW9ucy5yZWplY3Rpb24uZGVjaXNpb24pKSxcblx0XHR1cmw6IG9wdGlvbnMuZXZlbnQucmVzdWx0LmhyZWZcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUNhY2hlUmV1c2VUb2tlblJlamVjdGVkRGVjaXNpb24ob3B0aW9ucykge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwiaGFyZE5hdmlnYXRlXCIsXG5cdFx0cmVhc29uOiBcImNhY2hlUmV1c2VUb2tlblJlamVjdGVkXCIsXG5cdFx0dG9rZW46IG9wdGlvbnMuZXZlbnQudG9rZW4sXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25UcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5jYWNoZVJldXNlVG9rZW5SZWplY3RlZCwge1xuXHRcdFx0Li4ub3B0aW9ucy50cmFjZUZpZWxkcyxcblx0XHRcdGNhY2hlUmV1c2VUb2tlblJlYXNvbjogb3B0aW9ucy5yZWFzb25cblx0XHR9KSxcblx0XHR1cmw6IG9wdGlvbnMuZXZlbnQucmVzdWx0LmhyZWZcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUFjY2VwdGVkQ2FjaGVQcm9vZlRyYWNlRmllbGRzKHRyYWNlRmllbGRzLCBkZWNpc2lvbikge1xuXHRpZiAoZGVjaXNpb24gPT09IG51bGwpIHJldHVybiB0cmFjZUZpZWxkcztcblx0cmV0dXJuIHtcblx0XHQuLi50cmFjZUZpZWxkcyxcblx0XHRjYWNoZVByb29mQ29kZTogZGVjaXNpb24uY29kZSxcblx0XHRjYWNoZVByb29mUmV1c2VDbGFzczogZGVjaXNpb24ucmV1c2VDbGFzc1xuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlQ2FjaGVFbnRyeVByb3Bvc2FsRmllbGRzKGRlY2lzaW9uKSB7XG5cdGlmIChkZWNpc2lvbiA9PT0gbnVsbCkgcmV0dXJuIHt9O1xuXHRyZXR1cm4geyBjYWNoZUVudHJ5UmV1c2VEZWNpc2lvbjogZGVjaXNpb24gfTtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlSW50ZXJjZXB0ZWRQcmVzZXJ2YXRpb24ob3B0aW9ucykge1xuXHRjb25zdCBwcm9vZiA9IG9wdGlvbnMudGFyZ2V0U25hcHNob3QuaW50ZXJjZXB0aW9uO1xuXHRpZiAoIXByb29mKSByZXR1cm4ge1xuXHRcdGtpbmQ6IFwicmVqZWN0ZWRcIixcblx0XHRyZWFzb25Db2RlOiBOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5pbnRlcmNlcHRlZFJlamVjdGVkTWlzc2luZ1Byb29mXG5cdH07XG5cdGlmIChwcm9vZi50YXJnZXRNYXRjaGVkVXJsICE9PSBvcHRpb25zLnRhcmdldFNuYXBzaG90Lm1hdGNoZWRVcmwpIHJldHVybiB7XG5cdFx0a2luZDogXCJyZWplY3RlZFwiLFxuXHRcdHJlYXNvbkNvZGU6IE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLmludGVyY2VwdGVkUmVqZWN0ZWRUYXJnZXRNaXNtYXRjaFxuXHR9O1xuXHRjb25zdCBzb3VyY2VJZGVudGl0eSA9IGdldFZpc2libGVJbnRlcmNlcHRpb25Tb3VyY2VJZGVudGl0eShvcHRpb25zLmN1cnJlbnRTbmFwc2hvdCk7XG5cdGlmICghb3B0aW9ucy5yZXN0b3JlZEhpc3RvcnlTbmFwc2hvdCAmJiAocHJvb2Yuc291cmNlTWF0Y2hlZFVybCAhPT0gc291cmNlSWRlbnRpdHkubWF0Y2hlZFVybCB8fCBwcm9vZi5zb3VyY2VSb3V0ZUlkICE9PSBzb3VyY2VJZGVudGl0eS5yb3V0ZUlkKSkgcmV0dXJuIHtcblx0XHRraW5kOiBcInJlamVjdGVkXCIsXG5cdFx0cmVhc29uQ29kZTogTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMuaW50ZXJjZXB0ZWRSZWplY3RlZFVua25vd25Tb3VyY2Vcblx0fTtcblx0Y29uc3QgZGVjbGFyZWRJbnRlcmNlcHRpb24gPSBvcHRpb25zLnJvdXRlTWFuaWZlc3QgPT09IG51bGwgPyBudWxsIDogZmluZFJvdXRlTWFuaWZlc3RJbnRlcmNlcHRpb25Gb3JQcm9vZihvcHRpb25zLnJvdXRlTWFuaWZlc3QsIHByb29mKTtcblx0aWYgKG9wdGlvbnMucm91dGVNYW5pZmVzdCAhPT0gbnVsbCAmJiBkZWNsYXJlZEludGVyY2VwdGlvbiA9PT0gbnVsbCkgcmV0dXJuIHtcblx0XHRraW5kOiBcInJlamVjdGVkXCIsXG5cdFx0cmVhc29uQ29kZTogTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMuaW50ZXJjZXB0ZWRSZWplY3RlZFVuZGVjbGFyZWRUb3BvbG9neVxuXHR9O1xuXHRjb25zdCBwcmVzZXJ2ZWRMYXlvdXRJZHMgPSByZXNvbHZlU2FtZUxheW91dEFuY2VzdG9yUGVyc2lzdGVuY2VGb3JUb3BvbG9naWVzKG9wdGlvbnMuY3VycmVudFRvcG9sb2d5LCBvcHRpb25zLnRhcmdldFRvcG9sb2d5KTtcblx0aWYgKHByZXNlcnZlZExheW91dElkcy5sZW5ndGggPT09IDApIHJldHVybiB7XG5cdFx0a2luZDogXCJyZWplY3RlZFwiLFxuXHRcdHJlYXNvbkNvZGU6IE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLmludGVyY2VwdGVkUmVqZWN0ZWRJbmNvbXBhdGlibGVSb290XG5cdH07XG5cdGNvbnN0IHByZXNlcnZlZExheW91dElkU2V0ID0gbmV3IFNldChwcmVzZXJ2ZWRMYXlvdXRJZHMpO1xuXHRjb25zdCB0YXJnZXRTbG90QmluZGluZyA9IG9wdGlvbnMudGFyZ2V0VG9wb2xvZ3kuc2xvdEJpbmRpbmdzLmZpbmQoKGJpbmRpbmcpID0+IGJpbmRpbmcuc2xvdElkID09PSBwcm9vZi5zbG90SWQpO1xuXHRpZiAoIXRhcmdldFNsb3RCaW5kaW5nIHx8IHRhcmdldFNsb3RCaW5kaW5nLnN0YXRlICE9PSBcImFjdGl2ZVwiIHx8IHRhcmdldFNsb3RCaW5kaW5nLm93bmVyTGF5b3V0SWQgPT09IG51bGwgfHwgIXByZXNlcnZlZExheW91dElkU2V0Lmhhcyh0YXJnZXRTbG90QmluZGluZy5vd25lckxheW91dElkKSkgcmV0dXJuIHtcblx0XHRraW5kOiBcInJlamVjdGVkXCIsXG5cdFx0cmVhc29uQ29kZTogTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMuaW50ZXJjZXB0ZWRSZWplY3RlZE1pc3NpbmdTbG90UHJvb2Zcblx0fTtcblx0aWYgKGRlY2xhcmVkSW50ZXJjZXB0aW9uICE9PSBudWxsICYmIHRhcmdldFNsb3RCaW5kaW5nLm93bmVyTGF5b3V0SWQgIT09IGRlY2xhcmVkSW50ZXJjZXB0aW9uLm93bmVyTGF5b3V0SWQpIHJldHVybiB7XG5cdFx0a2luZDogXCJyZWplY3RlZFwiLFxuXHRcdHJlYXNvbkNvZGU6IE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLmludGVyY2VwdGVkUmVqZWN0ZWRVbmRlY2xhcmVkVG9wb2xvZ3lcblx0fTtcblx0Y29uc3QgcHJlc2VydmVEZWZhdWx0T3JVbm1hdGNoZWRTbG90SWRzID0gcmVzb2x2ZURlZmF1bHRPclVubWF0Y2hlZFNsb3RQZXJzaXN0ZW5jZUZvckxheW91dHMoe1xuXHRcdGN1cnJlbnRTbG90QmluZGluZ3M6IG9wdGlvbnMuY3VycmVudFRvcG9sb2d5LnNsb3RCaW5kaW5ncyxcblx0XHRwcmVzZXJ2ZWRMYXlvdXRJZHMsXG5cdFx0dGFyZ2V0U2xvdEJpbmRpbmdzOiBvcHRpb25zLnRhcmdldFRvcG9sb2d5LnNsb3RCaW5kaW5nc1xuXHR9KS5maWx0ZXIoKHNsb3RJZCkgPT4gc2xvdElkICE9PSBwcm9vZi5zbG90SWQpO1xuXHRjb25zdCBwcmVzZXJ2ZVNvdXJjZVNsb3RJZHMgPSBvcHRpb25zLmxhbmUgPT09IFwibmF2aWdhdGlvblwiID8gcmVzb2x2ZUludGVyY2VwdGVkU291cmNlU2xvdFBlcnNpc3RlbmNlRm9yTGF5b3V0cyh7XG5cdFx0Y3VycmVudFNsb3RCaW5kaW5nczogb3B0aW9ucy5jdXJyZW50VG9wb2xvZ3kuc2xvdEJpbmRpbmdzLFxuXHRcdHByZXNlcnZlZExheW91dElkcyxcblx0XHR0YXJnZXRJbnRlcmNlcHRpb25TbG90SWQ6IHByb29mLnNsb3RJZCxcblx0XHR0YXJnZXRTbG90QmluZGluZ3M6IG9wdGlvbnMudGFyZ2V0VG9wb2xvZ3kuc2xvdEJpbmRpbmdzXG5cdH0pIDogW107XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJhcHByb3ZlZFwiLFxuXHRcdHByZXNlcnZlRWxlbWVudElkczogcHJlc2VydmVkTGF5b3V0SWRzLFxuXHRcdHByZXNlcnZlUHJldmlvdXNTbG90SWRzOiBbLi4uLyogQF9fUFVSRV9fICovIG5ldyBTZXQoWy4uLnByZXNlcnZlRGVmYXVsdE9yVW5tYXRjaGVkU2xvdElkcywgLi4ucHJlc2VydmVTb3VyY2VTbG90SWRzXSldLnNvcnQoY29tcGFyZUFwcEVsZW1lbnRzU2xvdElkcylcblx0fTtcbn1cbmZ1bmN0aW9uIHBsYW5GbGlnaHRSZXNwb25zZUFycml2ZWQob3B0aW9ucykge1xuXHRjb25zdCB0YXJnZXRTbmFwc2hvdCA9IG9wdGlvbnMuZXZlbnQucmVzdWx0LnRhcmdldFNuYXBzaG90O1xuXHRjb25zdCBjdXJyZW50VG9wb2xvZ3kgPSByZXNvbHZlUm91dGVUb3BvbG9neVNuYXBzaG90KHtcblx0XHRyb3V0ZU1hbmlmZXN0OiBvcHRpb25zLnJvdXRlTWFuaWZlc3QsXG5cdFx0c2xvdEJpbmRpbmdTb3VyY2U6IFwic25hcHNob3RcIixcblx0XHRzbmFwc2hvdDogb3B0aW9ucy5zdGF0ZS52aXNpYmxlU25hcHNob3Rcblx0fSk7XG5cdGNvbnN0IHRhcmdldFRvcG9sb2d5ID0gcmVzb2x2ZVJvdXRlVG9wb2xvZ3lTbmFwc2hvdCh7XG5cdFx0cm91dGVNYW5pZmVzdDogb3B0aW9ucy5yb3V0ZU1hbmlmZXN0LFxuXHRcdHNsb3RCaW5kaW5nU291cmNlOiBcIm1hbmlmZXN0VGFyZ2V0XCIsXG5cdFx0c25hcHNob3Q6IHRhcmdldFNuYXBzaG90XG5cdH0pO1xuXHRjb25zdCB0cmFjZUZpZWxkcyA9IGNyZWF0ZVJvb3RCb3VuZGFyeVRyYWNlRmllbGRzKHtcblx0XHRjdXJyZW50Um9vdExheW91dFRyZWVQYXRoOiBjdXJyZW50VG9wb2xvZ3kua2luZCA9PT0gXCJrbm93blwiID8gY3VycmVudFRvcG9sb2d5LnRvcG9sb2d5LnJvb3RMYXlvdXRUcmVlUGF0aCA6IG51bGwsXG5cdFx0ZXZlbnQ6IG9wdGlvbnMuZXZlbnQsXG5cdFx0bmV4dFJvb3RMYXlvdXRUcmVlUGF0aDogdGFyZ2V0VG9wb2xvZ3kua2luZCA9PT0gXCJrbm93blwiID8gdGFyZ2V0VG9wb2xvZ3kudG9wb2xvZ3kucm9vdExheW91dFRyZWVQYXRoIDogbnVsbCxcblx0XHRzdGF0ZTogb3B0aW9ucy5zdGF0ZVxuXHR9KTtcblx0aWYgKG9wdGlvbnMuZXZlbnQudG9rZW4ubGFuZSA9PT0gXCJwcmVmZXRjaFwiKSByZXR1cm4ge1xuXHRcdGtpbmQ6IFwibm9Db21taXRcIixcblx0XHRyZWFzb246IFwicHJlZmV0Y2hPbmx5XCIsXG5cdFx0dG9rZW46IG9wdGlvbnMuZXZlbnQudG9rZW4sXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25UcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5wcmVmZXRjaE9ubHksIHRyYWNlRmllbGRzKVxuXHR9O1xuXHRjb25zdCBjYWNoZUVudHJ5UHJvb2ZFdmFsdWF0aW9uID0gZXZhbHVhdGVDYWNoZUVudHJ5UmV1c2VQcm9vZihvcHRpb25zLmV2ZW50LnJlc3VsdC5jYWNoZUVudHJ5UmV1c2VQcm9vZik7XG5cdGlmIChjYWNoZUVudHJ5UHJvb2ZFdmFsdWF0aW9uLmtpbmQgPT09IFwicmVqZWN0ZWRcIikgcmV0dXJuIGNyZWF0ZUNhY2hlUHJvb2ZSZWplY3RlZERlY2lzaW9uKHtcblx0XHRldmVudDogb3B0aW9ucy5ldmVudCxcblx0XHRyZWplY3Rpb246IGNhY2hlRW50cnlQcm9vZkV2YWx1YXRpb24sXG5cdFx0dHJhY2VGaWVsZHNcblx0fSk7XG5cdGNvbnN0IGFjY2VwdGVkQ2FjaGVFbnRyeURlY2lzaW9uID0gY2FjaGVFbnRyeVByb29mRXZhbHVhdGlvbi5kZWNpc2lvbjtcblx0aWYgKGFjY2VwdGVkQ2FjaGVFbnRyeURlY2lzaW9uICE9PSBudWxsKSB7XG5cdFx0Y29uc3QgcmV1c2VWZXJkaWN0ID0gdmVyaWZ5T3BlcmF0aW9uVG9rZW5Gb3JDYWNoZVJldXNlKG9wdGlvbnMuZXZlbnQudG9rZW4sIHtcblx0XHRcdGdyYXBoVmVyc2lvbjogb3B0aW9ucy5yb3V0ZU1hbmlmZXN0Py5ncmFwaFZlcnNpb24gPz8gbnVsbCxcblx0XHRcdGluc3RhbGxlZENhY2hlVmFyaWFudEZpbmdlcnByaW50OiBudWxsXG5cdFx0fSk7XG5cdFx0aWYgKCFyZXVzZVZlcmRpY3QuYXV0aG9yaXplZCkgcmV0dXJuIGNyZWF0ZUNhY2hlUmV1c2VUb2tlblJlamVjdGVkRGVjaXNpb24oe1xuXHRcdFx0ZXZlbnQ6IG9wdGlvbnMuZXZlbnQsXG5cdFx0XHRyZWFzb246IHJldXNlVmVyZGljdC5yZWFzb24sXG5cdFx0XHR0cmFjZUZpZWxkc1xuXHRcdH0pO1xuXHR9XG5cdGNvbnN0IGNvbW1pdFRyYWNlRmllbGRzID0gY3JlYXRlQWNjZXB0ZWRDYWNoZVByb29mVHJhY2VGaWVsZHModHJhY2VGaWVsZHMsIGFjY2VwdGVkQ2FjaGVFbnRyeURlY2lzaW9uKTtcblx0Y29uc3QgY2FjaGVFbnRyeVByb3Bvc2FsRmllbGRzID0gY3JlYXRlQ2FjaGVFbnRyeVByb3Bvc2FsRmllbGRzKGFjY2VwdGVkQ2FjaGVFbnRyeURlY2lzaW9uKTtcblx0aWYgKHRhcmdldFNuYXBzaG90LmludGVyY2VwdGlvbiAhPT0gbnVsbCkge1xuXHRcdGlmIChjdXJyZW50VG9wb2xvZ3kua2luZCA9PT0gXCJ1bmtub3duXCIgfHwgdGFyZ2V0VG9wb2xvZ3kua2luZCA9PT0gXCJ1bmtub3duXCIpIHJldHVybiBjcmVhdGVJbnRlcmNlcHRpb25Qcm9vZlJlamVjdGVkRGVjaXNpb24oe1xuXHRcdFx0ZXZlbnQ6IG9wdGlvbnMuZXZlbnQsXG5cdFx0XHRyZWFzb25Db2RlOiBOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5pbnRlcmNlcHRlZFJlamVjdGVkVW5kZWNsYXJlZFRvcG9sb2d5LFxuXHRcdFx0dHJhY2VGaWVsZHM6IGNvbW1pdFRyYWNlRmllbGRzXG5cdFx0fSk7XG5cdFx0Y29uc3QgdmFsaWRhdGlvbiA9IHZhbGlkYXRlSW50ZXJjZXB0ZWRQcmVzZXJ2YXRpb24oe1xuXHRcdFx0Y3VycmVudFNuYXBzaG90OiBvcHRpb25zLnN0YXRlLnZpc2libGVTbmFwc2hvdCxcblx0XHRcdGN1cnJlbnRUb3BvbG9neTogY3VycmVudFRvcG9sb2d5LnRvcG9sb2d5LFxuXHRcdFx0bGFuZTogb3B0aW9ucy5ldmVudC50b2tlbi5sYW5lLFxuXHRcdFx0cmVzdG9yZWRIaXN0b3J5U25hcHNob3Q6IG9wdGlvbnMuZXZlbnQucmVzdWx0LnJlc3RvcmVkSGlzdG9yeVNuYXBzaG90ID09PSB0cnVlLFxuXHRcdFx0cm91dGVNYW5pZmVzdDogb3B0aW9ucy5yb3V0ZU1hbmlmZXN0LFxuXHRcdFx0dGFyZ2V0U25hcHNob3QsXG5cdFx0XHR0YXJnZXRUb3BvbG9neTogdGFyZ2V0VG9wb2xvZ3kudG9wb2xvZ3lcblx0XHR9KTtcblx0XHRpZiAodmFsaWRhdGlvbi5raW5kID09PSBcInJlamVjdGVkXCIpIHJldHVybiBjcmVhdGVJbnRlcmNlcHRpb25Qcm9vZlJlamVjdGVkRGVjaXNpb24oe1xuXHRcdFx0ZXZlbnQ6IG9wdGlvbnMuZXZlbnQsXG5cdFx0XHRyZWFzb25Db2RlOiB2YWxpZGF0aW9uLnJlYXNvbkNvZGUsXG5cdFx0XHR0cmFjZUZpZWxkczogY29tbWl0VHJhY2VGaWVsZHNcblx0XHR9KTtcblx0XHRyZXR1cm4ge1xuXHRcdFx0a2luZDogXCJwcm9wb3NlQ29tbWl0XCIsXG5cdFx0XHRwcm9wb3NhbDoge1xuXHRcdFx0XHQuLi5jYWNoZUVudHJ5UHJvcG9zYWxGaWVsZHMsXG5cdFx0XHRcdHByZXNlcnZlQWJzZW50U2xvdHM6IGZhbHNlLFxuXHRcdFx0XHRwcmVzZXJ2ZUVsZW1lbnRJZHM6IHZhbGlkYXRpb24ucHJlc2VydmVFbGVtZW50SWRzLFxuXHRcdFx0XHRwcmVzZXJ2ZVByZXZpb3VzU2xvdElkczogdmFsaWRhdGlvbi5wcmVzZXJ2ZVByZXZpb3VzU2xvdElkcyxcblx0XHRcdFx0cmVhc29uOiBcImludGVyY2VwdGVkQ3VycmVudFJvb3RCb3VuZGFyeVwiLFxuXHRcdFx0XHR0YXJnZXRTbmFwc2hvdFxuXHRcdFx0fSxcblx0XHRcdHRva2VuOiBvcHRpb25zLmV2ZW50LnRva2VuLFxuXHRcdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25UcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5pbnRlcmNlcHRlZENvbW1pdEN1cnJlbnQsIGNvbW1pdFRyYWNlRmllbGRzKVxuXHRcdH07XG5cdH1cblx0Y29uc3QgdHJhbnNpdGlvbiA9IGN1cnJlbnRUb3BvbG9neS5raW5kID09PSBcInVua25vd25cIiB8fCB0YXJnZXRUb3BvbG9neS5raW5kID09PSBcInVua25vd25cIiA/IFwicm9vdEJvdW5kYXJ5VW5rbm93blwiIDogY2xhc3NpZnlSb290Qm91bmRhcnlUcmFuc2l0aW9uKGN1cnJlbnRUb3BvbG9neS50b3BvbG9neS5yb290Qm91bmRhcnlJZCwgdGFyZ2V0VG9wb2xvZ3kudG9wb2xvZ3kucm9vdEJvdW5kYXJ5SWQpO1xuXHRpZiAodHJhbnNpdGlvbiA9PT0gXCJyb290Qm91bmRhcnlDaGFuZ2VkXCIpIHJldHVybiB7XG5cdFx0a2luZDogXCJoYXJkTmF2aWdhdGVcIixcblx0XHRyZWFzb246IFwicm9vdEJvdW5kYXJ5Q2hhbmdlZFwiLFxuXHRcdHRva2VuOiBvcHRpb25zLmV2ZW50LnRva2VuLFxuXHRcdHRyYWNlOiBjcmVhdGVOYXZpZ2F0aW9uVHJhY2UoTmF2aWdhdGlvblRyYWNlUmVhc29uQ29kZXMucm9vdEJvdW5kYXJ5Q2hhbmdlZCwgY29tbWl0VHJhY2VGaWVsZHMpLFxuXHRcdHVybDogb3B0aW9ucy5ldmVudC5yZXN1bHQuaHJlZlxuXHR9O1xuXHRpZiAodHJhbnNpdGlvbiA9PT0gXCJyb290Qm91bmRhcnlVbmtub3duXCIpIHJldHVybiB7XG5cdFx0a2luZDogXCJwcm9wb3NlQ29tbWl0XCIsXG5cdFx0cHJvcG9zYWw6IHtcblx0XHRcdC4uLmNhY2hlRW50cnlQcm9wb3NhbEZpZWxkcyxcblx0XHRcdHByZXNlcnZlQWJzZW50U2xvdHM6IGZhbHNlLFxuXHRcdFx0cHJlc2VydmVFbGVtZW50SWRzOiBbXSxcblx0XHRcdHByZXNlcnZlUHJldmlvdXNTbG90SWRzOiBbXSxcblx0XHRcdHJlYXNvbjogXCJ1bnByb3ZlblRvcG9sb2d5RmFsbGJhY2tcIixcblx0XHRcdHRhcmdldFNuYXBzaG90XG5cdFx0fSxcblx0XHR0b2tlbjogb3B0aW9ucy5ldmVudC50b2tlbixcblx0XHR0cmFjZTogY3JlYXRlTmF2aWdhdGlvblRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnJvb3RCb3VuZGFyeVVua25vd24sIGNvbW1pdFRyYWNlRmllbGRzKVxuXHR9O1xuXHRpZiAoY3VycmVudFRvcG9sb2d5LmtpbmQgIT09IFwia25vd25cIiB8fCB0YXJnZXRUb3BvbG9neS5raW5kICE9PSBcImtub3duXCIpIHRocm93IG5ldyBFcnJvcihcIlt2aW5leHRdIEN1cnJlbnQtcm9vdCBuYXZpZ2F0aW9uIHBsYW5uaW5nIHJlcXVpcmVzIG1hbmlmZXN0IHRvcG9sb2d5XCIpO1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQ6IFwicHJvcG9zZUNvbW1pdFwiLFxuXHRcdHByb3Bvc2FsOiB7XG5cdFx0XHQuLi5jYWNoZUVudHJ5UHJvcG9zYWxGaWVsZHMsXG5cdFx0XHRwcmVzZXJ2ZUFic2VudFNsb3RzOiBmYWxzZSxcblx0XHRcdHByZXNlcnZlRWxlbWVudElkczogcmVzb2x2ZUN1cnJlbnRSb290Qm91bmRhcnlDb21taXRFbGVtZW50UGVyc2lzdGVuY2Uoe1xuXHRcdFx0XHRjdXJyZW50VG9wb2xvZ3k6IGN1cnJlbnRUb3BvbG9neS50b3BvbG9neSxcblx0XHRcdFx0bGFuZTogb3B0aW9ucy5ldmVudC50b2tlbi5sYW5lLFxuXHRcdFx0XHR0YXJnZXRUb3BvbG9neTogdGFyZ2V0VG9wb2xvZ3kudG9wb2xvZ3lcblx0XHRcdH0pLFxuXHRcdFx0cHJlc2VydmVQcmV2aW91c1Nsb3RJZHM6IHJlc29sdmVDdXJyZW50Um9vdEJvdW5kYXJ5Q29tbWl0U2xvdFBlcnNpc3RlbmNlKHtcblx0XHRcdFx0Y3VycmVudFRvcG9sb2d5OiBjdXJyZW50VG9wb2xvZ3kudG9wb2xvZ3ksXG5cdFx0XHRcdGxhbmU6IG9wdGlvbnMuZXZlbnQudG9rZW4ubGFuZSxcblx0XHRcdFx0dGFyZ2V0VG9wb2xvZ3k6IHRhcmdldFRvcG9sb2d5LnRvcG9sb2d5XG5cdFx0XHR9KSxcblx0XHRcdHJlYXNvbjogXCJjdXJyZW50Um9vdEJvdW5kYXJ5XCIsXG5cdFx0XHR0YXJnZXRTbmFwc2hvdFxuXHRcdH0sXG5cdFx0dG9rZW46IG9wdGlvbnMuZXZlbnQudG9rZW4sXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25UcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5jb21taXRDdXJyZW50LCBjb21taXRUcmFjZUZpZWxkcylcblx0fTtcbn1cbmZ1bmN0aW9uIHBsYW5OYXZpZ2F0aW9uKGlucHV0KSB7XG5cdHN3aXRjaCAoaW5wdXQuZXZlbnQua2luZCkge1xuXHRcdGNhc2UgXCJuYXZpZ2F0ZVwiOiByZXR1cm4gY3JlYXRlUmVxdWVzdFdvcmtEZWNpc2lvbih7XG5cdFx0XHRldmVudEtpbmQ6IGlucHV0LmV2ZW50LmtpbmQsXG5cdFx0XHRzdGF0ZTogaW5wdXQuc3RhdGUsXG5cdFx0XHR3b3JrOiB7XG5cdFx0XHRcdGhyZWY6IGlucHV0LmV2ZW50LmhyZWYsXG5cdFx0XHRcdGtpbmQ6IFwiZmxpZ2h0XCIsXG5cdFx0XHRcdG1vZGU6IGlucHV0LmV2ZW50Lm1vZGVcblx0XHRcdH1cblx0XHR9KTtcblx0XHRjYXNlIFwicmVmcmVzaFwiOiByZXR1cm4gY3JlYXRlUmVxdWVzdFdvcmtEZWNpc2lvbih7XG5cdFx0XHRldmVudEtpbmQ6IGlucHV0LmV2ZW50LmtpbmQsXG5cdFx0XHRzdGF0ZTogaW5wdXQuc3RhdGUsXG5cdFx0XHR3b3JrOiB7XG5cdFx0XHRcdGhyZWY6IGlucHV0LnN0YXRlLnZpc2libGVTbmFwc2hvdC5kaXNwbGF5VXJsLFxuXHRcdFx0XHRraW5kOiBcImZsaWdodFwiLFxuXHRcdFx0XHRtb2RlOiBcInJlZnJlc2hcIlxuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGNhc2UgXCJ0cmF2ZXJzZVwiOiByZXR1cm4gY3JlYXRlUmVxdWVzdFdvcmtEZWNpc2lvbih7XG5cdFx0XHRldmVudEtpbmQ6IGlucHV0LmV2ZW50LmtpbmQsXG5cdFx0XHRzdGF0ZTogaW5wdXQuc3RhdGUsXG5cdFx0XHR3b3JrOiB7XG5cdFx0XHRcdGRpcmVjdGlvbjogaW5wdXQuZXZlbnQuZGlyZWN0aW9uLFxuXHRcdFx0XHRoaXN0b3J5U3RhdGU6IGlucHV0LmV2ZW50Lmhpc3RvcnlTdGF0ZSxcblx0XHRcdFx0a2luZDogXCJ0cmF2ZXJzZUZsaWdodFwiXG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0Y2FzZSBcInByZWZldGNoXCI6IHJldHVybiBjcmVhdGVSZXF1ZXN0V29ya0RlY2lzaW9uKHtcblx0XHRcdGV2ZW50S2luZDogaW5wdXQuZXZlbnQua2luZCxcblx0XHRcdHN0YXRlOiBpbnB1dC5zdGF0ZSxcblx0XHRcdHdvcms6IHtcblx0XHRcdFx0aHJlZjogaW5wdXQuZXZlbnQuaHJlZixcblx0XHRcdFx0a2luZDogXCJwcmVmZXRjaFwiXG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0Y2FzZSBcImZsaWdodFJlc3BvbnNlQXJyaXZlZFwiOiByZXR1cm4gcGxhbkZsaWdodFJlc3BvbnNlQXJyaXZlZCh7XG5cdFx0XHRldmVudDogaW5wdXQuZXZlbnQsXG5cdFx0XHRyb3V0ZU1hbmlmZXN0OiBpbnB1dC5yb3V0ZU1hbmlmZXN0LFxuXHRcdFx0c3RhdGU6IGlucHV0LnN0YXRlXG5cdFx0fSk7XG5cdFx0ZGVmYXVsdDoge1xuXHRcdFx0Y29uc3QgX2V4aGF1c3RpdmUgPSBpbnB1dC5ldmVudDtcblx0XHRcdHRocm93IG5ldyBFcnJvcihcIlt2aW5leHRdIFVua25vd24gbmF2aWdhdGlvbiBldmVudDogXCIgKyBTdHJpbmcoX2V4aGF1c3RpdmUpKTtcblx0XHR9XG5cdH1cbn1cbmZ1bmN0aW9uIGNsYXNzaWZ5U2VydmVyQWN0aW9uUmVzdWx0KGZhY3RzKSB7XG5cdGlmIChmYWN0cy5jbGllbnRDb21wYXRpYmlsaXR5SWQgPT09IG51bGwpIHJldHVybiB7XG5cdFx0a2luZDogXCJwcm9jZWVkXCIsXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25UcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5wcm9jZWVkVG9Db21taXQsIHt9KVxuXHR9O1xuXHRpZiAoIWZhY3RzLmlzUnNjQ29udGVudFR5cGUpIHJldHVybiB7XG5cdFx0a2luZDogXCJwcm9jZWVkXCIsXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25UcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5wcm9jZWVkVG9Db21taXQsIHt9KVxuXHR9O1xuXHRpZiAocmVzb2x2ZVJzY0NvbXBhdGliaWxpdHlOYXZpZ2F0aW9uRGVjaXNpb24oe1xuXHRcdGNsaWVudENvbXBhdGliaWxpdHlJZDogZmFjdHMuY2xpZW50Q29tcGF0aWJpbGl0eUlkLFxuXHRcdGN1cnJlbnRIcmVmOiBmYWN0cy5jdXJyZW50SHJlZixcblx0XHRvcmlnaW46IGZhY3RzLm9yaWdpbixcblx0XHRyZXNwb25zZUNvbXBhdGliaWxpdHlJZDogZmFjdHMuY29tcGF0aWJpbGl0eUlkSGVhZGVyLFxuXHRcdHJlc3BvbnNlVXJsOiBmYWN0cy5yZXNwb25zZVVybFxuXHR9KS5raW5kID09PSBcImNvbXBhdGlibGVcIikgcmV0dXJuIHtcblx0XHRraW5kOiBcInByb2NlZWRcIixcblx0XHR0cmFjZTogY3JlYXRlTmF2aWdhdGlvblRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnByb2NlZWRUb0NvbW1pdCwge30pXG5cdH07XG5cdGlmIChmYWN0cy5hY3Rpb25SZWRpcmVjdEhyZWYgIT09IG51bGwpIHJldHVybiB7XG5cdFx0a2luZDogXCJoYXJkTmF2aWdhdGVcIixcblx0XHR1cmw6IGZhY3RzLmFjdGlvblJlZGlyZWN0SHJlZixcblx0XHRoaXN0b3J5TW9kZTogZmFjdHMuYWN0aW9uUmVkaXJlY3RUeXBlID09PSBcInB1c2hcIiA/IFwiYXNzaWduXCIgOiBcInJlcGxhY2VcIixcblx0XHRjbGVhckNsaWVudE5hdmlnYXRpb25DYWNoZXM6IHRydWUsXG5cdFx0cmVhc29uOiBcInNlcnZlckFjdGlvblJlZGlyZWN0Q29tcGF0aWJpbGl0eU1pc21hdGNoXCIsXG5cdFx0dHJhY2U6IGNyZWF0ZU5hdmlnYXRpb25UcmFjZShOYXZpZ2F0aW9uVHJhY2VSZWFzb25Db2Rlcy5zZXJ2ZXJBY3Rpb25SZWRpcmVjdENvbXBhdGliaWxpdHlNaXNtYXRjaCwgeyB0YXJnZXRIcmVmOiBmYWN0cy5hY3Rpb25SZWRpcmVjdEhyZWYgfSlcblx0fTtcblx0Y29uc3QgdGFyZ2V0VXJsID0gZmFjdHMuY3VycmVudEhyZWY7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJoYXJkTmF2aWdhdGVcIixcblx0XHR1cmw6IHRhcmdldFVybCxcblx0XHRjbGVhckNsaWVudE5hdmlnYXRpb25DYWNoZXM6IGZhbHNlLFxuXHRcdHJlYXNvbjogXCJzZXJ2ZXJBY3Rpb25Sc2NDb21wYXRpYmlsaXR5TWlzbWF0Y2hcIixcblx0XHR0cmFjZTogY3JlYXRlTmF2aWdhdGlvblRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnNlcnZlckFjdGlvblJzY0NvbXBhdGliaWxpdHlNaXNtYXRjaCwgeyB0YXJnZXRIcmVmOiB0YXJnZXRVcmwgfSlcblx0fTtcbn1cbmZ1bmN0aW9uIGNsYXNzaWZ5UnNjTmF2aWdhdGlvbkVycm9yKGZhY3RzKSB7XG5cdHJldHVybiB7XG5cdFx0a2luZDogXCJoYXJkTmF2aWdhdGVcIixcblx0XHR1cmw6IGZhY3RzLmN1cnJlbnRIcmVmLFxuXHRcdHJlYXNvbjogXCJyc2NOYXZpZ2F0aW9uRXJyb3JcIixcblx0XHR0cmFjZTogY3JlYXRlTmF2aWdhdGlvblRyYWNlKE5hdmlnYXRpb25UcmFjZVJlYXNvbkNvZGVzLnJzY05hdmlnYXRpb25FcnJvciwgeyB0YXJnZXRIcmVmOiBmYWN0cy5jdXJyZW50SHJlZiB9KVxuXHR9O1xufVxuY29uc3QgbmF2aWdhdGlvblBsYW5uZXIgPSB7XG5cdGNsYXNzaWZ5RWFybHlOYXZpZ2F0aW9uSW50ZW50LFxuXHRjbGFzc2lmeU5hdmlnYXRpb25QcmVmZXRjaFByb2JlLFxuXHRjbGFzc2lmeU5hdmlnYXRpb25SZXVzZSxcblx0Y2xhc3NpZnlSc2NGZXRjaFJlc3VsdCxcblx0Y2xhc3NpZnlSc2NOYXZpZ2F0aW9uRXJyb3IsXG5cdGNsYXNzaWZ5Um9vdEJvdW5kYXJ5VHJhbnNpdGlvbixcblx0Y2xhc3NpZnlTZXJ2ZXJBY3Rpb25SZXN1bHQsXG5cdGNsYXNzaWZ5VmlzaXRlZFJlc3BvbnNlQ2FjaGVDYW5kaWRhdGUsXG5cdHBsYW46IHBsYW5OYXZpZ2F0aW9uLFxuXHRyZXNvbHZlQ3VycmVudFJvb3RCb3VuZGFyeUVsZW1lbnRQZXJzaXN0ZW5jZSxcblx0cmVzb2x2ZU1vdW50ZWRQYXJhbGxlbFNsb3RQZXJzaXN0ZW5jZSxcblx0cmVzb2x2ZVNhbWVMYXlvdXRBbmNlc3RvclBlcnNpc3RlbmNlXG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBuYXZpZ2F0aW9uUGxhbm5lciwgcmVzb2x2ZURlZmF1bHRPclVubWF0Y2hlZFNsb3RQZXJzaXN0ZW5jZUZvckxheW91dHMgfTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN2RixNQUFNLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEcsTUFBTSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsNENBQTRDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDeEssTUFBTSxDQUFDLENBQUMsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDLHlDQUF5QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDNUssTUFBTSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDN0gsTUFBTSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNwRSxNQUFNLENBQUMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLENBQUMsc0NBQXNDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNoSyxNQUFNLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsb0NBQW9DLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN6SyxNQUFNLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7QUFDeEMsUUFBUSxDQUFDLDJCQUEyQixDQUFDLGNBQWMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ25FLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakY7QUFDQSxLQUFLLENBQUMsb0NBQW9DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDO0FBQ3JFLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM1QyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkgsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0JBQWtCO0FBQ3pDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSTtBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMscUJBQXFCLENBQUMsMEJBQTBCLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDdkUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsMEJBQTBCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSTtBQUNuQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNwQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pGLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQywrQkFBK0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTTtBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQywwQ0FBMEMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3RCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVztBQUNsQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU07QUFDeEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pGLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsYUFBYTtBQUM3QyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNmLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLDBDQUEwQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzdELENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXO0FBQ2xDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUN4QixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVE7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixDQUFDLDBCQUEwQixDQUFDLGNBQWMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN6SCxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLGFBQWE7QUFDaEQsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWM7QUFDekMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsNEJBQTRCLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDOUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsMEJBQTBCLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsMEJBQTBCLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM5RixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLDBDQUEwQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUM1RyxDQUFDLENBQUMsTUFBTSxDQUFDLDBDQUEwQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUs7QUFDckIsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNSLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsMEJBQTBCLENBQUMsaUJBQWlCO0FBQzNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMseUNBQXlDLENBQUM7QUFDekUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsS0FBSyxDQUFDLHFCQUFxQjtBQUNwRCxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVc7QUFDaEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNO0FBQ3RCLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxxQkFBcUI7QUFDdEQsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsMENBQTBDLENBQUM7QUFDdkcsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUs7QUFDcEIsQ0FBQyxDQUFDLEtBQUs7QUFDUCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQztBQUNwQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsMEJBQTBCLENBQUMsd0JBQXdCO0FBQ2pFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDO0FBQzFELENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsS0FBSyxDQUFDLDBCQUEwQjtBQUN0RCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTTtBQUN2QixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYTtBQUNyQyxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxzQkFBc0I7QUFDdkQsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDNUQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsNEJBQTRCLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDO0FBQy9FLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQywwQ0FBMEMsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUs7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxjQUFjLENBQUMsb0JBQW9CO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsY0FBYyxDQUFDLGVBQWU7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQywwQ0FBMEMsQ0FBQztBQUM1RixDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDUixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSTtBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsS0FBSyxDQUFDLDBCQUEwQjtBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLGVBQWU7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDO0FBQ3ZILENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLHNDQUFzQyxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsbUJBQW1CO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsS0FBSyxDQUFDLHNCQUFzQjtBQUN2RCxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQztBQUMvRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsMENBQTBDLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsY0FBYyxDQUFDLG9CQUFvQjtBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxlQUFlO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzdFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsMENBQTBDLENBQUM7QUFDNUYsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSTtBQUNwQixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1IsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLElBQUk7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLG1CQUFtQjtBQUMxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLGVBQWU7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTTtBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLE1BQU0sQ0FBQywwQ0FBMEMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDUixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLG9CQUFvQjtBQUM5RCxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLO0FBQ3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUN6QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMscUJBQXFCLENBQUMsMEJBQTBCLENBQUMsZUFBZSxDQUFDLENBQUMsK0JBQStCLENBQUMsS0FBSyxDQUFDO0FBQ2pILENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLGdDQUFnQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdELENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUMzRTtBQUNBLFFBQVEsQ0FBQyw2QkFBNkIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNyRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDN0U7QUFDQSxRQUFRLENBQUMsNkJBQTZCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxHQUFHLENBQUMsT0FBTztBQUNaLENBQUMsR0FBRyxDQUFDLElBQUk7QUFDVCxDQUFDLEdBQUcsQ0FBQztBQUNMLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztBQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEtBQUs7QUFDL0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxnQ0FBZ0MsQ0FBQywwQkFBMEIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEtBQUs7QUFDaEcsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLDZCQUE2QixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQztBQUNsSCxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xHLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7QUFDaEcsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3BGLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzFGLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLElBQUk7QUFDN0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDMUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLDBCQUEwQixDQUFDLGVBQWUsQ0FBQyxDQUFDLEtBQUs7QUFDM0YsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSTtBQUNqQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUM1QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUk7QUFDbEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNO0FBQ3RCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxnQ0FBZ0MsQ0FBQywwQkFBMEIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUs7QUFDOUYsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDekMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsSUFBSTtBQUM3QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUMxQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsZ0NBQWdDLENBQUMsMEJBQTBCLENBQUMsY0FBYyxDQUFDLENBQUMsS0FBSztBQUMxRixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEtBQUs7QUFDOUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDMUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLDBCQUEwQixDQUFDLG1CQUFtQixDQUFDLENBQUMsS0FBSztBQUMvRixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyxxQ0FBcUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDZixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxvQkFBb0I7QUFDL0IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoRCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDZixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2xCLENBQUMsQ0FBQztBQUNGLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzFCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNmLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUN6QjtBQUNBLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjO0FBQ2pDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVTtBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2pELENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLDBCQUEwQixDQUFDLDBCQUEwQixDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzlHLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLHVCQUF1QixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3hDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMxRixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUMxRixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztBQUM5QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsMEJBQTBCLENBQUMsMEJBQTBCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLO0FBQzFGLENBQUMsQ0FBQztBQUNGLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ25GLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUN6QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsMEJBQTBCLENBQUMsMEJBQTBCLENBQUMscUJBQXFCLENBQUMsQ0FBQyxLQUFLO0FBQzNGLENBQUMsQ0FBQztBQUNGLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQywwQkFBMEIsQ0FBQywwQkFBMEIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEtBQUs7QUFDM0YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLHdCQUF3QixDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQztBQUMzSCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN6RixDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3BEO0FBQ0EsUUFBUSxDQUFDLCtCQUErQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2hELENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzFELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNkLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QjtBQUNuQyxDQUFDLENBQUM7QUFDRixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNkLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDbEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDekMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsYUFBYTtBQUN4QixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3pCO0FBQ0EsUUFBUSxDQUFDLDJCQUEyQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQy9DLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTO0FBQy9CLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYztBQUN6QyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYztBQUM3QyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3pCLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLG1DQUFtQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3RELENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxvQ0FBb0MsQ0FBQztBQUM3RSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUMxRTtBQUNBLFFBQVEsQ0FBQyw2QkFBNkIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoRCxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsbUNBQW1DLENBQUMsT0FBTyxDQUFDO0FBQ3ZFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQzFELENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDbEM7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDM0MsQ0FBQyxHQUFHLENBQUM7QUFDTCxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDN0QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3pDLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyw2QkFBNkIsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNuRCxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNyRTtBQUNBLFFBQVEsQ0FBQyxrQ0FBa0MsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN2RSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLDZCQUE2QixDQUFDLFVBQVUsQ0FBQztBQUMzRCxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUMzSSxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ1o7QUFDQSxRQUFRLENBQUMsNEJBQTRCLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDekQsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsNkJBQTZCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pHO0FBQ0EsUUFBUSxDQUFDLHNDQUFzQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pELENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsbUNBQW1DLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUNyRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO0FBQ3JFLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ25GLENBQUMsS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDekcsQ0FBQyxFQUFFLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsdUJBQXVCLENBQUM7QUFDMUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQ2xELENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUNyRjtBQUNBLFFBQVEsQ0FBQyxpQ0FBaUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNwRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsc0NBQXNDLENBQUM7QUFDbkYsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCO0FBQ3BELENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLGFBQWE7QUFDOUMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLE1BQU0sQ0FBQyxzQ0FBc0MsQ0FBQztBQUMvQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLFVBQVU7QUFDakMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPO0FBQzNCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxRQUFRLENBQUMsZ0NBQWdDLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUN2RixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRO0FBQ3hCLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzVGO0FBQ0EsUUFBUSxDQUFDLHNDQUFzQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3RFLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQy9DLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM3RjtBQUNBLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsaUNBQWlDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7QUFDakksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2pGLENBQUMsS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMvSCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNmLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTO0FBQzdCLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsc0NBQXNDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUMzRixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsZ0NBQWdDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO0FBQ25JLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLHFDQUFxQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JFLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsNkJBQTZCLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDO0FBQzFFLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsNkJBQTZCLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDO0FBQzFFLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsc0NBQXNDLENBQUM7QUFDNUQsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0I7QUFDcEMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhO0FBQzlCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUN0RixDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsa0JBQWtCLENBQUM7QUFDM0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsNENBQTRDLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLGtCQUFrQixDQUFDO0FBQ2hLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDZCQUE2QixDQUFDLENBQUMsUUFBUTtBQUM1RSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQyxRQUFRO0FBQ3ZJLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUNyQixDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNaO0FBQ0EsUUFBUSxDQUFDLDZCQUE2QixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2hELENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsV0FBVztBQUM5QixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxPQUFPLENBQUMseUJBQXlCO0FBQzlELENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsQyxDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQztBQUM3QyxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxPQUFPLENBQUMseUJBQXlCO0FBQzlELENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0JBQW9CO0FBQ2pFLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxzQkFBc0I7QUFDeEQsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLFFBQVEsQ0FBQyw4QkFBOEIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDbkYsQ0FBQyxFQUFFLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLG1CQUFtQixDQUFDO0FBQ2hHLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztBQUNwRztBQUNBLFFBQVEsQ0FBQyxvQ0FBb0MsQ0FBQyxlQUFlLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUMvRSxDQUFDLE1BQU0sQ0FBQyxpREFBaUQsQ0FBQywyQkFBMkIsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ3BKO0FBQ0EsUUFBUSxDQUFDLGlEQUFpRCxDQUFDLGVBQWUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQzVGLENBQUMsRUFBRSxDQUFDLENBQUMsOEJBQThCLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDdkksQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFDOUYsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDbkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3pELENBQUMsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUNoQyxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsZUFBZTtBQUN2QjtBQUNBLFFBQVEsQ0FBQyxxQ0FBcUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUNoRixDQUFDLE1BQU0sQ0FBQywrQ0FBK0MsQ0FBQyxlQUFlLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQyxlQUFlLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUMvSTtBQUNBLFFBQVEsQ0FBQywrQ0FBK0MsQ0FBQyxlQUFlLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQzlGLENBQUMsRUFBRSxDQUFDLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUMvQyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztBQUN6RCxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzlDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRO0FBQzNDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQzdELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDNUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDOUIsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLGdCQUFnQjtBQUN4QjtBQUNBLFFBQVEsQ0FBQyw0Q0FBNEMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUN2RixDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsb0NBQW9DLENBQUMsZUFBZSxDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ2pHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywrQ0FBK0MsQ0FBQyxlQUFlLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ3hIO0FBQ0EsUUFBUSxDQUFDLGtEQUFrRCxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3JFLENBQUMsTUFBTSxDQUFDLGlEQUFpRCxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDO0FBQzFHO0FBQ0EsUUFBUSxDQUFDLCtDQUErQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xFLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxpREFBaUQsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQztBQUM5SCxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLGtEQUFrRCxDQUFDO0FBQ3RGLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsWUFBWTtBQUMzRCxDQUFDLENBQUMsa0JBQWtCO0FBQ3BCLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsNENBQTRDLENBQUM7QUFDMUUsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxZQUFZO0FBQzNELENBQUMsQ0FBQyxrQkFBa0I7QUFDcEIsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDO0FBQzVIO0FBQ0EsUUFBUSxDQUFDLDRDQUE0QyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQy9ELENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQztBQUNqRSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMzRixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUNwRSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO0FBQy9OLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztBQUNwRTtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRztBQUN6QztBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSTtBQUN0RSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUc7QUFDeEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsT0FBTztBQUM1RSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUNyQztBQUNBLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUs7QUFDaEUsQ0FBQztBQUNELFFBQVEsQ0FBQyxrREFBa0QsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNyRSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUM7QUFDakUsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyRCxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDN0MsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO0FBQ3hDLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzlDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRO0FBQzlDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDMUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUMvQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7QUFDdkMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUNqQyxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDO0FBQ3hEO0FBQ0EsUUFBUSxDQUFDLGlEQUFpRCxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BFLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN6RyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUM7QUFDakUsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ3pELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUMsUUFBUTtBQUN6RSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVE7QUFDeEYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdEUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQztBQUNsRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUMsUUFBUTtBQUM1RSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUMsUUFBUTtBQUMzSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUM7QUFDN0MsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztBQUN4RDtBQUNBLFFBQVEsQ0FBQyxvQ0FBb0MsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN4RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDbkMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCO0FBQ3BELENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO0FBQ2pDLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLDZCQUE2QixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVTtBQUNwRixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3BCLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLHVDQUF1QyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzFELENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDO0FBQ3JDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUM1QixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM3QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDOUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQztBQUNGLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNyQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNyQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNsQixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNsQixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2xCLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLG1DQUFtQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2hCLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2hCLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSTtBQUMvQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUk7QUFDL0IsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM1QixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyxnQ0FBZ0MsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuRCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUN0QixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUM5QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQzVCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ25LLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUM1QixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyxxQ0FBcUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN4RCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUN0QixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQztBQUNuQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQzVCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO0FBQ25GLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFDNUIsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsbUNBQW1DLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDcEUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVztBQUMxQyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2hCLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSTtBQUMvQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDakMsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsOEJBQThCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzdDO0FBQ0EsUUFBUSxDQUFDLCtCQUErQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xELENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxZQUFZO0FBQ2xELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztBQUN6QyxDQUFDLENBQUM7QUFDRixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNsQixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsMEJBQTBCLENBQUM7QUFDekMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDO0FBQ3JGLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDMUosQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztBQUN6QyxDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxxQ0FBcUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3pJLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUM3RSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLDBCQUEwQixDQUFDO0FBQ3pDLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxpREFBaUQsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQztBQUM5SCxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUM3QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLDBCQUEwQixDQUFDO0FBQ3pDLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDO0FBQ3pELENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUNqSCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDbEwsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztBQUN6QyxDQUFDLENBQUM7QUFDRixDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNySCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLDBCQUEwQixDQUFDO0FBQ3pDLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQyxrREFBa0QsQ0FBQztBQUM5RixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLFlBQVk7QUFDM0QsQ0FBQyxDQUFDLGtCQUFrQjtBQUNwQixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUMvQyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLGlEQUFpRCxDQUFDO0FBQ2pILENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsWUFBWTtBQUMzRCxDQUFDLENBQUMsa0JBQWtCO0FBQ3BCLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNO0FBQ3hDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEIsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsa0JBQWtCO0FBQ3hDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHlCQUF5QjtBQUN4SixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM1QyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGNBQWM7QUFDM0QsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQztBQUN0RCxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWE7QUFDdEMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDL0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDO0FBQ3JELENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYTtBQUN0QyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUNyQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsNkJBQTZCLENBQUM7QUFDbkQsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDbEgsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQ3RCLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzdHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDckQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUN4QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQzVCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXO0FBQ25GLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQztBQUMxRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0NBQWdDLENBQUM7QUFDNUYsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQ3RCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyx5QkFBeUI7QUFDdEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsUUFBUTtBQUN0RSxDQUFDLEVBQUUsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzVELENBQUMsQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMscUNBQXFDLENBQUM7QUFDN0UsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUs7QUFDdkIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU07QUFDOUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxXQUFXLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztBQUN2RyxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUMsMEJBQTBCLENBQUM7QUFDNUYsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHVDQUF1QyxDQUFDO0FBQzlILENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLHFDQUFxQztBQUMvRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsZUFBZTtBQUNqRCxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxlQUFlLENBQUMsUUFBUTtBQUM1QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pGLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLGNBQWM7QUFDakIsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsdUNBQXVDLENBQUM7QUFDckYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUs7QUFDdkIsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsVUFBVSxDQUFDLFVBQVU7QUFDcEMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxLQUFLO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxVQUFVLENBQUMsa0JBQWtCO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxVQUFVLENBQUMsdUJBQXVCO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSztBQUM3QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLGlCQUFpQjtBQUN0RyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUM7QUFDck8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDbEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDO0FBQy9CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixDQUFDLDBCQUEwQixDQUFDLG1CQUFtQixDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDakcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQzVCLENBQUMsQ0FBQztBQUNGLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztBQUN2QixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0I7QUFDOUIsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxLQUFLO0FBQzdCLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixDQUFDLDBCQUEwQixDQUFDLG1CQUFtQixDQUFDLENBQUMsaUJBQWlCO0FBQ2hHLENBQUMsQ0FBQztBQUNGLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakssQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDdkIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCO0FBQzlCLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsS0FBSztBQUM3QixDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLGtEQUFrRCxDQUFDO0FBQzFFLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVE7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsK0NBQStDLENBQUM7QUFDNUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxlQUFlLENBQUMsUUFBUTtBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUk7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxjQUFjLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSztBQUM1QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMscUJBQXFCLENBQUMsMEJBQTBCLENBQUMsYUFBYSxDQUFDLENBQUMsaUJBQWlCO0FBQzFGLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHlCQUF5QixDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUM5QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSztBQUNyQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUk7QUFDOUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDckIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLFVBQVU7QUFDaEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNsQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMseUJBQXlCLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJO0FBQzlCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVk7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQWM7QUFDekIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHlCQUF5QixDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUM5QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSztBQUNyQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ25CLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHlCQUF5QixDQUFDO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDbEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNqQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMscUJBQXFCLENBQUMsMEJBQTBCLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdFLENBQUMsQ0FBQztBQUNGLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0UsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxFQUFFLENBQUMsQ0FBQyx5Q0FBeUMsQ0FBQztBQUMvQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxLQUFLLENBQUMscUJBQXFCO0FBQ3BELENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVztBQUNoQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU07QUFDdEIsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsS0FBSyxDQUFDLHFCQUFxQjtBQUN0RCxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNsQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixDQUFDLDBCQUEwQixDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLENBQUM7QUFDRixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUMvQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxrQkFBa0I7QUFDL0IsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3pFLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLElBQUk7QUFDbkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMseUNBQXlDLENBQUM7QUFDckQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHFCQUFxQixDQUFDLDBCQUEwQixDQUFDLHlDQUF5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQzdJLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVc7QUFDcEMsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVM7QUFDaEIsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsS0FBSztBQUNwQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQztBQUNoRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMscUJBQXFCLENBQUMsMEJBQTBCLENBQUMsb0NBQW9DLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDekgsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXO0FBQ3hCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO0FBQzlCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDL0csQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsNkJBQTZCO0FBQzlCLENBQUMsK0JBQStCO0FBQ2hDLENBQUMsdUJBQXVCO0FBQ3hCLENBQUMsc0JBQXNCO0FBQ3ZCLENBQUMsMEJBQTBCO0FBQzNCLENBQUMsOEJBQThCO0FBQy9CLENBQUMsMEJBQTBCO0FBQzNCLENBQUMscUNBQXFDO0FBQ3RDLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYztBQUNyQixDQUFDLDRDQUE0QztBQUM3QyxDQUFDLHFDQUFxQztBQUN0QyxDQUFDO0FBQ0QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsTUFBTSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLGtEQUFrRCxDQUFDLENBQUM7In0=