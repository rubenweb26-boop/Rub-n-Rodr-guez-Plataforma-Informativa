const startTransition = __vite__cjsImport9_react["startTransition"]; const useInsertionEffect = __vite__cjsImport9_react["useInsertionEffect"]; const useLayoutEffect = __vite__cjsImport9_react["useLayoutEffect"];const flushSync = __vite__cjsImport10_reactDom["flushSync"];import { stripBasePath } from "/node_modules/vinext/dist/utils/base-path.js?v=b41becdd";
import { withBasePath } from "/node_modules/vinext/dist/shims/url-utils.js?v=b41becdd";
import { clearAppNavigationFailureTarget, getAppNavigationFailureTarget } from "/node_modules/vinext/dist/client/app-nav-failure-handler.js?v=b41becdd";
import { resolveServerActionOperationLane, shouldScheduleRefreshForDiscardedServerAction } from "/node_modules/vinext/dist/server/app-browser-action-result.js?v=b41becdd";
import { resolveActiveRoutePaths } from "/node_modules/vinext/dist/server/app-history-state.js?v=b41becdd";
import { claimAppRouterScrollIntentForCommit, clearAppRouterScrollIntent, consumeAppRouterScrollIntent } from "/node_modules/vinext/dist/shims/app-router-scroll-state.js?v=b41becdd";
import { activateNavigationSnapshot, clearPendingPathname, commitClientNavigationState, createSnapshotPathAndSearch } from "/node_modules/vinext/dist/shims/navigation.js?v=b41becdd";
import { FRESH_APP_NAVIGATION_PAYLOAD_ORIGIN, createPendingNavigationCommit, createPendingNavigationCommitFromElements } from "/node_modules/vinext/dist/server/app-browser-state.js?v=b41becdd";
import { applyApprovedVisibleCommit, approveHmrVisibleCommit, approvePendingNavigationCommit, resolveAndClassifyNavigationCommit } from "/node_modules/vinext/dist/server/app-browser-visible-commit.js?v=b41becdd";
import __vite__cjsImport9_react from "/node_modules/.vite/deps/react.js?v=b41becdd";
import __vite__cjsImport10_reactDom from "/node_modules/.vite/deps/react-dom.js?v=b41becdd";
//#region src/server/app-browser-navigation-controller.ts
const HARD_NAVIGATION_LOOP_GUARD_KEY = "__vinext_hard_navigation_target__";
function normalizeBrowserHref(href) {
	try {
		return new URL(href, window.location.href).href;
	} catch {
		return href;
	}
}
function readHardNavigationLoopGuard() {
	try {
		return window.sessionStorage.getItem(HARD_NAVIGATION_LOOP_GUARD_KEY);
	} catch {
		return null;
	}
}
function writeHardNavigationLoopGuard(targetHref) {
	try {
		window.sessionStorage.setItem(HARD_NAVIGATION_LOOP_GUARD_KEY, targetHref);
		return window.sessionStorage.getItem(HARD_NAVIGATION_LOOP_GUARD_KEY) === targetHref;
	} catch {
		return false;
	}
}
function clearHardNavigationLoopGuard() {
	try {
		window.sessionStorage.removeItem(HARD_NAVIGATION_LOOP_GUARD_KEY);
	} catch {}
}
function navigateDocumentDirectly(href, mode) {
	if (mode === "replace") window.location.replace(href);
	else window.location.assign(href);
}
function performHardNavigationWithLoopGuard(href, mode = "assign", navigateDocument = navigateDocumentDirectly) {
	const targetHref = normalizeBrowserHref(href);
	const currentHref = normalizeBrowserHref(window.location.href);
	if (readHardNavigationLoopGuard() === targetHref && currentHref === targetHref) {
		clearHardNavigationLoopGuard();
		console.error(`[vinext] Prevented repeated hard navigation to ${targetHref}; leaving the current document in place to avoid a reload loop.`);
		return false;
	}
	if (!writeHardNavigationLoopGuard(targetHref) && currentHref === targetHref) {
		console.error(`[vinext] Hard navigation to ${targetHref} requires a reload-loop guard, but sessionStorage is unavailable; leaving the current document in place.`);
		return false;
	}
	navigateDocument(href, mode);
	return true;
}
function createBasePathStrippedPathAndSearch(url, basePath) {
	const pathname = stripBasePath(url.pathname, basePath);
	const query = new URLSearchParams(url.search).toString();
	return query === "" ? pathname : `${pathname}?${query}`;
}
function isSnapshotTargetHref(basePath, snapshot, targetHref) {
	try {
		const baseHref = typeof window === "undefined" ? "http://localhost" : window.location.href;
		return createBasePathStrippedPathAndSearch(new URL(targetHref, baseHref), basePath) === createSnapshotPathAndSearch(snapshot);
	} catch {
		return false;
	}
}
function createAppBrowserNavigationController(deps = {}) {
	const basePath = deps.basePath ?? "";
	const commitClientNavigationStateImpl = deps.commitClientNavigationState ?? commitClientNavigationState;
	const performHardNavigation = deps.performHardNavigation ?? ((href, mode) => performHardNavigationWithLoopGuard(href, mode, deps.navigateDocument));
	const getRouteManifest = deps.getRouteManifest ?? (() => null);
	const loadRouteManifest = deps.loadRouteManifest ?? (() => null);
	const syncHistoryStatePreviousNextUrl = deps.syncHistoryStatePreviousNextUrl ?? (() => {});
	let nextNavigationRenderId = 0;
	let activeNavigationId = 0;
	let pendingUserNavigationId = null;
	let pendingUserNavigationLane = null;
	let committingNavigationRenderId = null;
	let pendingUserNavigationCommitStarted = false;
	let latestHmrUpdateId = 0;
	const pendingNavigationCommits = /* @__PURE__ */ new Map();
	const pendingNavigationFailureTargets = /* @__PURE__ */ new Map();
	const pendingNavigationPrePaintEffects = /* @__PURE__ */ new Map();
	const snapshotRenderIds = /* @__PURE__ */ new Set();
	let pendingUserNavigationShellHref = null;
	let retiredNavigationUrl = null;
	let setBrowserRouterState = null;
	let browserRouterStateRef = null;
	let activePendingBrowserRouterState = null;
	let resolveBrowserRouterStateReady = null;
	let browserRouterStateReadyPromise = null;
	let browserRouterStateHasCommitted = false;
	function getBrowserRouterStateSetter() {
		if (!setBrowserRouterState) throw new Error("[vinext] Browser router state setter is not initialized");
		return setBrowserRouterState;
	}
	function getBrowserRouterState() {
		if (!browserRouterStateRef) throw new Error("[vinext] Browser router state is not initialized");
		return browserRouterStateRef.current;
	}
	function waitForBrowserRouterStateReady() {
		if (browserRouterStateRef || browserRouterStateHasCommitted) return Promise.resolve();
		if (!browserRouterStateReadyPromise) browserRouterStateReadyPromise = new Promise((resolve) => {
			resolveBrowserRouterStateReady = resolve;
		});
		return browserRouterStateReadyPromise;
	}
	function markBrowserRouterStateReady() {
		browserRouterStateHasCommitted = true;
		const resolveReady = resolveBrowserRouterStateReady;
		resolveBrowserRouterStateReady = null;
		browserRouterStateReadyPromise = null;
		resolveReady?.();
	}
	function beginNavigation() {
		latestHmrUpdateId += 1;
		activeNavigationId += 1;
		pendingUserNavigationId = activeNavigationId;
		pendingUserNavigationLane = null;
		pendingUserNavigationCommitStarted = false;
		pendingUserNavigationShellHref = null;
		retiredNavigationUrl = null;
		return activeNavigationId;
	}
	function getActiveNavigationId() {
		return activeNavigationId;
	}
	function allocateRenderId() {
		nextNavigationRenderId += 1;
		return nextNavigationRenderId;
	}
	function hasBrowserRouterState() {
		return browserRouterStateRef !== null;
	}
	function isCurrentNavigation(navId) {
		return navId === activeNavigationId;
	}
	function beginPendingBrowserRouterState() {
		const setter = getBrowserRouterStateSetter();
		if (activePendingBrowserRouterState && !activePendingBrowserRouterState.settled) {
			activePendingBrowserRouterState.settled = true;
			activePendingBrowserRouterState.resolve(getBrowserRouterState());
		}
		let resolvePending;
		const promise = new Promise((resolve) => {
			resolvePending = resolve;
		});
		if (!resolvePending) throw new Error("[vinext] Failed to initialize browser router promise");
		const pending = {
			promise,
			resolve: resolvePending,
			settled: false
		};
		activePendingBrowserRouterState = pending;
		setter(promise);
		return pending;
	}
	function settlePendingBrowserRouterState(pending) {
		if (!pending || pending.settled) return;
		pending.settled = true;
		pending.resolve(getBrowserRouterState());
		if (activePendingBrowserRouterState === pending) activePendingBrowserRouterState = null;
	}
	function abandonPendingBrowserRouterState(pending) {
		if (!pending || pending.settled) return;
		pending.settled = true;
		if (activePendingBrowserRouterState === pending) activePendingBrowserRouterState = null;
	}
	function finalizeNavigation(navId, pending) {
		settlePendingBrowserRouterState(pending);
		if (isCurrentNavigation(navId)) {
			pendingUserNavigationId = null;
			pendingUserNavigationLane = null;
			pendingUserNavigationShellHref = null;
			retiredNavigationUrl = null;
			clearPendingPathname(navId);
		}
	}
	/**
	* Discard the user navigation that has not committed yet, keeping
	* `visibleState` (the committed tree) on screen. Next.js does the same when
	* a raw history.pushState/replaceState dispatches ACTION_RESTORE: the
	* pending action is marked discarded and the restore commits the current
	* tree in a transition, which replaces the navigation's suspended one.
	* Returns whether a navigation was discarded.
	*/
	function discardPendingNavigation(visibleState) {
		if (pendingUserNavigationId === null || pendingUserNavigationCommitStarted) return false;
		if (pendingUserNavigationShellHref !== null) {
			retiredNavigationUrl = {
				navigationId: pendingUserNavigationId,
				href: pendingUserNavigationShellHref
			};
			for (const renderId of pendingNavigationPrePaintEffects.keys()) releaseRenderSnapshot(renderId);
			return false;
		}
		activeNavigationId += 1;
		pendingUserNavigationId = null;
		pendingUserNavigationLane = null;
		clearAppRouterScrollIntent();
		for (const renderId of pendingNavigationPrePaintEffects.keys()) {
			pendingNavigationPrePaintEffects.delete(renderId);
			releaseRenderSnapshot(renderId);
		}
		clearCommittedNavigationFailureTargets(nextNavigationRenderId);
		settleNavigationCommits(nextNavigationRenderId, false);
		if (visibleState && setBrowserRouterState) {
			const setter = setBrowserRouterState;
			startTransition(() => {
				setter(visibleState);
			});
		}
		return true;
	}
	/**
	* Publish the URL update of a navigation render React is committing right
	* now. Its history entry is already written, but publishing normally runs in
	* NavigationCommitSignal's layout effect, after the route's own layout
	* effects. Called before a raw history write from such an effect, so the
	* write is published on top of the destination's.
	*/
	function flushCommittingNavigationUrl() {
		if (committingNavigationRenderId !== null) drainPrePaintEffects(committingNavigationRenderId);
	}
	function releaseRenderSnapshot(renderId) {
		if (snapshotRenderIds.delete(renderId)) commitClientNavigationStateImpl(void 0, { releaseSnapshot: true });
	}
	function isRetiredNavigationUrl(navId, targetHref) {
		return retiredNavigationUrl !== null && retiredNavigationUrl.navigationId === navId && retiredNavigationUrl.href === normalizeBrowserHref(targetHref);
	}
	function writeNavigationRenderHistory(renderId) {
		const effect = pendingNavigationPrePaintEffects.get(renderId);
		const writeHistory = effect?.writeHistory;
		if (!effect || !writeHistory) return;
		effect.writeHistory = null;
		writeHistory();
	}
	/**
	* Run all queued pre-paint effects for renderIds up to and including the
	* given renderId. When React supersedes a startTransition update (rapid
	* clicks on same-route links), the superseded NavigationCommitSignal never
	* mounts, so its pre-paint effect never fires. By draining all effects
	* <= the committed renderId here, the winning transition cleans up after
	* any superseded ones, keeping the counter balanced.
	*
	* Invariant: each superseded navigation gets a commitClientNavigationState()
	* to balance the activateNavigationSnapshot() from its renderNavigationPayload call.
	*/
	function drainPrePaintEffects(upToRenderId) {
		for (const [id, effect] of pendingNavigationPrePaintEffects) {
			if (id > upToRenderId) continue;
			pendingNavigationPrePaintEffects.delete(id);
			if (id === upToRenderId) {
				effect.writeHistory?.();
				effect.publish();
			} else releaseRenderSnapshot(id);
		}
	}
	/**
	* Settle all pending navigation renders through the supplied renderId. Only
	* the exact render whose layout effect ran is a successful commit; older
	* superseded renders and cleanup-only settlements resolve as no-commit.
	*/
	function settleNavigationCommits(renderId, committed) {
		for (const [pendingId, pendingCommit] of pendingNavigationCommits) {
			if (pendingId > renderId) continue;
			pendingNavigationCommits.delete(pendingId);
			const didCommit = committed && pendingId === renderId;
			if (didCommit && pendingCommit.committedState !== null) pendingCommit.onCommittedState?.(pendingCommit.committedState);
			pendingCommit.resolve(didCommit);
		}
	}
	/**
	* Runs when React starts committing a render, before it changes the route
	* tree's DOM, and writes the render's history entry.
	*/
	function beginNavigationRenderCommit(renderId) {
		committingNavigationRenderId = renderId;
		const committingCommit = pendingNavigationCommits.get(renderId);
		const committingOperation = committingCommit?.committedState?.activeOperation;
		if (committingCommit && committingOperation?.navigationCommitKind === "detached" && committingOperation.navigationId === pendingUserNavigationId) pendingUserNavigationShellHref = normalizeBrowserHref(committingCommit.targetHref);
		else pendingUserNavigationCommitStarted = true;
		clearCommittedNavigationFailureTargets(renderId);
		writeNavigationRenderHistory(renderId);
	}
	function commitNavigationRender(renderId) {
		committingNavigationRenderId = null;
		drainPrePaintEffects(renderId);
		settleNavigationCommits(renderId, true);
	}
	function clearCommittedNavigationFailureTargets(renderId) {
		for (const [pendingId, targetHref] of pendingNavigationFailureTargets) {
			if (pendingId > renderId) continue;
			pendingNavigationFailureTargets.delete(pendingId);
			clearAppNavigationFailureTarget(targetHref);
		}
	}
	async function hmrReplaceTree(nextElements, pendingNavigationSnapshot) {
		const hmrUpdateId = ++latestHmrUpdateId;
		const startedDuringUserNavigation = pendingUserNavigationLane === "navigation";
		if (!hasBrowserRouterState()) return;
		const currentState = getBrowserRouterState();
		const renderId = allocateRenderId();
		const [navigationSnapshot, , routeManifestLoaded] = await Promise.all([
			pendingNavigationSnapshot,
			nextElements,
			loadRouteManifest()
		]);
		const pending = await createPendingNavigationCommit({
			currentState,
			nextElements,
			navigationSnapshot,
			operationLane: "hmr",
			payloadOrigin: FRESH_APP_NAVIGATION_PAYLOAD_ORIGIN,
			renderId,
			type: "replace"
		});
		if (hmrUpdateId !== latestHmrUpdateId || startedDuringUserNavigation) return;
		if (!hasBrowserRouterState()) return;
		if (routeManifestLoaded === false) {
			performHardNavigation(withBasePath(createSnapshotPathAndSearch(navigationSnapshot), basePath));
			return;
		}
		const approval = approveHmrVisibleCommit({
			currentState: getBrowserRouterState(),
			pending,
			routeManifest: deps.getRouteManifest?.() ?? null,
			targetHref: createSnapshotPathAndSearch(navigationSnapshot)
		});
		if (approval.approvedCommit) {
			const approvedHmrCommit = approval.approvedCommit;
			startTransition(() => {
				dispatchVisibleCommit(approvedHmrCommit);
			});
		} else if (approval.decision.disposition === "hard-navigate") performHardNavigation(createSnapshotPathAndSearch(navigationSnapshot));
	}
	/**
	* Rendered before the route tree (see createAppRouteTree). Insertion effects
	* run in the mutation phase, in tree order, after each component's own
	* subtree mutations, so this one runs before React changes the route tree's
	* DOM. An effect on NavigationCommitSignal itself would run after them.
	*/
	function NavigationHistoryCommit({ renderId }) {
		useInsertionEffect(() => {
			beginNavigationRenderCommit(renderId);
		}, [renderId]);
		return null;
	}
	function NavigationCommitSignal({ renderId, children }) {
		useLayoutEffect(() => {
			commitNavigationRender(renderId);
			return () => {
				settleNavigationCommits(renderId, false);
			};
		}, [renderId]);
		return children;
	}
	function dispatchApprovedVisibleCommit(renderId, commit, pendingRouterState, visibleCommitMode, republishPendingRouterState) {
		const setter = getBrowserRouterStateSetter();
		const pendingCommit = pendingNavigationCommits.get(renderId);
		const captureCandidateState = (state) => {
			if (pendingCommit) pendingCommit.committedState = state;
			return state;
		};
		if (pendingRouterState) {
			if (pendingRouterState.settled) return;
			const committedState = captureCandidateState(applyApprovedVisibleCommit(getBrowserRouterState(), commit));
			pendingRouterState.settled = true;
			pendingRouterState.resolve(committedState);
			if (activePendingBrowserRouterState === pendingRouterState) activePendingBrowserRouterState = null;
			if (republishPendingRouterState) startTransition(() => {
				setter(committedState);
			});
			return;
		}
		if (visibleCommitMode === "synchronous") {
			flushSync(() => {
				const committedState = captureCandidateState(applyApprovedVisibleCommit(getBrowserRouterState(), commit));
				setter(committedState);
			});
			return;
		}
		startTransition(() => {
			const committedState = captureCandidateState(applyApprovedVisibleCommit(getBrowserRouterState(), commit));
			setter(committedState);
		});
	}
	/** Calls the setter directly; the caller chooses the update's priority. */
	function dispatchVisibleCommit(commit) {
		getBrowserRouterStateSetter()(applyApprovedVisibleCommit(getBrowserRouterState(), commit));
	}
	function createRestoredHistorySnapshotCommit(options) {
		const operation = {
			id: options.renderId,
			lane: "traverse",
			startedVisibleCommitVersion: options.currentState.visibleCommitVersion,
			state: "pending"
		};
		return {
			action: {
				bfcacheIds: options.restoredState.bfcacheIds,
				elements: options.restoredState.elements,
				interception: options.restoredState.interception,
				interceptionContext: options.restoredState.interceptionContext,
				layoutIds: options.restoredState.layoutIds,
				navigationSnapshot: options.restoredState.navigationSnapshot,
				operation,
				previousNextUrl: options.restoredState.previousNextUrl,
				renderId: options.renderId,
				rootLayoutTreePath: options.restoredState.rootLayoutTreePath,
				reuseCurrentBfcacheIds: false,
				routeId: options.restoredState.routeId,
				skippedLayoutIds: [],
				slotBindings: options.restoredState.slotBindings,
				type: "traverse"
			},
			interception: options.restoredState.interception,
			interceptionContext: options.restoredState.interceptionContext,
			previousNextUrl: options.restoredState.previousNextUrl,
			rootLayoutTreePath: options.restoredState.rootLayoutTreePath,
			routeId: options.restoredState.routeId,
			restoredHistorySnapshot: true,
			skippedLayoutIds: []
		};
	}
	function restoreHistorySnapshotVisibleState(options) {
		if (!options.restoreCopiedExternalHistoryEntry && !isSnapshotTargetHref(basePath, options.state.navigationSnapshot, options.targetHref)) return false;
		const approvalTargetHref = options.restoreCopiedExternalHistoryEntry ? createSnapshotPathAndSearch(options.state.navigationSnapshot) : options.targetHref;
		const currentState = getBrowserRouterState();
		const pending = createRestoredHistorySnapshotCommit({
			currentState,
			renderId: allocateRenderId(),
			restoredState: options.state
		});
		const approval = approvePendingNavigationCommit({
			activeNavigationId,
			currentState,
			pending,
			routeManifest: getRouteManifest(),
			startedNavigationId: options.navId,
			targetHref: approvalTargetHref
		});
		if (approval.approvedCommit === null) return false;
		options.beforeCommit?.();
		dispatchVisibleCommit(approval.approvedCommit);
		return true;
	}
	function notifyDiscardedServerActionRevalidation(lifecycleOptions) {
		const revalidation = lifecycleOptions?.revalidation ?? "none";
		if (!shouldScheduleRefreshForDiscardedServerAction(revalidation)) return;
		lifecycleOptions?.onDiscardedRevalidation?.();
	}
	function isSamePathSearchHashCommit(targetHref) {
		if (typeof window === "undefined") return false;
		try {
			const currentUrl = new URL(window.location.href);
			const targetUrl = new URL(targetHref, currentUrl.href);
			return targetUrl.origin === currentUrl.origin && targetUrl.pathname === currentUrl.pathname && targetUrl.search !== currentUrl.search && targetUrl.hash !== "";
		} catch {
			return false;
		}
	}
	function shouldRepublishPendingRouterState(options) {
		if (options.actionType === "traverse") return false;
		if (options.historyUpdateMode === void 0) return false;
		if (options.scrollIntent?.hash == null) return false;
		return isSamePathSearchHashCommit(options.targetHref);
	}
	async function renderNavigationPayload(options) {
		const routeManifestLoad = loadRouteManifest();
		if (routeManifestLoad !== null && !await routeManifestLoad) {
			settlePendingBrowserRouterState(options.pendingRouterState);
			consumeAppRouterScrollIntent(options.scrollIntent ?? null);
			if (isCurrentNavigation(options.navId)) performHardNavigation(options.targetHref, options.historyUpdateMode === "push" ? "assign" : "replace");
			return "no-commit";
		}
		if (options.navId === pendingUserNavigationId) pendingUserNavigationLane = options.operationLane;
		const renderId = allocateRenderId();
		const failureTarget = getAppNavigationFailureTarget(options.targetHref);
		if (failureTarget) pendingNavigationFailureTargets.set(renderId, failureTarget);
		let resolveCommitted;
		const committed = new Promise((resolve) => {
			resolveCommitted = resolve;
			pendingNavigationCommits.set(renderId, {
				committedState: null,
				onCommittedState: options.onCommittedState,
				resolve,
				targetHref: options.targetHref
			});
		});
		try {
			const pendingOptions = {
				currentState: options.navigationInitiationState,
				navigationCommitKind: options.navigationCommitKind,
				navigationId: options.navId,
				navigationSnapshot: options.navigationSnapshot,
				operationLane: options.operationLane,
				payloadOrigin: options.payloadOrigin,
				previousNextUrl: options.previousNextUrl,
				renderId,
				restoredBfcacheIds: options.restoredBfcacheIds,
				reuseCurrentBfcacheIds: options.reuseCurrentBfcacheIds,
				type: options.actionType
			};
			const pending = options.nextElements instanceof Promise ? await createPendingNavigationCommit({
				...pendingOptions,
				nextElements: options.nextElements
			}) : createPendingNavigationCommitFromElements({
				...pendingOptions,
				nextElements: options.nextElements
			});
			const approval = approvePendingNavigationCommit({
				activeNavigationId,
				currentState: getBrowserRouterState(),
				pending,
				routeManifest: getRouteManifest(),
				startedNavigationId: options.navId,
				targetHref: options.targetHref
			});
			if (approval.decision.disposition === "no-commit") {
				settlePendingBrowserRouterState(options.pendingRouterState);
				pendingNavigationFailureTargets.delete(renderId);
				if (failureTarget) clearAppNavigationFailureTarget(failureTarget);
				pendingNavigationCommits.delete(renderId);
				resolveCommitted?.(false);
				consumeAppRouterScrollIntent(options.scrollIntent ?? null);
				return "no-commit";
			}
			if (approval.decision.disposition === "hard-navigate") {
				pendingNavigationFailureTargets.delete(renderId);
				pendingNavigationCommits.delete(renderId);
				consumeAppRouterScrollIntent(options.scrollIntent ?? null);
				if (performHardNavigation(options.targetHref, options.historyUpdateMode === "push" ? "assign" : "replace")) {
					abandonPendingBrowserRouterState(options.pendingRouterState);
					return "hard-navigate";
				}
				settlePendingBrowserRouterState(options.pendingRouterState);
				if (failureTarget) clearAppNavigationFailureTarget(failureTarget);
				return "no-commit";
			}
			const approvedCommit = approval.approvedCommit;
			if (approvedCommit === null) throw new Error("[vinext] Commit decision did not approve a visible commit");
			const approvedVisibleState = applyApprovedVisibleCommit(getBrowserRouterState(), approvedCommit);
			const commitEffect = options.createNavigationCommitEffect({
				activeRoutePaths: resolveActiveRoutePaths(approvedVisibleState.slotBindings),
				bfcacheIds: approvedVisibleState.bfcacheIds,
				href: options.targetHref,
				historyUpdateMode: options.historyUpdateMode,
				navId: options.navId,
				params: options.params,
				previousNextUrl: approvedCommit.previousNextUrl,
				targetHistoryIndex: options.targetHistoryIndex
			});
			pendingNavigationPrePaintEffects.set(renderId, {
				writeHistory: () => {
					commitEffect.writeHistory({ keepCurrentUrl: isRetiredNavigationUrl(options.navId, options.targetHref) });
				},
				publish: () => {
					commitEffect.publish({ releaseSnapshot: snapshotRenderIds.delete(renderId) });
				}
			});
			claimAppRouterScrollIntentForCommit(options.scrollIntent, renderId);
			if (!isRetiredNavigationUrl(options.navId, options.targetHref)) {
				activateNavigationSnapshot();
				snapshotRenderIds.add(renderId);
			}
			dispatchApprovedVisibleCommit(renderId, approvedCommit, options.pendingRouterState, options.visibleCommitMode ?? "transition", shouldRepublishPendingRouterState(options));
			if (options.navigationResponseCompletion) options.navigationResponseCompletion.then(() => {
				if (!isCurrentNavigation(options.navId) || !hasBrowserRouterState()) return;
				const committedState = pendingNavigationCommits.get(renderId)?.committedState;
				if (!committedState) return;
				startTransition(() => {
					getBrowserRouterStateSetter()(committedState);
				});
			}, () => {});
		} catch (error) {
			pendingNavigationFailureTargets.delete(renderId);
			pendingNavigationPrePaintEffects.delete(renderId);
			pendingNavigationCommits.delete(renderId);
			if (snapshotRenderIds.delete(renderId)) commitClientNavigationStateImpl(options.navId);
			settlePendingBrowserRouterState(options.pendingRouterState);
			resolveCommitted?.(false);
			throw error;
		}
		return committed.then((didCommit) => didCommit ? "committed" : "no-commit");
	}
	async function commitSameUrlNavigatePayload(nextElements, navigationSnapshot, returnValue, actionInitiationState, lifecycleOptions) {
		const currentState = actionInitiationState ?? getBrowserRouterState();
		const startedNavigationId = lifecycleOptions?.startedNavigationId ?? activeNavigationId;
		const targetHref = lifecycleOptions?.targetHref ?? window.location.href;
		const routeManifestLoad = loadRouteManifest();
		if (routeManifestLoad !== null && !await routeManifestLoad) {
			if (isCurrentNavigation(startedNavigationId)) {
				performHardNavigation(targetHref);
				return;
			}
			notifyDiscardedServerActionRevalidation(lifecycleOptions);
			return resolveSameUrlActionReturnValue(returnValue);
		}
		const { approvedCommit, decision, pending, trace: _navigationTrace } = await resolveAndClassifyNavigationCommit({
			activeNavigationId,
			currentState,
			getActiveNavigationId: () => activeNavigationId,
			getCurrentStateForApproval: getBrowserRouterState,
			navigationSnapshot,
			nextElements,
			renderId: allocateRenderId(),
			operationLane: resolveServerActionOperationLane(lifecycleOptions?.revalidation ?? "none"),
			payloadOrigin: FRESH_APP_NAVIGATION_PAYLOAD_ORIGIN,
			startedNavigationId,
			routeManifest: getRouteManifest(),
			targetHref,
			type: "navigate"
		});
		if (decision.disposition === "hard-navigate") {
			performHardNavigation(targetHref);
			return;
		}
		if (approvedCommit) {
			const latestApproval = approvePendingNavigationCommit({
				activeNavigationId,
				currentState: getBrowserRouterState(),
				pending,
				routeManifest: getRouteManifest(),
				startedNavigationId,
				targetHref
			});
			if (latestApproval.decision.disposition === "hard-navigate") {
				performHardNavigation(targetHref);
				return;
			}
			if (latestApproval.approvedCommit) {
				const approvedRevalidationCommit = latestApproval.approvedCommit;
				startTransition(() => {
					dispatchVisibleCommit(approvedRevalidationCommit);
				});
				syncHistoryStatePreviousNextUrl(approvedRevalidationCommit.previousNextUrl, approvedRevalidationCommit.action.bfcacheIds);
			} else notifyDiscardedServerActionRevalidation(lifecycleOptions);
		} else if (decision.disposition === "no-commit") notifyDiscardedServerActionRevalidation(lifecycleOptions);
		return resolveSameUrlActionReturnValue(returnValue);
	}
	async function resolveSameUrlActionReturnValue(returnValue) {
		if (returnValue) {
			if (!returnValue.ok) throw await returnValue.data;
			return returnValue.data;
		}
	}
	function attachBrowserRouterState(setter, stateRef) {
		setBrowserRouterState = setter;
		browserRouterStateRef = stateRef;
		markBrowserRouterStateReady();
		return () => {
			if (setBrowserRouterState === setter) setBrowserRouterState = null;
			if (browserRouterStateRef === stateRef) {
				browserRouterStateRef = null;
				browserRouterStateHasCommitted = false;
			}
		};
	}
	return {
		beginNavigation,
		getActiveNavigationId,
		hasBrowserRouterState,
		getBrowserRouterState,
		isCurrentNavigation,
		performHardNavigation,
		waitForBrowserRouterStateReady,
		attachBrowserRouterState,
		beginPendingBrowserRouterState,
		abandonPendingBrowserRouterState,
		finalizeNavigation,
		discardPendingNavigation,
		flushCommittingNavigationUrl,
		restoreHistorySnapshotVisibleState,
		renderNavigationPayload,
		commitSameUrlNavigatePayload,
		hmrReplaceTree,
		drainPrePaintEffects,
		beginNavigationRenderCommit,
		commitNavigationRender,
		clearCommittedNavigationFailureTargets,
		NavigationCommitSignal,
		NavigationHistoryCommit
	};
}
//#endregion
export { clearHardNavigationLoopGuard, createAppBrowserNavigationController, createBasePathStrippedPathAndSearch, createSnapshotPathAndSearch, navigateDocumentDirectly };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC1icm93c2VyLW5hdmlnYXRpb24tY29udHJvbGxlci5qcz92PWI0MWJlY2RkIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHN0YXJ0VHJhbnNpdGlvbiA9IF9fdml0ZV9fY2pzSW1wb3J0OV9yZWFjdFtcInN0YXJ0VHJhbnNpdGlvblwiXTsgY29uc3QgdXNlSW5zZXJ0aW9uRWZmZWN0ID0gX192aXRlX19janNJbXBvcnQ5X3JlYWN0W1widXNlSW5zZXJ0aW9uRWZmZWN0XCJdOyBjb25zdCB1c2VMYXlvdXRFZmZlY3QgPSBfX3ZpdGVfX2Nqc0ltcG9ydDlfcmVhY3RbXCJ1c2VMYXlvdXRFZmZlY3RcIl07Y29uc3QgZmx1c2hTeW5jID0gX192aXRlX19janNJbXBvcnQxMF9yZWFjdERvbVtcImZsdXNoU3luY1wiXTtpbXBvcnQgeyBzdHJpcEJhc2VQYXRoIH0gZnJvbSBcIi9ub2RlX21vZHVsZXMvdmluZXh0L2Rpc3QvdXRpbHMvYmFzZS1wYXRoLmpzP3Y9YjQxYmVjZGRcIjtcbmltcG9ydCB7IHdpdGhCYXNlUGF0aCB9IGZyb20gXCIvbm9kZV9tb2R1bGVzL3ZpbmV4dC9kaXN0L3NoaW1zL3VybC11dGlscy5qcz92PWI0MWJlY2RkXCI7XG5pbXBvcnQgeyBjbGVhckFwcE5hdmlnYXRpb25GYWlsdXJlVGFyZ2V0LCBnZXRBcHBOYXZpZ2F0aW9uRmFpbHVyZVRhcmdldCB9IGZyb20gXCIvbm9kZV9tb2R1bGVzL3ZpbmV4dC9kaXN0L2NsaWVudC9hcHAtbmF2LWZhaWx1cmUtaGFuZGxlci5qcz92PWI0MWJlY2RkXCI7XG5pbXBvcnQgeyByZXNvbHZlU2VydmVyQWN0aW9uT3BlcmF0aW9uTGFuZSwgc2hvdWxkU2NoZWR1bGVSZWZyZXNoRm9yRGlzY2FyZGVkU2VydmVyQWN0aW9uIH0gZnJvbSBcIi9ub2RlX21vZHVsZXMvdmluZXh0L2Rpc3Qvc2VydmVyL2FwcC1icm93c2VyLWFjdGlvbi1yZXN1bHQuanM/dj1iNDFiZWNkZFwiO1xuaW1wb3J0IHsgcmVzb2x2ZUFjdGl2ZVJvdXRlUGF0aHMgfSBmcm9tIFwiL25vZGVfbW9kdWxlcy92aW5leHQvZGlzdC9zZXJ2ZXIvYXBwLWhpc3Rvcnktc3RhdGUuanM/dj1iNDFiZWNkZFwiO1xuaW1wb3J0IHsgY2xhaW1BcHBSb3V0ZXJTY3JvbGxJbnRlbnRGb3JDb21taXQsIGNsZWFyQXBwUm91dGVyU2Nyb2xsSW50ZW50LCBjb25zdW1lQXBwUm91dGVyU2Nyb2xsSW50ZW50IH0gZnJvbSBcIi9ub2RlX21vZHVsZXMvdmluZXh0L2Rpc3Qvc2hpbXMvYXBwLXJvdXRlci1zY3JvbGwtc3RhdGUuanM/dj1iNDFiZWNkZFwiO1xuaW1wb3J0IHsgYWN0aXZhdGVOYXZpZ2F0aW9uU25hcHNob3QsIGNsZWFyUGVuZGluZ1BhdGhuYW1lLCBjb21taXRDbGllbnROYXZpZ2F0aW9uU3RhdGUsIGNyZWF0ZVNuYXBzaG90UGF0aEFuZFNlYXJjaCB9IGZyb20gXCIvbm9kZV9tb2R1bGVzL3ZpbmV4dC9kaXN0L3NoaW1zL25hdmlnYXRpb24uanM/dj1iNDFiZWNkZFwiO1xuaW1wb3J0IHsgRlJFU0hfQVBQX05BVklHQVRJT05fUEFZTE9BRF9PUklHSU4sIGNyZWF0ZVBlbmRpbmdOYXZpZ2F0aW9uQ29tbWl0LCBjcmVhdGVQZW5kaW5nTmF2aWdhdGlvbkNvbW1pdEZyb21FbGVtZW50cyB9IGZyb20gXCIvbm9kZV9tb2R1bGVzL3ZpbmV4dC9kaXN0L3NlcnZlci9hcHAtYnJvd3Nlci1zdGF0ZS5qcz92PWI0MWJlY2RkXCI7XG5pbXBvcnQgeyBhcHBseUFwcHJvdmVkVmlzaWJsZUNvbW1pdCwgYXBwcm92ZUhtclZpc2libGVDb21taXQsIGFwcHJvdmVQZW5kaW5nTmF2aWdhdGlvbkNvbW1pdCwgcmVzb2x2ZUFuZENsYXNzaWZ5TmF2aWdhdGlvbkNvbW1pdCB9IGZyb20gXCIvbm9kZV9tb2R1bGVzL3ZpbmV4dC9kaXN0L3NlcnZlci9hcHAtYnJvd3Nlci12aXNpYmxlLWNvbW1pdC5qcz92PWI0MWJlY2RkXCI7XG5pbXBvcnQgX192aXRlX19janNJbXBvcnQ5X3JlYWN0IGZyb20gXCIvbm9kZV9tb2R1bGVzLy52aXRlL2RlcHMvcmVhY3QuanM/dj1iNDFiZWNkZFwiO1xuaW1wb3J0IF9fdml0ZV9fY2pzSW1wb3J0MTBfcmVhY3REb20gZnJvbSBcIi9ub2RlX21vZHVsZXMvLnZpdGUvZGVwcy9yZWFjdC1kb20uanM/dj1iNDFiZWNkZFwiO1xuLy8jcmVnaW9uIHNyYy9zZXJ2ZXIvYXBwLWJyb3dzZXItbmF2aWdhdGlvbi1jb250cm9sbGVyLnRzXG5jb25zdCBIQVJEX05BVklHQVRJT05fTE9PUF9HVUFSRF9LRVkgPSBcIl9fdmluZXh0X2hhcmRfbmF2aWdhdGlvbl90YXJnZXRfX1wiO1xuZnVuY3Rpb24gbm9ybWFsaXplQnJvd3NlckhyZWYoaHJlZikge1xuXHR0cnkge1xuXHRcdHJldHVybiBuZXcgVVJMKGhyZWYsIHdpbmRvdy5sb2NhdGlvbi5ocmVmKS5ocmVmO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm4gaHJlZjtcblx0fVxufVxuZnVuY3Rpb24gcmVhZEhhcmROYXZpZ2F0aW9uTG9vcEd1YXJkKCkge1xuXHR0cnkge1xuXHRcdHJldHVybiB3aW5kb3cuc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShIQVJEX05BVklHQVRJT05fTE9PUF9HVUFSRF9LRVkpO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxufVxuZnVuY3Rpb24gd3JpdGVIYXJkTmF2aWdhdGlvbkxvb3BHdWFyZCh0YXJnZXRIcmVmKSB7XG5cdHRyeSB7XG5cdFx0d2luZG93LnNlc3Npb25TdG9yYWdlLnNldEl0ZW0oSEFSRF9OQVZJR0FUSU9OX0xPT1BfR1VBUkRfS0VZLCB0YXJnZXRIcmVmKTtcblx0XHRyZXR1cm4gd2luZG93LnNlc3Npb25TdG9yYWdlLmdldEl0ZW0oSEFSRF9OQVZJR0FUSU9OX0xPT1BfR1VBUkRfS0VZKSA9PT0gdGFyZ2V0SHJlZjtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59XG5mdW5jdGlvbiBjbGVhckhhcmROYXZpZ2F0aW9uTG9vcEd1YXJkKCkge1xuXHR0cnkge1xuXHRcdHdpbmRvdy5zZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKEhBUkRfTkFWSUdBVElPTl9MT09QX0dVQVJEX0tFWSk7XG5cdH0gY2F0Y2gge31cbn1cbmZ1bmN0aW9uIG5hdmlnYXRlRG9jdW1lbnREaXJlY3RseShocmVmLCBtb2RlKSB7XG5cdGlmIChtb2RlID09PSBcInJlcGxhY2VcIikgd2luZG93LmxvY2F0aW9uLnJlcGxhY2UoaHJlZik7XG5cdGVsc2Ugd2luZG93LmxvY2F0aW9uLmFzc2lnbihocmVmKTtcbn1cbmZ1bmN0aW9uIHBlcmZvcm1IYXJkTmF2aWdhdGlvbldpdGhMb29wR3VhcmQoaHJlZiwgbW9kZSA9IFwiYXNzaWduXCIsIG5hdmlnYXRlRG9jdW1lbnQgPSBuYXZpZ2F0ZURvY3VtZW50RGlyZWN0bHkpIHtcblx0Y29uc3QgdGFyZ2V0SHJlZiA9IG5vcm1hbGl6ZUJyb3dzZXJIcmVmKGhyZWYpO1xuXHRjb25zdCBjdXJyZW50SHJlZiA9IG5vcm1hbGl6ZUJyb3dzZXJIcmVmKHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcblx0aWYgKHJlYWRIYXJkTmF2aWdhdGlvbkxvb3BHdWFyZCgpID09PSB0YXJnZXRIcmVmICYmIGN1cnJlbnRIcmVmID09PSB0YXJnZXRIcmVmKSB7XG5cdFx0Y2xlYXJIYXJkTmF2aWdhdGlvbkxvb3BHdWFyZCgpO1xuXHRcdGNvbnNvbGUuZXJyb3IoYFt2aW5leHRdIFByZXZlbnRlZCByZXBlYXRlZCBoYXJkIG5hdmlnYXRpb24gdG8gJHt0YXJnZXRIcmVmfTsgbGVhdmluZyB0aGUgY3VycmVudCBkb2N1bWVudCBpbiBwbGFjZSB0byBhdm9pZCBhIHJlbG9hZCBsb29wLmApO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHRpZiAoIXdyaXRlSGFyZE5hdmlnYXRpb25Mb29wR3VhcmQodGFyZ2V0SHJlZikgJiYgY3VycmVudEhyZWYgPT09IHRhcmdldEhyZWYpIHtcblx0XHRjb25zb2xlLmVycm9yKGBbdmluZXh0XSBIYXJkIG5hdmlnYXRpb24gdG8gJHt0YXJnZXRIcmVmfSByZXF1aXJlcyBhIHJlbG9hZC1sb29wIGd1YXJkLCBidXQgc2Vzc2lvblN0b3JhZ2UgaXMgdW5hdmFpbGFibGU7IGxlYXZpbmcgdGhlIGN1cnJlbnQgZG9jdW1lbnQgaW4gcGxhY2UuYCk7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cdG5hdmlnYXRlRG9jdW1lbnQoaHJlZiwgbW9kZSk7XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gY3JlYXRlQmFzZVBhdGhTdHJpcHBlZFBhdGhBbmRTZWFyY2godXJsLCBiYXNlUGF0aCkge1xuXHRjb25zdCBwYXRobmFtZSA9IHN0cmlwQmFzZVBhdGgodXJsLnBhdGhuYW1lLCBiYXNlUGF0aCk7XG5cdGNvbnN0IHF1ZXJ5ID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh1cmwuc2VhcmNoKS50b1N0cmluZygpO1xuXHRyZXR1cm4gcXVlcnkgPT09IFwiXCIgPyBwYXRobmFtZSA6IGAke3BhdGhuYW1lfT8ke3F1ZXJ5fWA7XG59XG5mdW5jdGlvbiBpc1NuYXBzaG90VGFyZ2V0SHJlZihiYXNlUGF0aCwgc25hcHNob3QsIHRhcmdldEhyZWYpIHtcblx0dHJ5IHtcblx0XHRjb25zdCBiYXNlSHJlZiA9IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIgPyBcImh0dHA6Ly9sb2NhbGhvc3RcIiA6IHdpbmRvdy5sb2NhdGlvbi5ocmVmO1xuXHRcdHJldHVybiBjcmVhdGVCYXNlUGF0aFN0cmlwcGVkUGF0aEFuZFNlYXJjaChuZXcgVVJMKHRhcmdldEhyZWYsIGJhc2VIcmVmKSwgYmFzZVBhdGgpID09PSBjcmVhdGVTbmFwc2hvdFBhdGhBbmRTZWFyY2goc25hcHNob3QpO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZUFwcEJyb3dzZXJOYXZpZ2F0aW9uQ29udHJvbGxlcihkZXBzID0ge30pIHtcblx0Y29uc3QgYmFzZVBhdGggPSBkZXBzLmJhc2VQYXRoID8/IFwiXCI7XG5cdGNvbnN0IGNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZUltcGwgPSBkZXBzLmNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZSA/PyBjb21taXRDbGllbnROYXZpZ2F0aW9uU3RhdGU7XG5cdGNvbnN0IHBlcmZvcm1IYXJkTmF2aWdhdGlvbiA9IGRlcHMucGVyZm9ybUhhcmROYXZpZ2F0aW9uID8/ICgoaHJlZiwgbW9kZSkgPT4gcGVyZm9ybUhhcmROYXZpZ2F0aW9uV2l0aExvb3BHdWFyZChocmVmLCBtb2RlLCBkZXBzLm5hdmlnYXRlRG9jdW1lbnQpKTtcblx0Y29uc3QgZ2V0Um91dGVNYW5pZmVzdCA9IGRlcHMuZ2V0Um91dGVNYW5pZmVzdCA/PyAoKCkgPT4gbnVsbCk7XG5cdGNvbnN0IGxvYWRSb3V0ZU1hbmlmZXN0ID0gZGVwcy5sb2FkUm91dGVNYW5pZmVzdCA/PyAoKCkgPT4gbnVsbCk7XG5cdGNvbnN0IHN5bmNIaXN0b3J5U3RhdGVQcmV2aW91c05leHRVcmwgPSBkZXBzLnN5bmNIaXN0b3J5U3RhdGVQcmV2aW91c05leHRVcmwgPz8gKCgpID0+IHt9KTtcblx0bGV0IG5leHROYXZpZ2F0aW9uUmVuZGVySWQgPSAwO1xuXHRsZXQgYWN0aXZlTmF2aWdhdGlvbklkID0gMDtcblx0bGV0IHBlbmRpbmdVc2VyTmF2aWdhdGlvbklkID0gbnVsbDtcblx0bGV0IHBlbmRpbmdVc2VyTmF2aWdhdGlvbkxhbmUgPSBudWxsO1xuXHRsZXQgY29tbWl0dGluZ05hdmlnYXRpb25SZW5kZXJJZCA9IG51bGw7XG5cdGxldCBwZW5kaW5nVXNlck5hdmlnYXRpb25Db21taXRTdGFydGVkID0gZmFsc2U7XG5cdGxldCBsYXRlc3RIbXJVcGRhdGVJZCA9IDA7XG5cdGNvbnN0IHBlbmRpbmdOYXZpZ2F0aW9uQ29tbWl0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGNvbnN0IHBlbmRpbmdOYXZpZ2F0aW9uRmFpbHVyZVRhcmdldHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRjb25zdCBwZW5kaW5nTmF2aWdhdGlvblByZVBhaW50RWZmZWN0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGNvbnN0IHNuYXBzaG90UmVuZGVySWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0bGV0IHBlbmRpbmdVc2VyTmF2aWdhdGlvblNoZWxsSHJlZiA9IG51bGw7XG5cdGxldCByZXRpcmVkTmF2aWdhdGlvblVybCA9IG51bGw7XG5cdGxldCBzZXRCcm93c2VyUm91dGVyU3RhdGUgPSBudWxsO1xuXHRsZXQgYnJvd3NlclJvdXRlclN0YXRlUmVmID0gbnVsbDtcblx0bGV0IGFjdGl2ZVBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUgPSBudWxsO1xuXHRsZXQgcmVzb2x2ZUJyb3dzZXJSb3V0ZXJTdGF0ZVJlYWR5ID0gbnVsbDtcblx0bGV0IGJyb3dzZXJSb3V0ZXJTdGF0ZVJlYWR5UHJvbWlzZSA9IG51bGw7XG5cdGxldCBicm93c2VyUm91dGVyU3RhdGVIYXNDb21taXR0ZWQgPSBmYWxzZTtcblx0ZnVuY3Rpb24gZ2V0QnJvd3NlclJvdXRlclN0YXRlU2V0dGVyKCkge1xuXHRcdGlmICghc2V0QnJvd3NlclJvdXRlclN0YXRlKSB0aHJvdyBuZXcgRXJyb3IoXCJbdmluZXh0XSBCcm93c2VyIHJvdXRlciBzdGF0ZSBzZXR0ZXIgaXMgbm90IGluaXRpYWxpemVkXCIpO1xuXHRcdHJldHVybiBzZXRCcm93c2VyUm91dGVyU3RhdGU7XG5cdH1cblx0ZnVuY3Rpb24gZ2V0QnJvd3NlclJvdXRlclN0YXRlKCkge1xuXHRcdGlmICghYnJvd3NlclJvdXRlclN0YXRlUmVmKSB0aHJvdyBuZXcgRXJyb3IoXCJbdmluZXh0XSBCcm93c2VyIHJvdXRlciBzdGF0ZSBpcyBub3QgaW5pdGlhbGl6ZWRcIik7XG5cdFx0cmV0dXJuIGJyb3dzZXJSb3V0ZXJTdGF0ZVJlZi5jdXJyZW50O1xuXHR9XG5cdGZ1bmN0aW9uIHdhaXRGb3JCcm93c2VyUm91dGVyU3RhdGVSZWFkeSgpIHtcblx0XHRpZiAoYnJvd3NlclJvdXRlclN0YXRlUmVmIHx8IGJyb3dzZXJSb3V0ZXJTdGF0ZUhhc0NvbW1pdHRlZCkgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdGlmICghYnJvd3NlclJvdXRlclN0YXRlUmVhZHlQcm9taXNlKSBicm93c2VyUm91dGVyU3RhdGVSZWFkeVByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdFx0cmVzb2x2ZUJyb3dzZXJSb3V0ZXJTdGF0ZVJlYWR5ID0gcmVzb2x2ZTtcblx0XHR9KTtcblx0XHRyZXR1cm4gYnJvd3NlclJvdXRlclN0YXRlUmVhZHlQcm9taXNlO1xuXHR9XG5cdGZ1bmN0aW9uIG1hcmtCcm93c2VyUm91dGVyU3RhdGVSZWFkeSgpIHtcblx0XHRicm93c2VyUm91dGVyU3RhdGVIYXNDb21taXR0ZWQgPSB0cnVlO1xuXHRcdGNvbnN0IHJlc29sdmVSZWFkeSA9IHJlc29sdmVCcm93c2VyUm91dGVyU3RhdGVSZWFkeTtcblx0XHRyZXNvbHZlQnJvd3NlclJvdXRlclN0YXRlUmVhZHkgPSBudWxsO1xuXHRcdGJyb3dzZXJSb3V0ZXJTdGF0ZVJlYWR5UHJvbWlzZSA9IG51bGw7XG5cdFx0cmVzb2x2ZVJlYWR5Py4oKTtcblx0fVxuXHRmdW5jdGlvbiBiZWdpbk5hdmlnYXRpb24oKSB7XG5cdFx0bGF0ZXN0SG1yVXBkYXRlSWQgKz0gMTtcblx0XHRhY3RpdmVOYXZpZ2F0aW9uSWQgKz0gMTtcblx0XHRwZW5kaW5nVXNlck5hdmlnYXRpb25JZCA9IGFjdGl2ZU5hdmlnYXRpb25JZDtcblx0XHRwZW5kaW5nVXNlck5hdmlnYXRpb25MYW5lID0gbnVsbDtcblx0XHRwZW5kaW5nVXNlck5hdmlnYXRpb25Db21taXRTdGFydGVkID0gZmFsc2U7XG5cdFx0cGVuZGluZ1VzZXJOYXZpZ2F0aW9uU2hlbGxIcmVmID0gbnVsbDtcblx0XHRyZXRpcmVkTmF2aWdhdGlvblVybCA9IG51bGw7XG5cdFx0cmV0dXJuIGFjdGl2ZU5hdmlnYXRpb25JZDtcblx0fVxuXHRmdW5jdGlvbiBnZXRBY3RpdmVOYXZpZ2F0aW9uSWQoKSB7XG5cdFx0cmV0dXJuIGFjdGl2ZU5hdmlnYXRpb25JZDtcblx0fVxuXHRmdW5jdGlvbiBhbGxvY2F0ZVJlbmRlcklkKCkge1xuXHRcdG5leHROYXZpZ2F0aW9uUmVuZGVySWQgKz0gMTtcblx0XHRyZXR1cm4gbmV4dE5hdmlnYXRpb25SZW5kZXJJZDtcblx0fVxuXHRmdW5jdGlvbiBoYXNCcm93c2VyUm91dGVyU3RhdGUoKSB7XG5cdFx0cmV0dXJuIGJyb3dzZXJSb3V0ZXJTdGF0ZVJlZiAhPT0gbnVsbDtcblx0fVxuXHRmdW5jdGlvbiBpc0N1cnJlbnROYXZpZ2F0aW9uKG5hdklkKSB7XG5cdFx0cmV0dXJuIG5hdklkID09PSBhY3RpdmVOYXZpZ2F0aW9uSWQ7XG5cdH1cblx0ZnVuY3Rpb24gYmVnaW5QZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlKCkge1xuXHRcdGNvbnN0IHNldHRlciA9IGdldEJyb3dzZXJSb3V0ZXJTdGF0ZVNldHRlcigpO1xuXHRcdGlmIChhY3RpdmVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlICYmICFhY3RpdmVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlLnNldHRsZWQpIHtcblx0XHRcdGFjdGl2ZVBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUuc2V0dGxlZCA9IHRydWU7XG5cdFx0XHRhY3RpdmVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlLnJlc29sdmUoZ2V0QnJvd3NlclJvdXRlclN0YXRlKCkpO1xuXHRcdH1cblx0XHRsZXQgcmVzb2x2ZVBlbmRpbmc7XG5cdFx0Y29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRyZXNvbHZlUGVuZGluZyA9IHJlc29sdmU7XG5cdFx0fSk7XG5cdFx0aWYgKCFyZXNvbHZlUGVuZGluZykgdGhyb3cgbmV3IEVycm9yKFwiW3ZpbmV4dF0gRmFpbGVkIHRvIGluaXRpYWxpemUgYnJvd3NlciByb3V0ZXIgcHJvbWlzZVwiKTtcblx0XHRjb25zdCBwZW5kaW5nID0ge1xuXHRcdFx0cHJvbWlzZSxcblx0XHRcdHJlc29sdmU6IHJlc29sdmVQZW5kaW5nLFxuXHRcdFx0c2V0dGxlZDogZmFsc2Vcblx0XHR9O1xuXHRcdGFjdGl2ZVBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUgPSBwZW5kaW5nO1xuXHRcdHNldHRlcihwcm9taXNlKTtcblx0XHRyZXR1cm4gcGVuZGluZztcblx0fVxuXHRmdW5jdGlvbiBzZXR0bGVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlKHBlbmRpbmcpIHtcblx0XHRpZiAoIXBlbmRpbmcgfHwgcGVuZGluZy5zZXR0bGVkKSByZXR1cm47XG5cdFx0cGVuZGluZy5zZXR0bGVkID0gdHJ1ZTtcblx0XHRwZW5kaW5nLnJlc29sdmUoZ2V0QnJvd3NlclJvdXRlclN0YXRlKCkpO1xuXHRcdGlmIChhY3RpdmVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlID09PSBwZW5kaW5nKSBhY3RpdmVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlID0gbnVsbDtcblx0fVxuXHRmdW5jdGlvbiBhYmFuZG9uUGVuZGluZ0Jyb3dzZXJSb3V0ZXJTdGF0ZShwZW5kaW5nKSB7XG5cdFx0aWYgKCFwZW5kaW5nIHx8IHBlbmRpbmcuc2V0dGxlZCkgcmV0dXJuO1xuXHRcdHBlbmRpbmcuc2V0dGxlZCA9IHRydWU7XG5cdFx0aWYgKGFjdGl2ZVBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUgPT09IHBlbmRpbmcpIGFjdGl2ZVBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUgPSBudWxsO1xuXHR9XG5cdGZ1bmN0aW9uIGZpbmFsaXplTmF2aWdhdGlvbihuYXZJZCwgcGVuZGluZykge1xuXHRcdHNldHRsZVBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUocGVuZGluZyk7XG5cdFx0aWYgKGlzQ3VycmVudE5hdmlnYXRpb24obmF2SWQpKSB7XG5cdFx0XHRwZW5kaW5nVXNlck5hdmlnYXRpb25JZCA9IG51bGw7XG5cdFx0XHRwZW5kaW5nVXNlck5hdmlnYXRpb25MYW5lID0gbnVsbDtcblx0XHRcdHBlbmRpbmdVc2VyTmF2aWdhdGlvblNoZWxsSHJlZiA9IG51bGw7XG5cdFx0XHRyZXRpcmVkTmF2aWdhdGlvblVybCA9IG51bGw7XG5cdFx0XHRjbGVhclBlbmRpbmdQYXRobmFtZShuYXZJZCk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIERpc2NhcmQgdGhlIHVzZXIgbmF2aWdhdGlvbiB0aGF0IGhhcyBub3QgY29tbWl0dGVkIHlldCwga2VlcGluZ1xuXHQqIGB2aXNpYmxlU3RhdGVgICh0aGUgY29tbWl0dGVkIHRyZWUpIG9uIHNjcmVlbi4gTmV4dC5qcyBkb2VzIHRoZSBzYW1lIHdoZW5cblx0KiBhIHJhdyBoaXN0b3J5LnB1c2hTdGF0ZS9yZXBsYWNlU3RhdGUgZGlzcGF0Y2hlcyBBQ1RJT05fUkVTVE9SRTogdGhlXG5cdCogcGVuZGluZyBhY3Rpb24gaXMgbWFya2VkIGRpc2NhcmRlZCBhbmQgdGhlIHJlc3RvcmUgY29tbWl0cyB0aGUgY3VycmVudFxuXHQqIHRyZWUgaW4gYSB0cmFuc2l0aW9uLCB3aGljaCByZXBsYWNlcyB0aGUgbmF2aWdhdGlvbidzIHN1c3BlbmRlZCBvbmUuXG5cdCogUmV0dXJucyB3aGV0aGVyIGEgbmF2aWdhdGlvbiB3YXMgZGlzY2FyZGVkLlxuXHQqL1xuXHRmdW5jdGlvbiBkaXNjYXJkUGVuZGluZ05hdmlnYXRpb24odmlzaWJsZVN0YXRlKSB7XG5cdFx0aWYgKHBlbmRpbmdVc2VyTmF2aWdhdGlvbklkID09PSBudWxsIHx8IHBlbmRpbmdVc2VyTmF2aWdhdGlvbkNvbW1pdFN0YXJ0ZWQpIHJldHVybiBmYWxzZTtcblx0XHRpZiAocGVuZGluZ1VzZXJOYXZpZ2F0aW9uU2hlbGxIcmVmICE9PSBudWxsKSB7XG5cdFx0XHRyZXRpcmVkTmF2aWdhdGlvblVybCA9IHtcblx0XHRcdFx0bmF2aWdhdGlvbklkOiBwZW5kaW5nVXNlck5hdmlnYXRpb25JZCxcblx0XHRcdFx0aHJlZjogcGVuZGluZ1VzZXJOYXZpZ2F0aW9uU2hlbGxIcmVmXG5cdFx0XHR9O1xuXHRcdFx0Zm9yIChjb25zdCByZW5kZXJJZCBvZiBwZW5kaW5nTmF2aWdhdGlvblByZVBhaW50RWZmZWN0cy5rZXlzKCkpIHJlbGVhc2VSZW5kZXJTbmFwc2hvdChyZW5kZXJJZCk7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHRcdGFjdGl2ZU5hdmlnYXRpb25JZCArPSAxO1xuXHRcdHBlbmRpbmdVc2VyTmF2aWdhdGlvbklkID0gbnVsbDtcblx0XHRwZW5kaW5nVXNlck5hdmlnYXRpb25MYW5lID0gbnVsbDtcblx0XHRjbGVhckFwcFJvdXRlclNjcm9sbEludGVudCgpO1xuXHRcdGZvciAoY29uc3QgcmVuZGVySWQgb2YgcGVuZGluZ05hdmlnYXRpb25QcmVQYWludEVmZmVjdHMua2V5cygpKSB7XG5cdFx0XHRwZW5kaW5nTmF2aWdhdGlvblByZVBhaW50RWZmZWN0cy5kZWxldGUocmVuZGVySWQpO1xuXHRcdFx0cmVsZWFzZVJlbmRlclNuYXBzaG90KHJlbmRlcklkKTtcblx0XHR9XG5cdFx0Y2xlYXJDb21taXR0ZWROYXZpZ2F0aW9uRmFpbHVyZVRhcmdldHMobmV4dE5hdmlnYXRpb25SZW5kZXJJZCk7XG5cdFx0c2V0dGxlTmF2aWdhdGlvbkNvbW1pdHMobmV4dE5hdmlnYXRpb25SZW5kZXJJZCwgZmFsc2UpO1xuXHRcdGlmICh2aXNpYmxlU3RhdGUgJiYgc2V0QnJvd3NlclJvdXRlclN0YXRlKSB7XG5cdFx0XHRjb25zdCBzZXR0ZXIgPSBzZXRCcm93c2VyUm91dGVyU3RhdGU7XG5cdFx0XHRzdGFydFRyYW5zaXRpb24oKCkgPT4ge1xuXHRcdFx0XHRzZXR0ZXIodmlzaWJsZVN0YXRlKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXHQvKipcblx0KiBQdWJsaXNoIHRoZSBVUkwgdXBkYXRlIG9mIGEgbmF2aWdhdGlvbiByZW5kZXIgUmVhY3QgaXMgY29tbWl0dGluZyByaWdodFxuXHQqIG5vdy4gSXRzIGhpc3RvcnkgZW50cnkgaXMgYWxyZWFkeSB3cml0dGVuLCBidXQgcHVibGlzaGluZyBub3JtYWxseSBydW5zIGluXG5cdCogTmF2aWdhdGlvbkNvbW1pdFNpZ25hbCdzIGxheW91dCBlZmZlY3QsIGFmdGVyIHRoZSByb3V0ZSdzIG93biBsYXlvdXRcblx0KiBlZmZlY3RzLiBDYWxsZWQgYmVmb3JlIGEgcmF3IGhpc3Rvcnkgd3JpdGUgZnJvbSBzdWNoIGFuIGVmZmVjdCwgc28gdGhlXG5cdCogd3JpdGUgaXMgcHVibGlzaGVkIG9uIHRvcCBvZiB0aGUgZGVzdGluYXRpb24ncy5cblx0Ki9cblx0ZnVuY3Rpb24gZmx1c2hDb21taXR0aW5nTmF2aWdhdGlvblVybCgpIHtcblx0XHRpZiAoY29tbWl0dGluZ05hdmlnYXRpb25SZW5kZXJJZCAhPT0gbnVsbCkgZHJhaW5QcmVQYWludEVmZmVjdHMoY29tbWl0dGluZ05hdmlnYXRpb25SZW5kZXJJZCk7XG5cdH1cblx0ZnVuY3Rpb24gcmVsZWFzZVJlbmRlclNuYXBzaG90KHJlbmRlcklkKSB7XG5cdFx0aWYgKHNuYXBzaG90UmVuZGVySWRzLmRlbGV0ZShyZW5kZXJJZCkpIGNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZUltcGwodm9pZCAwLCB7IHJlbGVhc2VTbmFwc2hvdDogdHJ1ZSB9KTtcblx0fVxuXHRmdW5jdGlvbiBpc1JldGlyZWROYXZpZ2F0aW9uVXJsKG5hdklkLCB0YXJnZXRIcmVmKSB7XG5cdFx0cmV0dXJuIHJldGlyZWROYXZpZ2F0aW9uVXJsICE9PSBudWxsICYmIHJldGlyZWROYXZpZ2F0aW9uVXJsLm5hdmlnYXRpb25JZCA9PT0gbmF2SWQgJiYgcmV0aXJlZE5hdmlnYXRpb25VcmwuaHJlZiA9PT0gbm9ybWFsaXplQnJvd3NlckhyZWYodGFyZ2V0SHJlZik7XG5cdH1cblx0ZnVuY3Rpb24gd3JpdGVOYXZpZ2F0aW9uUmVuZGVySGlzdG9yeShyZW5kZXJJZCkge1xuXHRcdGNvbnN0IGVmZmVjdCA9IHBlbmRpbmdOYXZpZ2F0aW9uUHJlUGFpbnRFZmZlY3RzLmdldChyZW5kZXJJZCk7XG5cdFx0Y29uc3Qgd3JpdGVIaXN0b3J5ID0gZWZmZWN0Py53cml0ZUhpc3Rvcnk7XG5cdFx0aWYgKCFlZmZlY3QgfHwgIXdyaXRlSGlzdG9yeSkgcmV0dXJuO1xuXHRcdGVmZmVjdC53cml0ZUhpc3RvcnkgPSBudWxsO1xuXHRcdHdyaXRlSGlzdG9yeSgpO1xuXHR9XG5cdC8qKlxuXHQqIFJ1biBhbGwgcXVldWVkIHByZS1wYWludCBlZmZlY3RzIGZvciByZW5kZXJJZHMgdXAgdG8gYW5kIGluY2x1ZGluZyB0aGVcblx0KiBnaXZlbiByZW5kZXJJZC4gV2hlbiBSZWFjdCBzdXBlcnNlZGVzIGEgc3RhcnRUcmFuc2l0aW9uIHVwZGF0ZSAocmFwaWRcblx0KiBjbGlja3Mgb24gc2FtZS1yb3V0ZSBsaW5rcyksIHRoZSBzdXBlcnNlZGVkIE5hdmlnYXRpb25Db21taXRTaWduYWwgbmV2ZXJcblx0KiBtb3VudHMsIHNvIGl0cyBwcmUtcGFpbnQgZWZmZWN0IG5ldmVyIGZpcmVzLiBCeSBkcmFpbmluZyBhbGwgZWZmZWN0c1xuXHQqIDw9IHRoZSBjb21taXR0ZWQgcmVuZGVySWQgaGVyZSwgdGhlIHdpbm5pbmcgdHJhbnNpdGlvbiBjbGVhbnMgdXAgYWZ0ZXJcblx0KiBhbnkgc3VwZXJzZWRlZCBvbmVzLCBrZWVwaW5nIHRoZSBjb3VudGVyIGJhbGFuY2VkLlxuXHQqXG5cdCogSW52YXJpYW50OiBlYWNoIHN1cGVyc2VkZWQgbmF2aWdhdGlvbiBnZXRzIGEgY29tbWl0Q2xpZW50TmF2aWdhdGlvblN0YXRlKClcblx0KiB0byBiYWxhbmNlIHRoZSBhY3RpdmF0ZU5hdmlnYXRpb25TbmFwc2hvdCgpIGZyb20gaXRzIHJlbmRlck5hdmlnYXRpb25QYXlsb2FkIGNhbGwuXG5cdCovXG5cdGZ1bmN0aW9uIGRyYWluUHJlUGFpbnRFZmZlY3RzKHVwVG9SZW5kZXJJZCkge1xuXHRcdGZvciAoY29uc3QgW2lkLCBlZmZlY3RdIG9mIHBlbmRpbmdOYXZpZ2F0aW9uUHJlUGFpbnRFZmZlY3RzKSB7XG5cdFx0XHRpZiAoaWQgPiB1cFRvUmVuZGVySWQpIGNvbnRpbnVlO1xuXHRcdFx0cGVuZGluZ05hdmlnYXRpb25QcmVQYWludEVmZmVjdHMuZGVsZXRlKGlkKTtcblx0XHRcdGlmIChpZCA9PT0gdXBUb1JlbmRlcklkKSB7XG5cdFx0XHRcdGVmZmVjdC53cml0ZUhpc3Rvcnk/LigpO1xuXHRcdFx0XHRlZmZlY3QucHVibGlzaCgpO1xuXHRcdFx0fSBlbHNlIHJlbGVhc2VSZW5kZXJTbmFwc2hvdChpZCk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFNldHRsZSBhbGwgcGVuZGluZyBuYXZpZ2F0aW9uIHJlbmRlcnMgdGhyb3VnaCB0aGUgc3VwcGxpZWQgcmVuZGVySWQuIE9ubHlcblx0KiB0aGUgZXhhY3QgcmVuZGVyIHdob3NlIGxheW91dCBlZmZlY3QgcmFuIGlzIGEgc3VjY2Vzc2Z1bCBjb21taXQ7IG9sZGVyXG5cdCogc3VwZXJzZWRlZCByZW5kZXJzIGFuZCBjbGVhbnVwLW9ubHkgc2V0dGxlbWVudHMgcmVzb2x2ZSBhcyBuby1jb21taXQuXG5cdCovXG5cdGZ1bmN0aW9uIHNldHRsZU5hdmlnYXRpb25Db21taXRzKHJlbmRlcklkLCBjb21taXR0ZWQpIHtcblx0XHRmb3IgKGNvbnN0IFtwZW5kaW5nSWQsIHBlbmRpbmdDb21taXRdIG9mIHBlbmRpbmdOYXZpZ2F0aW9uQ29tbWl0cykge1xuXHRcdFx0aWYgKHBlbmRpbmdJZCA+IHJlbmRlcklkKSBjb250aW51ZTtcblx0XHRcdHBlbmRpbmdOYXZpZ2F0aW9uQ29tbWl0cy5kZWxldGUocGVuZGluZ0lkKTtcblx0XHRcdGNvbnN0IGRpZENvbW1pdCA9IGNvbW1pdHRlZCAmJiBwZW5kaW5nSWQgPT09IHJlbmRlcklkO1xuXHRcdFx0aWYgKGRpZENvbW1pdCAmJiBwZW5kaW5nQ29tbWl0LmNvbW1pdHRlZFN0YXRlICE9PSBudWxsKSBwZW5kaW5nQ29tbWl0Lm9uQ29tbWl0dGVkU3RhdGU/LihwZW5kaW5nQ29tbWl0LmNvbW1pdHRlZFN0YXRlKTtcblx0XHRcdHBlbmRpbmdDb21taXQucmVzb2x2ZShkaWRDb21taXQpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBSdW5zIHdoZW4gUmVhY3Qgc3RhcnRzIGNvbW1pdHRpbmcgYSByZW5kZXIsIGJlZm9yZSBpdCBjaGFuZ2VzIHRoZSByb3V0ZVxuXHQqIHRyZWUncyBET00sIGFuZCB3cml0ZXMgdGhlIHJlbmRlcidzIGhpc3RvcnkgZW50cnkuXG5cdCovXG5cdGZ1bmN0aW9uIGJlZ2luTmF2aWdhdGlvblJlbmRlckNvbW1pdChyZW5kZXJJZCkge1xuXHRcdGNvbW1pdHRpbmdOYXZpZ2F0aW9uUmVuZGVySWQgPSByZW5kZXJJZDtcblx0XHRjb25zdCBjb21taXR0aW5nQ29tbWl0ID0gcGVuZGluZ05hdmlnYXRpb25Db21taXRzLmdldChyZW5kZXJJZCk7XG5cdFx0Y29uc3QgY29tbWl0dGluZ09wZXJhdGlvbiA9IGNvbW1pdHRpbmdDb21taXQ/LmNvbW1pdHRlZFN0YXRlPy5hY3RpdmVPcGVyYXRpb247XG5cdFx0aWYgKGNvbW1pdHRpbmdDb21taXQgJiYgY29tbWl0dGluZ09wZXJhdGlvbj8ubmF2aWdhdGlvbkNvbW1pdEtpbmQgPT09IFwiZGV0YWNoZWRcIiAmJiBjb21taXR0aW5nT3BlcmF0aW9uLm5hdmlnYXRpb25JZCA9PT0gcGVuZGluZ1VzZXJOYXZpZ2F0aW9uSWQpIHBlbmRpbmdVc2VyTmF2aWdhdGlvblNoZWxsSHJlZiA9IG5vcm1hbGl6ZUJyb3dzZXJIcmVmKGNvbW1pdHRpbmdDb21taXQudGFyZ2V0SHJlZik7XG5cdFx0ZWxzZSBwZW5kaW5nVXNlck5hdmlnYXRpb25Db21taXRTdGFydGVkID0gdHJ1ZTtcblx0XHRjbGVhckNvbW1pdHRlZE5hdmlnYXRpb25GYWlsdXJlVGFyZ2V0cyhyZW5kZXJJZCk7XG5cdFx0d3JpdGVOYXZpZ2F0aW9uUmVuZGVySGlzdG9yeShyZW5kZXJJZCk7XG5cdH1cblx0ZnVuY3Rpb24gY29tbWl0TmF2aWdhdGlvblJlbmRlcihyZW5kZXJJZCkge1xuXHRcdGNvbW1pdHRpbmdOYXZpZ2F0aW9uUmVuZGVySWQgPSBudWxsO1xuXHRcdGRyYWluUHJlUGFpbnRFZmZlY3RzKHJlbmRlcklkKTtcblx0XHRzZXR0bGVOYXZpZ2F0aW9uQ29tbWl0cyhyZW5kZXJJZCwgdHJ1ZSk7XG5cdH1cblx0ZnVuY3Rpb24gY2xlYXJDb21taXR0ZWROYXZpZ2F0aW9uRmFpbHVyZVRhcmdldHMocmVuZGVySWQpIHtcblx0XHRmb3IgKGNvbnN0IFtwZW5kaW5nSWQsIHRhcmdldEhyZWZdIG9mIHBlbmRpbmdOYXZpZ2F0aW9uRmFpbHVyZVRhcmdldHMpIHtcblx0XHRcdGlmIChwZW5kaW5nSWQgPiByZW5kZXJJZCkgY29udGludWU7XG5cdFx0XHRwZW5kaW5nTmF2aWdhdGlvbkZhaWx1cmVUYXJnZXRzLmRlbGV0ZShwZW5kaW5nSWQpO1xuXHRcdFx0Y2xlYXJBcHBOYXZpZ2F0aW9uRmFpbHVyZVRhcmdldCh0YXJnZXRIcmVmKTtcblx0XHR9XG5cdH1cblx0YXN5bmMgZnVuY3Rpb24gaG1yUmVwbGFjZVRyZWUobmV4dEVsZW1lbnRzLCBwZW5kaW5nTmF2aWdhdGlvblNuYXBzaG90KSB7XG5cdFx0Y29uc3QgaG1yVXBkYXRlSWQgPSArK2xhdGVzdEhtclVwZGF0ZUlkO1xuXHRcdGNvbnN0IHN0YXJ0ZWREdXJpbmdVc2VyTmF2aWdhdGlvbiA9IHBlbmRpbmdVc2VyTmF2aWdhdGlvbkxhbmUgPT09IFwibmF2aWdhdGlvblwiO1xuXHRcdGlmICghaGFzQnJvd3NlclJvdXRlclN0YXRlKCkpIHJldHVybjtcblx0XHRjb25zdCBjdXJyZW50U3RhdGUgPSBnZXRCcm93c2VyUm91dGVyU3RhdGUoKTtcblx0XHRjb25zdCByZW5kZXJJZCA9IGFsbG9jYXRlUmVuZGVySWQoKTtcblx0XHRjb25zdCBbbmF2aWdhdGlvblNuYXBzaG90LCAsIHJvdXRlTWFuaWZlc3RMb2FkZWRdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuXHRcdFx0cGVuZGluZ05hdmlnYXRpb25TbmFwc2hvdCxcblx0XHRcdG5leHRFbGVtZW50cyxcblx0XHRcdGxvYWRSb3V0ZU1hbmlmZXN0KClcblx0XHRdKTtcblx0XHRjb25zdCBwZW5kaW5nID0gYXdhaXQgY3JlYXRlUGVuZGluZ05hdmlnYXRpb25Db21taXQoe1xuXHRcdFx0Y3VycmVudFN0YXRlLFxuXHRcdFx0bmV4dEVsZW1lbnRzLFxuXHRcdFx0bmF2aWdhdGlvblNuYXBzaG90LFxuXHRcdFx0b3BlcmF0aW9uTGFuZTogXCJobXJcIixcblx0XHRcdHBheWxvYWRPcmlnaW46IEZSRVNIX0FQUF9OQVZJR0FUSU9OX1BBWUxPQURfT1JJR0lOLFxuXHRcdFx0cmVuZGVySWQsXG5cdFx0XHR0eXBlOiBcInJlcGxhY2VcIlxuXHRcdH0pO1xuXHRcdGlmIChobXJVcGRhdGVJZCAhPT0gbGF0ZXN0SG1yVXBkYXRlSWQgfHwgc3RhcnRlZER1cmluZ1VzZXJOYXZpZ2F0aW9uKSByZXR1cm47XG5cdFx0aWYgKCFoYXNCcm93c2VyUm91dGVyU3RhdGUoKSkgcmV0dXJuO1xuXHRcdGlmIChyb3V0ZU1hbmlmZXN0TG9hZGVkID09PSBmYWxzZSkge1xuXHRcdFx0cGVyZm9ybUhhcmROYXZpZ2F0aW9uKHdpdGhCYXNlUGF0aChjcmVhdGVTbmFwc2hvdFBhdGhBbmRTZWFyY2gobmF2aWdhdGlvblNuYXBzaG90KSwgYmFzZVBhdGgpKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgYXBwcm92YWwgPSBhcHByb3ZlSG1yVmlzaWJsZUNvbW1pdCh7XG5cdFx0XHRjdXJyZW50U3RhdGU6IGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpLFxuXHRcdFx0cGVuZGluZyxcblx0XHRcdHJvdXRlTWFuaWZlc3Q6IGRlcHMuZ2V0Um91dGVNYW5pZmVzdD8uKCkgPz8gbnVsbCxcblx0XHRcdHRhcmdldEhyZWY6IGNyZWF0ZVNuYXBzaG90UGF0aEFuZFNlYXJjaChuYXZpZ2F0aW9uU25hcHNob3QpXG5cdFx0fSk7XG5cdFx0aWYgKGFwcHJvdmFsLmFwcHJvdmVkQ29tbWl0KSB7XG5cdFx0XHRjb25zdCBhcHByb3ZlZEhtckNvbW1pdCA9IGFwcHJvdmFsLmFwcHJvdmVkQ29tbWl0O1xuXHRcdFx0c3RhcnRUcmFuc2l0aW9uKCgpID0+IHtcblx0XHRcdFx0ZGlzcGF0Y2hWaXNpYmxlQ29tbWl0KGFwcHJvdmVkSG1yQ29tbWl0KTtcblx0XHRcdH0pO1xuXHRcdH0gZWxzZSBpZiAoYXBwcm92YWwuZGVjaXNpb24uZGlzcG9zaXRpb24gPT09IFwiaGFyZC1uYXZpZ2F0ZVwiKSBwZXJmb3JtSGFyZE5hdmlnYXRpb24oY3JlYXRlU25hcHNob3RQYXRoQW5kU2VhcmNoKG5hdmlnYXRpb25TbmFwc2hvdCkpO1xuXHR9XG5cdC8qKlxuXHQqIFJlbmRlcmVkIGJlZm9yZSB0aGUgcm91dGUgdHJlZSAoc2VlIGNyZWF0ZUFwcFJvdXRlVHJlZSkuIEluc2VydGlvbiBlZmZlY3RzXG5cdCogcnVuIGluIHRoZSBtdXRhdGlvbiBwaGFzZSwgaW4gdHJlZSBvcmRlciwgYWZ0ZXIgZWFjaCBjb21wb25lbnQncyBvd25cblx0KiBzdWJ0cmVlIG11dGF0aW9ucywgc28gdGhpcyBvbmUgcnVucyBiZWZvcmUgUmVhY3QgY2hhbmdlcyB0aGUgcm91dGUgdHJlZSdzXG5cdCogRE9NLiBBbiBlZmZlY3Qgb24gTmF2aWdhdGlvbkNvbW1pdFNpZ25hbCBpdHNlbGYgd291bGQgcnVuIGFmdGVyIHRoZW0uXG5cdCovXG5cdGZ1bmN0aW9uIE5hdmlnYXRpb25IaXN0b3J5Q29tbWl0KHsgcmVuZGVySWQgfSkge1xuXHRcdHVzZUluc2VydGlvbkVmZmVjdCgoKSA9PiB7XG5cdFx0XHRiZWdpbk5hdmlnYXRpb25SZW5kZXJDb21taXQocmVuZGVySWQpO1xuXHRcdH0sIFtyZW5kZXJJZF0pO1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdGZ1bmN0aW9uIE5hdmlnYXRpb25Db21taXRTaWduYWwoeyByZW5kZXJJZCwgY2hpbGRyZW4gfSkge1xuXHRcdHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG5cdFx0XHRjb21taXROYXZpZ2F0aW9uUmVuZGVyKHJlbmRlcklkKTtcblx0XHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRcdHNldHRsZU5hdmlnYXRpb25Db21taXRzKHJlbmRlcklkLCBmYWxzZSk7XG5cdFx0XHR9O1xuXHRcdH0sIFtyZW5kZXJJZF0pO1xuXHRcdHJldHVybiBjaGlsZHJlbjtcblx0fVxuXHRmdW5jdGlvbiBkaXNwYXRjaEFwcHJvdmVkVmlzaWJsZUNvbW1pdChyZW5kZXJJZCwgY29tbWl0LCBwZW5kaW5nUm91dGVyU3RhdGUsIHZpc2libGVDb21taXRNb2RlLCByZXB1Ymxpc2hQZW5kaW5nUm91dGVyU3RhdGUpIHtcblx0XHRjb25zdCBzZXR0ZXIgPSBnZXRCcm93c2VyUm91dGVyU3RhdGVTZXR0ZXIoKTtcblx0XHRjb25zdCBwZW5kaW5nQ29tbWl0ID0gcGVuZGluZ05hdmlnYXRpb25Db21taXRzLmdldChyZW5kZXJJZCk7XG5cdFx0Y29uc3QgY2FwdHVyZUNhbmRpZGF0ZVN0YXRlID0gKHN0YXRlKSA9PiB7XG5cdFx0XHRpZiAocGVuZGluZ0NvbW1pdCkgcGVuZGluZ0NvbW1pdC5jb21taXR0ZWRTdGF0ZSA9IHN0YXRlO1xuXHRcdFx0cmV0dXJuIHN0YXRlO1xuXHRcdH07XG5cdFx0aWYgKHBlbmRpbmdSb3V0ZXJTdGF0ZSkge1xuXHRcdFx0aWYgKHBlbmRpbmdSb3V0ZXJTdGF0ZS5zZXR0bGVkKSByZXR1cm47XG5cdFx0XHRjb25zdCBjb21taXR0ZWRTdGF0ZSA9IGNhcHR1cmVDYW5kaWRhdGVTdGF0ZShhcHBseUFwcHJvdmVkVmlzaWJsZUNvbW1pdChnZXRCcm93c2VyUm91dGVyU3RhdGUoKSwgY29tbWl0KSk7XG5cdFx0XHRwZW5kaW5nUm91dGVyU3RhdGUuc2V0dGxlZCA9IHRydWU7XG5cdFx0XHRwZW5kaW5nUm91dGVyU3RhdGUucmVzb2x2ZShjb21taXR0ZWRTdGF0ZSk7XG5cdFx0XHRpZiAoYWN0aXZlUGVuZGluZ0Jyb3dzZXJSb3V0ZXJTdGF0ZSA9PT0gcGVuZGluZ1JvdXRlclN0YXRlKSBhY3RpdmVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlID0gbnVsbDtcblx0XHRcdGlmIChyZXB1Ymxpc2hQZW5kaW5nUm91dGVyU3RhdGUpIHN0YXJ0VHJhbnNpdGlvbigoKSA9PiB7XG5cdFx0XHRcdHNldHRlcihjb21taXR0ZWRTdGF0ZSk7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0aWYgKHZpc2libGVDb21taXRNb2RlID09PSBcInN5bmNocm9ub3VzXCIpIHtcblx0XHRcdGZsdXNoU3luYygoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGNvbW1pdHRlZFN0YXRlID0gY2FwdHVyZUNhbmRpZGF0ZVN0YXRlKGFwcGx5QXBwcm92ZWRWaXNpYmxlQ29tbWl0KGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpLCBjb21taXQpKTtcblx0XHRcdFx0c2V0dGVyKGNvbW1pdHRlZFN0YXRlKTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRzdGFydFRyYW5zaXRpb24oKCkgPT4ge1xuXHRcdFx0Y29uc3QgY29tbWl0dGVkU3RhdGUgPSBjYXB0dXJlQ2FuZGlkYXRlU3RhdGUoYXBwbHlBcHByb3ZlZFZpc2libGVDb21taXQoZ2V0QnJvd3NlclJvdXRlclN0YXRlKCksIGNvbW1pdCkpO1xuXHRcdFx0c2V0dGVyKGNvbW1pdHRlZFN0YXRlKTtcblx0XHR9KTtcblx0fVxuXHQvKiogQ2FsbHMgdGhlIHNldHRlciBkaXJlY3RseTsgdGhlIGNhbGxlciBjaG9vc2VzIHRoZSB1cGRhdGUncyBwcmlvcml0eS4gKi9cblx0ZnVuY3Rpb24gZGlzcGF0Y2hWaXNpYmxlQ29tbWl0KGNvbW1pdCkge1xuXHRcdGdldEJyb3dzZXJSb3V0ZXJTdGF0ZVNldHRlcigpKGFwcGx5QXBwcm92ZWRWaXNpYmxlQ29tbWl0KGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpLCBjb21taXQpKTtcblx0fVxuXHRmdW5jdGlvbiBjcmVhdGVSZXN0b3JlZEhpc3RvcnlTbmFwc2hvdENvbW1pdChvcHRpb25zKSB7XG5cdFx0Y29uc3Qgb3BlcmF0aW9uID0ge1xuXHRcdFx0aWQ6IG9wdGlvbnMucmVuZGVySWQsXG5cdFx0XHRsYW5lOiBcInRyYXZlcnNlXCIsXG5cdFx0XHRzdGFydGVkVmlzaWJsZUNvbW1pdFZlcnNpb246IG9wdGlvbnMuY3VycmVudFN0YXRlLnZpc2libGVDb21taXRWZXJzaW9uLFxuXHRcdFx0c3RhdGU6IFwicGVuZGluZ1wiXG5cdFx0fTtcblx0XHRyZXR1cm4ge1xuXHRcdFx0YWN0aW9uOiB7XG5cdFx0XHRcdGJmY2FjaGVJZHM6IG9wdGlvbnMucmVzdG9yZWRTdGF0ZS5iZmNhY2hlSWRzLFxuXHRcdFx0XHRlbGVtZW50czogb3B0aW9ucy5yZXN0b3JlZFN0YXRlLmVsZW1lbnRzLFxuXHRcdFx0XHRpbnRlcmNlcHRpb246IG9wdGlvbnMucmVzdG9yZWRTdGF0ZS5pbnRlcmNlcHRpb24sXG5cdFx0XHRcdGludGVyY2VwdGlvbkNvbnRleHQ6IG9wdGlvbnMucmVzdG9yZWRTdGF0ZS5pbnRlcmNlcHRpb25Db250ZXh0LFxuXHRcdFx0XHRsYXlvdXRJZHM6IG9wdGlvbnMucmVzdG9yZWRTdGF0ZS5sYXlvdXRJZHMsXG5cdFx0XHRcdG5hdmlnYXRpb25TbmFwc2hvdDogb3B0aW9ucy5yZXN0b3JlZFN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdCxcblx0XHRcdFx0b3BlcmF0aW9uLFxuXHRcdFx0XHRwcmV2aW91c05leHRVcmw6IG9wdGlvbnMucmVzdG9yZWRTdGF0ZS5wcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdHJlbmRlcklkOiBvcHRpb25zLnJlbmRlcklkLFxuXHRcdFx0XHRyb290TGF5b3V0VHJlZVBhdGg6IG9wdGlvbnMucmVzdG9yZWRTdGF0ZS5yb290TGF5b3V0VHJlZVBhdGgsXG5cdFx0XHRcdHJldXNlQ3VycmVudEJmY2FjaGVJZHM6IGZhbHNlLFxuXHRcdFx0XHRyb3V0ZUlkOiBvcHRpb25zLnJlc3RvcmVkU3RhdGUucm91dGVJZCxcblx0XHRcdFx0c2tpcHBlZExheW91dElkczogW10sXG5cdFx0XHRcdHNsb3RCaW5kaW5nczogb3B0aW9ucy5yZXN0b3JlZFN0YXRlLnNsb3RCaW5kaW5ncyxcblx0XHRcdFx0dHlwZTogXCJ0cmF2ZXJzZVwiXG5cdFx0XHR9LFxuXHRcdFx0aW50ZXJjZXB0aW9uOiBvcHRpb25zLnJlc3RvcmVkU3RhdGUuaW50ZXJjZXB0aW9uLFxuXHRcdFx0aW50ZXJjZXB0aW9uQ29udGV4dDogb3B0aW9ucy5yZXN0b3JlZFN0YXRlLmludGVyY2VwdGlvbkNvbnRleHQsXG5cdFx0XHRwcmV2aW91c05leHRVcmw6IG9wdGlvbnMucmVzdG9yZWRTdGF0ZS5wcmV2aW91c05leHRVcmwsXG5cdFx0XHRyb290TGF5b3V0VHJlZVBhdGg6IG9wdGlvbnMucmVzdG9yZWRTdGF0ZS5yb290TGF5b3V0VHJlZVBhdGgsXG5cdFx0XHRyb3V0ZUlkOiBvcHRpb25zLnJlc3RvcmVkU3RhdGUucm91dGVJZCxcblx0XHRcdHJlc3RvcmVkSGlzdG9yeVNuYXBzaG90OiB0cnVlLFxuXHRcdFx0c2tpcHBlZExheW91dElkczogW11cblx0XHR9O1xuXHR9XG5cdGZ1bmN0aW9uIHJlc3RvcmVIaXN0b3J5U25hcHNob3RWaXNpYmxlU3RhdGUob3B0aW9ucykge1xuXHRcdGlmICghb3B0aW9ucy5yZXN0b3JlQ29waWVkRXh0ZXJuYWxIaXN0b3J5RW50cnkgJiYgIWlzU25hcHNob3RUYXJnZXRIcmVmKGJhc2VQYXRoLCBvcHRpb25zLnN0YXRlLm5hdmlnYXRpb25TbmFwc2hvdCwgb3B0aW9ucy50YXJnZXRIcmVmKSkgcmV0dXJuIGZhbHNlO1xuXHRcdGNvbnN0IGFwcHJvdmFsVGFyZ2V0SHJlZiA9IG9wdGlvbnMucmVzdG9yZUNvcGllZEV4dGVybmFsSGlzdG9yeUVudHJ5ID8gY3JlYXRlU25hcHNob3RQYXRoQW5kU2VhcmNoKG9wdGlvbnMuc3RhdGUubmF2aWdhdGlvblNuYXBzaG90KSA6IG9wdGlvbnMudGFyZ2V0SHJlZjtcblx0XHRjb25zdCBjdXJyZW50U3RhdGUgPSBnZXRCcm93c2VyUm91dGVyU3RhdGUoKTtcblx0XHRjb25zdCBwZW5kaW5nID0gY3JlYXRlUmVzdG9yZWRIaXN0b3J5U25hcHNob3RDb21taXQoe1xuXHRcdFx0Y3VycmVudFN0YXRlLFxuXHRcdFx0cmVuZGVySWQ6IGFsbG9jYXRlUmVuZGVySWQoKSxcblx0XHRcdHJlc3RvcmVkU3RhdGU6IG9wdGlvbnMuc3RhdGVcblx0XHR9KTtcblx0XHRjb25zdCBhcHByb3ZhbCA9IGFwcHJvdmVQZW5kaW5nTmF2aWdhdGlvbkNvbW1pdCh7XG5cdFx0XHRhY3RpdmVOYXZpZ2F0aW9uSWQsXG5cdFx0XHRjdXJyZW50U3RhdGUsXG5cdFx0XHRwZW5kaW5nLFxuXHRcdFx0cm91dGVNYW5pZmVzdDogZ2V0Um91dGVNYW5pZmVzdCgpLFxuXHRcdFx0c3RhcnRlZE5hdmlnYXRpb25JZDogb3B0aW9ucy5uYXZJZCxcblx0XHRcdHRhcmdldEhyZWY6IGFwcHJvdmFsVGFyZ2V0SHJlZlxuXHRcdH0pO1xuXHRcdGlmIChhcHByb3ZhbC5hcHByb3ZlZENvbW1pdCA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuXHRcdG9wdGlvbnMuYmVmb3JlQ29tbWl0Py4oKTtcblx0XHRkaXNwYXRjaFZpc2libGVDb21taXQoYXBwcm92YWwuYXBwcm92ZWRDb21taXQpO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cdGZ1bmN0aW9uIG5vdGlmeURpc2NhcmRlZFNlcnZlckFjdGlvblJldmFsaWRhdGlvbihsaWZlY3ljbGVPcHRpb25zKSB7XG5cdFx0Y29uc3QgcmV2YWxpZGF0aW9uID0gbGlmZWN5Y2xlT3B0aW9ucz8ucmV2YWxpZGF0aW9uID8/IFwibm9uZVwiO1xuXHRcdGlmICghc2hvdWxkU2NoZWR1bGVSZWZyZXNoRm9yRGlzY2FyZGVkU2VydmVyQWN0aW9uKHJldmFsaWRhdGlvbikpIHJldHVybjtcblx0XHRsaWZlY3ljbGVPcHRpb25zPy5vbkRpc2NhcmRlZFJldmFsaWRhdGlvbj8uKCk7XG5cdH1cblx0ZnVuY3Rpb24gaXNTYW1lUGF0aFNlYXJjaEhhc2hDb21taXQodGFyZ2V0SHJlZikge1xuXHRcdGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gZmFsc2U7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGN1cnJlbnRVcmwgPSBuZXcgVVJMKHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcblx0XHRcdGNvbnN0IHRhcmdldFVybCA9IG5ldyBVUkwodGFyZ2V0SHJlZiwgY3VycmVudFVybC5ocmVmKTtcblx0XHRcdHJldHVybiB0YXJnZXRVcmwub3JpZ2luID09PSBjdXJyZW50VXJsLm9yaWdpbiAmJiB0YXJnZXRVcmwucGF0aG5hbWUgPT09IGN1cnJlbnRVcmwucGF0aG5hbWUgJiYgdGFyZ2V0VXJsLnNlYXJjaCAhPT0gY3VycmVudFVybC5zZWFyY2ggJiYgdGFyZ2V0VXJsLmhhc2ggIT09IFwiXCI7XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIHNob3VsZFJlcHVibGlzaFBlbmRpbmdSb3V0ZXJTdGF0ZShvcHRpb25zKSB7XG5cdFx0aWYgKG9wdGlvbnMuYWN0aW9uVHlwZSA9PT0gXCJ0cmF2ZXJzZVwiKSByZXR1cm4gZmFsc2U7XG5cdFx0aWYgKG9wdGlvbnMuaGlzdG9yeVVwZGF0ZU1vZGUgPT09IHZvaWQgMCkgcmV0dXJuIGZhbHNlO1xuXHRcdGlmIChvcHRpb25zLnNjcm9sbEludGVudD8uaGFzaCA9PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdFx0cmV0dXJuIGlzU2FtZVBhdGhTZWFyY2hIYXNoQ29tbWl0KG9wdGlvbnMudGFyZ2V0SHJlZik7XG5cdH1cblx0YXN5bmMgZnVuY3Rpb24gcmVuZGVyTmF2aWdhdGlvblBheWxvYWQob3B0aW9ucykge1xuXHRcdGNvbnN0IHJvdXRlTWFuaWZlc3RMb2FkID0gbG9hZFJvdXRlTWFuaWZlc3QoKTtcblx0XHRpZiAocm91dGVNYW5pZmVzdExvYWQgIT09IG51bGwgJiYgIWF3YWl0IHJvdXRlTWFuaWZlc3RMb2FkKSB7XG5cdFx0XHRzZXR0bGVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlKG9wdGlvbnMucGVuZGluZ1JvdXRlclN0YXRlKTtcblx0XHRcdGNvbnN1bWVBcHBSb3V0ZXJTY3JvbGxJbnRlbnQob3B0aW9ucy5zY3JvbGxJbnRlbnQgPz8gbnVsbCk7XG5cdFx0XHRpZiAoaXNDdXJyZW50TmF2aWdhdGlvbihvcHRpb25zLm5hdklkKSkgcGVyZm9ybUhhcmROYXZpZ2F0aW9uKG9wdGlvbnMudGFyZ2V0SHJlZiwgb3B0aW9ucy5oaXN0b3J5VXBkYXRlTW9kZSA9PT0gXCJwdXNoXCIgPyBcImFzc2lnblwiIDogXCJyZXBsYWNlXCIpO1xuXHRcdFx0cmV0dXJuIFwibm8tY29tbWl0XCI7XG5cdFx0fVxuXHRcdGlmIChvcHRpb25zLm5hdklkID09PSBwZW5kaW5nVXNlck5hdmlnYXRpb25JZCkgcGVuZGluZ1VzZXJOYXZpZ2F0aW9uTGFuZSA9IG9wdGlvbnMub3BlcmF0aW9uTGFuZTtcblx0XHRjb25zdCByZW5kZXJJZCA9IGFsbG9jYXRlUmVuZGVySWQoKTtcblx0XHRjb25zdCBmYWlsdXJlVGFyZ2V0ID0gZ2V0QXBwTmF2aWdhdGlvbkZhaWx1cmVUYXJnZXQob3B0aW9ucy50YXJnZXRIcmVmKTtcblx0XHRpZiAoZmFpbHVyZVRhcmdldCkgcGVuZGluZ05hdmlnYXRpb25GYWlsdXJlVGFyZ2V0cy5zZXQocmVuZGVySWQsIGZhaWx1cmVUYXJnZXQpO1xuXHRcdGxldCByZXNvbHZlQ29tbWl0dGVkO1xuXHRcdGNvbnN0IGNvbW1pdHRlZCA9IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRyZXNvbHZlQ29tbWl0dGVkID0gcmVzb2x2ZTtcblx0XHRcdHBlbmRpbmdOYXZpZ2F0aW9uQ29tbWl0cy5zZXQocmVuZGVySWQsIHtcblx0XHRcdFx0Y29tbWl0dGVkU3RhdGU6IG51bGwsXG5cdFx0XHRcdG9uQ29tbWl0dGVkU3RhdGU6IG9wdGlvbnMub25Db21taXR0ZWRTdGF0ZSxcblx0XHRcdFx0cmVzb2x2ZSxcblx0XHRcdFx0dGFyZ2V0SHJlZjogb3B0aW9ucy50YXJnZXRIcmVmXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgcGVuZGluZ09wdGlvbnMgPSB7XG5cdFx0XHRcdGN1cnJlbnRTdGF0ZTogb3B0aW9ucy5uYXZpZ2F0aW9uSW5pdGlhdGlvblN0YXRlLFxuXHRcdFx0XHRuYXZpZ2F0aW9uQ29tbWl0S2luZDogb3B0aW9ucy5uYXZpZ2F0aW9uQ29tbWl0S2luZCxcblx0XHRcdFx0bmF2aWdhdGlvbklkOiBvcHRpb25zLm5hdklkLFxuXHRcdFx0XHRuYXZpZ2F0aW9uU25hcHNob3Q6IG9wdGlvbnMubmF2aWdhdGlvblNuYXBzaG90LFxuXHRcdFx0XHRvcGVyYXRpb25MYW5lOiBvcHRpb25zLm9wZXJhdGlvbkxhbmUsXG5cdFx0XHRcdHBheWxvYWRPcmlnaW46IG9wdGlvbnMucGF5bG9hZE9yaWdpbixcblx0XHRcdFx0cHJldmlvdXNOZXh0VXJsOiBvcHRpb25zLnByZXZpb3VzTmV4dFVybCxcblx0XHRcdFx0cmVuZGVySWQsXG5cdFx0XHRcdHJlc3RvcmVkQmZjYWNoZUlkczogb3B0aW9ucy5yZXN0b3JlZEJmY2FjaGVJZHMsXG5cdFx0XHRcdHJldXNlQ3VycmVudEJmY2FjaGVJZHM6IG9wdGlvbnMucmV1c2VDdXJyZW50QmZjYWNoZUlkcyxcblx0XHRcdFx0dHlwZTogb3B0aW9ucy5hY3Rpb25UeXBlXG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgcGVuZGluZyA9IG9wdGlvbnMubmV4dEVsZW1lbnRzIGluc3RhbmNlb2YgUHJvbWlzZSA/IGF3YWl0IGNyZWF0ZVBlbmRpbmdOYXZpZ2F0aW9uQ29tbWl0KHtcblx0XHRcdFx0Li4ucGVuZGluZ09wdGlvbnMsXG5cdFx0XHRcdG5leHRFbGVtZW50czogb3B0aW9ucy5uZXh0RWxlbWVudHNcblx0XHRcdH0pIDogY3JlYXRlUGVuZGluZ05hdmlnYXRpb25Db21taXRGcm9tRWxlbWVudHMoe1xuXHRcdFx0XHQuLi5wZW5kaW5nT3B0aW9ucyxcblx0XHRcdFx0bmV4dEVsZW1lbnRzOiBvcHRpb25zLm5leHRFbGVtZW50c1xuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCBhcHByb3ZhbCA9IGFwcHJvdmVQZW5kaW5nTmF2aWdhdGlvbkNvbW1pdCh7XG5cdFx0XHRcdGFjdGl2ZU5hdmlnYXRpb25JZCxcblx0XHRcdFx0Y3VycmVudFN0YXRlOiBnZXRCcm93c2VyUm91dGVyU3RhdGUoKSxcblx0XHRcdFx0cGVuZGluZyxcblx0XHRcdFx0cm91dGVNYW5pZmVzdDogZ2V0Um91dGVNYW5pZmVzdCgpLFxuXHRcdFx0XHRzdGFydGVkTmF2aWdhdGlvbklkOiBvcHRpb25zLm5hdklkLFxuXHRcdFx0XHR0YXJnZXRIcmVmOiBvcHRpb25zLnRhcmdldEhyZWZcblx0XHRcdH0pO1xuXHRcdFx0aWYgKGFwcHJvdmFsLmRlY2lzaW9uLmRpc3Bvc2l0aW9uID09PSBcIm5vLWNvbW1pdFwiKSB7XG5cdFx0XHRcdHNldHRsZVBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUob3B0aW9ucy5wZW5kaW5nUm91dGVyU3RhdGUpO1xuXHRcdFx0XHRwZW5kaW5nTmF2aWdhdGlvbkZhaWx1cmVUYXJnZXRzLmRlbGV0ZShyZW5kZXJJZCk7XG5cdFx0XHRcdGlmIChmYWlsdXJlVGFyZ2V0KSBjbGVhckFwcE5hdmlnYXRpb25GYWlsdXJlVGFyZ2V0KGZhaWx1cmVUYXJnZXQpO1xuXHRcdFx0XHRwZW5kaW5nTmF2aWdhdGlvbkNvbW1pdHMuZGVsZXRlKHJlbmRlcklkKTtcblx0XHRcdFx0cmVzb2x2ZUNvbW1pdHRlZD8uKGZhbHNlKTtcblx0XHRcdFx0Y29uc3VtZUFwcFJvdXRlclNjcm9sbEludGVudChvcHRpb25zLnNjcm9sbEludGVudCA/PyBudWxsKTtcblx0XHRcdFx0cmV0dXJuIFwibm8tY29tbWl0XCI7XG5cdFx0XHR9XG5cdFx0XHRpZiAoYXBwcm92YWwuZGVjaXNpb24uZGlzcG9zaXRpb24gPT09IFwiaGFyZC1uYXZpZ2F0ZVwiKSB7XG5cdFx0XHRcdHBlbmRpbmdOYXZpZ2F0aW9uRmFpbHVyZVRhcmdldHMuZGVsZXRlKHJlbmRlcklkKTtcblx0XHRcdFx0cGVuZGluZ05hdmlnYXRpb25Db21taXRzLmRlbGV0ZShyZW5kZXJJZCk7XG5cdFx0XHRcdGNvbnN1bWVBcHBSb3V0ZXJTY3JvbGxJbnRlbnQob3B0aW9ucy5zY3JvbGxJbnRlbnQgPz8gbnVsbCk7XG5cdFx0XHRcdGlmIChwZXJmb3JtSGFyZE5hdmlnYXRpb24ob3B0aW9ucy50YXJnZXRIcmVmLCBvcHRpb25zLmhpc3RvcnlVcGRhdGVNb2RlID09PSBcInB1c2hcIiA/IFwiYXNzaWduXCIgOiBcInJlcGxhY2VcIikpIHtcblx0XHRcdFx0XHRhYmFuZG9uUGVuZGluZ0Jyb3dzZXJSb3V0ZXJTdGF0ZShvcHRpb25zLnBlbmRpbmdSb3V0ZXJTdGF0ZSk7XG5cdFx0XHRcdFx0cmV0dXJuIFwiaGFyZC1uYXZpZ2F0ZVwiO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHNldHRsZVBlbmRpbmdCcm93c2VyUm91dGVyU3RhdGUob3B0aW9ucy5wZW5kaW5nUm91dGVyU3RhdGUpO1xuXHRcdFx0XHRpZiAoZmFpbHVyZVRhcmdldCkgY2xlYXJBcHBOYXZpZ2F0aW9uRmFpbHVyZVRhcmdldChmYWlsdXJlVGFyZ2V0KTtcblx0XHRcdFx0cmV0dXJuIFwibm8tY29tbWl0XCI7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBhcHByb3ZlZENvbW1pdCA9IGFwcHJvdmFsLmFwcHJvdmVkQ29tbWl0O1xuXHRcdFx0aWYgKGFwcHJvdmVkQ29tbWl0ID09PSBudWxsKSB0aHJvdyBuZXcgRXJyb3IoXCJbdmluZXh0XSBDb21taXQgZGVjaXNpb24gZGlkIG5vdCBhcHByb3ZlIGEgdmlzaWJsZSBjb21taXRcIik7XG5cdFx0XHRjb25zdCBhcHByb3ZlZFZpc2libGVTdGF0ZSA9IGFwcGx5QXBwcm92ZWRWaXNpYmxlQ29tbWl0KGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpLCBhcHByb3ZlZENvbW1pdCk7XG5cdFx0XHRjb25zdCBjb21taXRFZmZlY3QgPSBvcHRpb25zLmNyZWF0ZU5hdmlnYXRpb25Db21taXRFZmZlY3Qoe1xuXHRcdFx0XHRhY3RpdmVSb3V0ZVBhdGhzOiByZXNvbHZlQWN0aXZlUm91dGVQYXRocyhhcHByb3ZlZFZpc2libGVTdGF0ZS5zbG90QmluZGluZ3MpLFxuXHRcdFx0XHRiZmNhY2hlSWRzOiBhcHByb3ZlZFZpc2libGVTdGF0ZS5iZmNhY2hlSWRzLFxuXHRcdFx0XHRocmVmOiBvcHRpb25zLnRhcmdldEhyZWYsXG5cdFx0XHRcdGhpc3RvcnlVcGRhdGVNb2RlOiBvcHRpb25zLmhpc3RvcnlVcGRhdGVNb2RlLFxuXHRcdFx0XHRuYXZJZDogb3B0aW9ucy5uYXZJZCxcblx0XHRcdFx0cGFyYW1zOiBvcHRpb25zLnBhcmFtcyxcblx0XHRcdFx0cHJldmlvdXNOZXh0VXJsOiBhcHByb3ZlZENvbW1pdC5wcmV2aW91c05leHRVcmwsXG5cdFx0XHRcdHRhcmdldEhpc3RvcnlJbmRleDogb3B0aW9ucy50YXJnZXRIaXN0b3J5SW5kZXhcblx0XHRcdH0pO1xuXHRcdFx0cGVuZGluZ05hdmlnYXRpb25QcmVQYWludEVmZmVjdHMuc2V0KHJlbmRlcklkLCB7XG5cdFx0XHRcdHdyaXRlSGlzdG9yeTogKCkgPT4ge1xuXHRcdFx0XHRcdGNvbW1pdEVmZmVjdC53cml0ZUhpc3RvcnkoeyBrZWVwQ3VycmVudFVybDogaXNSZXRpcmVkTmF2aWdhdGlvblVybChvcHRpb25zLm5hdklkLCBvcHRpb25zLnRhcmdldEhyZWYpIH0pO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRwdWJsaXNoOiAoKSA9PiB7XG5cdFx0XHRcdFx0Y29tbWl0RWZmZWN0LnB1Ymxpc2goeyByZWxlYXNlU25hcHNob3Q6IHNuYXBzaG90UmVuZGVySWRzLmRlbGV0ZShyZW5kZXJJZCkgfSk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdFx0Y2xhaW1BcHBSb3V0ZXJTY3JvbGxJbnRlbnRGb3JDb21taXQob3B0aW9ucy5zY3JvbGxJbnRlbnQsIHJlbmRlcklkKTtcblx0XHRcdGlmICghaXNSZXRpcmVkTmF2aWdhdGlvblVybChvcHRpb25zLm5hdklkLCBvcHRpb25zLnRhcmdldEhyZWYpKSB7XG5cdFx0XHRcdGFjdGl2YXRlTmF2aWdhdGlvblNuYXBzaG90KCk7XG5cdFx0XHRcdHNuYXBzaG90UmVuZGVySWRzLmFkZChyZW5kZXJJZCk7XG5cdFx0XHR9XG5cdFx0XHRkaXNwYXRjaEFwcHJvdmVkVmlzaWJsZUNvbW1pdChyZW5kZXJJZCwgYXBwcm92ZWRDb21taXQsIG9wdGlvbnMucGVuZGluZ1JvdXRlclN0YXRlLCBvcHRpb25zLnZpc2libGVDb21taXRNb2RlID8/IFwidHJhbnNpdGlvblwiLCBzaG91bGRSZXB1Ymxpc2hQZW5kaW5nUm91dGVyU3RhdGUob3B0aW9ucykpO1xuXHRcdFx0aWYgKG9wdGlvbnMubmF2aWdhdGlvblJlc3BvbnNlQ29tcGxldGlvbikgb3B0aW9ucy5uYXZpZ2F0aW9uUmVzcG9uc2VDb21wbGV0aW9uLnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRpZiAoIWlzQ3VycmVudE5hdmlnYXRpb24ob3B0aW9ucy5uYXZJZCkgfHwgIWhhc0Jyb3dzZXJSb3V0ZXJTdGF0ZSgpKSByZXR1cm47XG5cdFx0XHRcdGNvbnN0IGNvbW1pdHRlZFN0YXRlID0gcGVuZGluZ05hdmlnYXRpb25Db21taXRzLmdldChyZW5kZXJJZCk/LmNvbW1pdHRlZFN0YXRlO1xuXHRcdFx0XHRpZiAoIWNvbW1pdHRlZFN0YXRlKSByZXR1cm47XG5cdFx0XHRcdHN0YXJ0VHJhbnNpdGlvbigoKSA9PiB7XG5cdFx0XHRcdFx0Z2V0QnJvd3NlclJvdXRlclN0YXRlU2V0dGVyKCkoY29tbWl0dGVkU3RhdGUpO1xuXHRcdFx0XHR9KTtcblx0XHRcdH0sICgpID0+IHt9KTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0cGVuZGluZ05hdmlnYXRpb25GYWlsdXJlVGFyZ2V0cy5kZWxldGUocmVuZGVySWQpO1xuXHRcdFx0cGVuZGluZ05hdmlnYXRpb25QcmVQYWludEVmZmVjdHMuZGVsZXRlKHJlbmRlcklkKTtcblx0XHRcdHBlbmRpbmdOYXZpZ2F0aW9uQ29tbWl0cy5kZWxldGUocmVuZGVySWQpO1xuXHRcdFx0aWYgKHNuYXBzaG90UmVuZGVySWRzLmRlbGV0ZShyZW5kZXJJZCkpIGNvbW1pdENsaWVudE5hdmlnYXRpb25TdGF0ZUltcGwob3B0aW9ucy5uYXZJZCk7XG5cdFx0XHRzZXR0bGVQZW5kaW5nQnJvd3NlclJvdXRlclN0YXRlKG9wdGlvbnMucGVuZGluZ1JvdXRlclN0YXRlKTtcblx0XHRcdHJlc29sdmVDb21taXR0ZWQ/LihmYWxzZSk7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9XG5cdFx0cmV0dXJuIGNvbW1pdHRlZC50aGVuKChkaWRDb21taXQpID0+IGRpZENvbW1pdCA/IFwiY29tbWl0dGVkXCIgOiBcIm5vLWNvbW1pdFwiKTtcblx0fVxuXHRhc3luYyBmdW5jdGlvbiBjb21taXRTYW1lVXJsTmF2aWdhdGVQYXlsb2FkKG5leHRFbGVtZW50cywgbmF2aWdhdGlvblNuYXBzaG90LCByZXR1cm5WYWx1ZSwgYWN0aW9uSW5pdGlhdGlvblN0YXRlLCBsaWZlY3ljbGVPcHRpb25zKSB7XG5cdFx0Y29uc3QgY3VycmVudFN0YXRlID0gYWN0aW9uSW5pdGlhdGlvblN0YXRlID8/IGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSgpO1xuXHRcdGNvbnN0IHN0YXJ0ZWROYXZpZ2F0aW9uSWQgPSBsaWZlY3ljbGVPcHRpb25zPy5zdGFydGVkTmF2aWdhdGlvbklkID8/IGFjdGl2ZU5hdmlnYXRpb25JZDtcblx0XHRjb25zdCB0YXJnZXRIcmVmID0gbGlmZWN5Y2xlT3B0aW9ucz8udGFyZ2V0SHJlZiA/PyB3aW5kb3cubG9jYXRpb24uaHJlZjtcblx0XHRjb25zdCByb3V0ZU1hbmlmZXN0TG9hZCA9IGxvYWRSb3V0ZU1hbmlmZXN0KCk7XG5cdFx0aWYgKHJvdXRlTWFuaWZlc3RMb2FkICE9PSBudWxsICYmICFhd2FpdCByb3V0ZU1hbmlmZXN0TG9hZCkge1xuXHRcdFx0aWYgKGlzQ3VycmVudE5hdmlnYXRpb24oc3RhcnRlZE5hdmlnYXRpb25JZCkpIHtcblx0XHRcdFx0cGVyZm9ybUhhcmROYXZpZ2F0aW9uKHRhcmdldEhyZWYpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRub3RpZnlEaXNjYXJkZWRTZXJ2ZXJBY3Rpb25SZXZhbGlkYXRpb24obGlmZWN5Y2xlT3B0aW9ucyk7XG5cdFx0XHRyZXR1cm4gcmVzb2x2ZVNhbWVVcmxBY3Rpb25SZXR1cm5WYWx1ZShyZXR1cm5WYWx1ZSk7XG5cdFx0fVxuXHRcdGNvbnN0IHsgYXBwcm92ZWRDb21taXQsIGRlY2lzaW9uLCBwZW5kaW5nLCB0cmFjZTogX25hdmlnYXRpb25UcmFjZSB9ID0gYXdhaXQgcmVzb2x2ZUFuZENsYXNzaWZ5TmF2aWdhdGlvbkNvbW1pdCh7XG5cdFx0XHRhY3RpdmVOYXZpZ2F0aW9uSWQsXG5cdFx0XHRjdXJyZW50U3RhdGUsXG5cdFx0XHRnZXRBY3RpdmVOYXZpZ2F0aW9uSWQ6ICgpID0+IGFjdGl2ZU5hdmlnYXRpb25JZCxcblx0XHRcdGdldEN1cnJlbnRTdGF0ZUZvckFwcHJvdmFsOiBnZXRCcm93c2VyUm91dGVyU3RhdGUsXG5cdFx0XHRuYXZpZ2F0aW9uU25hcHNob3QsXG5cdFx0XHRuZXh0RWxlbWVudHMsXG5cdFx0XHRyZW5kZXJJZDogYWxsb2NhdGVSZW5kZXJJZCgpLFxuXHRcdFx0b3BlcmF0aW9uTGFuZTogcmVzb2x2ZVNlcnZlckFjdGlvbk9wZXJhdGlvbkxhbmUobGlmZWN5Y2xlT3B0aW9ucz8ucmV2YWxpZGF0aW9uID8/IFwibm9uZVwiKSxcblx0XHRcdHBheWxvYWRPcmlnaW46IEZSRVNIX0FQUF9OQVZJR0FUSU9OX1BBWUxPQURfT1JJR0lOLFxuXHRcdFx0c3RhcnRlZE5hdmlnYXRpb25JZCxcblx0XHRcdHJvdXRlTWFuaWZlc3Q6IGdldFJvdXRlTWFuaWZlc3QoKSxcblx0XHRcdHRhcmdldEhyZWYsXG5cdFx0XHR0eXBlOiBcIm5hdmlnYXRlXCJcblx0XHR9KTtcblx0XHRpZiAoZGVjaXNpb24uZGlzcG9zaXRpb24gPT09IFwiaGFyZC1uYXZpZ2F0ZVwiKSB7XG5cdFx0XHRwZXJmb3JtSGFyZE5hdmlnYXRpb24odGFyZ2V0SHJlZik7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChhcHByb3ZlZENvbW1pdCkge1xuXHRcdFx0Y29uc3QgbGF0ZXN0QXBwcm92YWwgPSBhcHByb3ZlUGVuZGluZ05hdmlnYXRpb25Db21taXQoe1xuXHRcdFx0XHRhY3RpdmVOYXZpZ2F0aW9uSWQsXG5cdFx0XHRcdGN1cnJlbnRTdGF0ZTogZ2V0QnJvd3NlclJvdXRlclN0YXRlKCksXG5cdFx0XHRcdHBlbmRpbmcsXG5cdFx0XHRcdHJvdXRlTWFuaWZlc3Q6IGdldFJvdXRlTWFuaWZlc3QoKSxcblx0XHRcdFx0c3RhcnRlZE5hdmlnYXRpb25JZCxcblx0XHRcdFx0dGFyZ2V0SHJlZlxuXHRcdFx0fSk7XG5cdFx0XHRpZiAobGF0ZXN0QXBwcm92YWwuZGVjaXNpb24uZGlzcG9zaXRpb24gPT09IFwiaGFyZC1uYXZpZ2F0ZVwiKSB7XG5cdFx0XHRcdHBlcmZvcm1IYXJkTmF2aWdhdGlvbih0YXJnZXRIcmVmKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0aWYgKGxhdGVzdEFwcHJvdmFsLmFwcHJvdmVkQ29tbWl0KSB7XG5cdFx0XHRcdGNvbnN0IGFwcHJvdmVkUmV2YWxpZGF0aW9uQ29tbWl0ID0gbGF0ZXN0QXBwcm92YWwuYXBwcm92ZWRDb21taXQ7XG5cdFx0XHRcdHN0YXJ0VHJhbnNpdGlvbigoKSA9PiB7XG5cdFx0XHRcdFx0ZGlzcGF0Y2hWaXNpYmxlQ29tbWl0KGFwcHJvdmVkUmV2YWxpZGF0aW9uQ29tbWl0KTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHN5bmNIaXN0b3J5U3RhdGVQcmV2aW91c05leHRVcmwoYXBwcm92ZWRSZXZhbGlkYXRpb25Db21taXQucHJldmlvdXNOZXh0VXJsLCBhcHByb3ZlZFJldmFsaWRhdGlvbkNvbW1pdC5hY3Rpb24uYmZjYWNoZUlkcyk7XG5cdFx0XHR9IGVsc2Ugbm90aWZ5RGlzY2FyZGVkU2VydmVyQWN0aW9uUmV2YWxpZGF0aW9uKGxpZmVjeWNsZU9wdGlvbnMpO1xuXHRcdH0gZWxzZSBpZiAoZGVjaXNpb24uZGlzcG9zaXRpb24gPT09IFwibm8tY29tbWl0XCIpIG5vdGlmeURpc2NhcmRlZFNlcnZlckFjdGlvblJldmFsaWRhdGlvbihsaWZlY3ljbGVPcHRpb25zKTtcblx0XHRyZXR1cm4gcmVzb2x2ZVNhbWVVcmxBY3Rpb25SZXR1cm5WYWx1ZShyZXR1cm5WYWx1ZSk7XG5cdH1cblx0YXN5bmMgZnVuY3Rpb24gcmVzb2x2ZVNhbWVVcmxBY3Rpb25SZXR1cm5WYWx1ZShyZXR1cm5WYWx1ZSkge1xuXHRcdGlmIChyZXR1cm5WYWx1ZSkge1xuXHRcdFx0aWYgKCFyZXR1cm5WYWx1ZS5vaykgdGhyb3cgYXdhaXQgcmV0dXJuVmFsdWUuZGF0YTtcblx0XHRcdHJldHVybiByZXR1cm5WYWx1ZS5kYXRhO1xuXHRcdH1cblx0fVxuXHRmdW5jdGlvbiBhdHRhY2hCcm93c2VyUm91dGVyU3RhdGUoc2V0dGVyLCBzdGF0ZVJlZikge1xuXHRcdHNldEJyb3dzZXJSb3V0ZXJTdGF0ZSA9IHNldHRlcjtcblx0XHRicm93c2VyUm91dGVyU3RhdGVSZWYgPSBzdGF0ZVJlZjtcblx0XHRtYXJrQnJvd3NlclJvdXRlclN0YXRlUmVhZHkoKTtcblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0aWYgKHNldEJyb3dzZXJSb3V0ZXJTdGF0ZSA9PT0gc2V0dGVyKSBzZXRCcm93c2VyUm91dGVyU3RhdGUgPSBudWxsO1xuXHRcdFx0aWYgKGJyb3dzZXJSb3V0ZXJTdGF0ZVJlZiA9PT0gc3RhdGVSZWYpIHtcblx0XHRcdFx0YnJvd3NlclJvdXRlclN0YXRlUmVmID0gbnVsbDtcblx0XHRcdFx0YnJvd3NlclJvdXRlclN0YXRlSGFzQ29tbWl0dGVkID0gZmFsc2U7XG5cdFx0XHR9XG5cdFx0fTtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdGJlZ2luTmF2aWdhdGlvbixcblx0XHRnZXRBY3RpdmVOYXZpZ2F0aW9uSWQsXG5cdFx0aGFzQnJvd3NlclJvdXRlclN0YXRlLFxuXHRcdGdldEJyb3dzZXJSb3V0ZXJTdGF0ZSxcblx0XHRpc0N1cnJlbnROYXZpZ2F0aW9uLFxuXHRcdHBlcmZvcm1IYXJkTmF2aWdhdGlvbixcblx0XHR3YWl0Rm9yQnJvd3NlclJvdXRlclN0YXRlUmVhZHksXG5cdFx0YXR0YWNoQnJvd3NlclJvdXRlclN0YXRlLFxuXHRcdGJlZ2luUGVuZGluZ0Jyb3dzZXJSb3V0ZXJTdGF0ZSxcblx0XHRhYmFuZG9uUGVuZGluZ0Jyb3dzZXJSb3V0ZXJTdGF0ZSxcblx0XHRmaW5hbGl6ZU5hdmlnYXRpb24sXG5cdFx0ZGlzY2FyZFBlbmRpbmdOYXZpZ2F0aW9uLFxuXHRcdGZsdXNoQ29tbWl0dGluZ05hdmlnYXRpb25VcmwsXG5cdFx0cmVzdG9yZUhpc3RvcnlTbmFwc2hvdFZpc2libGVTdGF0ZSxcblx0XHRyZW5kZXJOYXZpZ2F0aW9uUGF5bG9hZCxcblx0XHRjb21taXRTYW1lVXJsTmF2aWdhdGVQYXlsb2FkLFxuXHRcdGhtclJlcGxhY2VUcmVlLFxuXHRcdGRyYWluUHJlUGFpbnRFZmZlY3RzLFxuXHRcdGJlZ2luTmF2aWdhdGlvblJlbmRlckNvbW1pdCxcblx0XHRjb21taXROYXZpZ2F0aW9uUmVuZGVyLFxuXHRcdGNsZWFyQ29tbWl0dGVkTmF2aWdhdGlvbkZhaWx1cmVUYXJnZXRzLFxuXHRcdE5hdmlnYXRpb25Db21taXRTaWduYWwsXG5cdFx0TmF2aWdhdGlvbkhpc3RvcnlDb21taXRcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY2xlYXJIYXJkTmF2aWdhdGlvbkxvb3BHdWFyZCwgY3JlYXRlQXBwQnJvd3Nlck5hdmlnYXRpb25Db250cm9sbGVyLCBjcmVhdGVCYXNlUGF0aFN0cmlwcGVkUGF0aEFuZFNlYXJjaCwgY3JlYXRlU25hcHNob3RQYXRoQW5kU2VhcmNoLCBuYXZpZ2F0ZURvY3VtZW50RGlyZWN0bHkgfTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN2VyxNQUFNLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN0RixNQUFNLENBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN2SixNQUFNLENBQUMsQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLENBQUMsNkNBQTZDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUMxSyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUMxRyxNQUFNLENBQUMsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3JMLE1BQU0sQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNyTCxNQUFNLENBQUMsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsNkJBQTZCLENBQUMsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDaE0sTUFBTSxDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25OLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25GLE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUMzRixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7QUFDdkQsS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDO0FBQzFFLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNwQyxDQUFDLEdBQUcsQ0FBQztBQUNMLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUk7QUFDakQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLEdBQUcsQ0FBQztBQUNMLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsOEJBQThCLENBQUM7QUFDdEUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLDRCQUE0QixDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2xELENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLDhCQUE4QixDQUFDLENBQUMsVUFBVSxDQUFDO0FBQzNFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDckYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2QsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLEdBQUcsQ0FBQztBQUNMLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyw4QkFBOEIsQ0FBQztBQUNsRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNWO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzlDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUN0RCxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDbEM7QUFDQSxRQUFRLENBQUMsa0NBQWtDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDaEgsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7QUFDOUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUMvRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNqRixDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM5SSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDZCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNwSyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDZCxDQUFDO0FBQ0QsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0IsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNaO0FBQ0EsUUFBUSxDQUFDLG1DQUFtQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVELENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDdkQsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN6RCxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEQ7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDOUQsQ0FBQyxHQUFHLENBQUM7QUFDTCxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJO0FBQzVGLENBQUMsQ0FBQyxNQUFNLENBQUMsbUNBQW1DLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDO0FBQy9ILENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNkLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxvQ0FBb0MsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQjtBQUN4RyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUNwSixDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQy9ELENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakUsQ0FBQyxLQUFLLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNGLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ25DLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3JDLENBQUMsR0FBRyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3hDLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQy9DLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxLQUFLLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsRSxDQUFDLEtBQUssQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25FLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDMUMsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDaEMsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDakMsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDakMsQ0FBQyxHQUFHLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDM0MsQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDMUMsQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDMUMsQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDM0MsQ0FBQyxRQUFRLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3hHLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCO0FBQzlCLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNqRyxDQUFDLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLE9BQU87QUFDdEMsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRyxDQUFDLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLE1BQU0sQ0FBQyw4QkFBOEI7QUFDdkMsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLDhCQUE4QjtBQUNyRCxDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdkMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3ZDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxrQkFBa0I7QUFDOUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2xDLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM1QyxDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdkMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzdCLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCO0FBQzNCLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0I7QUFDM0IsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsTUFBTSxDQUFDLHNCQUFzQjtBQUMvQixDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3ZDLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUNyQyxDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25GLENBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqRCxDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0FBQ25FLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYztBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDOUYsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDVixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxjQUFjO0FBQzFCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDM0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDakIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQ2hCLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQywrQkFBK0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU07QUFDekMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDeEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3pGLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxnQ0FBZ0MsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU07QUFDekMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDeEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDekYsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxPQUFPLENBQUM7QUFDMUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDakMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDbkMsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDeEMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDOUIsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDO0FBQzlCLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7QUFDeEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDbkUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUc7QUFDdEUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxTQUFTO0FBQzdDLENBQUMsQ0FBQztBQUNGLENBQUMsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQzFGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLHVCQUF1QjtBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLGdDQUFnQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUM7QUFDbEcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDZixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDaEMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2xDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxnQ0FBZ0MsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEUsQ0FBQyxDQUFDLENBQUMsZ0NBQWdDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUM7QUFDbEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLHNDQUFzQyxDQUFDLHNCQUFzQixDQUFDO0FBQ2hFLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN4RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMscUJBQXFCO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQztBQUNyRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUMzRSxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUM7QUFDRixDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsb0JBQW9CLENBQUMsNEJBQTRCLENBQUM7QUFDL0YsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDNUcsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFVBQVUsQ0FBQztBQUN2SixDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsNEJBQTRCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7QUFDL0QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVk7QUFDM0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTTtBQUN0QyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM1QixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDaEIsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7QUFDdEUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbkUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQztBQUN0RSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsUUFBUTtBQUNwRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQztBQUM1RSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJO0FBQ3BGLENBQUMsQ0FBQztBQUNGLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVE7QUFDbEMsQ0FBQyxDQUFDLENBQUMsZ0NBQWdDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUM7QUFDbkMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN4RSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDcEUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTTtBQUN2RSxDQUFDLENBQUM7QUFDRixDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN2RCxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDeEQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUM7QUFDekgsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7QUFDbkMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUNwRCxDQUFDLENBQUM7QUFDRixDQUFDLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDekMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztBQUNqRSxDQUFDLENBQUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLGVBQWU7QUFDL0UsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQztBQUN0TyxDQUFDLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2hELENBQUMsQ0FBQyxzQ0FBc0MsQ0FBQyxRQUFRLENBQUM7QUFDbEQsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLFFBQVEsQ0FBQztBQUN4QyxDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3JDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUM7QUFDaEMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN6QyxDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsc0NBQXNDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0QsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO0FBQ3pFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUTtBQUNyQyxDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLFVBQVUsQ0FBQztBQUM5QyxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCO0FBQ3pDLENBQUMsQ0FBQyxLQUFLLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDaEYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN0QyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7QUFDeEUsQ0FBQyxDQUFDLENBQUMseUJBQXlCO0FBQzVCLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDZixDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxZQUFZO0FBQ2YsQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUNmLENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUNyQixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxtQ0FBbUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNYLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsTUFBTTtBQUM5RSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3RDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQywyQkFBMkIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakcsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDVixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ25ELENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLGtCQUFrQjtBQUM3RCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjO0FBQ3BELENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLGlCQUFpQixDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywyQkFBMkIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ3RJLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN0RSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDcEUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUMzRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUN2RSxDQUFDLENBQUM7QUFDRixDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxRQUFRLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxRQUFRLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVE7QUFDakIsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLDZCQUE2QixDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBQzlILENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0FBQzlELENBQUMsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMxRCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNmLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTTtBQUN6QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM1RyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDcEMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDckcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDVCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsMEJBQTBCLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0csQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDVCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLDBCQUEwQixDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzVHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUMzRSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzVGLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxtQ0FBbUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2RCxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVE7QUFDdkIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLG9CQUFvQjtBQUN6RSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDbEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVTtBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsUUFBUTtBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsWUFBWTtBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUI7QUFDbEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFNBQVM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsa0JBQWtCO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxlQUFlO0FBQzFELENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVE7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsa0JBQWtCO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxLQUFLO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxPQUFPO0FBQzFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFlBQVk7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsWUFBWTtBQUNuRCxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsbUJBQW1CO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZUFBZTtBQUN6RCxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsa0JBQWtCO0FBQy9ELENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsT0FBTztBQUN6QyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLElBQUk7QUFDaEMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLGtDQUFrQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUN2SixDQUFDLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsaUNBQWlDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVU7QUFDM0osQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDZixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUNyQixDQUFDLENBQUMsQ0FBQyxZQUFZO0FBQ2YsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNWLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUNyQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ3BELENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNiLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyx1Q0FBdUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMvRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyw2Q0FBNkMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDMUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLDBCQUEwQixDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2pELENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2YsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLGlDQUFpQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ3JELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDeEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDdEQsQ0FBQyxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDO0FBQ3ZELENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsNEJBQTRCLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDakosQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUNyQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhO0FBQ2xHLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDO0FBQ3pFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDO0FBQ2pGLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCO0FBQ3RCLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDN0IsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSTtBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQjtBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLHlCQUF5QjtBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsT0FBTyxDQUFDLG9CQUFvQjtBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWE7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYTtBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxlQUFlO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxPQUFPLENBQUMsc0JBQXNCO0FBQzFELENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQztBQUNqRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHlDQUF5QyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUM7QUFDL0QsQ0FBQyxDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsK0JBQStCLENBQUMsYUFBYSxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzlELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQ0FBZ0MsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsK0JBQStCLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsK0JBQStCLENBQUMsYUFBYSxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjO0FBQ2pELENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDNUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUM7QUFDbkcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLDRCQUE0QixDQUFDO0FBQzdELENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLENBQUM7QUFDaEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxVQUFVO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVU7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUI7QUFDaEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsY0FBYyxDQUFDLGVBQWU7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxnQ0FBZ0MsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0csQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsbUNBQW1DLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN0RSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsNkJBQTZCLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3SyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxPQUFPLENBQUMsNEJBQTRCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdGLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQy9FLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsY0FBYztBQUNqRixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTTtBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQ3pGLENBQUMsQ0FBQyxDQUFDLCtCQUErQixDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQ2QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3RSxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLDRCQUE0QixDQUFDLFlBQVksQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3JJLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCO0FBQ3pGLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUk7QUFDekUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyx1Q0FBdUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUM1RCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsK0JBQStCLENBQUMsV0FBVyxDQUFDO0FBQ3RELENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxDQUFDO0FBQ2xILENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUNyQixDQUFDLENBQUMsQ0FBQyxZQUFZO0FBQ2YsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0I7QUFDbEQsQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxxQkFBcUI7QUFDcEQsQ0FBQyxDQUFDLENBQUMsa0JBQWtCO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDZixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLGdDQUFnQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDNUYsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsbUNBQW1DO0FBQ3JELENBQUMsQ0FBQyxDQUFDLG1CQUFtQjtBQUN0QixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDYixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyw4QkFBOEIsQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxjQUFjO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsK0JBQStCLENBQUMsMEJBQTBCLENBQUMsZUFBZSxDQUFDLENBQUMsMEJBQTBCLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztBQUM3SCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHVDQUF1QyxDQUFDLGdCQUFnQixDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVDQUF1QyxDQUFDLGdCQUFnQixDQUFDO0FBQzVHLENBQUMsQ0FBQyxNQUFNLENBQUMsK0JBQStCLENBQUMsV0FBVyxDQUFDO0FBQ3JELENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsK0JBQStCLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUk7QUFDcEQsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJO0FBQzFCLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNyRCxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDaEMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2xDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzFDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsZUFBZTtBQUNqQixDQUFDLENBQUMscUJBQXFCO0FBQ3ZCLENBQUMsQ0FBQyxxQkFBcUI7QUFDdkIsQ0FBQyxDQUFDLHFCQUFxQjtBQUN2QixDQUFDLENBQUMsbUJBQW1CO0FBQ3JCLENBQUMsQ0FBQyxxQkFBcUI7QUFDdkIsQ0FBQyxDQUFDLDhCQUE4QjtBQUNoQyxDQUFDLENBQUMsd0JBQXdCO0FBQzFCLENBQUMsQ0FBQyw4QkFBOEI7QUFDaEMsQ0FBQyxDQUFDLGdDQUFnQztBQUNsQyxDQUFDLENBQUMsa0JBQWtCO0FBQ3BCLENBQUMsQ0FBQyx3QkFBd0I7QUFDMUIsQ0FBQyxDQUFDLDRCQUE0QjtBQUM5QixDQUFDLENBQUMsa0NBQWtDO0FBQ3BDLENBQUMsQ0FBQyx1QkFBdUI7QUFDekIsQ0FBQyxDQUFDLDRCQUE0QjtBQUM5QixDQUFDLENBQUMsY0FBYztBQUNoQixDQUFDLENBQUMsb0JBQW9CO0FBQ3RCLENBQUMsQ0FBQywyQkFBMkI7QUFDN0IsQ0FBQyxDQUFDLHNCQUFzQjtBQUN4QixDQUFDLENBQUMsc0NBQXNDO0FBQ3hDLENBQUMsQ0FBQyxzQkFBc0I7QUFDeEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILE1BQU0sQ0FBQyxDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDOyJ9