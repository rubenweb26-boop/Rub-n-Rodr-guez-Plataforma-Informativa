const React$1 = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport6_react, 1);const Fragment$1 = __vite__cjsImport7_react_jsxRuntime["Fragment"]; const jsx = __vite__cjsImport7_react_jsxRuntime["jsx"];"use client";
import { APP_BFCACHE_SEGMENT_IDENTITIES_KEY, AppElementsWire, UNMATCHED_SLOT } from "/node_modules/vinext/dist/server/app-elements-wire.js?v=b41becdd";
import "/node_modules/vinext/dist/server/app-elements.js?v=b41becdd";
import { isNestedBfcacheSlotSegmentId, isNestedBfcacheSlotSegmentIdFor } from "/node_modules/vinext/dist/server/bfcache-identity.js?v=b41becdd";
import { notFound } from "/node_modules/vinext/dist/shims/navigation-errors.js?v=b41becdd";
import { getBfcacheIdMapContext, getBfcacheSegmentIdContext } from "/node_modules/vinext/dist/shims/navigation-context-state.js?v=b41becdd";
import "/node_modules/vinext/dist/shims/navigation-server.js?v=b41becdd";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=b41becdd";
import __vite__cjsImport7_react_jsxRuntime from "/node_modules/.vite/deps/react_jsx-runtime.js?v=b41becdd";
//#region src/shims/slot.tsx
const EMPTY_ELEMENTS = Object.freeze({});
const warnedMissingEntryIds = /* @__PURE__ */ new Set();
const warnedTransportMetadataEntryIds = /* @__PURE__ */ new Set();
/**
* Holds resolved AppElements (not a Promise). React 19's use(Promise) during
* hydration triggers "async Client Component" for native Promises that lack
* React's internal .status property. Storing resolved values sidesteps this.
*/
const ElementsContext = React$1.createContext(EMPTY_ELEMENTS);
const ChildrenContext = React$1.createContext(null);
const ParallelSlotsContext = React$1.createContext(null);
/**
* The query the server rendered a Slot's element with. Client pages read it
* (see `client-page-root.tsx`), so a page that first renders under a later
* navigation (a kept branch a refresh fetched from its own URL, or one still
* streaming when an intercepted navigation keeps it) reads its own response's
* query.
*/
const RenderedSearchContext = React$1.createContext(void 0);
const renderedSearchByElement = /* @__PURE__ */ new WeakMap();
/** Record the query the server rendered these elements with. */
function setAppElementsRenderedSearch(elements, search) {
	for (const element of Object.values(elements)) if (typeof element === "object" && element !== null) renderedSearchByElement.set(element, search);
}
/**
* Bind a payload's elements to the snapshot of the navigation that delivers
* them, unless they already carry a query (a merged supplemental refresh, or
* an element an earlier payload delivered). Read at render time, so a query
* that arrives after the head (initial hydration) is still seen.
*/
function bindAppElementsRenderedSearch(elements, snapshot) {
	for (const element of Object.values(elements)) if (typeof element === "object" && element !== null && !renderedSearchByElement.has(element)) renderedSearchByElement.set(element, snapshot);
}
function getElementRenderedSearch(element) {
	if (typeof element !== "object" || element === null) return void 0;
	const source = renderedSearchByElement.get(element);
	return typeof source === "object" ? source.renderedSearch ?? source.search : source;
}
const BfcacheIdMapContext = getBfcacheIdMapContext();
const BfcacheSegmentIdContext = getBfcacheSegmentIdContext();
const EMPTY_BFCACHE_STATE_KEYS = Object.freeze({});
const MAX_BFCACHE_SLOT_ENTRIES_WITH_CACHE_COMPONENTS = 3;
const MAX_BFCACHE_SLOT_ENTRIES_WITHOUT_CACHE_COMPONENTS = 1;
const BfcacheIdentityMapContext = React$1.createContext(EMPTY_BFCACHE_STATE_KEYS);
function isCacheComponentsEnabled() {
	return String(process.env.__NEXT_CACHE_COMPONENTS) === "true";
}
function getBfcacheSlotEntryLimit() {
	return isCacheComponentsEnabled() ? MAX_BFCACHE_SLOT_ENTRIES_WITH_CACHE_COMPONENTS : MAX_BFCACHE_SLOT_ENTRIES_WITHOUT_CACHE_COMPONENTS;
}
function normalizeBfcacheSlotEntryLimit(maxEntries) {
	if (!Number.isFinite(maxEntries)) return 1;
	return Math.max(1, Math.trunc(maxEntries));
}
function updateBfcacheSlotEntryOrder(previousOrder, activeStateKey, maxEntries = getBfcacheSlotEntryLimit()) {
	const entryLimit = normalizeBfcacheSlotEntryLimit(maxEntries);
	const nextOrder = [activeStateKey];
	for (const stateKey of previousOrder) {
		if (nextOrder.length >= entryLimit) break;
		if (stateKey === activeStateKey) continue;
		nextOrder.push(stateKey);
	}
	return nextOrder;
}
function pruneBfcacheSlotEntrySnapshots(snapshotsByStateKey, retainedOrder) {
	const retainedKeys = new Set(retainedOrder);
	for (const stateKey of snapshotsByStateKey.keys()) if (!retainedKeys.has(stateKey)) snapshotsByStateKey.delete(stateKey);
}
function haveSameBfcacheSlotEntryOrder(left, right) {
	if (left.length !== right.length) return false;
	for (let index = 0; index < left.length; index++) if (left[index] !== right[index]) return false;
	return true;
}
function stageBfcacheSlotEntryForRender(committedSnapshots, committedOrder, activeEntry, maxEntries = getBfcacheSlotEntryLimit()) {
	const snapshots = new Map(committedSnapshots);
	snapshots.set(activeEntry.stateKey, activeEntry);
	const order = updateBfcacheSlotEntryOrder(committedOrder, activeEntry.stateKey, maxEntries);
	pruneBfcacheSlotEntrySnapshots(snapshots, order);
	return {
		entries: order.map((stateKey) => snapshots.get(stateKey)).filter((entry) => entry !== void 0),
		order,
		snapshots
	};
}
function isArtifactCompatibilityEnvelopeValue(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	return "schemaVersion" in value && "appElementsSchemaVersion" in value && "rscPayloadSchemaVersion" in value && "graphVersion" in value && "deploymentVersion" in value && "rootBoundaryId" in value && "renderEpoch" in value;
}
function isSlotBindingValue(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	return "ownerLayoutId" in value && "slotId" in value && "state" in value;
}
function isSlotBindingListValue(value) {
	return Array.isArray(value) && value.length > 0 && value.every(isSlotBindingValue);
}
function isSkippedLayoutIdsMetadataValue(id, value) {
	return id === "__skippedLayoutIds" && Array.isArray(value) && value.every((entry) => typeof entry === "string");
}
function isBfcacheSegmentIdentitiesMetadataValue(id, value) {
	if (id !== "__bfcacheSegmentIdentities" || typeof value !== "object" || value === null || Array.isArray(value)) return false;
	return Object.entries(value).every(([elementId, identity]) => {
		const parsed = AppElementsWire.parseElementKey(elementId);
		return parsed !== null && parsed.kind !== "route" && typeof identity === "string";
	});
}
function isInterceptionMetadataValue(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	return "sourceMatchedUrl" in value && typeof value.sourceMatchedUrl === "string" && "sourceRouteId" in value && typeof value.sourceRouteId === "string" && "slotId" in value && typeof value.slotId === "string" && "targetMatchedUrl" in value && typeof value.targetMatchedUrl === "string" && "targetRouteId" in value && typeof value.targetRouteId === "string";
}
function isCacheEntryReuseProofValue(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	return "kind" in value && value.kind === "runtime-cache-entry" && "decision" in value;
}
function isTransportMetadataValue(id, value) {
	return isBfcacheSegmentIdentitiesMetadataValue(id, value) || isArtifactCompatibilityEnvelopeValue(value) || isCacheEntryReuseProofValue(value) || isInterceptionMetadataValue(value) || isSkippedLayoutIdsMetadataValue(id, value) || isSlotBindingListValue(value);
}
function warnTransportMetadataEntry(id) {
	if ("development" === "production") return;
	if (warnedTransportMetadataEntryIds.has(id)) return;
	warnedTransportMetadataEntryIds.add(id);
	console.warn("[vinext] Transport metadata value found under App Router render entry: " + id);
}
/**
* Provider stack for Activity-retained BFCache entries. Each retained entry
* re-provides the elements, state-key map, and segment id it was captured with,
* falling back to the live boundary values for entries that predate per-entry
* capture.
*/
function BfcacheEntryProviders({ entry, fallbackElements, fallbackSegmentId, fallbackStateKeyMap, SegmentContext }) {
	return /* @__PURE__ */ jsx(BfcacheIdentityMapContext.Provider, {
		value: entry.stateKeyMap ?? fallbackStateKeyMap,
		children: /* @__PURE__ */ jsx(ElementsContext.Provider, {
			value: entry.elements ?? fallbackElements,
			children: /* @__PURE__ */ jsx(SegmentContext.Provider, {
				value: entry.segmentId ?? fallbackSegmentId,
				children: entry.content
			})
		})
	});
}
function useBfcacheSlotEntries(activeEntry) {
	const snapshotsByStateKey = React$1.useRef(/* @__PURE__ */ new Map());
	const [entryOrder, setEntryOrder] = React$1.useState(() => [activeEntry.stateKey]);
	const committedSnapshots = snapshotsByStateKey.current;
	const staged = stageBfcacheSlotEntryForRender(committedSnapshots, entryOrder, activeEntry);
	const nextOrder = staged.order;
	const orderChanged = !haveSameBfcacheSlotEntryOrder(entryOrder, nextOrder);
	React$1.useLayoutEffect(() => {
		snapshotsByStateKey.current = staged.snapshots;
	}, [staged.snapshots]);
	if ("development" !== "production" && !staged.snapshots.has(activeEntry.stateKey)) throw new Error("BFCache Activity slot is missing the active entry snapshot");
	if (orderChanged) setEntryOrder(nextOrder);
	return staged.entries;
}
function BfcacheActivitySlotBoundary({ activeStateKey, content, elements, id, SegmentContext, stateKeyMap }) {
	const renderEntries = useBfcacheSlotEntries({
		content,
		elements,
		segmentId: id,
		stateKey: activeStateKey,
		stateKeyMap
	});
	return /* @__PURE__ */ jsx(Fragment$1, { children: renderEntries.map((entry) => /* @__PURE__ */ jsx(React$1.Activity, {
		mode: entry.stateKey === activeStateKey ? "visible" : "hidden",
		children: /* @__PURE__ */ jsx(BfcacheEntryProviders, {
			entry,
			fallbackElements: elements,
			fallbackSegmentId: id,
			fallbackStateKeyMap: stateKeyMap,
			SegmentContext
		})
	}, entry.stateKey)) });
}
/**
* Adds a nested segment-owned Activity cache inside a flattened AppElements
* entry. Named parallel routes are transported as one slot value, but Next.js
* retains each descendant segment independently. This boundary recreates that
* ownership without requiring a separate wire entry for every nested segment.
*/
function BfcacheSegmentBoundary({ children, id, stateKey }) {
	const elements = React$1.useContext(ElementsContext);
	const identityMap = React$1.useContext(BfcacheIdentityMapContext);
	const activeStateKey = resolveBfcacheSegmentStateKey(id, identityMap, React$1.useContext(BfcacheIdMapContext));
	if (!BfcacheSegmentIdContext || activeStateKey === void 0) return /* @__PURE__ */ jsx(React$1.Fragment, { children }, stateKey);
	if (!isCacheComponentsEnabled()) return /* @__PURE__ */ jsx(BfcacheSegmentIdContext.Provider, {
		value: id,
		children
	}, activeStateKey);
	return /* @__PURE__ */ jsx(BfcacheActivitySlotBoundary, {
		activeStateKey,
		content: children,
		elements,
		id,
		SegmentContext: BfcacheSegmentIdContext,
		stateKeyMap: identityMap
	});
}
/**
* Retains a layout's children across navigations that change which segment
* they render. Each child keeps its own wrappers, so a page and a nested layout
* give the layout's children different element shapes, and a retention list
* inside the child would remount with them. Next.js keeps this Activity list in
* the parent's layout router, above the child's boundaries, so a page left for a
* sibling with its own layout keeps its state when navigating back.
*/
function BfcacheChildrenBoundary({ children, id, stateKey }) {
	if (!BfcacheIdMapContext || !BfcacheSegmentIdContext || !isCacheComponentsEnabled()) return /* @__PURE__ */ jsx(Fragment$1, { children });
	return /* @__PURE__ */ jsx(BfcacheChildrenActivityBoundary, {
		id,
		IdMapContext: BfcacheIdMapContext,
		SegmentContext: BfcacheSegmentIdContext,
		stateKey,
		children
	});
}
function BfcacheChildrenActivityBoundary({ children, id, IdMapContext, SegmentContext, stateKey }) {
	const elements = React$1.useContext(ElementsContext);
	const identityMap = React$1.useContext(BfcacheIdentityMapContext);
	const bfcacheIdMap = React$1.useContext(IdMapContext);
	const segmentId = React$1.useContext(SegmentContext);
	const activeStateKey = stateKey ?? (id === void 0 ? void 0 : resolveBfcacheSegmentStateKey(id, identityMap, bfcacheIdMap));
	if (segmentId === null || activeStateKey === void 0) return /* @__PURE__ */ jsx(Fragment$1, { children });
	return /* @__PURE__ */ jsx(BfcacheActivitySlotBoundary, {
		activeStateKey,
		content: children,
		elements,
		id: segmentId,
		SegmentContext,
		stateKeyMap: identityMap
	});
}
function getNonCacheComponentsSegmentKey(id, activeStateKey) {
	const parsed = AppElementsWire.parseElementKey(id);
	return parsed !== null && parsed.kind !== "route" ? activeStateKey : void 0;
}
function resolveBfcacheSegmentStateKey(id, identityMap, bfcacheIdMap) {
	return identityMap[id] ?? bfcacheIdMap?.[id];
}
function BfcacheSlotBoundary({ content, id }) {
	const SegmentContext = BfcacheSegmentIdContext;
	const elements = React$1.useContext(ElementsContext);
	const identityMap = React$1.useContext(BfcacheIdentityMapContext);
	const activeStateKey = resolveBfcacheSegmentStateKey(id, identityMap, React$1.useContext(BfcacheIdMapContext));
	if (!SegmentContext) return /* @__PURE__ */ jsx(Fragment$1, { children: content });
	if (activeStateKey === void 0) return /* @__PURE__ */ jsx(SegmentContext.Provider, {
		value: id,
		children: content
	});
	if (!isCacheComponentsEnabled()) return /* @__PURE__ */ jsx(SegmentContext.Provider, {
		value: id,
		children: content
	}, getNonCacheComponentsSegmentKey(id, activeStateKey));
	return /* @__PURE__ */ jsx(BfcacheActivitySlotBoundary, {
		activeStateKey,
		content,
		elements,
		id,
		SegmentContext,
		stateKeyMap: identityMap
	});
}
function mergeElements(prev, next, options = {}) {
	const clearAbsentSlots = typeof options === "boolean" ? options : options.clearAbsentSlots ?? false;
	const preserveAbsentSlots = typeof options === "boolean" ? !options : options.preserveAbsentSlots ?? true;
	const preserveElementIds = typeof options === "boolean" ? [] : options.preserveElementIds ?? [];
	const preserveElementSeedIds = typeof options === "boolean" ? [] : options.preserveElementSeedIds ?? [];
	const preservePreviousSlotIds = typeof options === "boolean" ? [] : options.preservePreviousSlotIds ?? [];
	const merged = { ...next };
	const preservedIdentityIds = /* @__PURE__ */ new Set();
	for (const id of preserveElementIds) if (Object.hasOwn(prev, id)) {
		const value = prev[id];
		if (value !== void 0) {
			merged[id] = value;
			preservedIdentityIds.add(id);
		}
	}
	for (const id of preserveElementSeedIds) {
		if (preservedIdentityIds.has(id) || !Object.hasOwn(prev, id)) continue;
		const value = prev[id];
		if (value !== void 0) merged[id] = value;
	}
	const slotKeys = new Set([...Object.keys(prev), ...Object.keys(next)].filter((key) => AppElementsWire.isSlotId(key) && !isNestedBfcacheSlotSegmentId(key)));
	if (clearAbsentSlots) {
		for (const key of slotKeys) if (!Object.hasOwn(next, key)) delete merged[key];
	} else if (preserveAbsentSlots) {
		for (const key of slotKeys) if (!Object.hasOwn(merged, key) && Object.hasOwn(prev, key)) {
			const value = prev[key];
			if (value !== void 0) {
				merged[key] = value;
				preservedIdentityIds.add(key);
			}
		}
	}
	for (const id of preservePreviousSlotIds) {
		if (!AppElementsWire.isSlotId(id)) continue;
		if (!Object.hasOwn(prev, id)) continue;
		const value = prev[id];
		if (value !== void 0 && value !== UNMATCHED_SLOT) {
			merged[id] = value;
			preservedIdentityIds.add(id);
			for (const nestedId of Object.keys(prev)) {
				if (!isNestedBfcacheSlotSegmentIdFor(nestedId, id)) continue;
				const nestedValue = prev[nestedId];
				if (nestedValue !== void 0) merged[nestedId] = nestedValue;
				preservedIdentityIds.add(nestedId);
			}
		}
	}
	if (preservedIdentityIds.size > 0) {
		const previousIdentityValue = prev[APP_BFCACHE_SEGMENT_IDENTITIES_KEY];
		const nextIdentityValue = next[APP_BFCACHE_SEGMENT_IDENTITIES_KEY];
		const hasPreviousIdentities = isBfcacheSegmentIdentitiesMetadataValue(APP_BFCACHE_SEGMENT_IDENTITIES_KEY, previousIdentityValue);
		const hasNextIdentities = isBfcacheSegmentIdentitiesMetadataValue(APP_BFCACHE_SEGMENT_IDENTITIES_KEY, nextIdentityValue);
		const previousIdentities = hasPreviousIdentities ? { ...previousIdentityValue } : {};
		const mergedIdentities = hasNextIdentities ? { ...nextIdentityValue } : {};
		const identityIds = /* @__PURE__ */ new Set([...Object.keys(previousIdentities), ...Object.keys(mergedIdentities)]);
		const preservedParentIds = new Set(preservedIdentityIds);
		for (const parentId of preservedParentIds) for (const identityId of identityIds) if (isNestedBfcacheSlotSegmentIdFor(identityId, parentId)) preservedIdentityIds.add(identityId);
		for (const id of preservedIdentityIds) {
			const previousIdentity = previousIdentities[id];
			if (previousIdentity === void 0) delete mergedIdentities[id];
			else mergedIdentities[id] = previousIdentity;
		}
		if (hasPreviousIdentities || hasNextIdentities) merged[APP_BFCACHE_SEGMENT_IDENTITIES_KEY] = mergedIdentities;
	}
	return merged;
}
function Slot({ id, children, parallelSlots }) {
	const elements = React$1.useContext(ElementsContext);
	if (!Object.hasOwn(elements, id)) {
		if ("development" !== "production" && !AppElementsWire.isSlotId(id)) {
			if (!warnedMissingEntryIds.has(id)) {
				warnedMissingEntryIds.add(id);
				console.warn("[vinext] Missing App Router element entry during render: " + id);
			}
		}
		return null;
	}
	const element = elements[id];
	if (isTransportMetadataValue(id, element)) {
		warnTransportMetadataEntry(id);
		return null;
	}
	if (element === UNMATCHED_SLOT) notFound();
	if (element === null) return null;
	const content = /* @__PURE__ */ jsx(RenderedSearchContext.Provider, {
		value: getElementRenderedSearch(element),
		children: /* @__PURE__ */ jsx(ParallelSlotsContext.Provider, {
			value: parallelSlots ?? null,
			children: /* @__PURE__ */ jsx(ChildrenContext.Provider, {
				value: children ?? null,
				children: element
			})
		})
	});
	return BfcacheIdMapContext && BfcacheSegmentIdContext ? /* @__PURE__ */ jsx(BfcacheSlotBoundary, {
		id,
		content
	}) : content;
}
function Children() {
	return React$1.useContext(ChildrenContext);
}
function ParallelSlot({ name }) {
	return React$1.useContext(ParallelSlotsContext)?.[name] ?? null;
}
//#endregion
export { BfcacheChildrenBoundary, BfcacheIdentityMapContext, BfcacheSegmentBoundary, Children, ChildrenContext, ElementsContext, ParallelSlot, ParallelSlotsContext, RenderedSearchContext, Slot, UNMATCHED_SLOT, bindAppElementsRenderedSearch, getNonCacheComponentsSegmentKey, mergeElements, resolveBfcacheSegmentStateKey, setAppElementsRenderedSearch, stageBfcacheSlotEntryForRender, updateBfcacheSlotEntryOrder };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUE7QUFDQSxTQUFTLG9DQUFvQyxpQkFBaUIsc0JBQXNCO0FBQ3BGLE9BQU87QUFDUCxTQUFTLDhCQUE4Qix1Q0FBdUM7QUFDOUUsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx3QkFBd0Isa0NBQWtDO0FBQ25FLE9BQU87QUFDUCxZQUFZLGFBQWE7QUFDekIsU0FBUyxZQUFZLFlBQVksV0FBVzs7QUFFNUMsTUFBTSxpQkFBaUIsT0FBTyxPQUFPLENBQUMsQ0FBQztBQUN2QyxNQUFNLHdDQUF3QyxJQUFJLElBQUk7QUFDdEQsTUFBTSxrREFBa0QsSUFBSSxJQUFJOzs7Ozs7QUFNaEUsTUFBTSxrQkFBa0IsUUFBUSxjQUFjLGNBQWM7QUFDNUQsTUFBTSxrQkFBa0IsUUFBUSxjQUFjLElBQUk7QUFDbEQsTUFBTSx1QkFBdUIsUUFBUSxjQUFjLElBQUk7Ozs7Ozs7O0FBUXZELE1BQU0sd0JBQXdCLFFBQVEsY0FBYyxLQUFLLENBQUM7QUFDMUQsTUFBTSwwQ0FBMEMsSUFBSSxRQUFROztBQUU1RCxTQUFTLDZCQUE2QixVQUFVLFFBQVE7Q0FDdkQsS0FBSyxNQUFNLFdBQVcsT0FBTyxPQUFPLFFBQVEsR0FBRyxJQUFJLE9BQU8sWUFBWSxZQUFZLFlBQVksTUFBTSx3QkFBd0IsSUFBSSxTQUFTLE1BQU07QUFDaEo7Ozs7Ozs7QUFPQSxTQUFTLDhCQUE4QixVQUFVLFVBQVU7Q0FDMUQsS0FBSyxNQUFNLFdBQVcsT0FBTyxPQUFPLFFBQVEsR0FBRyxJQUFJLE9BQU8sWUFBWSxZQUFZLFlBQVksUUFBUSxDQUFDLHdCQUF3QixJQUFJLE9BQU8sR0FBRyx3QkFBd0IsSUFBSSxTQUFTLFFBQVE7QUFDM0w7QUFDQSxTQUFTLHlCQUF5QixTQUFTO0NBQzFDLElBQUksT0FBTyxZQUFZLFlBQVksWUFBWSxNQUFNLE9BQU8sS0FBSztDQUNqRSxNQUFNLFNBQVMsd0JBQXdCLElBQUksT0FBTztDQUNsRCxPQUFPLE9BQU8sV0FBVyxXQUFXLE9BQU8sa0JBQWtCLE9BQU8sU0FBUztBQUM5RTtBQUNBLE1BQU0sc0JBQXNCLHVCQUF1QjtBQUNuRCxNQUFNLDBCQUEwQiwyQkFBMkI7QUFDM0QsTUFBTSwyQkFBMkIsT0FBTyxPQUFPLENBQUMsQ0FBQztBQUNqRCxNQUFNLGlEQUFpRDtBQUN2RCxNQUFNLG9EQUFvRDtBQUMxRCxNQUFNLDRCQUE0QixRQUFRLGNBQWMsd0JBQXdCO0FBQ2hGLFNBQVMsMkJBQTJCO0NBQ25DLE9BQU8sT0FBTyxRQUFRLElBQUksdUJBQXVCLE1BQU07QUFDeEQ7QUFDQSxTQUFTLDJCQUEyQjtDQUNuQyxPQUFPLHlCQUF5QixJQUFJLGlEQUFpRDtBQUN0RjtBQUNBLFNBQVMsK0JBQStCLFlBQVk7Q0FDbkQsSUFBSSxDQUFDLE9BQU8sU0FBUyxVQUFVLEdBQUcsT0FBTztDQUN6QyxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxVQUFVLENBQUM7QUFDMUM7QUFDQSxTQUFTLDRCQUE0QixlQUFlLGdCQUFnQixhQUFhLHlCQUF5QixHQUFHO0NBQzVHLE1BQU0sYUFBYSwrQkFBK0IsVUFBVTtDQUM1RCxNQUFNLFlBQVksQ0FBQyxjQUFjO0NBQ2pDLEtBQUssTUFBTSxZQUFZLGVBQWU7RUFDckMsSUFBSSxVQUFVLFVBQVUsWUFBWTtFQUNwQyxJQUFJLGFBQWEsZ0JBQWdCO0VBQ2pDLFVBQVUsS0FBSyxRQUFRO0NBQ3hCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUywrQkFBK0IscUJBQXFCLGVBQWU7Q0FDM0UsTUFBTSxlQUFlLElBQUksSUFBSSxhQUFhO0NBQzFDLEtBQUssTUFBTSxZQUFZLG9CQUFvQixLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsSUFBSSxRQUFRLEdBQUcsb0JBQW9CLE9BQU8sUUFBUTtBQUN4SDtBQUNBLFNBQVMsOEJBQThCLE1BQU0sT0FBTztDQUNuRCxJQUFJLEtBQUssV0FBVyxNQUFNLFFBQVEsT0FBTztDQUN6QyxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsS0FBSyxRQUFRLFNBQVMsSUFBSSxLQUFLLFdBQVcsTUFBTSxRQUFRLE9BQU87Q0FDM0YsT0FBTztBQUNSO0FBQ0EsU0FBUywrQkFBK0Isb0JBQW9CLGdCQUFnQixhQUFhLGFBQWEseUJBQXlCLEdBQUc7Q0FDakksTUFBTSxZQUFZLElBQUksSUFBSSxrQkFBa0I7Q0FDNUMsVUFBVSxJQUFJLFlBQVksVUFBVSxXQUFXO0NBQy9DLE1BQU0sUUFBUSw0QkFBNEIsZ0JBQWdCLFlBQVksVUFBVSxVQUFVO0NBQzFGLCtCQUErQixXQUFXLEtBQUs7Q0FDL0MsT0FBTztFQUNOLFNBQVMsTUFBTSxLQUFLLGFBQWEsVUFBVSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxVQUFVLFVBQVUsS0FBSyxDQUFDO0VBQzVGO0VBQ0E7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxxQ0FBcUMsT0FBTztDQUNwRCxJQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsUUFBUSxNQUFNLFFBQVEsS0FBSyxHQUFHLE9BQU87Q0FDaEYsT0FBTyxtQkFBbUIsU0FBUyw4QkFBOEIsU0FBUyw2QkFBNkIsU0FBUyxrQkFBa0IsU0FBUyx1QkFBdUIsU0FBUyxvQkFBb0IsU0FBUyxpQkFBaUI7QUFDMU47QUFDQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2xDLElBQUksT0FBTyxVQUFVLFlBQVksVUFBVSxRQUFRLE1BQU0sUUFBUSxLQUFLLEdBQUcsT0FBTztDQUNoRixPQUFPLG1CQUFtQixTQUFTLFlBQVksU0FBUyxXQUFXO0FBQ3BFO0FBQ0EsU0FBUyx1QkFBdUIsT0FBTztDQUN0QyxPQUFPLE1BQU0sUUFBUSxLQUFLLEtBQUssTUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNLGtCQUFrQjtBQUNsRjtBQUNBLFNBQVMsZ0NBQWdDLElBQUksT0FBTztDQUNuRCxPQUFPLE9BQU8sd0JBQXdCLE1BQU0sUUFBUSxLQUFLLEtBQUssTUFBTSxPQUFPLFVBQVUsT0FBTyxVQUFVLFFBQVE7QUFDL0c7QUFDQSxTQUFTLHdDQUF3QyxJQUFJLE9BQU87Q0FDM0QsSUFBSSxPQUFPLGdDQUFnQyxPQUFPLFVBQVUsWUFBWSxVQUFVLFFBQVEsTUFBTSxRQUFRLEtBQUssR0FBRyxPQUFPO0NBQ3ZILE9BQU8sT0FBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLGNBQWM7RUFDN0QsTUFBTSxTQUFTLGdCQUFnQixnQkFBZ0IsU0FBUztFQUN4RCxPQUFPLFdBQVcsUUFBUSxPQUFPLFNBQVMsV0FBVyxPQUFPLGFBQWE7Q0FDMUUsQ0FBQztBQUNGO0FBQ0EsU0FBUyw0QkFBNEIsT0FBTztDQUMzQyxJQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsUUFBUSxNQUFNLFFBQVEsS0FBSyxHQUFHLE9BQU87Q0FDaEYsT0FBTyxzQkFBc0IsU0FBUyxPQUFPLE1BQU0scUJBQXFCLFlBQVksbUJBQW1CLFNBQVMsT0FBTyxNQUFNLGtCQUFrQixZQUFZLFlBQVksU0FBUyxPQUFPLE1BQU0sV0FBVyxZQUFZLHNCQUFzQixTQUFTLE9BQU8sTUFBTSxxQkFBcUIsWUFBWSxtQkFBbUIsU0FBUyxPQUFPLE1BQU0sa0JBQWtCO0FBQzdWO0FBQ0EsU0FBUyw0QkFBNEIsT0FBTztDQUMzQyxJQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsUUFBUSxNQUFNLFFBQVEsS0FBSyxHQUFHLE9BQU87Q0FDaEYsT0FBTyxVQUFVLFNBQVMsTUFBTSxTQUFTLHlCQUF5QixjQUFjO0FBQ2pGO0FBQ0EsU0FBUyx5QkFBeUIsSUFBSSxPQUFPO0NBQzVDLE9BQU8sd0NBQXdDLElBQUksS0FBSyxLQUFLLHFDQUFxQyxLQUFLLEtBQUssNEJBQTRCLEtBQUssS0FBSyw0QkFBNEIsS0FBSyxLQUFLLGdDQUFnQyxJQUFJLEtBQUssS0FBSyx1QkFBdUIsS0FBSztBQUNuUTtBQUNBLFNBQVMsMkJBQTJCLElBQUk7Q0FDdkMsc0JBQTZCLGNBQWM7Q0FDM0MsSUFBSSxnQ0FBZ0MsSUFBSSxFQUFFLEdBQUc7Q0FDN0MsZ0NBQWdDLElBQUksRUFBRTtDQUN0QyxRQUFRLEtBQUssNEVBQTRFLEVBQUU7QUFDNUY7Ozs7Ozs7QUFPQSxTQUFTLHNCQUFzQixFQUFFLE9BQU8sa0JBQWtCLG1CQUFtQixxQkFBcUIsa0JBQWtCO0NBQ25ILE9BQXVCLG9CQUFJLDBCQUEwQixVQUFVO0VBQzlELE9BQU8sTUFBTSxlQUFlO0VBQzVCLFVBQTBCLG9CQUFJLGdCQUFnQixVQUFVO0dBQ3ZELE9BQU8sTUFBTSxZQUFZO0dBQ3pCLFVBQTBCLG9CQUFJLGVBQWUsVUFBVTtJQUN0RCxPQUFPLE1BQU0sYUFBYTtJQUMxQixVQUFVLE1BQU07R0FDakIsQ0FBQztFQUNGLENBQUM7Q0FDRixDQUFDO0FBQ0Y7QUFDQSxTQUFTLHNCQUFzQixhQUFhO0NBQzNDLE1BQU0sc0JBQXNCLFFBQVEsdUJBQXVCLElBQUksSUFBSSxDQUFDO0NBQ3BFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixRQUFRLGVBQWUsQ0FBQyxZQUFZLFFBQVEsQ0FBQztDQUNqRixNQUFNLHFCQUFxQixvQkFBb0I7Q0FDL0MsTUFBTSxTQUFTLCtCQUErQixvQkFBb0IsWUFBWSxXQUFXO0NBQ3pGLE1BQU0sWUFBWSxPQUFPO0NBQ3pCLE1BQU0sZUFBZSxDQUFDLDhCQUE4QixZQUFZLFNBQVM7Q0FDekUsUUFBUSxzQkFBc0I7RUFDN0Isb0JBQW9CLFVBQVUsT0FBTztDQUN0QyxHQUFHLENBQUMsT0FBTyxTQUFTLENBQUM7Q0FDckIsc0JBQTZCLGdCQUFnQixDQUFDLE9BQU8sVUFBVSxJQUFJLFlBQVksUUFBUSxHQUFHLE1BQU0sSUFBSSxNQUFNLDREQUE0RDtDQUN0SyxJQUFJLGNBQWMsY0FBYyxTQUFTO0NBQ3pDLE9BQU8sT0FBTztBQUNmO0FBQ0EsU0FBUyw0QkFBNEIsRUFBRSxnQkFBZ0IsU0FBUyxVQUFVLElBQUksZ0JBQWdCLGVBQWU7Q0FDNUcsTUFBTSxnQkFBZ0Isc0JBQXNCO0VBQzNDO0VBQ0E7RUFDQSxXQUFXO0VBQ1gsVUFBVTtFQUNWO0NBQ0QsQ0FBQztDQUNELE9BQXVCLG9CQUFJLFlBQVksRUFBRSxVQUFVLGNBQWMsS0FBSyxVQUEwQixvQkFBSSxRQUFRLFVBQVU7RUFDckgsTUFBTSxNQUFNLGFBQWEsaUJBQWlCLFlBQVk7RUFDdEQsVUFBMEIsb0JBQUksdUJBQXVCO0dBQ3BEO0dBQ0Esa0JBQWtCO0dBQ2xCLG1CQUFtQjtHQUNuQixxQkFBcUI7R0FDckI7RUFDRCxDQUFDO0NBQ0YsR0FBRyxNQUFNLFFBQVEsQ0FBQyxFQUFFLENBQUM7QUFDdEI7Ozs7Ozs7QUFPQSxTQUFTLHVCQUF1QixFQUFFLFVBQVUsSUFBSSxZQUFZO0NBQzNELE1BQU0sV0FBVyxRQUFRLFdBQVcsZUFBZTtDQUNuRCxNQUFNLGNBQWMsUUFBUSxXQUFXLHlCQUF5QjtDQUNoRSxNQUFNLGlCQUFpQiw4QkFBOEIsSUFBSSxhQUFhLFFBQVEsV0FBVyxtQkFBbUIsQ0FBQztDQUM3RyxJQUFJLENBQUMsMkJBQTJCLG1CQUFtQixLQUFLLEdBQUcsT0FBdUIsb0JBQUksUUFBUSxVQUFVLEVBQUUsU0FBUyxHQUFHLFFBQVE7Q0FDOUgsSUFBSSxDQUFDLHlCQUF5QixHQUFHLE9BQXVCLG9CQUFJLHdCQUF3QixVQUFVO0VBQzdGLE9BQU87RUFDUDtDQUNELEdBQUcsY0FBYztDQUNqQixPQUF1QixvQkFBSSw2QkFBNkI7RUFDdkQ7RUFDQSxTQUFTO0VBQ1Q7RUFDQTtFQUNBLGdCQUFnQjtFQUNoQixhQUFhO0NBQ2QsQ0FBQztBQUNGOzs7Ozs7Ozs7QUFTQSxTQUFTLHdCQUF3QixFQUFFLFVBQVUsSUFBSSxZQUFZO0NBQzVELElBQUksQ0FBQyx1QkFBdUIsQ0FBQywyQkFBMkIsQ0FBQyx5QkFBeUIsR0FBRyxPQUF1QixvQkFBSSxZQUFZLEVBQUUsU0FBUyxDQUFDO0NBQ3hJLE9BQXVCLG9CQUFJLGlDQUFpQztFQUMzRDtFQUNBLGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEI7RUFDQTtDQUNELENBQUM7QUFDRjtBQUNBLFNBQVMsZ0NBQWdDLEVBQUUsVUFBVSxJQUFJLGNBQWMsZ0JBQWdCLFlBQVk7Q0FDbEcsTUFBTSxXQUFXLFFBQVEsV0FBVyxlQUFlO0NBQ25ELE1BQU0sY0FBYyxRQUFRLFdBQVcseUJBQXlCO0NBQ2hFLE1BQU0sZUFBZSxRQUFRLFdBQVcsWUFBWTtDQUNwRCxNQUFNLFlBQVksUUFBUSxXQUFXLGNBQWM7Q0FDbkQsTUFBTSxpQkFBaUIsYUFBYSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksOEJBQThCLElBQUksYUFBYSxZQUFZO0NBQ3hILElBQUksY0FBYyxRQUFRLG1CQUFtQixLQUFLLEdBQUcsT0FBdUIsb0JBQUksWUFBWSxFQUFFLFNBQVMsQ0FBQztDQUN4RyxPQUF1QixvQkFBSSw2QkFBNkI7RUFDdkQ7RUFDQSxTQUFTO0VBQ1Q7RUFDQSxJQUFJO0VBQ0o7RUFDQSxhQUFhO0NBQ2QsQ0FBQztBQUNGO0FBQ0EsU0FBUyxnQ0FBZ0MsSUFBSSxnQkFBZ0I7Q0FDNUQsTUFBTSxTQUFTLGdCQUFnQixnQkFBZ0IsRUFBRTtDQUNqRCxPQUFPLFdBQVcsUUFBUSxPQUFPLFNBQVMsVUFBVSxpQkFBaUIsS0FBSztBQUMzRTtBQUNBLFNBQVMsOEJBQThCLElBQUksYUFBYSxjQUFjO0NBQ3JFLE9BQU8sWUFBWSxPQUFPLGVBQWU7QUFDMUM7QUFDQSxTQUFTLG9CQUFvQixFQUFFLFNBQVMsTUFBTTtDQUM3QyxNQUFNLGlCQUFpQjtDQUN2QixNQUFNLFdBQVcsUUFBUSxXQUFXLGVBQWU7Q0FDbkQsTUFBTSxjQUFjLFFBQVEsV0FBVyx5QkFBeUI7Q0FDaEUsTUFBTSxpQkFBaUIsOEJBQThCLElBQUksYUFBYSxRQUFRLFdBQVcsbUJBQW1CLENBQUM7Q0FDN0csSUFBSSxDQUFDLGdCQUFnQixPQUF1QixvQkFBSSxZQUFZLEVBQUUsVUFBVSxRQUFRLENBQUM7Q0FDakYsSUFBSSxtQkFBbUIsS0FBSyxHQUFHLE9BQXVCLG9CQUFJLGVBQWUsVUFBVTtFQUNsRixPQUFPO0VBQ1AsVUFBVTtDQUNYLENBQUM7Q0FDRCxJQUFJLENBQUMseUJBQXlCLEdBQUcsT0FBdUIsb0JBQUksZUFBZSxVQUFVO0VBQ3BGLE9BQU87RUFDUCxVQUFVO0NBQ1gsR0FBRyxnQ0FBZ0MsSUFBSSxjQUFjLENBQUM7Q0FDdEQsT0FBdUIsb0JBQUksNkJBQTZCO0VBQ3ZEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxhQUFhO0NBQ2QsQ0FBQztBQUNGO0FBQ0EsU0FBUyxjQUFjLE1BQU0sTUFBTSxVQUFVLENBQUMsR0FBRztDQUNoRCxNQUFNLG1CQUFtQixPQUFPLFlBQVksWUFBWSxVQUFVLFFBQVEsb0JBQW9CO0NBQzlGLE1BQU0sc0JBQXNCLE9BQU8sWUFBWSxZQUFZLENBQUMsVUFBVSxRQUFRLHVCQUF1QjtDQUNyRyxNQUFNLHFCQUFxQixPQUFPLFlBQVksWUFBWSxDQUFDLElBQUksUUFBUSxzQkFBc0IsQ0FBQztDQUM5RixNQUFNLHlCQUF5QixPQUFPLFlBQVksWUFBWSxDQUFDLElBQUksUUFBUSwwQkFBMEIsQ0FBQztDQUN0RyxNQUFNLDBCQUEwQixPQUFPLFlBQVksWUFBWSxDQUFDLElBQUksUUFBUSwyQkFBMkIsQ0FBQztDQUN4RyxNQUFNLFNBQVMsRUFBRSxHQUFHLEtBQUs7Q0FDekIsTUFBTSx1Q0FBdUMsSUFBSSxJQUFJO0NBQ3JELEtBQUssTUFBTSxNQUFNLG9CQUFvQixJQUFJLE9BQU8sT0FBTyxNQUFNLEVBQUUsR0FBRztFQUNqRSxNQUFNLFFBQVEsS0FBSztFQUNuQixJQUFJLFVBQVUsS0FBSyxHQUFHO0dBQ3JCLE9BQU8sTUFBTTtHQUNiLHFCQUFxQixJQUFJLEVBQUU7RUFDNUI7Q0FDRDtDQUNBLEtBQUssTUFBTSxNQUFNLHdCQUF3QjtFQUN4QyxJQUFJLHFCQUFxQixJQUFJLEVBQUUsS0FBSyxDQUFDLE9BQU8sT0FBTyxNQUFNLEVBQUUsR0FBRztFQUM5RCxNQUFNLFFBQVEsS0FBSztFQUNuQixJQUFJLFVBQVUsS0FBSyxHQUFHLE9BQU8sTUFBTTtDQUNwQztDQUNBLE1BQU0sV0FBVyxJQUFJLElBQUksQ0FBQyxHQUFHLE9BQU8sS0FBSyxJQUFJLEdBQUcsR0FBRyxPQUFPLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLFFBQVEsZ0JBQWdCLFNBQVMsR0FBRyxLQUFLLENBQUMsNkJBQTZCLEdBQUcsQ0FBQyxDQUFDO0NBQzFKLElBQUksa0JBQWtCO0VBQ3JCLEtBQUssTUFBTSxPQUFPLFVBQVUsSUFBSSxDQUFDLE9BQU8sT0FBTyxNQUFNLEdBQUcsR0FBRyxPQUFPLE9BQU87Q0FDMUUsT0FBTyxJQUFJLHFCQUFxQjtFQUMvQixLQUFLLE1BQU0sT0FBTyxVQUFVLElBQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxHQUFHLEtBQUssT0FBTyxPQUFPLE1BQU0sR0FBRyxHQUFHO0dBQ3hGLE1BQU0sUUFBUSxLQUFLO0dBQ25CLElBQUksVUFBVSxLQUFLLEdBQUc7SUFDckIsT0FBTyxPQUFPO0lBQ2QscUJBQXFCLElBQUksR0FBRztHQUM3QjtFQUNEO0NBQ0Q7Q0FDQSxLQUFLLE1BQU0sTUFBTSx5QkFBeUI7RUFDekMsSUFBSSxDQUFDLGdCQUFnQixTQUFTLEVBQUUsR0FBRztFQUNuQyxJQUFJLENBQUMsT0FBTyxPQUFPLE1BQU0sRUFBRSxHQUFHO0VBQzlCLE1BQU0sUUFBUSxLQUFLO0VBQ25CLElBQUksVUFBVSxLQUFLLEtBQUssVUFBVSxnQkFBZ0I7R0FDakQsT0FBTyxNQUFNO0dBQ2IscUJBQXFCLElBQUksRUFBRTtHQUMzQixLQUFLLE1BQU0sWUFBWSxPQUFPLEtBQUssSUFBSSxHQUFHO0lBQ3pDLElBQUksQ0FBQyxnQ0FBZ0MsVUFBVSxFQUFFLEdBQUc7SUFDcEQsTUFBTSxjQUFjLEtBQUs7SUFDekIsSUFBSSxnQkFBZ0IsS0FBSyxHQUFHLE9BQU8sWUFBWTtJQUMvQyxxQkFBcUIsSUFBSSxRQUFRO0dBQ2xDO0VBQ0Q7Q0FDRDtDQUNBLElBQUkscUJBQXFCLE9BQU8sR0FBRztFQUNsQyxNQUFNLHdCQUF3QixLQUFLO0VBQ25DLE1BQU0sb0JBQW9CLEtBQUs7RUFDL0IsTUFBTSx3QkFBd0Isd0NBQXdDLG9DQUFvQyxxQkFBcUI7RUFDL0gsTUFBTSxvQkFBb0Isd0NBQXdDLG9DQUFvQyxpQkFBaUI7RUFDdkgsTUFBTSxxQkFBcUIsd0JBQXdCLEVBQUUsR0FBRyxzQkFBc0IsSUFBSSxDQUFDO0VBQ25GLE1BQU0sbUJBQW1CLG9CQUFvQixFQUFFLEdBQUcsa0JBQWtCLElBQUksQ0FBQztFQUN6RSxNQUFNLDhCQUE4QixJQUFJLElBQUksQ0FBQyxHQUFHLE9BQU8sS0FBSyxrQkFBa0IsR0FBRyxHQUFHLE9BQU8sS0FBSyxnQkFBZ0IsQ0FBQyxDQUFDO0VBQ2xILE1BQU0scUJBQXFCLElBQUksSUFBSSxvQkFBb0I7RUFDdkQsS0FBSyxNQUFNLFlBQVksb0JBQW9CLEtBQUssTUFBTSxjQUFjLGFBQWEsSUFBSSxnQ0FBZ0MsWUFBWSxRQUFRLEdBQUcscUJBQXFCLElBQUksVUFBVTtFQUMvSyxLQUFLLE1BQU0sTUFBTSxzQkFBc0I7R0FDdEMsTUFBTSxtQkFBbUIsbUJBQW1CO0dBQzVDLElBQUkscUJBQXFCLEtBQUssR0FBRyxPQUFPLGlCQUFpQjtRQUNwRCxpQkFBaUIsTUFBTTtFQUM3QjtFQUNBLElBQUkseUJBQXlCLG1CQUFtQixPQUFPLHNDQUFzQztDQUM5RjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsS0FBSyxFQUFFLElBQUksVUFBVSxpQkFBaUI7Q0FDOUMsTUFBTSxXQUFXLFFBQVEsV0FBVyxlQUFlO0NBQ25ELElBQUksQ0FBQyxPQUFPLE9BQU8sVUFBVSxFQUFFLEdBQUc7RUFDakMsc0JBQTZCLGdCQUFnQixDQUFDLGdCQUFnQixTQUFTLEVBQUUsR0FBRztHQUMzRSxJQUFJLENBQUMsc0JBQXNCLElBQUksRUFBRSxHQUFHO0lBQ25DLHNCQUFzQixJQUFJLEVBQUU7SUFDNUIsUUFBUSxLQUFLLDhEQUE4RCxFQUFFO0dBQzlFO0VBQ0Q7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLFVBQVUsU0FBUztDQUN6QixJQUFJLHlCQUF5QixJQUFJLE9BQU8sR0FBRztFQUMxQywyQkFBMkIsRUFBRTtFQUM3QixPQUFPO0NBQ1I7Q0FDQSxJQUFJLFlBQVksZ0JBQWdCLFNBQVM7Q0FDekMsSUFBSSxZQUFZLE1BQU0sT0FBTztDQUM3QixNQUFNLFVBQTBCLG9CQUFJLHNCQUFzQixVQUFVO0VBQ25FLE9BQU8seUJBQXlCLE9BQU87RUFDdkMsVUFBMEIsb0JBQUkscUJBQXFCLFVBQVU7R0FDNUQsT0FBTyxpQkFBaUI7R0FDeEIsVUFBMEIsb0JBQUksZ0JBQWdCLFVBQVU7SUFDdkQsT0FBTyxZQUFZO0lBQ25CLFVBQVU7R0FDWCxDQUFDO0VBQ0YsQ0FBQztDQUNGLENBQUM7Q0FDRCxPQUFPLHVCQUF1QiwwQkFBMEMsb0JBQUkscUJBQXFCO0VBQ2hHO0VBQ0E7Q0FDRCxDQUFDLElBQUk7QUFDTjtBQUNBLFNBQVMsV0FBVztDQUNuQixPQUFPLFFBQVEsV0FBVyxlQUFlO0FBQzFDO0FBQ0EsU0FBUyxhQUFhLEVBQUUsUUFBUTtDQUMvQixPQUFPLFFBQVEsV0FBVyxvQkFBb0IsQ0FBQyxHQUFHLFNBQVM7QUFDNUQ7O0FBRUEsU0FBUyx5QkFBeUIsMkJBQTJCLHdCQUF3QixVQUFVLGlCQUFpQixpQkFBaUIsY0FBYyxzQkFBc0IsdUJBQXVCLE1BQU0sZ0JBQWdCLCtCQUErQixpQ0FBaUMsZUFBZSwrQkFBK0IsOEJBQThCLGdDQUFnQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzbG90LmpzP3Y9YjQxYmVjZGQiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyBBUFBfQkZDQUNIRV9TRUdNRU5UX0lERU5USVRJRVNfS0VZLCBBcHBFbGVtZW50c1dpcmUsIFVOTUFUQ0hFRF9TTE9UIH0gZnJvbSBcIi4uL3NlcnZlci9hcHAtZWxlbWVudHMtd2lyZS5qc1wiO1xuaW1wb3J0IFwiLi4vc2VydmVyL2FwcC1lbGVtZW50cy5qc1wiO1xuaW1wb3J0IHsgaXNOZXN0ZWRCZmNhY2hlU2xvdFNlZ21lbnRJZCwgaXNOZXN0ZWRCZmNhY2hlU2xvdFNlZ21lbnRJZEZvciB9IGZyb20gXCIuLi9zZXJ2ZXIvYmZjYWNoZS1pZGVudGl0eS5qc1wiO1xuaW1wb3J0IHsgbm90Rm91bmQgfSBmcm9tIFwiLi9uYXZpZ2F0aW9uLWVycm9ycy5qc1wiO1xuaW1wb3J0IHsgZ2V0QmZjYWNoZUlkTWFwQ29udGV4dCwgZ2V0QmZjYWNoZVNlZ21lbnRJZENvbnRleHQgfSBmcm9tIFwiLi9uYXZpZ2F0aW9uLWNvbnRleHQtc3RhdGUuanNcIjtcbmltcG9ydCBcIi4vbmF2aWdhdGlvbi1zZXJ2ZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBGcmFnbWVudCBhcyBGcmFnbWVudCQxLCBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvc2hpbXMvc2xvdC50c3hcbmNvbnN0IEVNUFRZX0VMRU1FTlRTID0gT2JqZWN0LmZyZWV6ZSh7fSk7XG5jb25zdCB3YXJuZWRNaXNzaW5nRW50cnlJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuY29uc3Qgd2FybmVkVHJhbnNwb3J0TWV0YWRhdGFFbnRyeUlkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4vKipcbiogSG9sZHMgcmVzb2x2ZWQgQXBwRWxlbWVudHMgKG5vdCBhIFByb21pc2UpLiBSZWFjdCAxOSdzIHVzZShQcm9taXNlKSBkdXJpbmdcbiogaHlkcmF0aW9uIHRyaWdnZXJzIFwiYXN5bmMgQ2xpZW50IENvbXBvbmVudFwiIGZvciBuYXRpdmUgUHJvbWlzZXMgdGhhdCBsYWNrXG4qIFJlYWN0J3MgaW50ZXJuYWwgLnN0YXR1cyBwcm9wZXJ0eS4gU3RvcmluZyByZXNvbHZlZCB2YWx1ZXMgc2lkZXN0ZXBzIHRoaXMuXG4qL1xuY29uc3QgRWxlbWVudHNDb250ZXh0ID0gUmVhY3QkMS5jcmVhdGVDb250ZXh0KEVNUFRZX0VMRU1FTlRTKTtcbmNvbnN0IENoaWxkcmVuQ29udGV4dCA9IFJlYWN0JDEuY3JlYXRlQ29udGV4dChudWxsKTtcbmNvbnN0IFBhcmFsbGVsU2xvdHNDb250ZXh0ID0gUmVhY3QkMS5jcmVhdGVDb250ZXh0KG51bGwpO1xuLyoqXG4qIFRoZSBxdWVyeSB0aGUgc2VydmVyIHJlbmRlcmVkIGEgU2xvdCdzIGVsZW1lbnQgd2l0aC4gQ2xpZW50IHBhZ2VzIHJlYWQgaXRcbiogKHNlZSBgY2xpZW50LXBhZ2Utcm9vdC50c3hgKSwgc28gYSBwYWdlIHRoYXQgZmlyc3QgcmVuZGVycyB1bmRlciBhIGxhdGVyXG4qIG5hdmlnYXRpb24gKGEga2VwdCBicmFuY2ggYSByZWZyZXNoIGZldGNoZWQgZnJvbSBpdHMgb3duIFVSTCwgb3Igb25lIHN0aWxsXG4qIHN0cmVhbWluZyB3aGVuIGFuIGludGVyY2VwdGVkIG5hdmlnYXRpb24ga2VlcHMgaXQpIHJlYWRzIGl0cyBvd24gcmVzcG9uc2Unc1xuKiBxdWVyeS5cbiovXG5jb25zdCBSZW5kZXJlZFNlYXJjaENvbnRleHQgPSBSZWFjdCQxLmNyZWF0ZUNvbnRleHQodm9pZCAwKTtcbmNvbnN0IHJlbmRlcmVkU2VhcmNoQnlFbGVtZW50ID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG4vKiogUmVjb3JkIHRoZSBxdWVyeSB0aGUgc2VydmVyIHJlbmRlcmVkIHRoZXNlIGVsZW1lbnRzIHdpdGguICovXG5mdW5jdGlvbiBzZXRBcHBFbGVtZW50c1JlbmRlcmVkU2VhcmNoKGVsZW1lbnRzLCBzZWFyY2gpIHtcblx0Zm9yIChjb25zdCBlbGVtZW50IG9mIE9iamVjdC52YWx1ZXMoZWxlbWVudHMpKSBpZiAodHlwZW9mIGVsZW1lbnQgPT09IFwib2JqZWN0XCIgJiYgZWxlbWVudCAhPT0gbnVsbCkgcmVuZGVyZWRTZWFyY2hCeUVsZW1lbnQuc2V0KGVsZW1lbnQsIHNlYXJjaCk7XG59XG4vKipcbiogQmluZCBhIHBheWxvYWQncyBlbGVtZW50cyB0byB0aGUgc25hcHNob3Qgb2YgdGhlIG5hdmlnYXRpb24gdGhhdCBkZWxpdmVyc1xuKiB0aGVtLCB1bmxlc3MgdGhleSBhbHJlYWR5IGNhcnJ5IGEgcXVlcnkgKGEgbWVyZ2VkIHN1cHBsZW1lbnRhbCByZWZyZXNoLCBvclxuKiBhbiBlbGVtZW50IGFuIGVhcmxpZXIgcGF5bG9hZCBkZWxpdmVyZWQpLiBSZWFkIGF0IHJlbmRlciB0aW1lLCBzbyBhIHF1ZXJ5XG4qIHRoYXQgYXJyaXZlcyBhZnRlciB0aGUgaGVhZCAoaW5pdGlhbCBoeWRyYXRpb24pIGlzIHN0aWxsIHNlZW4uXG4qL1xuZnVuY3Rpb24gYmluZEFwcEVsZW1lbnRzUmVuZGVyZWRTZWFyY2goZWxlbWVudHMsIHNuYXBzaG90KSB7XG5cdGZvciAoY29uc3QgZWxlbWVudCBvZiBPYmplY3QudmFsdWVzKGVsZW1lbnRzKSkgaWYgKHR5cGVvZiBlbGVtZW50ID09PSBcIm9iamVjdFwiICYmIGVsZW1lbnQgIT09IG51bGwgJiYgIXJlbmRlcmVkU2VhcmNoQnlFbGVtZW50LmhhcyhlbGVtZW50KSkgcmVuZGVyZWRTZWFyY2hCeUVsZW1lbnQuc2V0KGVsZW1lbnQsIHNuYXBzaG90KTtcbn1cbmZ1bmN0aW9uIGdldEVsZW1lbnRSZW5kZXJlZFNlYXJjaChlbGVtZW50KSB7XG5cdGlmICh0eXBlb2YgZWxlbWVudCAhPT0gXCJvYmplY3RcIiB8fCBlbGVtZW50ID09PSBudWxsKSByZXR1cm4gdm9pZCAwO1xuXHRjb25zdCBzb3VyY2UgPSByZW5kZXJlZFNlYXJjaEJ5RWxlbWVudC5nZXQoZWxlbWVudCk7XG5cdHJldHVybiB0eXBlb2Ygc291cmNlID09PSBcIm9iamVjdFwiID8gc291cmNlLnJlbmRlcmVkU2VhcmNoID8/IHNvdXJjZS5zZWFyY2ggOiBzb3VyY2U7XG59XG5jb25zdCBCZmNhY2hlSWRNYXBDb250ZXh0ID0gZ2V0QmZjYWNoZUlkTWFwQ29udGV4dCgpO1xuY29uc3QgQmZjYWNoZVNlZ21lbnRJZENvbnRleHQgPSBnZXRCZmNhY2hlU2VnbWVudElkQ29udGV4dCgpO1xuY29uc3QgRU1QVFlfQkZDQUNIRV9TVEFURV9LRVlTID0gT2JqZWN0LmZyZWV6ZSh7fSk7XG5jb25zdCBNQVhfQkZDQUNIRV9TTE9UX0VOVFJJRVNfV0lUSF9DQUNIRV9DT01QT05FTlRTID0gMztcbmNvbnN0IE1BWF9CRkNBQ0hFX1NMT1RfRU5UUklFU19XSVRIT1VUX0NBQ0hFX0NPTVBPTkVOVFMgPSAxO1xuY29uc3QgQmZjYWNoZUlkZW50aXR5TWFwQ29udGV4dCA9IFJlYWN0JDEuY3JlYXRlQ29udGV4dChFTVBUWV9CRkNBQ0hFX1NUQVRFX0tFWVMpO1xuZnVuY3Rpb24gaXNDYWNoZUNvbXBvbmVudHNFbmFibGVkKCkge1xuXHRyZXR1cm4gU3RyaW5nKHByb2Nlc3MuZW52Ll9fTkVYVF9DQUNIRV9DT01QT05FTlRTKSA9PT0gXCJ0cnVlXCI7XG59XG5mdW5jdGlvbiBnZXRCZmNhY2hlU2xvdEVudHJ5TGltaXQoKSB7XG5cdHJldHVybiBpc0NhY2hlQ29tcG9uZW50c0VuYWJsZWQoKSA/IE1BWF9CRkNBQ0hFX1NMT1RfRU5UUklFU19XSVRIX0NBQ0hFX0NPTVBPTkVOVFMgOiBNQVhfQkZDQUNIRV9TTE9UX0VOVFJJRVNfV0lUSE9VVF9DQUNIRV9DT01QT05FTlRTO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplQmZjYWNoZVNsb3RFbnRyeUxpbWl0KG1heEVudHJpZXMpIHtcblx0aWYgKCFOdW1iZXIuaXNGaW5pdGUobWF4RW50cmllcykpIHJldHVybiAxO1xuXHRyZXR1cm4gTWF0aC5tYXgoMSwgTWF0aC50cnVuYyhtYXhFbnRyaWVzKSk7XG59XG5mdW5jdGlvbiB1cGRhdGVCZmNhY2hlU2xvdEVudHJ5T3JkZXIocHJldmlvdXNPcmRlciwgYWN0aXZlU3RhdGVLZXksIG1heEVudHJpZXMgPSBnZXRCZmNhY2hlU2xvdEVudHJ5TGltaXQoKSkge1xuXHRjb25zdCBlbnRyeUxpbWl0ID0gbm9ybWFsaXplQmZjYWNoZVNsb3RFbnRyeUxpbWl0KG1heEVudHJpZXMpO1xuXHRjb25zdCBuZXh0T3JkZXIgPSBbYWN0aXZlU3RhdGVLZXldO1xuXHRmb3IgKGNvbnN0IHN0YXRlS2V5IG9mIHByZXZpb3VzT3JkZXIpIHtcblx0XHRpZiAobmV4dE9yZGVyLmxlbmd0aCA+PSBlbnRyeUxpbWl0KSBicmVhaztcblx0XHRpZiAoc3RhdGVLZXkgPT09IGFjdGl2ZVN0YXRlS2V5KSBjb250aW51ZTtcblx0XHRuZXh0T3JkZXIucHVzaChzdGF0ZUtleSk7XG5cdH1cblx0cmV0dXJuIG5leHRPcmRlcjtcbn1cbmZ1bmN0aW9uIHBydW5lQmZjYWNoZVNsb3RFbnRyeVNuYXBzaG90cyhzbmFwc2hvdHNCeVN0YXRlS2V5LCByZXRhaW5lZE9yZGVyKSB7XG5cdGNvbnN0IHJldGFpbmVkS2V5cyA9IG5ldyBTZXQocmV0YWluZWRPcmRlcik7XG5cdGZvciAoY29uc3Qgc3RhdGVLZXkgb2Ygc25hcHNob3RzQnlTdGF0ZUtleS5rZXlzKCkpIGlmICghcmV0YWluZWRLZXlzLmhhcyhzdGF0ZUtleSkpIHNuYXBzaG90c0J5U3RhdGVLZXkuZGVsZXRlKHN0YXRlS2V5KTtcbn1cbmZ1bmN0aW9uIGhhdmVTYW1lQmZjYWNoZVNsb3RFbnRyeU9yZGVyKGxlZnQsIHJpZ2h0KSB7XG5cdGlmIChsZWZ0Lmxlbmd0aCAhPT0gcmlnaHQubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG5cdGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBsZWZ0Lmxlbmd0aDsgaW5kZXgrKykgaWYgKGxlZnRbaW5kZXhdICE9PSByaWdodFtpbmRleF0pIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBzdGFnZUJmY2FjaGVTbG90RW50cnlGb3JSZW5kZXIoY29tbWl0dGVkU25hcHNob3RzLCBjb21taXR0ZWRPcmRlciwgYWN0aXZlRW50cnksIG1heEVudHJpZXMgPSBnZXRCZmNhY2hlU2xvdEVudHJ5TGltaXQoKSkge1xuXHRjb25zdCBzbmFwc2hvdHMgPSBuZXcgTWFwKGNvbW1pdHRlZFNuYXBzaG90cyk7XG5cdHNuYXBzaG90cy5zZXQoYWN0aXZlRW50cnkuc3RhdGVLZXksIGFjdGl2ZUVudHJ5KTtcblx0Y29uc3Qgb3JkZXIgPSB1cGRhdGVCZmNhY2hlU2xvdEVudHJ5T3JkZXIoY29tbWl0dGVkT3JkZXIsIGFjdGl2ZUVudHJ5LnN0YXRlS2V5LCBtYXhFbnRyaWVzKTtcblx0cHJ1bmVCZmNhY2hlU2xvdEVudHJ5U25hcHNob3RzKHNuYXBzaG90cywgb3JkZXIpO1xuXHRyZXR1cm4ge1xuXHRcdGVudHJpZXM6IG9yZGVyLm1hcCgoc3RhdGVLZXkpID0+IHNuYXBzaG90cy5nZXQoc3RhdGVLZXkpKS5maWx0ZXIoKGVudHJ5KSA9PiBlbnRyeSAhPT0gdm9pZCAwKSxcblx0XHRvcmRlcixcblx0XHRzbmFwc2hvdHNcblx0fTtcbn1cbmZ1bmN0aW9uIGlzQXJ0aWZhY3RDb21wYXRpYmlsaXR5RW52ZWxvcGVWYWx1ZSh2YWx1ZSkge1xuXHRpZiAodHlwZW9mIHZhbHVlICE9PSBcIm9iamVjdFwiIHx8IHZhbHVlID09PSBudWxsIHx8IEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBcInNjaGVtYVZlcnNpb25cIiBpbiB2YWx1ZSAmJiBcImFwcEVsZW1lbnRzU2NoZW1hVmVyc2lvblwiIGluIHZhbHVlICYmIFwicnNjUGF5bG9hZFNjaGVtYVZlcnNpb25cIiBpbiB2YWx1ZSAmJiBcImdyYXBoVmVyc2lvblwiIGluIHZhbHVlICYmIFwiZGVwbG95bWVudFZlcnNpb25cIiBpbiB2YWx1ZSAmJiBcInJvb3RCb3VuZGFyeUlkXCIgaW4gdmFsdWUgJiYgXCJyZW5kZXJFcG9jaFwiIGluIHZhbHVlO1xufVxuZnVuY3Rpb24gaXNTbG90QmluZGluZ1ZhbHVlKHZhbHVlKSB7XG5cdGlmICh0eXBlb2YgdmFsdWUgIT09IFwib2JqZWN0XCIgfHwgdmFsdWUgPT09IG51bGwgfHwgQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIFwib3duZXJMYXlvdXRJZFwiIGluIHZhbHVlICYmIFwic2xvdElkXCIgaW4gdmFsdWUgJiYgXCJzdGF0ZVwiIGluIHZhbHVlO1xufVxuZnVuY3Rpb24gaXNTbG90QmluZGluZ0xpc3RWYWx1ZSh2YWx1ZSkge1xuXHRyZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiYgdmFsdWUubGVuZ3RoID4gMCAmJiB2YWx1ZS5ldmVyeShpc1Nsb3RCaW5kaW5nVmFsdWUpO1xufVxuZnVuY3Rpb24gaXNTa2lwcGVkTGF5b3V0SWRzTWV0YWRhdGFWYWx1ZShpZCwgdmFsdWUpIHtcblx0cmV0dXJuIGlkID09PSBcIl9fc2tpcHBlZExheW91dElkc1wiICYmIEFycmF5LmlzQXJyYXkodmFsdWUpICYmIHZhbHVlLmV2ZXJ5KChlbnRyeSkgPT4gdHlwZW9mIGVudHJ5ID09PSBcInN0cmluZ1wiKTtcbn1cbmZ1bmN0aW9uIGlzQmZjYWNoZVNlZ21lbnRJZGVudGl0aWVzTWV0YWRhdGFWYWx1ZShpZCwgdmFsdWUpIHtcblx0aWYgKGlkICE9PSBcIl9fYmZjYWNoZVNlZ21lbnRJZGVudGl0aWVzXCIgfHwgdHlwZW9mIHZhbHVlICE9PSBcIm9iamVjdFwiIHx8IHZhbHVlID09PSBudWxsIHx8IEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBPYmplY3QuZW50cmllcyh2YWx1ZSkuZXZlcnkoKFtlbGVtZW50SWQsIGlkZW50aXR5XSkgPT4ge1xuXHRcdGNvbnN0IHBhcnNlZCA9IEFwcEVsZW1lbnRzV2lyZS5wYXJzZUVsZW1lbnRLZXkoZWxlbWVudElkKTtcblx0XHRyZXR1cm4gcGFyc2VkICE9PSBudWxsICYmIHBhcnNlZC5raW5kICE9PSBcInJvdXRlXCIgJiYgdHlwZW9mIGlkZW50aXR5ID09PSBcInN0cmluZ1wiO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIGlzSW50ZXJjZXB0aW9uTWV0YWRhdGFWYWx1ZSh2YWx1ZSkge1xuXHRpZiAodHlwZW9mIHZhbHVlICE9PSBcIm9iamVjdFwiIHx8IHZhbHVlID09PSBudWxsIHx8IEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBcInNvdXJjZU1hdGNoZWRVcmxcIiBpbiB2YWx1ZSAmJiB0eXBlb2YgdmFsdWUuc291cmNlTWF0Y2hlZFVybCA9PT0gXCJzdHJpbmdcIiAmJiBcInNvdXJjZVJvdXRlSWRcIiBpbiB2YWx1ZSAmJiB0eXBlb2YgdmFsdWUuc291cmNlUm91dGVJZCA9PT0gXCJzdHJpbmdcIiAmJiBcInNsb3RJZFwiIGluIHZhbHVlICYmIHR5cGVvZiB2YWx1ZS5zbG90SWQgPT09IFwic3RyaW5nXCIgJiYgXCJ0YXJnZXRNYXRjaGVkVXJsXCIgaW4gdmFsdWUgJiYgdHlwZW9mIHZhbHVlLnRhcmdldE1hdGNoZWRVcmwgPT09IFwic3RyaW5nXCIgJiYgXCJ0YXJnZXRSb3V0ZUlkXCIgaW4gdmFsdWUgJiYgdHlwZW9mIHZhbHVlLnRhcmdldFJvdXRlSWQgPT09IFwic3RyaW5nXCI7XG59XG5mdW5jdGlvbiBpc0NhY2hlRW50cnlSZXVzZVByb29mVmFsdWUodmFsdWUpIHtcblx0aWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJvYmplY3RcIiB8fCB2YWx1ZSA9PT0gbnVsbCB8fCBBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gXCJraW5kXCIgaW4gdmFsdWUgJiYgdmFsdWUua2luZCA9PT0gXCJydW50aW1lLWNhY2hlLWVudHJ5XCIgJiYgXCJkZWNpc2lvblwiIGluIHZhbHVlO1xufVxuZnVuY3Rpb24gaXNUcmFuc3BvcnRNZXRhZGF0YVZhbHVlKGlkLCB2YWx1ZSkge1xuXHRyZXR1cm4gaXNCZmNhY2hlU2VnbWVudElkZW50aXRpZXNNZXRhZGF0YVZhbHVlKGlkLCB2YWx1ZSkgfHwgaXNBcnRpZmFjdENvbXBhdGliaWxpdHlFbnZlbG9wZVZhbHVlKHZhbHVlKSB8fCBpc0NhY2hlRW50cnlSZXVzZVByb29mVmFsdWUodmFsdWUpIHx8IGlzSW50ZXJjZXB0aW9uTWV0YWRhdGFWYWx1ZSh2YWx1ZSkgfHwgaXNTa2lwcGVkTGF5b3V0SWRzTWV0YWRhdGFWYWx1ZShpZCwgdmFsdWUpIHx8IGlzU2xvdEJpbmRpbmdMaXN0VmFsdWUodmFsdWUpO1xufVxuZnVuY3Rpb24gd2FyblRyYW5zcG9ydE1ldGFkYXRhRW50cnkoaWQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIikgcmV0dXJuO1xuXHRpZiAod2FybmVkVHJhbnNwb3J0TWV0YWRhdGFFbnRyeUlkcy5oYXMoaWQpKSByZXR1cm47XG5cdHdhcm5lZFRyYW5zcG9ydE1ldGFkYXRhRW50cnlJZHMuYWRkKGlkKTtcblx0Y29uc29sZS53YXJuKFwiW3ZpbmV4dF0gVHJhbnNwb3J0IG1ldGFkYXRhIHZhbHVlIGZvdW5kIHVuZGVyIEFwcCBSb3V0ZXIgcmVuZGVyIGVudHJ5OiBcIiArIGlkKTtcbn1cbi8qKlxuKiBQcm92aWRlciBzdGFjayBmb3IgQWN0aXZpdHktcmV0YWluZWQgQkZDYWNoZSBlbnRyaWVzLiBFYWNoIHJldGFpbmVkIGVudHJ5XG4qIHJlLXByb3ZpZGVzIHRoZSBlbGVtZW50cywgc3RhdGUta2V5IG1hcCwgYW5kIHNlZ21lbnQgaWQgaXQgd2FzIGNhcHR1cmVkIHdpdGgsXG4qIGZhbGxpbmcgYmFjayB0byB0aGUgbGl2ZSBib3VuZGFyeSB2YWx1ZXMgZm9yIGVudHJpZXMgdGhhdCBwcmVkYXRlIHBlci1lbnRyeVxuKiBjYXB0dXJlLlxuKi9cbmZ1bmN0aW9uIEJmY2FjaGVFbnRyeVByb3ZpZGVycyh7IGVudHJ5LCBmYWxsYmFja0VsZW1lbnRzLCBmYWxsYmFja1NlZ21lbnRJZCwgZmFsbGJhY2tTdGF0ZUtleU1hcCwgU2VnbWVudENvbnRleHQgfSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChCZmNhY2hlSWRlbnRpdHlNYXBDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IGVudHJ5LnN0YXRlS2V5TWFwID8/IGZhbGxiYWNrU3RhdGVLZXlNYXAsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goRWxlbWVudHNDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0XHR2YWx1ZTogZW50cnkuZWxlbWVudHMgPz8gZmFsbGJhY2tFbGVtZW50cyxcblx0XHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFNlZ21lbnRDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0XHRcdHZhbHVlOiBlbnRyeS5zZWdtZW50SWQgPz8gZmFsbGJhY2tTZWdtZW50SWQsXG5cdFx0XHRcdGNoaWxkcmVuOiBlbnRyeS5jb250ZW50XG5cdFx0XHR9KVxuXHRcdH0pXG5cdH0pO1xufVxuZnVuY3Rpb24gdXNlQmZjYWNoZVNsb3RFbnRyaWVzKGFjdGl2ZUVudHJ5KSB7XG5cdGNvbnN0IHNuYXBzaG90c0J5U3RhdGVLZXkgPSBSZWFjdCQxLnVzZVJlZigvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKTtcblx0Y29uc3QgW2VudHJ5T3JkZXIsIHNldEVudHJ5T3JkZXJdID0gUmVhY3QkMS51c2VTdGF0ZSgoKSA9PiBbYWN0aXZlRW50cnkuc3RhdGVLZXldKTtcblx0Y29uc3QgY29tbWl0dGVkU25hcHNob3RzID0gc25hcHNob3RzQnlTdGF0ZUtleS5jdXJyZW50O1xuXHRjb25zdCBzdGFnZWQgPSBzdGFnZUJmY2FjaGVTbG90RW50cnlGb3JSZW5kZXIoY29tbWl0dGVkU25hcHNob3RzLCBlbnRyeU9yZGVyLCBhY3RpdmVFbnRyeSk7XG5cdGNvbnN0IG5leHRPcmRlciA9IHN0YWdlZC5vcmRlcjtcblx0Y29uc3Qgb3JkZXJDaGFuZ2VkID0gIWhhdmVTYW1lQmZjYWNoZVNsb3RFbnRyeU9yZGVyKGVudHJ5T3JkZXIsIG5leHRPcmRlcik7XG5cdFJlYWN0JDEudXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcblx0XHRzbmFwc2hvdHNCeVN0YXRlS2V5LmN1cnJlbnQgPSBzdGFnZWQuc25hcHNob3RzO1xuXHR9LCBbc3RhZ2VkLnNuYXBzaG90c10pO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFzdGFnZWQuc25hcHNob3RzLmhhcyhhY3RpdmVFbnRyeS5zdGF0ZUtleSkpIHRocm93IG5ldyBFcnJvcihcIkJGQ2FjaGUgQWN0aXZpdHkgc2xvdCBpcyBtaXNzaW5nIHRoZSBhY3RpdmUgZW50cnkgc25hcHNob3RcIik7XG5cdGlmIChvcmRlckNoYW5nZWQpIHNldEVudHJ5T3JkZXIobmV4dE9yZGVyKTtcblx0cmV0dXJuIHN0YWdlZC5lbnRyaWVzO1xufVxuZnVuY3Rpb24gQmZjYWNoZUFjdGl2aXR5U2xvdEJvdW5kYXJ5KHsgYWN0aXZlU3RhdGVLZXksIGNvbnRlbnQsIGVsZW1lbnRzLCBpZCwgU2VnbWVudENvbnRleHQsIHN0YXRlS2V5TWFwIH0pIHtcblx0Y29uc3QgcmVuZGVyRW50cmllcyA9IHVzZUJmY2FjaGVTbG90RW50cmllcyh7XG5cdFx0Y29udGVudCxcblx0XHRlbGVtZW50cyxcblx0XHRzZWdtZW50SWQ6IGlkLFxuXHRcdHN0YXRlS2V5OiBhY3RpdmVTdGF0ZUtleSxcblx0XHRzdGF0ZUtleU1hcFxuXHR9KTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goRnJhZ21lbnQkMSwgeyBjaGlsZHJlbjogcmVuZGVyRW50cmllcy5tYXAoKGVudHJ5KSA9PiAvKiBAX19QVVJFX18gKi8ganN4KFJlYWN0JDEuQWN0aXZpdHksIHtcblx0XHRtb2RlOiBlbnRyeS5zdGF0ZUtleSA9PT0gYWN0aXZlU3RhdGVLZXkgPyBcInZpc2libGVcIiA6IFwiaGlkZGVuXCIsXG5cdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goQmZjYWNoZUVudHJ5UHJvdmlkZXJzLCB7XG5cdFx0XHRlbnRyeSxcblx0XHRcdGZhbGxiYWNrRWxlbWVudHM6IGVsZW1lbnRzLFxuXHRcdFx0ZmFsbGJhY2tTZWdtZW50SWQ6IGlkLFxuXHRcdFx0ZmFsbGJhY2tTdGF0ZUtleU1hcDogc3RhdGVLZXlNYXAsXG5cdFx0XHRTZWdtZW50Q29udGV4dFxuXHRcdH0pXG5cdH0sIGVudHJ5LnN0YXRlS2V5KSkgfSk7XG59XG4vKipcbiogQWRkcyBhIG5lc3RlZCBzZWdtZW50LW93bmVkIEFjdGl2aXR5IGNhY2hlIGluc2lkZSBhIGZsYXR0ZW5lZCBBcHBFbGVtZW50c1xuKiBlbnRyeS4gTmFtZWQgcGFyYWxsZWwgcm91dGVzIGFyZSB0cmFuc3BvcnRlZCBhcyBvbmUgc2xvdCB2YWx1ZSwgYnV0IE5leHQuanNcbiogcmV0YWlucyBlYWNoIGRlc2NlbmRhbnQgc2VnbWVudCBpbmRlcGVuZGVudGx5LiBUaGlzIGJvdW5kYXJ5IHJlY3JlYXRlcyB0aGF0XG4qIG93bmVyc2hpcCB3aXRob3V0IHJlcXVpcmluZyBhIHNlcGFyYXRlIHdpcmUgZW50cnkgZm9yIGV2ZXJ5IG5lc3RlZCBzZWdtZW50LlxuKi9cbmZ1bmN0aW9uIEJmY2FjaGVTZWdtZW50Qm91bmRhcnkoeyBjaGlsZHJlbiwgaWQsIHN0YXRlS2V5IH0pIHtcblx0Y29uc3QgZWxlbWVudHMgPSBSZWFjdCQxLnVzZUNvbnRleHQoRWxlbWVudHNDb250ZXh0KTtcblx0Y29uc3QgaWRlbnRpdHlNYXAgPSBSZWFjdCQxLnVzZUNvbnRleHQoQmZjYWNoZUlkZW50aXR5TWFwQ29udGV4dCk7XG5cdGNvbnN0IGFjdGl2ZVN0YXRlS2V5ID0gcmVzb2x2ZUJmY2FjaGVTZWdtZW50U3RhdGVLZXkoaWQsIGlkZW50aXR5TWFwLCBSZWFjdCQxLnVzZUNvbnRleHQoQmZjYWNoZUlkTWFwQ29udGV4dCkpO1xuXHRpZiAoIUJmY2FjaGVTZWdtZW50SWRDb250ZXh0IHx8IGFjdGl2ZVN0YXRlS2V5ID09PSB2b2lkIDApIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFJlYWN0JDEuRnJhZ21lbnQsIHsgY2hpbGRyZW4gfSwgc3RhdGVLZXkpO1xuXHRpZiAoIWlzQ2FjaGVDb21wb25lbnRzRW5hYmxlZCgpKSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChCZmNhY2hlU2VnbWVudElkQ29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlOiBpZCxcblx0XHRjaGlsZHJlblxuXHR9LCBhY3RpdmVTdGF0ZUtleSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KEJmY2FjaGVBY3Rpdml0eVNsb3RCb3VuZGFyeSwge1xuXHRcdGFjdGl2ZVN0YXRlS2V5LFxuXHRcdGNvbnRlbnQ6IGNoaWxkcmVuLFxuXHRcdGVsZW1lbnRzLFxuXHRcdGlkLFxuXHRcdFNlZ21lbnRDb250ZXh0OiBCZmNhY2hlU2VnbWVudElkQ29udGV4dCxcblx0XHRzdGF0ZUtleU1hcDogaWRlbnRpdHlNYXBcblx0fSk7XG59XG4vKipcbiogUmV0YWlucyBhIGxheW91dCdzIGNoaWxkcmVuIGFjcm9zcyBuYXZpZ2F0aW9ucyB0aGF0IGNoYW5nZSB3aGljaCBzZWdtZW50XG4qIHRoZXkgcmVuZGVyLiBFYWNoIGNoaWxkIGtlZXBzIGl0cyBvd24gd3JhcHBlcnMsIHNvIGEgcGFnZSBhbmQgYSBuZXN0ZWQgbGF5b3V0XG4qIGdpdmUgdGhlIGxheW91dCdzIGNoaWxkcmVuIGRpZmZlcmVudCBlbGVtZW50IHNoYXBlcywgYW5kIGEgcmV0ZW50aW9uIGxpc3RcbiogaW5zaWRlIHRoZSBjaGlsZCB3b3VsZCByZW1vdW50IHdpdGggdGhlbS4gTmV4dC5qcyBrZWVwcyB0aGlzIEFjdGl2aXR5IGxpc3QgaW5cbiogdGhlIHBhcmVudCdzIGxheW91dCByb3V0ZXIsIGFib3ZlIHRoZSBjaGlsZCdzIGJvdW5kYXJpZXMsIHNvIGEgcGFnZSBsZWZ0IGZvciBhXG4qIHNpYmxpbmcgd2l0aCBpdHMgb3duIGxheW91dCBrZWVwcyBpdHMgc3RhdGUgd2hlbiBuYXZpZ2F0aW5nIGJhY2suXG4qL1xuZnVuY3Rpb24gQmZjYWNoZUNoaWxkcmVuQm91bmRhcnkoeyBjaGlsZHJlbiwgaWQsIHN0YXRlS2V5IH0pIHtcblx0aWYgKCFCZmNhY2hlSWRNYXBDb250ZXh0IHx8ICFCZmNhY2hlU2VnbWVudElkQ29udGV4dCB8fCAhaXNDYWNoZUNvbXBvbmVudHNFbmFibGVkKCkpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KEZyYWdtZW50JDEsIHsgY2hpbGRyZW4gfSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KEJmY2FjaGVDaGlsZHJlbkFjdGl2aXR5Qm91bmRhcnksIHtcblx0XHRpZCxcblx0XHRJZE1hcENvbnRleHQ6IEJmY2FjaGVJZE1hcENvbnRleHQsXG5cdFx0U2VnbWVudENvbnRleHQ6IEJmY2FjaGVTZWdtZW50SWRDb250ZXh0LFxuXHRcdHN0YXRlS2V5LFxuXHRcdGNoaWxkcmVuXG5cdH0pO1xufVxuZnVuY3Rpb24gQmZjYWNoZUNoaWxkcmVuQWN0aXZpdHlCb3VuZGFyeSh7IGNoaWxkcmVuLCBpZCwgSWRNYXBDb250ZXh0LCBTZWdtZW50Q29udGV4dCwgc3RhdGVLZXkgfSkge1xuXHRjb25zdCBlbGVtZW50cyA9IFJlYWN0JDEudXNlQ29udGV4dChFbGVtZW50c0NvbnRleHQpO1xuXHRjb25zdCBpZGVudGl0eU1hcCA9IFJlYWN0JDEudXNlQ29udGV4dChCZmNhY2hlSWRlbnRpdHlNYXBDb250ZXh0KTtcblx0Y29uc3QgYmZjYWNoZUlkTWFwID0gUmVhY3QkMS51c2VDb250ZXh0KElkTWFwQ29udGV4dCk7XG5cdGNvbnN0IHNlZ21lbnRJZCA9IFJlYWN0JDEudXNlQ29udGV4dChTZWdtZW50Q29udGV4dCk7XG5cdGNvbnN0IGFjdGl2ZVN0YXRlS2V5ID0gc3RhdGVLZXkgPz8gKGlkID09PSB2b2lkIDAgPyB2b2lkIDAgOiByZXNvbHZlQmZjYWNoZVNlZ21lbnRTdGF0ZUtleShpZCwgaWRlbnRpdHlNYXAsIGJmY2FjaGVJZE1hcCkpO1xuXHRpZiAoc2VnbWVudElkID09PSBudWxsIHx8IGFjdGl2ZVN0YXRlS2V5ID09PSB2b2lkIDApIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KEZyYWdtZW50JDEsIHsgY2hpbGRyZW4gfSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KEJmY2FjaGVBY3Rpdml0eVNsb3RCb3VuZGFyeSwge1xuXHRcdGFjdGl2ZVN0YXRlS2V5LFxuXHRcdGNvbnRlbnQ6IGNoaWxkcmVuLFxuXHRcdGVsZW1lbnRzLFxuXHRcdGlkOiBzZWdtZW50SWQsXG5cdFx0U2VnbWVudENvbnRleHQsXG5cdFx0c3RhdGVLZXlNYXA6IGlkZW50aXR5TWFwXG5cdH0pO1xufVxuZnVuY3Rpb24gZ2V0Tm9uQ2FjaGVDb21wb25lbnRzU2VnbWVudEtleShpZCwgYWN0aXZlU3RhdGVLZXkpIHtcblx0Y29uc3QgcGFyc2VkID0gQXBwRWxlbWVudHNXaXJlLnBhcnNlRWxlbWVudEtleShpZCk7XG5cdHJldHVybiBwYXJzZWQgIT09IG51bGwgJiYgcGFyc2VkLmtpbmQgIT09IFwicm91dGVcIiA/IGFjdGl2ZVN0YXRlS2V5IDogdm9pZCAwO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUJmY2FjaGVTZWdtZW50U3RhdGVLZXkoaWQsIGlkZW50aXR5TWFwLCBiZmNhY2hlSWRNYXApIHtcblx0cmV0dXJuIGlkZW50aXR5TWFwW2lkXSA/PyBiZmNhY2hlSWRNYXA/LltpZF07XG59XG5mdW5jdGlvbiBCZmNhY2hlU2xvdEJvdW5kYXJ5KHsgY29udGVudCwgaWQgfSkge1xuXHRjb25zdCBTZWdtZW50Q29udGV4dCA9IEJmY2FjaGVTZWdtZW50SWRDb250ZXh0O1xuXHRjb25zdCBlbGVtZW50cyA9IFJlYWN0JDEudXNlQ29udGV4dChFbGVtZW50c0NvbnRleHQpO1xuXHRjb25zdCBpZGVudGl0eU1hcCA9IFJlYWN0JDEudXNlQ29udGV4dChCZmNhY2hlSWRlbnRpdHlNYXBDb250ZXh0KTtcblx0Y29uc3QgYWN0aXZlU3RhdGVLZXkgPSByZXNvbHZlQmZjYWNoZVNlZ21lbnRTdGF0ZUtleShpZCwgaWRlbnRpdHlNYXAsIFJlYWN0JDEudXNlQ29udGV4dChCZmNhY2hlSWRNYXBDb250ZXh0KSk7XG5cdGlmICghU2VnbWVudENvbnRleHQpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KEZyYWdtZW50JDEsIHsgY2hpbGRyZW46IGNvbnRlbnQgfSk7XG5cdGlmIChhY3RpdmVTdGF0ZUtleSA9PT0gdm9pZCAwKSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChTZWdtZW50Q29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlOiBpZCxcblx0XHRjaGlsZHJlbjogY29udGVudFxuXHR9KTtcblx0aWYgKCFpc0NhY2hlQ29tcG9uZW50c0VuYWJsZWQoKSkgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goU2VnbWVudENvbnRleHQuUHJvdmlkZXIsIHtcblx0XHR2YWx1ZTogaWQsXG5cdFx0Y2hpbGRyZW46IGNvbnRlbnRcblx0fSwgZ2V0Tm9uQ2FjaGVDb21wb25lbnRzU2VnbWVudEtleShpZCwgYWN0aXZlU3RhdGVLZXkpKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goQmZjYWNoZUFjdGl2aXR5U2xvdEJvdW5kYXJ5LCB7XG5cdFx0YWN0aXZlU3RhdGVLZXksXG5cdFx0Y29udGVudCxcblx0XHRlbGVtZW50cyxcblx0XHRpZCxcblx0XHRTZWdtZW50Q29udGV4dCxcblx0XHRzdGF0ZUtleU1hcDogaWRlbnRpdHlNYXBcblx0fSk7XG59XG5mdW5jdGlvbiBtZXJnZUVsZW1lbnRzKHByZXYsIG5leHQsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCBjbGVhckFic2VudFNsb3RzID0gdHlwZW9mIG9wdGlvbnMgPT09IFwiYm9vbGVhblwiID8gb3B0aW9ucyA6IG9wdGlvbnMuY2xlYXJBYnNlbnRTbG90cyA/PyBmYWxzZTtcblx0Y29uc3QgcHJlc2VydmVBYnNlbnRTbG90cyA9IHR5cGVvZiBvcHRpb25zID09PSBcImJvb2xlYW5cIiA/ICFvcHRpb25zIDogb3B0aW9ucy5wcmVzZXJ2ZUFic2VudFNsb3RzID8/IHRydWU7XG5cdGNvbnN0IHByZXNlcnZlRWxlbWVudElkcyA9IHR5cGVvZiBvcHRpb25zID09PSBcImJvb2xlYW5cIiA/IFtdIDogb3B0aW9ucy5wcmVzZXJ2ZUVsZW1lbnRJZHMgPz8gW107XG5cdGNvbnN0IHByZXNlcnZlRWxlbWVudFNlZWRJZHMgPSB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJib29sZWFuXCIgPyBbXSA6IG9wdGlvbnMucHJlc2VydmVFbGVtZW50U2VlZElkcyA/PyBbXTtcblx0Y29uc3QgcHJlc2VydmVQcmV2aW91c1Nsb3RJZHMgPSB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJib29sZWFuXCIgPyBbXSA6IG9wdGlvbnMucHJlc2VydmVQcmV2aW91c1Nsb3RJZHMgPz8gW107XG5cdGNvbnN0IG1lcmdlZCA9IHsgLi4ubmV4dCB9O1xuXHRjb25zdCBwcmVzZXJ2ZWRJZGVudGl0eUlkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGZvciAoY29uc3QgaWQgb2YgcHJlc2VydmVFbGVtZW50SWRzKSBpZiAoT2JqZWN0Lmhhc093bihwcmV2LCBpZCkpIHtcblx0XHRjb25zdCB2YWx1ZSA9IHByZXZbaWRdO1xuXHRcdGlmICh2YWx1ZSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRtZXJnZWRbaWRdID0gdmFsdWU7XG5cdFx0XHRwcmVzZXJ2ZWRJZGVudGl0eUlkcy5hZGQoaWQpO1xuXHRcdH1cblx0fVxuXHRmb3IgKGNvbnN0IGlkIG9mIHByZXNlcnZlRWxlbWVudFNlZWRJZHMpIHtcblx0XHRpZiAocHJlc2VydmVkSWRlbnRpdHlJZHMuaGFzKGlkKSB8fCAhT2JqZWN0Lmhhc093bihwcmV2LCBpZCkpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IHZhbHVlID0gcHJldltpZF07XG5cdFx0aWYgKHZhbHVlICE9PSB2b2lkIDApIG1lcmdlZFtpZF0gPSB2YWx1ZTtcblx0fVxuXHRjb25zdCBzbG90S2V5cyA9IG5ldyBTZXQoWy4uLk9iamVjdC5rZXlzKHByZXYpLCAuLi5PYmplY3Qua2V5cyhuZXh0KV0uZmlsdGVyKChrZXkpID0+IEFwcEVsZW1lbnRzV2lyZS5pc1Nsb3RJZChrZXkpICYmICFpc05lc3RlZEJmY2FjaGVTbG90U2VnbWVudElkKGtleSkpKTtcblx0aWYgKGNsZWFyQWJzZW50U2xvdHMpIHtcblx0XHRmb3IgKGNvbnN0IGtleSBvZiBzbG90S2V5cykgaWYgKCFPYmplY3QuaGFzT3duKG5leHQsIGtleSkpIGRlbGV0ZSBtZXJnZWRba2V5XTtcblx0fSBlbHNlIGlmIChwcmVzZXJ2ZUFic2VudFNsb3RzKSB7XG5cdFx0Zm9yIChjb25zdCBrZXkgb2Ygc2xvdEtleXMpIGlmICghT2JqZWN0Lmhhc093bihtZXJnZWQsIGtleSkgJiYgT2JqZWN0Lmhhc093bihwcmV2LCBrZXkpKSB7XG5cdFx0XHRjb25zdCB2YWx1ZSA9IHByZXZba2V5XTtcblx0XHRcdGlmICh2YWx1ZSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdG1lcmdlZFtrZXldID0gdmFsdWU7XG5cdFx0XHRcdHByZXNlcnZlZElkZW50aXR5SWRzLmFkZChrZXkpO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRmb3IgKGNvbnN0IGlkIG9mIHByZXNlcnZlUHJldmlvdXNTbG90SWRzKSB7XG5cdFx0aWYgKCFBcHBFbGVtZW50c1dpcmUuaXNTbG90SWQoaWQpKSBjb250aW51ZTtcblx0XHRpZiAoIU9iamVjdC5oYXNPd24ocHJldiwgaWQpKSBjb250aW51ZTtcblx0XHRjb25zdCB2YWx1ZSA9IHByZXZbaWRdO1xuXHRcdGlmICh2YWx1ZSAhPT0gdm9pZCAwICYmIHZhbHVlICE9PSBVTk1BVENIRURfU0xPVCkge1xuXHRcdFx0bWVyZ2VkW2lkXSA9IHZhbHVlO1xuXHRcdFx0cHJlc2VydmVkSWRlbnRpdHlJZHMuYWRkKGlkKTtcblx0XHRcdGZvciAoY29uc3QgbmVzdGVkSWQgb2YgT2JqZWN0LmtleXMocHJldikpIHtcblx0XHRcdFx0aWYgKCFpc05lc3RlZEJmY2FjaGVTbG90U2VnbWVudElkRm9yKG5lc3RlZElkLCBpZCkpIGNvbnRpbnVlO1xuXHRcdFx0XHRjb25zdCBuZXN0ZWRWYWx1ZSA9IHByZXZbbmVzdGVkSWRdO1xuXHRcdFx0XHRpZiAobmVzdGVkVmFsdWUgIT09IHZvaWQgMCkgbWVyZ2VkW25lc3RlZElkXSA9IG5lc3RlZFZhbHVlO1xuXHRcdFx0XHRwcmVzZXJ2ZWRJZGVudGl0eUlkcy5hZGQobmVzdGVkSWQpO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRpZiAocHJlc2VydmVkSWRlbnRpdHlJZHMuc2l6ZSA+IDApIHtcblx0XHRjb25zdCBwcmV2aW91c0lkZW50aXR5VmFsdWUgPSBwcmV2W0FQUF9CRkNBQ0hFX1NFR01FTlRfSURFTlRJVElFU19LRVldO1xuXHRcdGNvbnN0IG5leHRJZGVudGl0eVZhbHVlID0gbmV4dFtBUFBfQkZDQUNIRV9TRUdNRU5UX0lERU5USVRJRVNfS0VZXTtcblx0XHRjb25zdCBoYXNQcmV2aW91c0lkZW50aXRpZXMgPSBpc0JmY2FjaGVTZWdtZW50SWRlbnRpdGllc01ldGFkYXRhVmFsdWUoQVBQX0JGQ0FDSEVfU0VHTUVOVF9JREVOVElUSUVTX0tFWSwgcHJldmlvdXNJZGVudGl0eVZhbHVlKTtcblx0XHRjb25zdCBoYXNOZXh0SWRlbnRpdGllcyA9IGlzQmZjYWNoZVNlZ21lbnRJZGVudGl0aWVzTWV0YWRhdGFWYWx1ZShBUFBfQkZDQUNIRV9TRUdNRU5UX0lERU5USVRJRVNfS0VZLCBuZXh0SWRlbnRpdHlWYWx1ZSk7XG5cdFx0Y29uc3QgcHJldmlvdXNJZGVudGl0aWVzID0gaGFzUHJldmlvdXNJZGVudGl0aWVzID8geyAuLi5wcmV2aW91c0lkZW50aXR5VmFsdWUgfSA6IHt9O1xuXHRcdGNvbnN0IG1lcmdlZElkZW50aXRpZXMgPSBoYXNOZXh0SWRlbnRpdGllcyA/IHsgLi4ubmV4dElkZW50aXR5VmFsdWUgfSA6IHt9O1xuXHRcdGNvbnN0IGlkZW50aXR5SWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoWy4uLk9iamVjdC5rZXlzKHByZXZpb3VzSWRlbnRpdGllcyksIC4uLk9iamVjdC5rZXlzKG1lcmdlZElkZW50aXRpZXMpXSk7XG5cdFx0Y29uc3QgcHJlc2VydmVkUGFyZW50SWRzID0gbmV3IFNldChwcmVzZXJ2ZWRJZGVudGl0eUlkcyk7XG5cdFx0Zm9yIChjb25zdCBwYXJlbnRJZCBvZiBwcmVzZXJ2ZWRQYXJlbnRJZHMpIGZvciAoY29uc3QgaWRlbnRpdHlJZCBvZiBpZGVudGl0eUlkcykgaWYgKGlzTmVzdGVkQmZjYWNoZVNsb3RTZWdtZW50SWRGb3IoaWRlbnRpdHlJZCwgcGFyZW50SWQpKSBwcmVzZXJ2ZWRJZGVudGl0eUlkcy5hZGQoaWRlbnRpdHlJZCk7XG5cdFx0Zm9yIChjb25zdCBpZCBvZiBwcmVzZXJ2ZWRJZGVudGl0eUlkcykge1xuXHRcdFx0Y29uc3QgcHJldmlvdXNJZGVudGl0eSA9IHByZXZpb3VzSWRlbnRpdGllc1tpZF07XG5cdFx0XHRpZiAocHJldmlvdXNJZGVudGl0eSA9PT0gdm9pZCAwKSBkZWxldGUgbWVyZ2VkSWRlbnRpdGllc1tpZF07XG5cdFx0XHRlbHNlIG1lcmdlZElkZW50aXRpZXNbaWRdID0gcHJldmlvdXNJZGVudGl0eTtcblx0XHR9XG5cdFx0aWYgKGhhc1ByZXZpb3VzSWRlbnRpdGllcyB8fCBoYXNOZXh0SWRlbnRpdGllcykgbWVyZ2VkW0FQUF9CRkNBQ0hFX1NFR01FTlRfSURFTlRJVElFU19LRVldID0gbWVyZ2VkSWRlbnRpdGllcztcblx0fVxuXHRyZXR1cm4gbWVyZ2VkO1xufVxuZnVuY3Rpb24gU2xvdCh7IGlkLCBjaGlsZHJlbiwgcGFyYWxsZWxTbG90cyB9KSB7XG5cdGNvbnN0IGVsZW1lbnRzID0gUmVhY3QkMS51c2VDb250ZXh0KEVsZW1lbnRzQ29udGV4dCk7XG5cdGlmICghT2JqZWN0Lmhhc093bihlbGVtZW50cywgaWQpKSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhQXBwRWxlbWVudHNXaXJlLmlzU2xvdElkKGlkKSkge1xuXHRcdFx0aWYgKCF3YXJuZWRNaXNzaW5nRW50cnlJZHMuaGFzKGlkKSkge1xuXHRcdFx0XHR3YXJuZWRNaXNzaW5nRW50cnlJZHMuYWRkKGlkKTtcblx0XHRcdFx0Y29uc29sZS53YXJuKFwiW3ZpbmV4dF0gTWlzc2luZyBBcHAgUm91dGVyIGVsZW1lbnQgZW50cnkgZHVyaW5nIHJlbmRlcjogXCIgKyBpZCk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdGNvbnN0IGVsZW1lbnQgPSBlbGVtZW50c1tpZF07XG5cdGlmIChpc1RyYW5zcG9ydE1ldGFkYXRhVmFsdWUoaWQsIGVsZW1lbnQpKSB7XG5cdFx0d2FyblRyYW5zcG9ydE1ldGFkYXRhRW50cnkoaWQpO1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdGlmIChlbGVtZW50ID09PSBVTk1BVENIRURfU0xPVCkgbm90Rm91bmQoKTtcblx0aWYgKGVsZW1lbnQgPT09IG51bGwpIHJldHVybiBudWxsO1xuXHRjb25zdCBjb250ZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChSZW5kZXJlZFNlYXJjaENvbnRleHQuUHJvdmlkZXIsIHtcblx0XHR2YWx1ZTogZ2V0RWxlbWVudFJlbmRlcmVkU2VhcmNoKGVsZW1lbnQpLFxuXHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFBhcmFsbGVsU2xvdHNDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0XHR2YWx1ZTogcGFyYWxsZWxTbG90cyA/PyBudWxsLFxuXHRcdFx0Y2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goQ2hpbGRyZW5Db250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0XHRcdHZhbHVlOiBjaGlsZHJlbiA/PyBudWxsLFxuXHRcdFx0XHRjaGlsZHJlbjogZWxlbWVudFxuXHRcdFx0fSlcblx0XHR9KVxuXHR9KTtcblx0cmV0dXJuIEJmY2FjaGVJZE1hcENvbnRleHQgJiYgQmZjYWNoZVNlZ21lbnRJZENvbnRleHQgPyAvKiBAX19QVVJFX18gKi8ganN4KEJmY2FjaGVTbG90Qm91bmRhcnksIHtcblx0XHRpZCxcblx0XHRjb250ZW50XG5cdH0pIDogY29udGVudDtcbn1cbmZ1bmN0aW9uIENoaWxkcmVuKCkge1xuXHRyZXR1cm4gUmVhY3QkMS51c2VDb250ZXh0KENoaWxkcmVuQ29udGV4dCk7XG59XG5mdW5jdGlvbiBQYXJhbGxlbFNsb3QoeyBuYW1lIH0pIHtcblx0cmV0dXJuIFJlYWN0JDEudXNlQ29udGV4dChQYXJhbGxlbFNsb3RzQ29udGV4dCk/LltuYW1lXSA/PyBudWxsO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBCZmNhY2hlQ2hpbGRyZW5Cb3VuZGFyeSwgQmZjYWNoZUlkZW50aXR5TWFwQ29udGV4dCwgQmZjYWNoZVNlZ21lbnRCb3VuZGFyeSwgQ2hpbGRyZW4sIENoaWxkcmVuQ29udGV4dCwgRWxlbWVudHNDb250ZXh0LCBQYXJhbGxlbFNsb3QsIFBhcmFsbGVsU2xvdHNDb250ZXh0LCBSZW5kZXJlZFNlYXJjaENvbnRleHQsIFNsb3QsIFVOTUFUQ0hFRF9TTE9ULCBiaW5kQXBwRWxlbWVudHNSZW5kZXJlZFNlYXJjaCwgZ2V0Tm9uQ2FjaGVDb21wb25lbnRzU2VnbWVudEtleSwgbWVyZ2VFbGVtZW50cywgcmVzb2x2ZUJmY2FjaGVTZWdtZW50U3RhdGVLZXksIHNldEFwcEVsZW1lbnRzUmVuZGVyZWRTZWFyY2gsIHN0YWdlQmZjYWNoZVNsb3RFbnRyeUZvclJlbmRlciwgdXBkYXRlQmZjYWNoZVNsb3RFbnRyeU9yZGVyIH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==